
CREATE PROCEDURE [dbo].[AVERAGE_DECLARE_VALUE_MAX]
                                                
                                                 @TradeNID INT
                     
AS
BEGIN
	DECLARE @DECLARE_VALUE_MAX NUMERIC(18,4)
	DECLARE @ORIG_DECLARE_SUM NUMERIC(18,4)
	DECLARE @ORIG_QTY_SUM     NUMERIC(18,4)
	DECLARE @DECLARE_AVG      NUMERIC(18,4)
	SET @ORIG_DECLARE_SUM = 0
	SET @ORIG_QTY_SUM = 0
	SET @DECLARE_AVG = 0
	DECLARE @IncDeclareValue VARCHAR(2) ='0'
	SELECT TOP 1 @IncDeclareValue = isnull(ParaValue,'0')
	FROM B_SysParams 
	WHERE ParaCode = 'IncDeclareValue'
	IF @IncDeclareValue  = '1'
	BEGIN
	   UPDATE 
		     D
	  SET      
			 d.DeclaredValue=case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else isnull(g.DeclaredValue,0)*d.L_QTY end
	  FROM 
			P_TradeDt D	 
		left outer join B_GoodsSKU gs on gs.SKU=d.SKU
		left outer join B_Goods g on g.NID=gs.GoodsID	
		LEFT outer JOIN B_StoreLocation bsl ON gs.LocationID = bsl.NID		
	  WHERE 	
			TradeNID=@TradeNID	
	END 

	SET @DECLARE_VALUE_MAX =ISNULL((SELECT bsp.ParaValue 
	                                FROM B_SysParams bsp 
	                                WHERE ParaCode = 'DECLARE_VALUE_MAX'),0)
	IF (@DECLARE_VALUE_MAX > 0)
	BEGIN
	  SELECT @ORIG_DECLARE_SUM = SUM(ISNULL(DeclaredValue,0)), 
	         @ORIG_QTY_SUM     = SUM(ISNULL(L_QTY,0))  
	  FROM P_TradeDt 
	  WHERE TradeNID = @TradeNID
	  
	  IF (@ORIG_QTY_SUM = 0)
	  BEGIN
	  	SET @ORIG_QTY_SUM = 1
	  END
	  
	  IF (@ORIG_DECLARE_SUM > @DECLARE_VALUE_MAX)
	  BEGIN
	  	SET @DECLARE_AVG = @DECLARE_VALUE_MAX / @ORIG_QTY_SUM 
	  	UPDATE P_TradeDt
	  	SET DeclaredValue = ROUND(L_QTY * @DECLARE_AVG,2)
	  	WHERE TradeNID = @TradeNID	  		
	  END
	END
END

