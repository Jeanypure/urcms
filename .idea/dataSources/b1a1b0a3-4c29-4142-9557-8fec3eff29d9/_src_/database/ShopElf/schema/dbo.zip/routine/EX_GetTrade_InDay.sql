  
create FUNCTION [dbo].[EX_GetTrade_InDay] --获取最近采购到货天数
  (
    @GoodsSkuID int = 0   
   )
RETURNS
  Int
AS
BEGIN
  Declare @InDay Int
  set @InDay =  
     (select top 1 convert(int,B.DelivDate - GETDATE()) from CG_StockOrderD(noLock) A 
       inner join CG_StockOrderM(noLock) B on A.StockOrderNID = B.NID  
        where (A.Amount-A.InAmount) > 0 
            and  B.DelivDate > GETDATE() 
           and A.GoodsSkuID = @GoodsSkuID 
      )
     
 Return @InDay

END
