 
Create FUNCTION [dbo].[EX_GetTrade_OneAmount] --获取最近采购到货数量
  (
    @GoodsSkuID int = 0   
   )
RETURNS
  Int
AS
BEGIN
  Declare @OneAmount Int
  set @OneAmount =  
     (select top 1 Amount  from CG_StockInD(noLock) A  
         inner join CG_StockInM(noLock) B on A.StockInNid = B.NID  
         where  A.GoodsSkuID = @GoodsSkuID 
           order By B.BillNumber desc 
     ) 
     
 Return @OneAmount

END   

