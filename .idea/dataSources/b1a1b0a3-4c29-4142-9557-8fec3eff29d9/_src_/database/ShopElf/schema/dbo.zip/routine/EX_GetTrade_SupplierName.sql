 
create FUNCTION [dbo].[EX_GetTrade_SupplierName] --获取最近采购到货天数
  (
    @GoodsSkuID int = 0   
   )
RETURNS
  varchar(1000)
AS
BEGIN
  Declare @SupplierName varchar(500)
  set @SupplierName =  
    (select top 1 SupplierName 
        from B_Supplier(noLock) A  
              inner join B_Goods(noLock) B on A.NID = B.SupplierID  
              inner join B_GoodsSku(noLock) gs on gs.GoodsID = B.NID  
              where gs.NID = @GoodsSkuID )  
  Return @SupplierName

END
