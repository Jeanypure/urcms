CREATE function [Ex_Fr_CalcShippingCost]
	(
	@ExpressID	int,
	@LogisticWayID	int,
	@CountryCode	varchar(10),
	@fallWeight		Float,  --重量为G,
	@SHIPTOZIP varchar(50)=''      --邮编
	)
RETURNS
	Float		
as
begin
	--查找国家所在大区
	declare
		@BeginWeight int,
		@BeginMoneyGoods money,
		@BeginMoneyFile money,		
		@AddWeight	int,
		@AddMoney	money,
		@RegionRate int,	
		@tmpWeight  int,
		@AllShippingCost	money,
		@FareID int,
		@Discount int,--折扣
		@SurchargeRate float,--燃油附加费率
		@allWeight float,
		@RateWeightBetween int,
		@ReturnMsg varchar(200),
	    @IsEub INT = 0,  --是否是E邮宝
	    @ServiceCode varchar(32), --物流方式服务代码
	    @TmpCount int,
	    @IsPassNoEmFar int 
	set
		@ReturnMsg = ''					
	set
		@FareID=0
	set
		@allWeight=@fallWeight
	if @ExpressID <>0 
	begin
		set
			@allWeight=@fallWeight*1000	
	end	
	declare @CountLogist int
    --add by ylq 2015-04-20  如果找不到物流方式，则返回0
    select @CountLogist = COUNT(1)  from B_LogisticWay  where nid=@LogisticWayID	
	if @CountLogist = 0 
	begin
	  return 0
	end
 	  
	--查找快递公司对应的物流折扣
	set
		@Discount=0
	set
		@SurchargeRate=0
	select top 1
		@Discount = ISNULL(discount,0)
	from 
		B_ExpressLogisticWay 
	where
		expressID=@ExpressID and
		logisticWayID=@LogisticWayID
			
	--cf 20130314 如果物流公司中没有设置，取运费设置中的
	if @Discount =0 
	begin
		select top 1
			@Discount = ISNULL(discount,0),
			@SurchargeRate=ISNULL(SurchargeRate,0)
		from 
			B_LogisticWay 
		where
			nid=@LogisticWayID	
	end	
	else
	begin
		select top 1
			@SurchargeRate=ISNULL(SurchargeRate,0)
		from 
			B_LogisticWay 
		where
			nid=@LogisticWayID		
	end
	--最后，如果折扣为0，那么变成100
	if @Discount=0 
      set @Discount=100	  
		
	--查找运费模板
	
	
	--没有设置国家，默认针对所有国家
	-- modify by ylq 20150908  条件再改下
	set @TmpCount = 0
	select @TmpCount = COUNT(*) from  B_EmsFare where
			LogisticWayID=@LogisticWayID and 
			NID in  (select Fareid from B_EmsFareCountry ec 
						left outer join B_Country c on c.NID = ec.CountryID
						left outer join B_EmsFarePostCode ep on ep.EmsFareCountryID=ec.NID 
						where c.CountryCode=@CountryCode and ((ep.postcodeS is null)or(
						          @SHIPTOZIP between ep.postcodeS and ep.postcodeE) ));
	if @TmpCount = 0 begin
	  select @TmpCount = COUNT(*) from B_EmsFare
		where LogisticWayID=@LogisticWayID and  BeginWeight <= @allWeight
		and NID not in (select distinct Fareid from B_EmsFareCountry)
		 
	  if @TmpCount > 0 begin
	    select top 1  @FareID=Isnull(NID,0)
		from  B_EmsFare
		where LogisticWayID=@LogisticWayID and  BeginWeight <= @allWeight 
		and NID not in (select distinct Fareid from B_EmsFareCountry)
		order by BeginWeight desc
	  end
	  else begin
		return 0	
	  end	
	end
	else begin
	  select top 1 
			@FareID=Isnull(NID,0)
		from 
			B_EmsFare
		where
			LogisticWayID=@LogisticWayID and BeginWeight <= @allWeight and 
			NID in  (select Fareid from B_EmsFareCountry ec 
						left outer join B_Country c on c.NID = ec.CountryID
						left outer join B_EmsFarePostCode ep on ep.EmsFareCountryID=ec.NID 
						where c.CountryCode=@CountryCode and ((ep.postcodeS is null)or(
						          @SHIPTOZIP between ep.postcodeS and ep.postcodeE) ))
		order by BeginWeight desc
	end

	SET @IsEub = (SELECT ISNULL(EUB,0) FROM B_LogisticWay WHERE NID = @LogisticWayID)
	set @ServiceCode = (select ISNULL(ServiceCode,'0') from B_LogisticWay WHERE NID = @LogisticWayID)
	
	if (@FareID=0) --判断阶段重量中没有设置最小1G的
	begin
	  set @TmpCount = 0
	  select @TmpCount = COUNT(*) from B_EmsFare 
	  where LogisticWayID=@LogisticWayID and 
			NID in  (select Fareid from B_EmsFareCountry ec 
							left outer join B_Country c on c.NID = ec.CountryID
							left outer join B_EmsFarePostCode ep on ep.EmsFareCountryID=ec.NID 
						where c.CountryCode=@CountryCode and ((ep.postcodeS is null)or(
						          @SHIPTOZIP between ep.postcodeS and ep.postcodeE) ))
	  if @TmpCount = 0 begin
	    select @TmpCount = COUNT(*) from B_EmsFare
			where LogisticWayID=@LogisticWayID and  BeginWeight > @allWeight
		 if @TmpCount > 0 begin
		    select top 1  @FareID=Isnull(NID,0)
			from  B_EmsFare
			where LogisticWayID=@LogisticWayID and  BeginWeight > @allWeight 
			order by BeginWeight 
		 end
		 else begin		
		   return	0
		 end
	  end
	  else begin
	    select top 1  @FareID=Isnull(NID,0)
			from  B_EmsFare
			where
				LogisticWayID=@LogisticWayID and BeginWeight > @allWeight and 
				NID in  (select Fareid from B_EmsFareCountry ec 
							left outer join B_Country c on c.NID = ec.CountryID
							left outer join B_EmsFarePostCode ep on ep.EmsFareCountryID=ec.NID 
						where c.CountryCode=@CountryCode and ((ep.postcodeS is null)or(
						          @SHIPTOZIP between ep.postcodeS and ep.postcodeE) ))
			order by BeginWeight
	  end
   end
 			
	if (@FareID=0)-- AND (NOT  ISNULL(@IsEub,0) IN (1,2)) --并且不是E邮宝(阶梯重量计算)
	begin
		return	0
	end			
	--查找计算规则
	select 	
		@BeginWeight	=BeginWeight,
		@BeginMoneyGoods=BeginMoneyGoods ,
		@BeginMoneyFile=ISNULL(BeginMoneyFile,0) ,		
		@AddWeight		=AddWeight,
		@AddMoney		=AddMoney,
		@RegionRate    = RegionRate
	from 
		B_EmsFare
	where
		NID=@FareID	
	--计算,参考官方 http://shipping.ebay.cn/express/e-packet/2684.html
	declare @AutoCalcEUB int =0
	set @AutoCalcEUB=(select top 1 paravalue from B_SysParams where ParaCode = 'AutoCalcEUB')  	
	if ISNULL(@IsEub,0) IN (1,2) and isnull(@AutoCalcEUB,0)=0 
	BEGIN
	    if (ISNULL(@ServiceCode,'0') = '1') or (ISNULL(@ServiceCode,'0') = '2')
	    begin
	       if (@allWeight > 10000 or @allWeight <=0)begin
			 return 0;
	       end
	    end
	    else begin 
			if (@allWeight > 2000 or @allWeight <=0) 
			begin
				return 0;
			end
		end 
		if @CountryCode='US' or @CountryCode='PR' 
		begin
 			IF @allWeight <= 60	  
 			  SET @AllShippingCost = 11.8
 			ELSE
 			  SET @AllShippingCost = @allWeight * 0.08 + 7	 	    
		end
		else
		if  @CountryCode ='CA'
		begin
 		 --   IF @allWeight <= 60	  
 			--  SET @AllShippingCost = 25
 			--ELSE
 		  SET @AllShippingCost = @allWeight * 0.08 + 25	 	    
		end
		else
		if  @CountryCode ='FR'
		begin
 		  SET @AllShippingCost = @allWeight * 0.07 + 26	 	    
		end
		else	
		if  @CountryCode ='RU'
		begin
 		  SET @AllShippingCost = @allWeight * 0.1 + 10 	    
		end
		else				
		if @CountryCode ='AU'  --澳大利亚
		begin
			if @allWeight <=500 
				set @AllShippingCost = 25 + @allWeight * 0.08;										
			else
				set @AllShippingCost = 30 + @allWeight * 0.08;										
		end
		else if (@CountryCode = 'GB' OR @CountryCode = 'UK') 	--英国,只支持线上EUB
		begin
			set @AllShippingCost = 25 + @allWeight * 0.07;										
		end
		else
		begin
			return 0;
		end;
   		set @BeginMoneyFile=0
	END 
	else
	begin
		if @BeginWeight >= @allWeight	
		begin
			set	@AllShippingCost = @BeginMoneyGoods
		end
		else
		begin
			set		@tmpWeight=@BeginWeight
			set		@AllShippingCost = @BeginMoneyGoods					
			while @tmpWeight<@allWeight 
			begin
				set	@tmpWeight=@tmpWeight+@AddWeight
				set	@AllShippingCost = @AllShippingCost+@AddMoney
				if @AddWeight=0
				begin
				  break
				end

			end	
		END
	end
    if @RegionRate>0  --大区折扣 为0 
      set @Discount = @RegionRate
    return ((@AllShippingCost+@AllShippingCost*@SurchargeRate/100)*@Discount/100)+ISNULL(@BeginMoneyFile,0)
end
