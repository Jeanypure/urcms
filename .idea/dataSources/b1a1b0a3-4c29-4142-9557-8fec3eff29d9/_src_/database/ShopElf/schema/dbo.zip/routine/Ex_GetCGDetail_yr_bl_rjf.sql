
Create FUNCTION [dbo].[Ex_GetCGDetail_yr_bl_rjf]
(
@billnumber varchar(100)=''
)
RETURNS
VarChar(8000)
AS
BEGIN	
Declare @SKU VarChar(8000)
SET @SKU = ''
  select 
    @SKU=@SKU+isnull(m.BillNumber,'')+';'
     from CG_StockInM m
  where m.StockOrder=@billnumber
if LEN(@SKU)>0
  set @SKU=SUBSTRING(@SKU,1,LEN(@SKU)-1)
RETURN @SKU
END
