
create FUNCTION [dbo].[Ex_GetEmailCateCode]
(
	@EmailCateID  int = 0
)

RETURNS varchar(2000)

AS
BEGIN
	DECLARE @EmailCateCode varchar(2000)
	DECLARE @fEmailCateCode varchar(2000)	
    DECLARE @ParentID INT
    Declare @i int=0

	SET @ParentID = 0
    SELECT  @EmailCateCode = CategoryCode,@ParentID = isnull(CategoryParentID,0) 
    FROM B_goodsCats GT 
    WHERE GT.NID=@EmailCateID
    
    set @fEmailCateCode=CAST(@ParentID as varchar(20))+'|'
    
    WHILE  @ParentID > 0 and @i<20
    BEGIN
      SELECT @EmailCateCode =nid ,@ParentID = CategoryParentID 
      FROM B_goodsCats GT 
      WHERE GT.nid = @ParentID
      set @fEmailCateCode =CAST(@ParentID as varchar(20))+'|'+@fEmailCateCode
      set @i=@i+1
    END
 

    RETURN @fEmailCateCode +	CAST(@emailCateID as varchar(20))+'|'
END

