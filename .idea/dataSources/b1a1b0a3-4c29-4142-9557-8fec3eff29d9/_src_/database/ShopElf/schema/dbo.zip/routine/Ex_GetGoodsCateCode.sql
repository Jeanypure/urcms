

CREATE FUNCTION [dbo].[Ex_GetGoodsCateCode]
(
	@GoodsCateID  int = 0
)

RETURNS varchar(2000)

AS
BEGIN
	DECLARE @GoodsCateCode varchar(2000)
	DECLARE @fGoodsCateCode varchar(2000)	
    DECLARE @ParentID INT
    Declare @i int=0

	SET @ParentID = 0
    SELECT  @GoodsCateCode = CategoryCode,@ParentID = isnull(CategoryParentID,0) 
    FROM B_goodsCats GT 
    WHERE GT.NID=@GoodsCateID
    
    set @fGoodsCateCode=CAST(@ParentID as varchar(20))+'|'
    
    WHILE  @ParentID > 0 and @i<20
    BEGIN
      SELECT @GoodsCateCode =nid ,@ParentID = CategoryParentID 
      FROM B_goodsCats GT 
      WHERE GT.nid = @ParentID
      set @fGoodsCateCode =CAST(@ParentID as varchar(20))+'|'+@fGoodsCateCode
      set @i=@i+1
    END
 

    RETURN @fGoodsCateCode +	CAST(@GoodsCateID as varchar(20))+'|'
END
