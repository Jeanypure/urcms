

CREATE FUNCTION [dbo].[Ex_GetGoodsListDescription]
(
	@GoodsID Int = 0,
	@TemplateID Int = 0	
)
RETURNS
	nvarchar(max)
AS
BEGIN	
	Declare @ListDescription nvarchar(Max)
	set 
		@ListDescription=isnull((select HtmlTemplate from B_GoodsTemplate where NID=@TemplateID),'')
	if @ListDescription = null
	  return  '1111'
	Declare
		@keyWord varchar(100)='' ,
		@Description varchar(max)=''
    declare GoodsListDescription  cursor local SCROLL    
    for    
    select Keyword,fDescription=[Description] from B_GoodsList where goodsnid=@goodsid  
    open GoodsListDescription     
    fetch next from GoodsListDescription into @keyWord,@Description    
    while @@fetch_status=0    
    begin        
		if rtrim(ltrim(@keyWord)) <>''
		begin
			set @Description=REPLACE(@Description,CHAR(13),'<BR>')
			--set @Description=REPLACE(@Description,CHAR(10),'<BR>')	
			--set @Description=REPLACE(@Description,CHAR(13)+CHAR(10),'<BR>')					
			set @ListDescription=REPLACE(@ListDescription,@keyWord,@Description)
		end           
		fetch next from  GoodsListDescription into @keyWord,@Description    
    end    
    close GoodsListDescription    
    deallocate GoodsListDescription 

	RETURN @ListDescription
END
