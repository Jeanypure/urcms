CREATE FUNCTION [dbo].[Ex_GetMergeOrderACKs]
(
	@TradeNID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @ACKs VarChar(max)
	SET @ACKs = ''
		SELECT
			@ACKs = @ACKs + isnull(d.[ack],'') +  ',' 
		FROM
			P_Trade_b d
		WHERE
			d.MergeBillID = @TradeNID and isnull(d.[ack],'')<> '' and CHARINDEX(d.[ack],@ACKs)=0

	RETURN substring(@ACKs,1,8000)
END
