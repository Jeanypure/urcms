CREATE FUNCTION [dbo].[Ex_GetMergeOrderItemIDS]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @ItemIDS VarChar(max)
	SET @ItemIDS = ''

		SELECT
			@ItemIDS = @ItemIDS + isnull(d.L_NUMBER,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_Trade_bdt d
		inner join 
			P_Trade_b b on b.NID=d.TradeNID
		WHERE
			b.MergeBillID = @TradeID and  isnull(d.L_NUMBER,'') <> ''

	RETURN substring(@ItemIDS,1,8000)
END
