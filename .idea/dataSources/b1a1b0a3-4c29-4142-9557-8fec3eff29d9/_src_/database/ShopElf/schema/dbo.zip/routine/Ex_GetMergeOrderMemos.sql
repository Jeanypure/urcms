CREATE FUNCTION [dbo].[Ex_GetMergeOrderMemos]
(
	@TradeNID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @Memos VarChar(max)
	SET @Memos = ''
		SELECT
			@Memos = @Memos + isnull(d.memo,'') +  ' ' 
		FROM
			P_Trade_b d
		WHERE
			d.MergeBillID = @TradeNID and isnull(d.[memo],'')<> '' 

	RETURN substring(@Memos,1,8000)
END
