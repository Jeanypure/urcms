CREATE FUNCTION [dbo].[Ex_GetMergeOrderNotes]
(
	@TradeNID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @Notes VarChar(max)
	SET @Notes = ''
		SELECT
			@Notes = @Notes + isnull(d.NOTE,'') +  ' ' 
		FROM
			P_Trade_b d
		WHERE
			d.MergeBillID = @TradeNID and isnull(d.NOTE,'')<> '' 

	RETURN substring(@Notes,1,8000)
END
