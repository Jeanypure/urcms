CREATE FUNCTION [dbo].[Ex_GetMergeOrderSubjects]
(
	@TradeNID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @Subjects VarChar(max)
	SET @Subjects = ''
		SELECT
			@Subjects = @Subjects + isnull(d.[SUBJECT],'') +  ' ' 
		FROM
			P_Trade_b d
		WHERE
			d.MergeBillID = @TradeNID and isnull(d.[Subject],'')<> '' 

	RETURN substring(@Subjects,1,8000)
END
