CREATE FUNCTION [dbo].[Ex_GetMergeOrderUsers]
(
	@TradeNID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @Users VarChar(max)
	SET @Users = ''
		SELECT
			@Users = @Users + isnull(d.[User],'') +  ',' 
		FROM
			P_Trade_b d
		WHERE
			d.MergeBillID = @TradeNID and isnull(d.[User],'')<> '' 
		group by 
			isnull(d.[User],'')
	RETURN substring(@Users,1,8000)
END
