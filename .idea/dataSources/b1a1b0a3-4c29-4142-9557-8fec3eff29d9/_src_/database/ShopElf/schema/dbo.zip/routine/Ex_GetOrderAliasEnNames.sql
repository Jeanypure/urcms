CREATE FUNCTION [dbo].[Ex_GetOrderAliasEnNames]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	SET @SKU = ''
	if exists(select nid from P_Trade(nolock) where NID=@TradeID)
	begin
		SELECT
			@SKU = @SKU + isnull(d.AliasEnName,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_tradeDt(nolock) d
		WHERE
			d.TradeNID = @TradeID
	end
	else
	if exists(select nid from P_Tradeun(nolock) where NID=@TradeID)
	begin
		SELECT
			@SKU = @SKU + isnull(d.AliasEnName,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_TradeDtUn(nolock) d
		WHERE
			d.TradeNID = @TradeID
	end	

	RETURN @SKU
END
