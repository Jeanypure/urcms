CREATE FUNCTION [dbo].[Ex_GetOrderItemIDS]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	SET @SKU = ''
	if exists(select nid from P_Trade(nolock) where NID=@TradeID)
	begin
		SELECT
			@SKU = @SKU + isnull(d.L_NUMBER,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_tradeDt(nolock) d
		WHERE
			d.TradeNID = @TradeID and  isnull(d.L_NUMBER,'') <> ''
	end
	else
	if exists(select nid from P_Trade_His(nolock) where NID=@TradeID)
	begin	
		SELECT
			@SKU = @SKU + isnull(d.L_NUMBER,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_TradeDt_His(nolock) d
		WHERE
			d.TradeNID = @TradeID and  isnull(d.L_NUMBER,'') <> ''
	end	
	RETURN @SKU
END

