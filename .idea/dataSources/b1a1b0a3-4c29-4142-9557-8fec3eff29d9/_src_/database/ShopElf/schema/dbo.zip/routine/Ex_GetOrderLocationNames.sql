
CREATE function [dbo].[Ex_GetOrderLocationNames]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @LocationNames VarChar(8000)
	Declare @L_Qty varchar(800)
	SET @LocationNames = ''
		select  
			@LocationNames = @LocationNames + isnull(sl.LocationName,'')  + ';'
		from
			P_TradeDt(nolock) d
		left outer join 
			B_GoodsSKU(nolock) gs on gs.SKU=d.SKU
		left outer join  
			B_GoodsSKULocation(nolock)  gsl on gsl.GoodsSKUID=gs.NID and gsl.StoreID=d.StoreID
		left outer join 
			B_StoreLocation sl  on sl.NID=gsl.LocationID	
		WHERE
			d.TradeNID = @TradeID				

	RETURN @LocationNames
END

