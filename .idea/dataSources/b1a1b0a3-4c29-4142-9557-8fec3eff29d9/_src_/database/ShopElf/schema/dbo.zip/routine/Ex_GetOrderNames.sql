create FUNCTION [dbo].[Ex_GetOrderNames]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	SET @SKU = ''
	if exists(select nid from P_Trade where NID=@TradeID)
	begin
		SELECT
			@SKU = @SKU + isnull(d.L_NAME,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_tradeDt d
		WHERE
			d.TradeNID = @TradeID
	end

	RETURN @SKU
END
