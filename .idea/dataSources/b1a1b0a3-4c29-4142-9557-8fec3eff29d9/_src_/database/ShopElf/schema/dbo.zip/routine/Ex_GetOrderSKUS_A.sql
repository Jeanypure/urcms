
create FUNCTION [dbo].[Ex_GetOrderSKUS_A]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	Declare @L_Qty varchar(800)
	declare @paraValue varchar(2) 
	SET @SKU = ''
	SET @L_Qty = ''
	
	set @paraValue = ( select top 1 ParaValue from B_SysParams where ParaCode='AllSkuReplaceAllGoods')
	if @paraValue is null
	 set @paraValue ='0'	
	if exists(select nid from P_Trade_A(nolock) where NID=@TradeID)
	begin
	    if @paraValue='1' 
	    begin
			SELECT
				@SKU = @SKU + isnull(d.sku,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
			FROM
				P_trade_ADt(nolock) d
			WHERE
				d.TradeNID = @TradeID
		end
		else
		begin
			SELECT
				@SKU = @SKU + isnull(d.L_NAME,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
			FROM
				P_trade_ADt(nolock) d
			WHERE
				d.TradeNID = @TradeID		
		end
	end
	RETURN @SKU
END

