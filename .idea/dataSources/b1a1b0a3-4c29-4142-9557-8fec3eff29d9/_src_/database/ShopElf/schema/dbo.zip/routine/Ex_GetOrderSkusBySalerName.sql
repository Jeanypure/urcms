
CREATE FUNCTION [dbo].[Ex_GetOrderSkusBySalerName]
(
	@TradeID Int = 0
	,@SalerName VARCHAR(50)
	,@SalerName2 VARCHAR(50)
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	Declare @L_Qty varchar(800)
	SET @SKU = ''
	SET @L_Qty = ''
	if exists(select nid from P_Trade where NID=@TradeID)
	begin
		SELECT
			@SKU = @SKU + isnull(d.sku,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_tradeDt d LEFT JOIN B_GoodsSKU bgs ON d.GoodsSKUID = bgs.NID
			            LEFT JOIN B_Goods bg     ON bg.NID = bgs.GoodsID
		WHERE
			d.TradeNID = @TradeID AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName) 
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
		order by 
			isnull(d.sku,'')
	end
	else
	if exists(select nid from P_Trade_His where NID=@TradeID)
	begin	
		SELECT
			@SKU = @SKU + isnull(d.sku,'') +  '*' + CONVERT(VarCHar,CONVERT(int, d.L_Qty)) + ';'
		FROM
			P_TradeDt_His d LEFT JOIN B_GoodsSKU bgs ON d.GoodsSKUID = bgs.NID
			            LEFT JOIN B_Goods bg     ON bg.NID = bgs.GoodsID
		WHERE
			d.TradeNID = @TradeID AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName) 
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
		order by 
			isnull(d.sku,'')			
	end	
	RETURN @SKU
END


