create FUNCTION [dbo].[Ex_GetOrderWeights]
(
	@TradeID Int = 0
)
RETURNS
	float
AS
BEGIN
	Declare @weights float 
	SET @weights = 0

		SELECT
			@weights = @weights + isnull(d.Weight,0)
		FROM
			P_tradeDt d
		WHERE
			d.TradeNID = @TradeID
	RETURN isnull(@weights,0)
END


