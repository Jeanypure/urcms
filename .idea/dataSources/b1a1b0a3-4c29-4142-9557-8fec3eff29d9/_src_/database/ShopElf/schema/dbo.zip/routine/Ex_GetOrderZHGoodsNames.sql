CREATE FUNCTION [dbo].[Ex_GetOrderZHGoodsNames]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	SET @SKU = ''
		SELECT
			@SKU = @SKU + isnull(a.GoodsName,'') +  '*' + CONVERT(VarCHar,CONVERT(int, a.L_Qty)) + ';'
		 from (	
				select 
					distinct 
					isnull(g.GoodsName,'') as GoodsName,
					d.L_NUMBER,
					case when d.L_TAXAMT=0 then d.L_QTY else d.L_TAXAMT end as l_qty
				FROM
					P_tradeDt d
				left outer join
					B_GoodsSKU gs on gs.SKU=d.eBaySKU
				left outer join 
					B_Goods g on g.NID = gs.GoodsID
				WHERE
					d.TradeNID = @TradeID
			)  a


	RETURN @SKU
END
