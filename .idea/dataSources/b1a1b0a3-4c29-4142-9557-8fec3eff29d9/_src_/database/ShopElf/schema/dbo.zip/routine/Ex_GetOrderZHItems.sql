CREATE FUNCTION [dbo].[Ex_GetOrderZHItems]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	Declare @L_Qty varchar(800)
	SET @SKU = ''
	SET @L_Qty = ''
		SELECT
			@SKU = @SKU + isnull(a.L_NUMBER,'') +  '*' + CONVERT(VarCHar,CONVERT(int, a.L_Qty)) + ';'
		 from (	
				select 
					distinct 
					isnull(d.L_NUMBER,'') as L_NUMBER,	
					case when d.L_TAXAMT=0 then d.L_QTY else d.L_TAXAMT end as l_qty
				FROM
					P_tradeDt d
				WHERE
					d.TradeNID = @TradeID
			)  a
	RETURN @SKU
END
