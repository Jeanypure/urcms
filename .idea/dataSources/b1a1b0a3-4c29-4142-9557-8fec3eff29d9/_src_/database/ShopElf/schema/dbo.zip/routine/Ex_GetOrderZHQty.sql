


CREATE FUNCTION [dbo].[Ex_GetOrderZHQty]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU int
	SET @SKU = 0
		SELECT
			@SKU = @SKU + a.L_Qty
		 from (	
				select 
					distinct 
					case when isnull(d.eBaySKU,'')<>'' then d.eBaySKU else d.SKU end as eBaySKU,
					d.L_EBAYITEMTXNID,
					case when d.L_TAXAMT=0 then d.L_QTY else d.L_TAXAMT end as l_qty
				FROM
					P_tradeDt d
				WHERE
					d.TradeNID = @TradeID
			)  a
	RETURN @SKU
END
