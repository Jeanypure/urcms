CREATE FUNCTION [dbo].[Ex_GetOrderZHSKUS]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	Declare @L_Qty varchar(800)
	SET @SKU = ''
	SET @L_Qty = ''
		SELECT
			@SKU = @SKU + isnull(a.eBaysku,'') +  '*' + CONVERT(VarCHar,CONVERT(int, a.L_Qty)) + ';'
		 from (	
				select 
					distinct 
					case when isnull(d.eBaysku,'')='' then SKU else  isnull(d.eBaysku,'') end as eBaySKU,
					d.L_NUMBER,					
					case when d.L_TAXAMT=0 then d.L_QTY else d.L_TAXAMT end as l_qty
				FROM
					P_tradeDt d
				WHERE
					d.TradeNID = @TradeID
			)  a
	RETURN @SKU
END
