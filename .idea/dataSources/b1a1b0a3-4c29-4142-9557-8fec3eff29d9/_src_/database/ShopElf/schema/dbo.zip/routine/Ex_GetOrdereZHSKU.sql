
CREATE FUNCTION [dbo].[Ex_GetOrdereZHSKU]
(
	@TradeID Int = 0
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @SKU VarChar(8000)
	SET @SKU = ''
	--L_OPTIONSVALUE为1是已解析过,不再返回 
		SELECT
			@SKU = case when @SKU='' then REPLACE('select '+CAST(NID AS VARCHAR) +','''+isnull(SKU,'')+'''','+',''' union all select '+CAST(NID AS VARCHAR)+',''') 
					else @SKU + ' union all '+ REPLACE('select '+CAST(NID AS VARCHAR) +','''+isnull(SKU,'')+'''','+',''' union all select '+CAST(NID AS VARCHAR)+',''' )  end

		FROM
			P_tradeDt d
		WHERE
			d.TradeNID = @TradeID
			and ISNULL(L_OPTIONSVALUE,'')<>'1'
			and isnull(SKU,'') like '%+%'
	RETURN @SKU
END
