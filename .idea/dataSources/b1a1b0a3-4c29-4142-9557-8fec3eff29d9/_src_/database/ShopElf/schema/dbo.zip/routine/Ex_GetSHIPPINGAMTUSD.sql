create FUNCTION [dbo].[Ex_GetSHIPPINGAMTUSD](@TradeNid INT = 0)
RETURNS NUMERIC(10,4) 
AS
BEGIN
	DECLARE @AMT_USD NUMERIC(10,4) = 0
   --查找USD的汇率
	DECLARE @ExchangeRate float = 0
	SET @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 	IF @ExchangeRate=0
 	  SET 	@ExchangeRate=1	
 	DECLARE @MergeFlag INT = 0  
 	SET @MergeFlag =  ISNULL((SELECT MergeFlag FROM P_Trade WHERE NID = @TradeNid),0)  
 	IF @MergeFlag = 0
 	BEGIN
 		SET @AMT_USD = ISNULL((SELECT ISNULL(m.SHIPPINGAMT,0)* ISNULL(c.ExchangeRate,1)/@ExchangeRate			
		                       FROM P_Trade m left join B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		                       WHERE m.NID = @TradeNid),0) 
 	END ELSE 
 	IF @MergeFlag = 1
 	BEGIN
 	  SET @AMT_USD = (SELECT SUM( ISNULL(m.SHIPPINGAMT,0)* ISNULL(c.ExchangeRate,1)/@ExchangeRate)		
 	                  FROM P_Trade_b m left join B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		              WHERE m.MergeBillID = @TradeNid) 	
 	END ELSE
 	BEGIN 
      SET @AMT_USD = 0 
 	END 
	RETURN @AMT_USD
END

