
CREATE FUNCTION [dbo].[Ex_GetSaleAfterOrderSKUS]
(
	@SaleAfterNID Int = 0,
	@IsEBaySKu int = 0
)
RETURNS
	VarChar(4000)
AS
BEGIN	
	Declare @SKU VarChar(Max)
	if @IsEBaySku = 0 begin
	  SET @SKU = ''
	  select @SKU=@SKU+ISNULL(gs.SKU,'')+',' 
		 from XS_SaleAfterD d 
		 inner join B_GoodsSKU gs on gs.NID=d.GoodsSKUID 
		 inner join B_Goods s on s.NID=d.GoodsID
		 where d.SaleAfterNID =@SaleAfterNID
		  order by D.NID 
		if LEN(@SKU)>0 set @SKU= SUBSTRING(@SKU,1,LEN(@SKU)-1)
	end
	else begin
	  SET @SKU = ''
	  select @SKU=@SKU+ISNULL(d.eBaySKU,'')+',' 
		 from XS_SaleAfterD d 
		 where d.SaleAfterNID =@SaleAfterNID
		  order by D.NID 
		if LEN(@SKU)>0 set @SKU= SUBSTRING(@SKU,1,LEN(@SKU)-1)
	end
	
	RETURN substring(@SKU,1,4000)
END
