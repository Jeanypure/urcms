
CREATE FUNCTION [dbo].[Ex_GetShopSKULinkSKU]
(
	@SKU varchar(100) = ''
)
RETURNS
	VarChar(100)
AS
BEGIN
	declare
		@ReturnSKu varchar(100)='',
		@StoreSKU  Varchar(100)=''
	set
		@ReturnSKu=@SKU	
	--判断是否对应库存SKU
	set 
		@StoreSKU=isnull((select sku from B_GoodsSKULinkShop 
					where isnull(ShopSKU,'')=@ReturnSKu and isnull(ShopSKU,'')<> ''),'')
	if @StoreSKU <> ''
	begin
	  set @ReturnSKu =@StoreSKU	
	end			
	else
	begin
		--判断是否启用了, 指定分隔符后面的SKU内容不要。如：A001/ABCD--->A001; A001*10/ABCD--->A001*10   
		declare
			@DelimiterFlag int=0 --0是不替换
			,@Delimiter VARCHAR(10) = ''
			,@TempSKu varchar(100)=''
		    
		set 
			@DelimiterFlag = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='DelimiterFlag')
		    
		if @DelimiterFlag = 1 --替换
		BEGIN
			set 
			  @Delimiter=(select ISNULL(Paravalue,'') from B_SysParams where ParaCode='Delimiter') 
			IF @Delimiter <> '' and CHARINDEX(@Delimiter,isNull(@SKU,''))>0 
			BEGIN   
				set
					@SKU = SUBSTRING(@SKU,1,PATINDEX('%'+@Delimiter+'%',@SKU)-1)
			END 
		end 
		--判断小额批发
		 --判断小额批发 0否，1是 单品SKU*数量，一定是*号-----start
		declare
			@SmallWholesale int=0
		declare
			@SmallWholesaleSymbol varchar(10)
		set 
			@SmallWholesale=(select ISNULL(Paravalue,0) from B_SysParams where ParaCode='Small Wholesale')
		set 
			@SmallWholesaleSymbol=(select ISNULL(Paravalue,'*') from B_SysParams where ParaCode='SmallWholesaleSymbol')		

		if @SmallWholesale=1 and CHARINDEX(@SmallWholesaleSymbol,isNull(@SKU,''))>0 
		begin    
			set	 @SKU =Substring(isNull(@SKU,''),1,CHARINDEX(@SmallWholesaleSymbol,isNull(@SKU,''))-1)
			
		end			
		
		set @ReturnSKu = @SKU
	end
	Return @ReturnSKu
END

