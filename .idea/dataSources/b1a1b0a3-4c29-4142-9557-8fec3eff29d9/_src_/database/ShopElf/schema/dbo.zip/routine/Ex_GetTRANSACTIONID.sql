

create FUNCTION [dbo].[Ex_GetTRANSACTIONID]
(
	@MergeFlag int,
	@tradenid  int,
	@L_EBAYITEMTXNID varchar(50),
	@L_NUMBER  varchar(50)
)
RETURNS
	VarChar(200)
AS
BEGIN	
	DECLARE @TransID varchar(50)=''
	
	if ISNULL(@MergeFlag,0)=0
	begin
	 set @TransID = isnull((select top 1 TRANSACTIONID from (
			select TRANSACTIONID from P_Trade where NID= @tradenid
			union 
			select TRANSACTIONID from P_TradeUn where NID= @tradenid
			union 
			select TRANSACTIONID from P_Trade_His where NID= @tradenid
			union 
			select TRANSACTIONID from P_Trade_b where NID= @tradenid	
			) aa),'')							
	end
	else --合并订单时
	begin
		set @TransID = isnull((select top 1  m.TRANSACTIONID from P_Trade_bdt d
								 left outer join P_Trade_b m on m.NID=d.TradeNID
				where	isnull(m.MergeBillID,0)= isnull(@tradenid,0) and 
						isnull(d.L_EBAYITEMTXNID,'')=isnull(@L_EBAYITEMTXNID,'')  and
						isnull(d.L_NUMBER,'')=isnull(@L_NUMBER,'') 						

			) ,'')	

	end
	return 	@TransID	
END


