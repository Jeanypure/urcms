CREATE FUNCTION [dbo].[Ex_Get_OutOfStockMemoLogs]
(
	@TradeID Int = 0, @tabFlag INT = 0  
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @ServiceMemo VarChar(8000),@TradeDtNID VarChar(10),@TradeDtoldNID VarChar(10) , @SKU VarChar(50), @AllServiceMemo  VarChar(8000)
	SET @ServiceMemo = ''
	SET @AllServiceMemo = ''
	SET @TradeDtoldNID= '0'	 
    IF (@tabFlag = 0) --采购备注
	BEGIN	  
	  DECLARE _TradeDt CURSOR							--2012-08-04 陈卫 修改
	  FOR SELECT  TradeDtNID, SKU, StockMemo			--只取CG_OutOfStock中最新的备注，
		  FROM CG_OutOfStock							--不能取CG_OutOfStockLog表的，因为CG_OutOfStock的触发器在写入CG_OutOfStockLog表之前已执行，导致取不到log表中的内容
		  WHERE
			TradeNID = @TradeID and  isnull(StockMemo,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
		SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END ELSE
	IF (@tabFlag = 1) --仓库备注
	BEGIN	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT  TradeDtNID, SKU, StoreMemo
		  FROM CG_OutOfStock
		  WHERE
			TradeNID = @TradeID and  isnull(StoreMemo,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
	    SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END ELSE
	IF (@tabFlag = 2) --派单备注
	BEGIN	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT  TradeDtNID, SKU,SaleMemo
		  FROM CG_OutOfStock
		  WHERE
			TradeNID = @TradeID and  isnull(SaleMemo,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
	    SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END ELSE
	IF (@tabFlag = 3) --客服备注
	BEGIN	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT  TradeDtNID, SKU, ServiceMemo
		  FROM CG_OutOfStock 
		  WHERE
			TradeNID = @TradeID and  isnull(ServiceMemo,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
	    SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END ELSE
	IF (@tabFlag = 4) --其它备注
	BEGIN	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT  TradeDtNID, SKU, PrintMemo
		  FROM  CG_OutOfStock ptdu 
		  WHERE
			TradeNID = @TradeID and  isnull(PrintMemo,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
	    SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END ELSE
	IF (@tabFlag = 5) --处理方法
	BEGIN	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT  TradeDtNID, SKU, ServiceMethod
		  FROM  CG_OutOfStock  
		  WHERE
			TradeNID = @TradeID and  isnull(ServiceMethod,'') <> ''
		ORDER BY sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @TradeDtNID, @SKU, @ServiceMemo
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
	    SET @AllServiceMemo = @AllServiceMemo + '【'+@SKU+'】' + @ServiceMemo + Char(13)+ char(10)
		FETCH NEXT FROM _TradeDt INTO  @TradeDtNID, @SKU, @ServiceMemo
	  END 
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	END
	RETURN @AllServiceMemo
END 


