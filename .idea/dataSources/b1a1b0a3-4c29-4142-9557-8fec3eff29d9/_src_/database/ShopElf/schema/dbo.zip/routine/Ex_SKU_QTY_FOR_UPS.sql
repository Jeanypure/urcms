Create FUNCTION [dbo].[Ex_SKU_QTY_FOR_UPS] 
  (
    @TableType int = 0,
    @TradeID Int = 0
   )
RETURNS
  VarChar(8000)
AS
BEGIN	
  Declare @SKU VarChar(8000)
  SET @SKU = ''
 
  if (@TableType=0 and exists(select nid from P_Trade(nolock) where NID=@TradeID))
  BEGIN 
    select @SKU =  @SKU + isnull(ltrim(rtrim(STR(dt.L_QTY))),'') + ' * ' + isnull(dt.SKU,'') + ';'
	FROM P_tradeDt(nolock) dt
	where  dt.TradeNID = @TradeID
	order by ISNULL(dt.SKU,'') 
  END
  else if (@TableType=1 and exists(select nid from P_Tradeun(nolock) where NID=@TradeID))							
  begin
    select @SKU =  @SKU + isnull(ltrim(rtrim(STR(dt.L_QTY))),'') + ' * ' + isnull(dt.SKU,'') + ';'
	FROM P_tradeDtun(nolock) dt
	where  dt.TradeNID = @TradeID
	order by ISNULL(dt.SKU,'') 
  end  

if @SKU <> '' 
begin
  set @SKU = substring(@SKU,1,len(@SKU)-1)
end  
RETURN @SKU
END
