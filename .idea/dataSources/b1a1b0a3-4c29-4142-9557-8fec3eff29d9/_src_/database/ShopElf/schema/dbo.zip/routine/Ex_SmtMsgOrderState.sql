
create FUNCTION [dbo].[Ex_SmtMsgOrderState]
(
	@ACK varchar(100),
	@OrderStateOrCustom int
)
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @OrderState VarChar(200)
	if @OrderStateOrCustom=0
	begin
	 --订单状态
	 if exists(select nid from P_Trade(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress' )
	 begin
	   SET @OrderState=(
	  
          SELECT top 1 OrderStatus = CASE WHEN m.FilterFlag = 5  THEN '待派单' WHEN (m.FilterFlag = 6) AND (l.eub = 1)  THEN '派至E邮宝' WHEN (m.FilterFlag = 6) AND (l.eub = 2) THEN '派至E线下邮宝' WHEN (m.FilterFlag = 6) AND (l.eub = 3) THEN '派4PX独立帐户' WHEN  (m.FilterFlag = 6) AND (l.eub = 4)  THEN '派至非E邮宝' WHEN m.FilterFlag = 20 THEN '等待拣货' WHEN m.FilterFlag = 22  THEN '待核单' WHEN  m.FilterFlag = 24 THEN '等待包装' WHEN  m.FilterFlag = 40 THEN '等待发货' WHEN  m.FilterFlag = 26 THEN '订单缺货(仓库)' WHEN m.FilterFlag = 28 THEN '缺货待包装' WHEN  (m.FilterFlag = 100) THEN '已发货' else '' end
           FROM P_Trade m LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID where   m.ADDRESSOWNER='aliexpress'  
           and m.ACK=@ACK)
	 end
	 else if exists(select nid from P_Trade_his(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	 begin
	     SET @OrderState=(select top 1 OrderStatus='已归档' FROM P_Trade_his m  
            where    m.ADDRESSOWNER='aliexpress'  and m.ACK=@ACK )
	 end
	 else if exists(select nid from P_Tradeun(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	 begin
	 
	   SET @OrderState=(SELECT  top 1
   OrderStatus = case WHEN  (m.FilterFlag = 0) THEN '等待付款' WHEN (m.FilterFlag = 1) THEN '订单缺货' WHEN  (m.FilterFlag = 2) THEN '订单退货' WHEN   (m.FilterFlag = 3) THEN '订单取消' WHEN  (m.FilterFlag = 4) THEN '异常单' else '' end
   FROM P_Tradeun m   
    where    m.ADDRESSOWNER='aliexpress'  and m.ACK=@ACK )
     
	 end
	 else if exists(select nid from P_Tradeun_his(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	 begin
	   SET @OrderState=(
	      SELECT top 1 OrderStatus = case WHEN  (m.FilterFlag = 0) THEN '等待付款' WHEN (m.FilterFlag = 1) THEN '订单缺货' WHEN  (m.FilterFlag = 2) THEN '订单退货' WHEN   (m.FilterFlag = 3) THEN '订单取消' WHEN  (m.FilterFlag = 4) THEN '异常单' else '' end
     FROM P_Tradeun_his m  
     where    m.ADDRESSOWNER='aliexpress'  and m.ACK=@ACK )
	 end
	 else if exists(select nid from P_Trade_b(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	 begin
	 --订单状态
	 	SET @OrderState=(
	 	select top 1 OrderStatus from (
	  
 SELECT OrderStatus = CASE WHEN m.FilterFlag = 5  THEN '待派单' WHEN (m.FilterFlag = 6) AND (l.eub = 1)  THEN '派至E邮宝' WHEN (m.FilterFlag = 6) AND (l.eub = 2) THEN '派至E线下邮宝' WHEN (m.FilterFlag = 6) AND (l.eub = 3) THEN '派4PX独立帐户' WHEN (m.FilterFlag = 6) AND (l.eub = 4) THEN '派至非E邮宝' WHEN (m.FilterFlag = 20) THEN '等待拣货' WHEN (m.FilterFlag = 22)  THEN '待核单' WHEN  (m.FilterFlag = 24) THEN '等待包装' WHEN  (m.FilterFlag = 40)  THEN '等待发货' WHEN  (m.FilterFlag = 26) THEN '订单缺货(仓库)' WHEN  (m.FilterFlag = 28)  THEN '缺货待包装' WHEN  (m.FilterFlag = 100) THEN '已发货' else '' end
  FROM P_Trade m LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID where   m.ADDRESSOWNER='aliexpress'  
  and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
 
  union all 
  select OrderStatus='已归档' FROM P_Trade_his m  
   where    m.ADDRESSOWNER='aliexpress'  and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
   union all  SELECT 
   OrderStatus = case WHEN  (m.FilterFlag = 0) THEN '等待付款' WHEN (m.FilterFlag = 1) THEN '订单缺货' WHEN  (m.FilterFlag = 2) THEN '订单退货' WHEN   (m.FilterFlag = 3) THEN '订单取消' WHEN  (m.FilterFlag = 4) THEN '异常单' else '' end
   FROM P_Tradeun m   
    where    m.ADDRESSOWNER='aliexpress'  and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
    union all  
    SELECT  OrderStatus = case WHEN  (m.FilterFlag = 0) THEN '等待付款' WHEN (m.FilterFlag = 1) THEN '订单缺货' WHEN  (m.FilterFlag = 2) THEN '订单退货' WHEN   (m.FilterFlag = 3) THEN '订单取消' WHEN  (m.FilterFlag = 4) THEN '异常单' else '' end
     FROM P_Tradeun_his m  
     where    m.ADDRESSOWNER='aliexpress'  and m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)) m  )

	 end
	 else
	 begin
	   SET @OrderState=''
	 end
	 

	end
	else if @OrderStateOrCustom=1
	begin
	  -- 自定义标签
	   if exists(select nid from P_Trade(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress' )
	   begin
	     SET @OrderState=(select top 1 REASONCODE from P_Trade m where   m.ADDRESSOWNER='aliexpress'  
         and m.ACK=@ACK )
	   end
	   else if exists(select nid from P_Trade_his(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	   begin
	     SET @OrderState=(select top 1 REASONCODE from P_Trade_His m where   m.ADDRESSOWNER='aliexpress'  
         and m.ACK=@ACK)
	   end
	   else if exists(select nid from P_Tradeun(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	   begin
	       SET @OrderState=(select top 1REASONCODE from P_Tradeun m where   m.ADDRESSOWNER='aliexpress'  
         and m.ACK=@ACK )
	   end
	   else if exists(select nid from P_Tradeun_his(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
	   begin
	     SET @OrderState=(select top 1 REASONCODE from P_Tradeun_his m where   m.ADDRESSOWNER='aliexpress'  
         and m.ACK=@ACK )
	   end
       else if exists(select nid from P_Trade_b(nolock) where ACK=@ACK and   ADDRESSOWNER='aliexpress')
       begin
            SET @OrderState=(select top 1 REASONCODE from (select REASONCODE from P_Trade m where   m.ADDRESSOWNER='aliexpress'  
         and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
         union all 
	  select REASONCODE from P_Trade_His m where   m.ADDRESSOWNER='aliexpress'  
         and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
            union all 
	  select REASONCODE from P_Tradeun m where   m.ADDRESSOWNER='aliexpress'  
         and  m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK)
               union all 
	  select REASONCODE from P_Tradeun_his m where   m.ADDRESSOWNER='aliexpress'  
         and m.NID in (SELECT Z.MergeBillID FROM P_trade_b Z WHERE z.ACK=@ACK))m
	  )
       end
       else
       begin
         SET @OrderState=''
       end
	  
	 
	end

	RETURN @OrderState
END
