create FUNCTION [dbo].[Ex_kcNumber] 
(
   @sku varchar(200) ,
   @xuan varchar(50)  --1为库存占用数量 2 saleprice  3 gs.[saleprice],0)-isnull(gg.[saleprice
  
 
   )
RETURNS
	VarChar(8000)
AS
BEGIN
	Declare @number VarChar(8000)
	SET @number = ''
	if  '1'=@xuan  
	begin                                                       
	   if exists(select bgs.NID from b_goodssku(nolock) bgs  where bgs.sku=@sku )            --如果sku存在在b_goodssku表中 取可用数量
	    begin
	    select 
	    @number= ((select sum(isnull(number,0)) - sum(isnull(ReservationNum,0)))) 
	    from B_GoodsSKU bgs 
	    inner join  KC_CurrentStock kc on kc.GoodsSKUID=bgs.NID
	    where bgs.sku=@sku
	    end 
	    else
	    begin
	       select 
	    @number= ((select sum(isnull(kc.number,0)) - sum(isnull(kc.ReservationNum,0)))) 
	    from B_GoodsSKULinkShop shop 
	    inner join B_GoodsSKU bgs on bgs.SKU=shop.SKU
	    inner join  KC_CurrentStock kc on kc.GoodsSKUID=bgs.NID
	    where shop.ShopSKU=@sku
	    
	    end
	end
	else
	if  '2'=@xuan
	begin	
		if exists(select bgs.NID from b_goodssku(nolock) bgs  where bgs.sku=@sku )            --如果sku存在在b_goodssku表中 取价格
	    begin
	    select 
	    @number= isnull(bg.[saleprice],0)
	    from B_GoodsSKU bgs 
	    inner join  KC_CurrentStock kc on kc.GoodsSKUID=bgs.NID
	    inner join b_goods bg on bg.NID=bgs.GoodsID
	    where bgs.sku=@sku
	    end 
	    else
	    begin
	       select 
	    @number= isnull(bg.[saleprice],0)
	    from B_GoodsSKULinkShop shop 
	    inner join B_GoodsSKU bgs on bgs.SKU=shop.SKU
	    inner join  KC_CurrentStock kc on kc.GoodsSKUID=bgs.NID
	    inner join b_goods bg on bg.NID=bgs.GoodsID
	    where shop.ShopSKU=@sku
	    end
	end	
	RETURN @number
END
