create proc [dbo].[GetAutoSyncShippedTrades]
AS
BEGIN
	DECLARE @SyncShippedType INT, @IsSyncOutStockOrder INT ,@SyncFaildCount INT, @InMonth INT,@BeginDate DATETIME
	SELECT TOP 1 @SyncShippedType = ISNULL(SyncShippedType,1)
           ,@IsSyncOutStockOrder =  ISNULL(IsSyncOutStockOrder,0) 
           ,@SyncFaildCount = ISNULL(SyncFaildCount,0) 
           ,@InMonth = ISNULL(InMonth,0)    
        
    FROM P_AutoSyncShppedBaseSet
    
    SET @BeginDate = DATEADD(DAY,-15,GETDATE())               --这里改为15天前的数据
 
    CREATE TABLE #AutoSyncShipped(NID VARCHAR(10)
                                 ,[USER] VARCHAR(100)
                                 ,BuyerID VARCHAR(100)
                                 ,RECEIVERBUSINESS VARCHAR(100)
                                 ,MergeFlag VARCHAR(100)
                                 ,ACK VARCHAR(100)
                                 ,TrackNo VARCHAR(100)
                                 ,EUB VARCHAR(2)
                                 ,MagentoFlag VARCHAR(2)
                                 ,Orig VARCHAR(2)
                                 ,SyncEUBEnable VARCHAR(2)
                                 ,SyncEBayEnable VARCHAR(2)
                                 ,logicsWayCode VARCHAR(50)
                                 ,logicsWayNID int                                 
                                 ,ServiceCode VARCHAR(200) 
                                 ,TRANSACTIONID VARCHAR(50)
                                 ,ADDRESSOWNER VARCHAR(10)
                                 ,SendNote VARCHAR(500)
                                 ,Build VARCHAR(500)
                                 ,SUFFIX VARCHAR(50))
                                   
    update P_TradeUn set SHIPPINGMETHOD = '0' where  (ISNULL(SHIPPINGMETHOD,'0.00') ='0.00')
    
    update P_trade set SHIPPINGMETHOD = '0' where  (ISNULL(SHIPPINGMETHOD,'0.00') ='0.00')
    
    --update P_Trade_His set SHIPPINGMETHOD = '0' where  (ISNULL(SHIPPINGMETHOD,'0.00') ='0.00') 
    
    IF (@SyncShippedType = 0)
    BEGIN
      INSERT INTO #AutoSyncShipped
      SELECT top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS, ISNULL(m.MergeFlag, '') MergeFlag ,m.ACK,
      case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag , '0'
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD, m.SUFFIX
      FROM P_Trade(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) = 5 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND  (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay')
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate )
    END ELSE
	IF (@SyncShippedType = 1)
    BEGIN
      INSERT INTO #AutoSyncShipped
      SELECT top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeFlag, '') MergeFlag ,m.ACK,
        case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
           0  as MagentoFlag, '0'
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_Trade(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) = 40 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0'	and (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay')
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate )
    END ELSE
	IF (@SyncShippedType = 2)
    BEGIN
      INSERT INTO #AutoSyncShipped
      SELECT  top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeFlag, '') MergeFlag ,m.ACK,
        case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag, '0'
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode  ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_Trade(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) = 100 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND  (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay') 
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate )
      UNION 
      SELECT  top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeBillID, '') MergeFlag ,m.ACK,  case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag, '1'
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_Trade_His(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID   
      WHERE ISNULL(m.FilterFlag,0) = 200 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay')  
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate )
    END ELSE
	IF (@SyncShippedType = 3)
    BEGIN
      INSERT INTO #AutoSyncShipped
      SELECT  top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeFlag, '') MergeFlag ,m.ACK,  
      case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag , '0'
           ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode  ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_Trade(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) >= 20 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND  (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay')  
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate)
      UNION 
      SELECT  top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeBillID, '') MergeFlag ,m.ACK,
        case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag, '1' 
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode  ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_Trade_His(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) = 200 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay') 
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate )
    END 
    --是否同步缺货订单
    IF (@IsSyncOutStockOrder = 1)
    BEGIN
      INSERT INTO #AutoSyncShipped
      SELECT  top 5000 m.NID,m.[USER],m.BuyerID,m.RECEIVERBUSINESS,ISNULL(m.MergeFlag, '') MergeFlag ,m.ACK,
        case when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID15') then isnull(m.BUILD,'')
           when (SUBSTRING(isnull(m.BUILD,''),1,4)='ID18') then isnull(m.BUILD,'')
           else ISNULL(m.TrackNo, '') end  -- 万邑通isp传内部处理替换成跟踪号
           ,ISNULL(l.EUB, '') EUB, 
            0  as MagentoFlag, '2'
            ,(SELECT TOP 1 ISNULL(SyncEUBEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEUBEnable
            ,(SELECT TOP 1 ISNULL(SyncEBayEnable,0) FROM S_PalSyncInfo WHERE EbayUserID=m.[USER])  as SyncEBayEnable
            ,l.code as logicsWayCode  ,m.logicsWayNID,l.ServiceCode,m.TRANSACTIONID,m.ADDRESSOWNER,l.SendNote,m.BUILD,m.SUFFIX
      FROM P_TradeUn(nolock) m LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID  
      WHERE ISNULL(m.FilterFlag,0) = 1 AND ISNULL(m.SHIPPINGMETHOD,'0') = '0' AND  (m.ADDRESSOWNER='paypal' or m.ADDRESSOWNER='ebay')  
      AND (DateAdd(hour,8,m.Ordertime) >= @BeginDate)
    END    
    --删除掉，大于同步最大次数的
    DELETE FROM #AutoSyncShipped 
    WHERE NID IN (SELECT OrderID 
                  FROM P_AutoSyncShipped 
                  WHERE ISNULL(IsSuccess,0) = 0 AND SyncCount > @SyncFaildCount) 
    --返回数据集
    SELECT   top 5000 NID
           ,[USER]
           ,BuyerID
           ,RECEIVERBUSINESS
           ,isnull(MergeFlag,0) AS MergeFlag
           ,ACK
           ,TrackNo
           ,isnull(EUB,0) AS EUB
           ,isnull(MagentoFlag,0) AS MagentoFlag
           ,isnull(Orig,0) AS Orig
           ,isnull(SyncEUBEnable,0) AS SyncEUBEnable
           ,isnull(SyncEBayEnable,0) AS SyncEBayEnable
           ,logicsWayCode
           ,ServiceCode
           ,logicsWayNID
           ,TRANSACTIONID
           ,ADDRESSOWNER
           ,SendNote
           ,Build
           ,SUFFIX
    FROM #AutoSyncShipped where isnull(ack,'') <> ''
    DROP TABLE #AutoSyncShipped 
END

