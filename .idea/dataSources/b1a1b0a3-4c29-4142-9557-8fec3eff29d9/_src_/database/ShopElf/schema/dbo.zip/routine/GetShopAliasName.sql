CREATE FUNCTION [dbo].[GetShopAliasName]() RETURNS VARCHAR(2000)
AS
BEGIN
	DECLARE @AllAliasName VARCHAR(2000)
	SET @AllAliasName = ''
	SELECT @AllAliasName = @AllAliasName + ''''+ NoteName +''','
	FROM (SELECT spsi.NoteName FROM S_PalSyncInfo spsi  
          UNION 
          SELECT DictionaryName FROM  B_Dictionary  
          WHERE     (CategoryID = 12)) c
    IF LEN(@AllAliasName) <= 1
      SET @AllAliasName =LEN(@AllAliasName)
    ELSE    	 
      SET @AllAliasName = substring(@AllAliasName,1,LEN(@AllAliasName) -1)
    RETURN @AllAliasName
END
