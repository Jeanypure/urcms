create proc [dbo].[InitAutoSyncShippedMsg]
AS
BEGIN
  DECLARE @LastDownMessageDate DATETIME
  SET @LastDownMessageDate = ISNULL((SELECT MIN(SyncTimePoint) FROM S_PalSyncInfo WHERE (SyncTimePoint IS NOT NULL)), GETDATE())	
  
  DECLARE @LastDownCaseDate DATETIME
  SET @LastDownCaseDate = ISNULL((SELECT MIN(DownEbayCaseTimePoint) FROM S_PalSyncInfo WHERE (DownEbayCaseTimePoint IS NOT NULL)), GETDATE())		
	
  IF EXISTS( SELECT 1 FROM P_AutoSyncShppedBaseSet) 
  BEGIN 
    SELECT SyncInvertal ,SyncFaildCount ,SyncShippedType ,IsSyncOutStockOrder,InMonth,
    IsDownMsg, @LastDownMessageDate AS LastDownMessageDate,IsDownCase,@LastDownCaseDate AS LastDownCaseDate  
    FROM P_AutoSyncShppedBaseSet 
  END ELSE
  BEGIN 
    INSERT INTO P_AutoSyncShppedBaseSet (SyncInvertal ,SyncFaildCount ,SyncShippedType ,IsSyncOutStockOrder,InMonth,IsDownMsg,IsDownCase)
	VALUES  (5 ,3 ,0 ,0,2,0,0)
    SELECT SyncInvertal ,SyncFaildCount ,SyncShippedType ,IsSyncOutStockOrder , @LastDownMessageDate AS LastDownMessageDate
    FROM P_AutoSyncShppedBaseSet 
 END
END

