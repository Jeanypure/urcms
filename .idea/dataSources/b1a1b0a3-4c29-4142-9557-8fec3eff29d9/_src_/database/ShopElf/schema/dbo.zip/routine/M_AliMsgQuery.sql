create proc [dbo].[M_AliMsgQuery]
	@resource_owner  varchar(200)='',
	@SqlStr          varchar(max)=''
	
AS
BEGIN
	set nocount on;
	declare
		@excSql varchar(max)=''
	if @resource_owner=''
	begin
		set @excSql='
		select channelId into #acktemp
		  from M_AliMsgRelation(nolock) m 
           left join S_AliSyncInfo(nolock) s on s.AliasName=m.SUFFIX 
            left join M_AliMessagesD(nolock) d on d.AliasName=m.suffix
            and d.ACK=m.channelId 
            and d.msgType=m.orderormessage 
		 '+@SqlStr;
	end
	else
	begin
		set @excSql='
		select channelId into #acktemp
		 from M_AliMsgRelation(nolock) m  left join M_AliMessagesD(nolock) d 
		 on d.AliasName=m.suffix and d.ACK=m.channelId  and d.msgType=m.orderormessage  
		 '+@SqlStr;
	end  
	 -- 正常
	set @excSql=@excSql+' select ACK,OrderState = CASE WHEN m.FilterFlag = 5  THEN ''待派单'' WHEN (m.FilterFlag = 6) AND (l.eub = 1)  THEN ''派至E邮宝'' WHEN (m.FilterFlag = 6) AND (l.eub = 2) THEN ''派至E线下邮宝'' WHEN (m.FilterFlag = 6) AND (l.eub = 3) THEN ''派4PX独立帐户'' WHEN  (m.FilterFlag = 6) AND (l.eub = 4)  THEN ''派至非E邮宝'' WHEN m.FilterFlag = 20 THEN ''等待拣货'' WHEN m.FilterFlag = 22  THEN ''待核单'' WHEN  m.FilterFlag = 24 THEN ''等待包装'' WHEN  m.FilterFlag = 40 THEN ''等待发货'' WHEN  m.FilterFlag = 26 THEN ''订单缺货(仓库)'' WHEN m.FilterFlag = 28 THEN ''缺货待包装'' WHEN  (m.FilterFlag = 100) THEN ''已发货'' else '''' end,REASONCODE
		 into #ordertemp
		 from P_Trade m with(nolock)
		 LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID
		 where ADDRESSOWNER=''aliexpress'' and ACK in (select channelId from #acktemp)
		 -- 历史
		 union all
		 select ACK,''已归档'',REASONCODE  
		 from P_Trade_his m with(nolock)
		 where ADDRESSOWNER=''aliexpress'' and ACK in (select channelId from #acktemp)
		 -- 异常
		 union all
		 select ACK, case WHEN  (m.FilterFlag = 0) THEN ''等待付款'' WHEN (m.FilterFlag = 1) THEN ''订单缺货'' WHEN  (m.FilterFlag = 2) THEN ''订单退货'' WHEN   (m.FilterFlag = 3) THEN ''订单取消'' WHEN  (m.FilterFlag = 4) THEN ''异常单'' else '''' end,REASONCODE
		 from P_TradeUn m with(nolock)
		 where ADDRESSOWNER=''aliexpress'' and ACK in (select channelId from #acktemp)
		 -- 异常历史
		 union all
		 select ACK, OrderState = case WHEN  (m.FilterFlag = 0) THEN ''等待付款'' WHEN (m.FilterFlag = 1) THEN ''订单缺货'' WHEN  (m.FilterFlag = 2) THEN ''订单退货'' WHEN   (m.FilterFlag = 3) THEN ''订单取消'' WHEN  (m.FilterFlag = 4) THEN ''异常单'' else '''' end
			 ,REASONCODE
		 from P_TradeUn_His m with(nolock)
		 where ADDRESSOWNER=''aliexpress'' and ACK in (select channelId from #acktemp)
		 -- 合并正常
		  union all
		  SELECT ack,OrderState = CASE WHEN m.FilterFlag = 5  THEN ''待派单'' WHEN (m.FilterFlag = 6) AND (l.eub = 1)  THEN ''派至E邮宝'' WHEN (m.FilterFlag = 6) AND (l.eub = 2) THEN ''派至E线下邮宝'' WHEN (m.FilterFlag = 6) AND (l.eub = 3) THEN ''派4PX独立帐户'' WHEN (m.FilterFlag = 6) AND (l.eub = 4) THEN ''派至非E邮宝'' WHEN (m.FilterFlag = 20) THEN ''等待拣货'' WHEN (m.FilterFlag = 22)  THEN ''待核单'' WHEN  (m.FilterFlag = 24) THEN ''等待包装'' WHEN  (m.FilterFlag = 40)  THEN ''等待发货'' WHEN  (m.FilterFlag = 26) THEN ''订单缺货(仓库)'' WHEN  (m.FilterFlag = 28)  THEN ''缺货待包装'' WHEN  (m.FilterFlag = 100) THEN ''已发货'' else '''' end,REASONCODE
		  FROM P_Trade m with(nolock) 
		  LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID
		  where m.ADDRESSOWNER=''aliexpress''  
		  and exists (SELECT top 1 nid FROM P_trade_b Z  with(nolock) WHERE ACK in (select channelId from #acktemp) and MergeBillID=m.NID)
		 --合并已归档
		 union all
		  SELECT ack,OrderState = ''已归档'',REASONCODE
		  FROM P_Trade_his m with(nolock) 
		  where m.ADDRESSOWNER=''aliexpress''  
		  and exists (SELECT top 1 nid FROM P_trade_b Z  with(nolock) WHERE ACK in (select channelId from #acktemp) and MergeBillID=m.NID)
		 --合并异常
		  union all
		 SELECT ack, OrderState = case WHEN  (m.FilterFlag = 0) THEN ''等待付款'' WHEN (m.FilterFlag = 1) THEN ''订单缺货'' WHEN  (m.FilterFlag = 2) THEN ''订单退货'' WHEN   (m.FilterFlag = 3) THEN ''订单取消'' WHEN  (m.FilterFlag = 4) THEN ''异常单'' else '''' end,REASONCODE
		  FROM P_TradeUn m with(nolock) 
		  where m.ADDRESSOWNER=''aliexpress''  
		  and exists (SELECT top 1 nid FROM P_trade_b Z  with(nolock) WHERE ACK in (select channelId from #acktemp) and MergeBillID=m.NID)
		--合并异常历史
		 union all
		SELECT ack,OrderState = case WHEN  (m.FilterFlag = 0) THEN ''等待付款'' WHEN (m.FilterFlag = 1) THEN ''订单缺货'' WHEN  (m.FilterFlag = 2) THEN ''订单退货'' WHEN   (m.FilterFlag = 3) THEN ''订单取消'' WHEN  (m.FilterFlag = 4) THEN ''异常单'' else '''' end,REASONCODE
		  FROM P_TradeUn_his m with(nolock) 
		  where m.ADDRESSOWNER=''aliexpress''  
		  and exists (SELECT top 1 nid FROM P_trade_b Z  with(nolock) WHERE ACK in (select channelId from #acktemp) and MergeBillID=m.NID)

		   
		 -- 汇总
		 select * into #ordersumemp from (
		 select ACK,MAX(OrderState) OrderState,MAX(REASONCODE) REASONCODE  from #ordertemp
		 group by ACK) s ';
	-- 查询订单留言
	if @resource_owner=''
	begin
		set @excSql=@excSql+' select m.*,OrderState,REASONCODE,               
            s.resource_owner as SellerLoginId 
           from M_AliMsgRelation(nolock) m 
            left join S_AliSyncInfo(nolock) s on s.AliasName=m.SUFFIX 
            left join M_AliMessagesD(nolock) d on d.AliasName=m.suffix and d.ACK=m.channelId and d.msgType=m.orderormessage 
            left join #ordersumemp temp on temp.ACK=m.channelId
            '+@SqlStr+' order by dealStat asc ';
	end
	else
	begin
		set @excSql=@excSql+' select m.*,OrderState,REASONCODE,
		 '''+@resource_owner+''' as SellerLoginId  
		 from M_AliMsgRelation(nolock) m  
		 left join M_AliMessagesD(nolock) d on d.AliasName=m.suffix and d.ACK=m.channelId  and d.msgType=m.orderormessage  
		 left join #ordersumemp temp on temp.ACK=m.channelId
		'+@SqlStr+' order by dealStat asc '
	end
    set @excSql=@excSql+' 
	drop table #acktemp
	drop table #ordertemp
	drop table #ordersumemp ';
	print @excSql
	exec(@excSql);		
	set nocount off;
end
