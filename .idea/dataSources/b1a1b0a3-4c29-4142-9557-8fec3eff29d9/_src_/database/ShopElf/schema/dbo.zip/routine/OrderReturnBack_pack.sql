Create PROCEDURE [dbo].[OrderReturnBack_pack] @TradeNids VARCHAR(max) = '',
                                 @ToFlag    int    = 0,
                                 @CurrUser  VARCHAR(50) = '',
                                 @ReturnMsg VarChar(200) OutPut	
AS
BEGIN
    -- 只用作物流退包
	--修改: 2013-06-05 陈卫 进行逻辑判断方面的修改
	set nocount on;
	IF ((@TradeNids = '') OR (@ToFlag = ''))
		RETURN
	IF (@CurrUser = '')
		SET @CurrUser = 'NoneUser'
	
	DECLARE @WillToFilterFlag INT = 0
	
	IF (@ToFlag = '1') --待派单
		SET @WillToFilterFlag = 5
	ELSE IF (@ToFlag = '2') --E邮宝/非E邮宝  exec OrderReturnBack '665', '1', 'admin'
		SET @WillToFilterFlag = 6
	ELSE IF (@ToFlag = '3') --待包装--未拣货  
		SET @WillToFilterFlag = 20
	ELSE IF (@ToFlag = '4') --待包装--未核单  
		SET @WillToFilterFlag = 22
	ELSE IF (@ToFlag = '5') --待包装--未包装
		SET @WillToFilterFlag = 24
	ELSE IF (@ToFlag = '6') --待发货  
		SET @WillToFilterFlag = 40
    ELSE IF (@ToFlag = '7') --已发货  
		SET @WillToFilterFlag = 100
	CREATE TABLE #OrderReturnBack ([NID] VARCHAR(10),
	                               [ExpressNID] VARCHAR(2),
	                               [logicsWayNID] VARCHAR(2),
	                               [ExpressStatus] VARCHAR(2),
	                               [FilterFlag] int,    
								   [MergeFlag] VARCHAR(2),
								   [CheckOrder] VARCHAR(2),
								   [RestoreStock]VARCHAR(2),
								    Orig VARCHAR(2),eub VARCHAR(2))
	CREATE TABLE #ret ([result] VARCHAR(100), [Msg] VARCHAR(2000))
    DECLARE @sSQLCmd varchar(max),@RetMsg nvarchar(max) = ''	--@RetMsg 8000 改为 max 陈卫
    --取出订单当前状态
    SET @sSQLCmd = 'INSERT INTO #OrderReturnBack([NID] ,[ExpressNID] ,[logicsWayNID] ,[ExpressStatus] ,[FilterFlag],Orig '+     
								  ',[MergeFlag] ,[CheckOrder] ,[RestoreStock], eub) '+
                   'SELECT m.[NID] , m.[ExpressNID] ,m.[logicsWayNID] ,m.[ExpressStatus] ,m.[FilterFlag], m.Orig'+    
						  ',m.[MergeFlag] ,m.[CheckOrder] ,m.[RestoreStock],l.eub '+
					
					'FROM (  SELECT [NID] ,[ExpressNID] ,[logicsWayNID] ,[ExpressStatus] ,[FilterFlag] '+     
								  ',[MergeFlag] ,[CheckOrder] ,[RestoreStock], 2 AS Orig '+ 
							'FROM [P_TradeUn] '+
							'WHERE NID IN ('+@TradeNids+') '+
							'UNION '+
							'SELECT [NID] ,[ExpressNID] ,[logicsWayNID] ,[ExpressStatus] ,[FilterFlag] '+     
								  ',[MergeFlag] ,[CheckOrder] ,[RestoreStock], 0 AS Orig '+
							'FROM [P_Trade] '+
							'WHERE NID IN  ('+@TradeNids+') '+
							'UNION '+
							'SELECT [NID] ,[ExpressNID] ,[logicsWayNID] ,[ExpressStatus] ,[FilterFlag] '+     
								  ',MergeBillID ,[CheckOrder] ,[RestoreStock], 1 AS Orig '+ 
							'FROM [P_Trade_His] '+
							'WHERE NID IN  ('+@TradeNids+') ' +
						    'UNION '+
							'SELECT [NID] ,[ExpressNID] ,[logicsWayNID] ,[ExpressStatus] ,[FilterFlag] '+     
								  ',MergeBillID ,[CheckOrder] ,[RestoreStock], 3 AS Orig '+ 
							'FROM [P_TradeUn_His] '+
							'WHERE NID IN  ('+@TradeNids+') 
							) AS  m '+
					'LEFT outer JOIN T_Express te on te.NID   = m.ExpressNID '+
					'LEFT outer JOIN B_LogisticWay l on l.NID = m.logicsWayNID';
    EXEC(@sSQLCmd)

    IF EXISTS (SELECT 1 FROM sysobjects WHERE NAME='#CodeRuleGet' AND [TYPE] = 'u' )
    DROP TABLE #CodeRuleGet
	CREATE TABLE #CodeRuleGet(RuleCode VARCHAR(200)) 
	
	DECLARE @Orig VARCHAR(1), @FilterFlag int, @eub VARCHAR(2), @NID VARCHAR(10), @RestoreStock VARCHAR(2), @CodeRuleGet VARCHAR(200)
	
	DECLARE CurOrderReturnBack CURSOR FOR 
		SELECT Orig , [FilterFlag], eub, [NID] ,[RestoreStock]  
	    	FROM #OrderReturnBack
	OPEN CurOrderReturnBack		
	
	WHILE (1=1)
	BEGIN
		FETCH NEXT FROM CurOrderReturnBack INTO @Orig, @FilterFlag, @eub, @NID, @RestoreStock		
		if @@fetch_status !=0 break; --处理完跳出
		
		--add by ylq 2015-05-27
		if (@Orig = 3) --已归档的异常订单
		begin
		  SET @RetMsg = @RetMsg + '订单"'+@NID+'"在待处理订单的【异常已归档】中,不能驳回!'+char(13);
	      continue; 
		end
		
		IF (@Orig = 2)  --待处理订单的异常订单
	   	BEGIN
	    	SET @RetMsg = @RetMsg + '订单"'+@NID+'"在待处理订单的【异常订单】中,不能驳回!'+char(13);
	    	continue;
	   	END
		if @FilterFlag = 5 
		begin
			SET @RetMsg = @RetMsg + '订单"'+@NID+'"在待处理订单的【待派单】中,不能驳回!'+char(13);
	    	continue;
		end;
		if (@FilterFlag = @WillToFilterFlag )
		begin
			SET @RetMsg = @RetMsg + '订单"'+@NID+'"不能驳回到当前自身状态!'+char(13);
	    	continue;
		end;
		IF (@FilterFlag < @WillToFilterFlag) 	--不能向流程之后驳回
       	BEGIN
        	SET @RetMsg = @RetMsg + '订单"'+@NID+'"在要驳回环节之前,不能驳回!'+char(13);
        	continue; 
       	END
       	
       	--已发货->未发货 驳回时要处理库存,帐,和库存占用
		IF (@WillToFilterFlag < 100) AND (@FilterFlag >= 100) and (@Orig = 0) --归档的已控制只能驳回到已发货,不用处理库存问题       	
       	--IF (@WillToFilterFlag < 10) AND (@FilterFlag >= 10) 
   	  	BEGIN
   			EXEC P_KC_SendDoneReturnBack @NID , @CurrUser,@WillToFilterFlag
   			INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
				VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '已发货订单库存占用和库存数量还原！')				 
   	  	END
   	  	
   	  	IF (@Orig = 1)  --已归档订单
	   	BEGIN
	   		BEGIN TRAN crSave    	   	 
	   		DECLARE @ins_error int = 0
	   		   	 
	   		SET IDENTITY_INSERT P_Trade ON 
	     	--驳回主表
        	INSERT INTO P_Trade([NID] 
				,[RECEIVERBUSINESS]
				,[RECEIVEREMAIL]
				,[RECEIVERID]
				,[EMAIL]
				,[PAYERID]
				,[PAYERSTATUS]
				,[COUNTRYCODE]
				,[PAYERBUSINESS]
				,[SALUTATION]
				,[FIRSTNAME]
				,[MIDDLENAME]
				,[LASTNAME]
				,[SUFFIX]
				,[ADDRESSOWNER]
				,[ADDRESSSTATUS]
				,[SHIPTONAME]
				,[SHIPTOSTREET]
				,[SHIPTOSTREET2]
				,[SHIPTOCITY]
				,[SHIPTOSTATE]
				,[SHIPTOZIP]
				,[SHIPTOCOUNTRYCODE]
				,[SHIPTOCOUNTRYNAME]
				,[SHIPTOPHONENUM]
				,[TRANSACTIONID]
				,[PARENTTRANSACTIONID]
				,[RECEIPTID]
				,[TRANSACTIONTYPE]
				,[PAYMENTTYPE]
				,[ORDERTIME]
				,[AMT]
				,[CURRENCYCODE]
				,[FEEAMT]
				,[SETTLEAMT]
				,[TAXAMT]
				,[EXCHANGERATE]
				,[PAYMENTSTATUS]
				,[PENDINGREASON]
				,[REASONCODE]
				,[PROTECTIONELIGIBILITY]
				,[PROTECTIONELIGIBILITYTYPE]
				,[INVNUM]
				,[CUSTOM]
				,[NOTE]
				,[SALESTAX]
				,[BUYERID]
				,[CLOSINGDATE]
				,[MULTIITEM]
				,[TIMESTAMP]
				,[SHIPDISCOUNT]
				,[INSURANCEAMOUNT]
				,[CORRELATIONID]
				,[ACK]
				,[VERSION]
				,[BUILD]
				,[SHIPPINGAMT]
				,[HANDLINGAMT]
				,[SHIPPINGMETHOD]
				,[SHIPAMOUNT]
				,[SHIPHANDLEAMOUNT]
				,[SUBJECT]
				,[EXPECTEDECHECKCLEARDATE]
				,[Guid]
				,[BUSINESS]
				,[User]
				,[TotalWeight]
				,[ExpressNID]
				,[ExpressFare]
				,[logicsWayNID]
				,[SelFlag]
				,[TrackNo]
				,[ExpressFare_Close]
				,[ExpressStatus]
				,[EvaluateStatus]
				,[TransMail]
				,[FilterFlag]
				,[PrintFlag]
				,[ShippingStatus]
				,[MergeFlag]
				,[Memo]
				,[AdditionalCharge]
				,[InsuranceFee]
				,[AllGoodsDetail]
				,[CheckOrder]
				,[GoodItemIDs]
          		,[BatchNum]
          		,[PackingMen]       ---增加以下几个后期新增加的字段 陈卫  
				,[PackageMen]
				,[PaidanDate]
				,[PaidanMen]
				,[ScanningMen]
				,[WeighingMen]
				,[ScanningDate]
				,[WeighingDate]
				,[OrigPackingMen]
				,[OrigPackageMen]
				,[GoodsCosts]
				,[ProfitMoney]
				,[doorplate]
				) 
            SELECT 
            	[NID]
				,[RECEIVERBUSINESS]
				,[RECEIVEREMAIL]
				,[RECEIVERID]
				,[EMAIL]
				,[PAYERID]
				,[PAYERSTATUS]
				,[COUNTRYCODE]
				,[PAYERBUSINESS]
				,[SALUTATION]
				,[FIRSTNAME]
				,[MIDDLENAME]
				,[LASTNAME]
				,[SUFFIX]
				,[ADDRESSOWNER]
				,[ADDRESSSTATUS]
				,[SHIPTONAME]
				,[SHIPTOSTREET]
				,[SHIPTOSTREET2]
				,[SHIPTOCITY]
				,[SHIPTOSTATE]
				,[SHIPTOZIP]
				,[SHIPTOCOUNTRYCODE]
				,[SHIPTOCOUNTRYNAME]
				,[SHIPTOPHONENUM]
				,[TRANSACTIONID]
				,[PARENTTRANSACTIONID]
				,[RECEIPTID]
				,[TRANSACTIONTYPE]
				,[PAYMENTTYPE]
				,[ORDERTIME]
				,[AMT]
				,[CURRENCYCODE]
				,[FEEAMT]
				,[SETTLEAMT]
				,[TAXAMT]
				,[EXCHANGERATE]
				,[PAYMENTSTATUS]
				,[PENDINGREASON]
				,[REASONCODE]
				,[PROTECTIONELIGIBILITY]
				,[PROTECTIONELIGIBILITYTYPE]
				,[INVNUM]
				,[CUSTOM]
				,[NOTE]
				,[SALESTAX]
				,[BUYERID]
				,[CLOSINGDATE]
				,[MULTIITEM]
				,[TIMESTAMP]
				,[SHIPDISCOUNT]
				,[INSURANCEAMOUNT]
				,[CORRELATIONID]
				,[ACK]
				,[VERSION]
				,[BUILD]
				,[SHIPPINGAMT]
				,[HANDLINGAMT]
				,[SHIPPINGMETHOD]
				,[SHIPAMOUNT]
				,[SHIPHANDLEAMOUNT]
				,[SUBJECT]
				,[EXPECTEDECHECKCLEARDATE]
				,[Guid]
				,[BUSINESS]
				,[User]
				,[TotalWeight]
				,[ExpressNID]
				,[ExpressFare]
				,[logicsWayNID]
				,[SelFlag]
				,[TrackNo]
				,[ExpressFare_Close]
				,[ExpressStatus]
				,[EvaluateStatus]
				,[TransMail]
				,[FilterFlag]
				,[PrintFlag]
				,[ShippingStatus]
				,[MergeBillID]
				,[Memo]
				,[AdditionalCharge]
				,[InsuranceFee]
				,[AllGoodsDetail]
				,[CheckOrder]
				,[GoodItemIDs] 
          		,[BatchNum]
                ,[PackingMen]	---增加以下几个字段 陈卫        
				,[PackageMen]		
				,[PaidanDate]
				,[PaidanMen]
				,[ScanningMen]
				,[WeighingMen]
				,[ScanningDate]
				,[WeighingDate]
				,[OrigPackingMen]
				,[OrigPackageMen]
				,[GoodsCosts]
				,[ProfitMoney]
				,[doorplate]				
            FROM P_Trade_His 
            	WHERE NID = @NID
             
            SELECT @ins_error=@@Error 
            TRUNCATE TABLE #CodeRuleGet
            INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 220,''
            SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
            
            ---已归档的,强制只能驳回到已发货,此功能实际已跳过了 '反归档' 的权限控制
            UPDATE P_Trade SET ExpressStatus=1,FilterFlag=100,BatchNum= @CodeRuleGet WHERE nid= @NID 
            SELECT @ins_error = @ins_error + @@Error 
            
            --驳回明细表
            INSERT INTO P_TradeDt([TradeNID]
                                    ,[L_EBAYITEMTXNID]
                                    ,[L_NAME]
                                    ,[L_NUMBER]
                                    ,[L_QTY]
                                    ,[L_SHIPPINGAMT]
                                    ,[L_HANDLINGAMT]
                                    ,[L_CURRENCYCODE]
                                    ,[L_AMT]
                                    ,[L_OPTIONSNAME]
                                    ,[L_OPTIONSVALUE]
                                    ,[L_TAXAMT]
                                    ,[SKU]
                                    ,[CostPrice]
                                    ,[AliasCnName]
                                    ,[AliasEnName]
                                    ,[Weight]
                                    ,[DeclaredValue]
                                    ,[OriginCountry]
                                    ,[OriginCountryCode]
                                    ,[BmpFileName]
                                    ,[GoodsName]
                                    ,[GoodsSKUID]
                                    ,[StoreID]
                                    ,[eBaySKU] --增加字段
                                    ,[L_ShipFee]
                                    ,[L_TransFee]
                                    ,[L_ExpressFare]
                                    ,[BuyerNote]
                                    )
		             SELECT         [TradeNID]
                                    ,[L_EBAYITEMTXNID]
                                    ,[L_NAME]
                                    ,[L_NUMBER]
                                    ,[L_QTY]
                                    ,[L_SHIPPINGAMT]
                                    ,[L_HANDLINGAMT]
                                    ,[L_CURRENCYCODE]
                                    ,[L_AMT]
                                    ,[L_OPTIONSNAME]
                                    ,[L_OPTIONSVALUE]
                                    ,[L_TAXAMT]
                                    ,[SKU]
                                    ,[CostPrice]
                                    ,[AliasCnName]
                                    ,[AliasEnName]
                                    ,[Weight]
                                    ,[DeclaredValue]
                                    ,[OriginCountry]
                                    ,[OriginCountryCode]
                                    ,[BmpFileName]
                                    ,[GoodsName]
                                    ,[GoodsSKUID]
                                    ,[StoreID]
                                    ,[eBaySKU] --增加字段 
                                    ,[L_ShipFee]
                                    ,[L_TransFee]
                                    ,[L_ExpressFare] 
                                    ,[BuyerNote]                                   
            FROM P_TradeDt_His 
            	WHERE TradeNID = @NID
            SELECT @ins_error = @ins_error + @@Error  
            
            --删除历史订单 
            DELETE FROM P_TradeDt_His WHERE TradeNID = @NID
            DELETE FROM P_Trade_His   WHERE NID = @NID
            --提交事务
            IF (@ins_error = 0) 
            BEGIN 				            	            	
            	COMMIT TRAN crSave
            	SET @RetMsg = @RetMsg + '已归档订单"'+@NID+'"只能驳回到已发货,驳回成功!'  +char(13)   
            	INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
            		VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '归档订单转到已发货')                
            END 
            ELSE
            begin				
            	ROLLBACK TRAN crSave
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败!'+char(13);
            end
            
	   	END	   	
	   	--驳到 待派单                                                                                                        
	   	else IF ((@Orig = 0) AND (@FilterFlag > 5) AND (@ToFlag = '1'))  
	   	begin
	   		BEGIN TRAN crSave2    	   	 	   	
   			DECLARE @ins_error2 INT  = 0
   			SET NOCOUNT ON;
   			if @WillToFilterFlag = 5 and @FilterFlag< 100
   			begin
   			  insert into #ret EXEC P_KC_FreeReservationNum @NID		--释放库存占用	
   			end   		
   			SELECT @ins_error2 = @ins_error2 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
        	INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 150,''
        	
        	SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
        	SELECT @ins_error2 = @ins_error2 + @@Error 	   	
   			UPDATE P_Trade
   			SET   FilterFlag = 5,--ExpressNID = 0,	      logicsWayNID = 0,
        	    AdditionalCharge = 0, InsuranceFee = 0, 
        	    RestoreStock=0,      
        	    ExpressStatus=0,
        	    BatchNum= @CodeRuleGet
   			WHERE NID = @NID
   			SELECT @ins_error2 = @ins_error2 + @@Error	
   				   		
   			--提交事务
			IF (@ins_error2 = 0) 
			BEGIN
				COMMIT TRAN crSave2
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功1!'  +char(13)     	 
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
        			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[待派单]！')   
			END 
			else
			begin				
            	ROLLBACK TRAN crSave2
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败1!'+char(13);
            end
	   	END 
	   	--驳回到 E邮宝/非E邮宝 ,即已派单但未转仓库  	   	
	   	ELSE IF ((@Orig = 0) AND (@FilterFlag >=20) AND (@ToFlag = '2'))  --原为 @FilterFlag>5, 改为>=20
	    begin
	    	BEGIN TRAN crSave3    	   	 	   	
   			DECLARE @ins_error3 INT = 0
   			SELECT @ins_error3 = @ins_error3 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
	    	IF isNull(@eub,0) IN (1,2,3)		--特定物流方式,EUB/4PX,原条件为(1,2,3,4),实际是(1,2,3) 4为无特定物流
	    	BEGIN 	   		
        		INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 160,''
        		SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
        		
        		UPDATE P_Trade 
        		SET FilterFlag = 6, RestoreStock=-1,
        		    ExpressStatus = 0,BatchNum=@CodeRuleGet 
        		WHERE NID = @NID             
        	END ELSE				--其它物流方式
        	BEGIN
        		INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 170,''	
        		SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
        		UPDATE P_Trade 
        		SET FilterFlag = 6,ExpressStatus = 0,
        		    BatchNum=@CodeRuleGet 
        		WHERE NID = @NID
        	END  
        	SELECT @ins_error3 = @ins_error3 + @@Error	            	   			   		
   			--提交事务
			IF (@ins_error3 = 0) 
			BEGIN
				COMMIT TRAN crSave3
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功!'  +char(13)
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
        			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[E邮宝/非E邮宝]！')   
			END 
			ELSE 
			begin				
            	ROLLBACK TRAN crSave3
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败2!'+char(13);
            end
	   	END
	   	--驳回到 待包装--未拣货   	   	 
	   	ELSE IF ((@Orig = 0) AND (@FilterFlag > 20) AND (@ToFlag = '3'))  
	   	begin
	  		BEGIN TRAN crSave4    	   	 	   	
   			DECLARE @ins_error4 INT   = 0 		
   			SELECT @ins_error4 = @ins_error4 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
      		INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 180,''
      	
      		SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
      		SELECT @ins_error4 = @ins_error4 + @@Error 	   	
   			
   			UPDATE P_Trade
   				SET  FilterFlag = 20, BatchNum= @CodeRuleGet, RestoreStock=-1
      	 		,ExpressStatus=0 --ExpressNID = 0,
   	 		WHERE NID = @NID
   	 		SELECT @ins_error4 = @ins_error4 + @@Error		   			   		
   			
   			--提交事务
			IF (@ins_error4 = 0) 
			BEGIN
				COMMIT TRAN crSave4
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功!'  +char(13)
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
      	  			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[待包装--未拣货]！')   
			END 
	  		ELSE 
			begin				
            	ROLLBACK TRAN crSave4
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败3!'+char(13);
            end
	   	END
	   	--驳回到 待包装--未核单    	   	 
	   	ELSE  IF ((@Orig = 0) AND (@FilterFlag >= 22) AND (@ToFlag = '4'))  
	   	begin	   		
	   		BEGIN TRAN crSave5    	   	 	   	
   			DECLARE @ins_error5 INT  = 0  		
   			SELECT @ins_error5 = @ins_error5 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
       		INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 190,''
       	
       		SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
       		SELECT @ins_error5 = @ins_error5 + @@Error 	   	
   	 		
   	 		UPDATE P_Trade
   				SET  FilterFlag = 22,  BatchNum= @CodeRuleGet, RestoreStock=-1
       	     	,ExpressStatus=0   --ExpressNID = 0,               
   	 		WHERE NID = @NID
   	 		SELECT @ins_error5 = @ins_error5 + @@Error		   			   		
   			
   			--提交事务
			IF (@ins_error5 = 0) --原来为 @ins_error4, 变量出错,导致回滚事务
			BEGIN
				COMMIT TRAN crSave5
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功!'  +char(13)
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
       	  			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[待包装--未核单]！')   
			END 
	  		ELSE 
			begin				
            	ROLLBACK TRAN crSave5
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败4!'+char(13);
            end
	   	END 
	   	--驳回到 待包装--未包装 	   	
	   	ELSE  IF ((@Orig = 0) AND (@FilterFlag > 24) AND (@ToFlag = '5'))  
	   	BEGIN
	   		BEGIN TRAN crSave6    	   	 	   	
   			DECLARE @ins_error6 INT   = 0 		
   			SELECT @ins_error6 = @ins_error6 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
        	INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 200,''
        	
        	SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
        	SELECT @ins_error6 = @ins_error6 + @@Error 	   	
   			
   			UPDATE P_Trade
   				SET  FilterFlag = 24, BatchNum= @CodeRuleGet, RestoreStock=-1
        	     , ExpressStatus=0 --ExpressNID = 0,
   	 		WHERE NID = @NID
   	 		SELECT @ins_error6 = @ins_error6 + @@Error		   			   		
   			--提交事务
			IF (@ins_error6 = 0) 
			BEGIN
				COMMIT TRAN crSave6
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功!'  +char(13)
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
        			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[待包装--未包装]！')   
			END  
	  		ELSE 
			begin				
            	ROLLBACK TRAN crSave6
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败5!'+char(13);
            end
	   	END 
	   	 --已发货 驳到 待发货
	   	ELSE IF ((@Orig = 0) AND (@FilterFlag >= 100) AND (@ToFlag = '6'))  
	   	BEGIN
	   		BEGIN TRAN crSave7    	   	 	   	
   			DECLARE @ins_error7 INT  = 0  		
   			SELECT @ins_error7 = @ins_error7 + @@Error  
   			TRUNCATE TABLE #CodeRuleGet
        	INSERT INTO #CodeRuleGet EXEC  P_S_CodeRuleGet 210,''
        	
        	SET @CodeRuleGet = (SELECT TOP 1 RuleCode FROM #CodeRuleGet)
        	SELECT @ins_error7 = @ins_error7 + @@Error 	   	
   			
   			UPDATE P_Trade
   				SET FilterFlag = 40,ExpressStatus=0,
        	    RestoreStock=-1,      
        	    BatchNum= @CodeRuleGet
   	 		WHERE NID = @NID
   	 		SELECT @ins_error7 = @ins_error7 + @@Error		   			   		
   			--提交事务
			IF (@ins_error7 = 0) 
			BEGIN
				COMMIT TRAN crSave7
				SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回成功!'  +char(13)
				INSERT INTO [P_TradeLogs]([TradeNID],[Operator],[Logs])
        			VALUES(@NID, @CurrUser ,@CurrUser+ Convert(varchar(25),GetDate(),121)+ '订单驳回到[待发货]！')   
			END 
	  		ELSE 
			begin				
            	ROLLBACK TRAN crSave7
            	SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败!'+char(13);
            end
	    END
	    else ----以上条件都不符合的,输出失败信息
	    begin
			SET @RetMsg = @RetMsg + '订单"'+@NID+'"驳回失败6!!!!!'+char(13);
	    end;                                                                                    

	END   -- while结束
	CLOSE CurOrderReturnBack
	DEALLOCATE CurOrderReturnBack	  
	DROP TABLE #CodeRuleGet    
	DROP TABLE #OrderReturnBack    
	DROP TABLE  #ret
	set @ReturnMsg=@RetMsg 
END
