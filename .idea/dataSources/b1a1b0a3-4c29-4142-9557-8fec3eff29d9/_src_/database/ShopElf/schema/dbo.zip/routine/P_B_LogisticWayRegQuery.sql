CREATE Proc [P_B_LogisticWayRegQuery] 
	@LogicNID int
as
begin
		insert into B_LogisticWayReg([platform],logisticwayNID,upflag,CarrierEN)
		select ModuleName
				,@LogicNID,0,
				ISNULL((select top 1 
					code 
					from B_LogisticWay where NID=@LogicNID),'') 
		from P_SyncIncrement p 
		where modulename not in (select [PLATFORM] from B_LogisticWayReg  
							where logisticwayNID=@LogicNID)
							
	select [platform]= case when [platform]='trades' then 'ebay' else [platform] end,
			regex,upflag,trackmemo,logisticwaynid,nid,CarrierEN,
			CarrierUrl = (select top 1 CarrierUrl from P_SyncIncrement where ModuleName=B_LogisticWayReg.Platform )
			,CarrierUrll = (select top 1 case when len(CarrierUrl)>0 then '点击查看' else '' end 
			from P_SyncIncrement where ModuleName=B_LogisticWayReg.Platform )
	from B_LogisticWayReg 
	where logisticwayNID=@LogicNID

end
