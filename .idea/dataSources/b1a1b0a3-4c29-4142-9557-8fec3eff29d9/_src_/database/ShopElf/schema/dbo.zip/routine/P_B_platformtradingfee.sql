 
CREATE Proc [dbo].[P_B_platformtradingfee] 
@GoodsNid int
as
begin
insert into B_platformtradingfee([platform],GoodsNID)
   select   ModuleName    ,@GoodsNid   
from P_SyncIncrement p 
where modulename not in (select [PLATFORM] from B_platformtradingfee  
where GoodsNID=@GoodsNid )   and  modulename <> 'trades'
    union 
  select 'eBay', @GoodsNid from P_SyncIncrement where modulename = 'trades'
    and  'eBay' not in (select [PLATFORM] from B_platformtradingfee  
  where GoodsNID=@GoodsNid ) 
 
select   [platform] ,
 tradingfee, nid  
from B_platformtradingfee where GoodsNID = @GoodsNid  
   
end


