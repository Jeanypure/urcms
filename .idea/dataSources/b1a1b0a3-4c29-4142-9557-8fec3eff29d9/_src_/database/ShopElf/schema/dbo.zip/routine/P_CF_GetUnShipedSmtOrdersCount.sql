Create Proc [dbo].[P_CF_GetUnShipedSmtOrdersCount]
	
	@ANid varchar(100)='',
	@Ack varchar(100)='',
	@MergeBillID varchar(100)='' -- 空-非合并订单 ,非空-合并订单的订单编号
as
begin
  -- 速卖通同一个拆分订单订单数量(未发货)
  set @Ack=REPLACE(@Ack,'''','''''');
  declare 
		@fSql  varchar(8000);
  set @fSql='';
  if @MergeBillID=''
  begin
    -- 非合并订单
     set @fSql='select count(1) as OrderNum from ('
           +'select nid from P_Trade with(nolock) '
           +' where nid<>'+@ANid
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Tradeun with(nolock) '
           +' where nid<>'+@ANid
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Trade_his with(nolock) '
           +' where nid<>'+@ANid
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Trade_b with(nolock) '
           +' where Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +') m'
   
  end
  else
  begin
    -- 合并订单
     set @fSql='select count(1) as OrderNum from ('
           +'select nid from P_Trade with(nolock) '
           +' where nid<>'+@MergeBillID
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Tradeun with(nolock) '
           +' where nid<>'+@MergeBillID
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Trade_his with(nolock) '
           +' where nid<>'+@MergeBillID
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +' union all '
           +'select nid from P_Trade_b with(nolock) '
           +' where nid<>'+@ANid
           +' and Ack='''+@Ack+''' '
           +' and isnull(ADDRESSOWNER,'''')=''aliexpress'' '
           +' and ISNULL(SHIPPINGMETHOD,''0'')<>''1'' '
           +') m'
   
  end
   
   exec(@fSql)	;
end
