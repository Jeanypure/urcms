
create Proc [dbo].[P_CG_CanceStockOrderInAmount]
	@StockInBillnumber		Varchar(20)=''
as
begin
  DECLARE @StockOrderBillnumber varchar(20) = '' 
  select @StockOrderBillnumber = StockOrder from CG_StockInM m where  m.BillNumber=@StockInBillnumber            
  update  OD  
    set  OD.InAmount= OD.InAmount - isnull((select SUM(amount) from CG_StockInD d 
			inner join CG_StockInM m  on m.NID=d.StockInNID  
			where  m.BillNumber=@StockInBillnumber and
			       m.CheckFlag<>3 and od.GoodsSKUID=d.GoodsSKUID group by d.GoodsSKUID),0)
    from   
      CG_StockOrderD OD  
    inner join    
      CG_StockOrderM OM on om.NID=od.StockOrderNID 
         and om.BillNumber=@StockOrderBillnumber
    
end
