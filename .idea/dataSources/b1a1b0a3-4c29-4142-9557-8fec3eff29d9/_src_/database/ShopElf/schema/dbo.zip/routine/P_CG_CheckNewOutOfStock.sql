CREATE PROCEDURE [dbo].[P_CG_CheckNewOutOfStock]
	 @TradeNids VARCHAR(max) = ''
AS
BEGIN	
	SET NOCOUNT ON;		
	DECLARE @TradeNids_Bak  VARCHAR(max) = '',
	  @piPeiHaveGoods int
	  
	  
	set @piPeiHaveGoods = (select CONVERT(int, IsNull(paraValue,0)) from B_SysParams where ParaCode = 'PiPeiHaveGoodsStore')
	
	SET @TradeNids_Bak = @TradeNids
	CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
    DECLARE @sSQLCmd varchar(8000) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    while (PATINDEX('%,%', @TradeNids) > 0)
    begin
      set @index = PATINDEX('%,%', @TradeNids) - 1
      set @temp = SubString(@TradeNids,1,@index) 
      set @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
     
      if (LEN(@sSQLCmd)> 7500)
      begin
        exec(@sSQLCmd)
        SET @sSQLCmd = 'insert into #SelRecordTable select ';
      end 
      else 
      begin 
        if (len(@sSQLCmd) > 35)
        begin         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        end else
        begin
          SET @sSQLCmd = @sSQLCmd + @temp 
        end         
      end      
    end 
    if (len(@sSQLCmd) > 35)
    exec(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    exec(@sSQLCmd)
   
 ----------------------------------------------------------------------
   --add by ylq 2016-08-10  如果补货检测 直接分配到已有数量的仓库中去
   if (@piPeiHaveGoods = 1) begin
    
    select SUM(LineCount) as LineCount, TradeNid into #TabNum
    from (
     select A.TradeNid, 1 as linecount from P_TradeDtUn A
         inner join #SelRecordTable C on C.TradeNid = A.TradeNID 
         group By  A.TradeNid, GoodsSkuID
         ) A  group by TradeNid
          
         
     select B.StoreID, A.TradeNID, Sum(1) as LineCount into #TabStore
       from 
       ( select A.TradeNid, GoodsSkuID,SUM(L_Qty) as L_Qty from P_TradeDtUn A
         inner join #SelRecordTable C on C.TradeNid = A.TradeNID 
         group By  A.TradeNid, GoodsSkuID
       ) A
       inner join KC_CurrentStock B on A.GoodsSKUID = B.GoodsSKUID
       inner join B_Store sto on B.StoreID = sto.NID  
       where (B.Number - B.ReservationNum) >= A.L_QTY and IsNull(sto.IsVirtual,0) = 0
       group by B.StoreID, A.TradeNID 
       
    update P_TradeDtUn set StoreID = B.StoreID 
      from P_TradeDtUn A, #TabStore B
      where A.TradeNID = B.TradeNID
      and B.LineCount >= (select COUNT(*) from #TabNum where TradeNID = A.TradeNID  )
      
    drop table #TabNum
    drop table #TabStore
   end
 
   
   ----------------------------------------------------------------------- 
   
    --统计被选择记录所有的缺货产品，原来没生成过的
    CREATE TABLE #AllOutStockGoods
	(		
		GoodsSKUID INT NOT NULL DEFAULT 0,
		StoreID INT NOT NULL DEFAULT 0,
		OutNumber NUMERIC(10,2) NOT NULL DEFAULT 0,
		CanUseNum NUMERIC(10,2) NOT NULL DEFAULT 0
	) 
	
    CREATE TABLE #AllOutStockGoods1  
	(		
		GoodsSKUID INT NOT NULL DEFAULT 0,
		StoreID INT NOT NULL DEFAULT 0,
		ResNum NUMERIC(10,2) NOT NULL DEFAULT 0
	) 	
   --删除库存未关联的订单	
   DELETE FROM #SelRecordTable WHERE TradeNid IN ( SELECT DISTINCT ptdu.TradeNID       
                                                   FROM P_TradeDtUn ptdu JOIN #SelRecordTable srt ON ptdu.TradeNID = srt.TradeNid
                                                   WHERE ISNULL(ptdu.GoodsSKUID,0) = 0 OR ISNULL(ptdu.StoreID,0) = 0) 	
   INSERT INTO #AllOutStockGoods(GoodsSKUID
                                 ,StoreID
                                 ,OutNumber
                                 ,CanUseNum
                                 ) --占用数量
                                 
   SELECT                       ptdu.GoodsSKUID
                               ,ptdu.StoreID
                               ,SUM(ISNULL(ptdu.L_QTY,0)) AS OutNumber
                               ,0   
   FROM P_TradeDtUn ptdu 
   inner JOIN #SelRecordTable srt ON ptdu.TradeNID = srt.TradeNid
   WHERE 
   --ISNULL(ptdu.L_SHIPPINGAMT,0) = 0 AND 屏蔽掉，否则即使补货也不知道是否足了。
   ISNULL(ptdu.GoodsSKUID,0) <> 0 AND ISNULL(ptdu.StoreID,0) <> 0
   GROUP BY ptdu.GoodsSKUID, ptdu.StoreID  
   
   --生成GoodsSKUID 及 StoreId对应的缺货 占用的数量
   INSERT INTO #AllOutStockGoods1(GoodsSKUID
                                 ,StoreID
                                 ,ResNum) --占用数量
                                 
   SELECT                       ptdu.GoodsSKUID
                               ,ptdu.StoreID
                               ,SUM(ISNULL(ptdu.L_QTY,0))   
   FROM P_TradeDtUn ptdu 
   inner JOIN #AllOutStockGoods ag ON ag.StoreID = ptdu.StoreID and ag.GoodsSKUID=ptdu.GoodsSKUID
   inner join P_TradeUn pu on pu.NID=ptdu.TradeNID
   WHERE 
   pu.RestoreStock=-1 and pu.FilterFlag = 1 and 
   ISNULL(ptdu.GoodsSKUID,0) <> 0 AND ISNULL(ptdu.StoreID,0) <> 0
   GROUP BY ptdu.GoodsSKUID, ptdu.StoreID        
    
   --统计当前库存的所有可用数量 

   UPDATE aosg
   SET aosg.CanUseNum = ISNULL(kcs.Number,0) - (ISNULL(kcs.ReservationNum,0)- isnull(aosg1.ResNum,0))
   FROM #AllOutStockGoods aosg
   inner JOIN KC_CurrentStock kcs  ON kcs.StoreID = aosg.StoreID AND kcs.GoodsSKUID = aosg.GoodsSKUID
   left outer JOIN  #AllOutStockGoods1 aosg1 ON aosg1.StoreID = aosg.StoreID AND aosg1.GoodsSKUID = aosg.GoodsSKUID
 
   --暂时全都设置为不选择
   UPDATE pt
   SET pt.colorflag = 0
   FROM P_TradeUn pt
   -- JOIN #SelRecordTable srt ON pt.nid = srt.TradeNid  
   --暂时全都设置为缺货
   UPDATE ptdu
   SET ptdu.L_SHIPPINGAMT = 1
   FROM P_TradeDtUn ptdu JOIN #SelRecordTable srt ON ptdu.TradeNID = srt.TradeNid
   WHERE ISNULL(ptdu.GoodsSKUID,0) <> 0 AND ISNULL(ptdu.StoreID,0) <> 0
     
   --先把可用为0 的商品标记缺货，然后删除    --**0918*******************
   --UPDATE ptdu 
   --SET	L_SHIPPINGAMT = 1
   --FROM P_TradeDtUn ptdu JOIN #SelRecordTable srt ON  ptdu.TradeNID = srt.TradeNid
   --                      JOIN #AllOutStockGoods aosg ON ptdu.StoreID = aosg.StoreID AND ptdu.GoodsSKUID = aosg.GoodsSKUID  
   --WHERE aosg.CanUseNum = 0   
   --DELETE FROM #AllOutStockGoods WHERE CanUseNum = 0      
   --**0918******************* 
   
   --  select * from #AllOutStockGoods 
  --循环判断是否缺货(第一套)
  -- DECLARE @GoodsSKUID INT , @SoreID INT , @L_QTY INT , @NID INT 
  --DECLARE _TradeDtUn CURSOR
  --FOR SELECT ptd.NID, GoodsSKUID, ptd.StoreID, ISNULL(L_QTY,0) AS L_QTY
  --    FROM P_TradeDtUn ptd JOIN #SelRecordTable srt ON  ptd.TradeNID = srt.TradeNid 
  --                         JOIN P_TradeUn ptu ON ptd.TradeNID = ptu.NID
  --    ORDER BY DATEADD(HOUR,8,ptu.ORDERTIME), ptd.NID
  --OPEN _TradeDtUn
  --FETCH NEXT FROM _TradeDtUn INTO @NID, @GoodsSKUID, @SoreID, @L_QTY
  --WHILE (@@FETCH_STATUS = 0)
  --BEGIN    
  --  IF EXISTS (SELECT 1 
  --             FROM #AllOutStockGoods 
  --             WHERE StoreID = @SoreID AND GoodsSKUID = @GoodsSKUID AND CanUseNum >= @L_QTY)
  --  BEGIN
  --  	UPDATE #AllOutStockGoods 
  --  	SET CanUseNum = CanUseNum - @L_QTY 
  --  	WHERE StoreID = @SoreID AND GoodsSKUID = @GoodsSKUID
  --  	UPDATE P_tradeDtUn SET L_SHIPPINGAMT = 0 WHERE NID = @NID
  --  END ELSE
  --  BEGIN
  --  	UPDATE P_tradeDtUn SET L_SHIPPINGAMT = 1 WHERE NID = @NID
  --  END       	
  --	FETCH NEXT FROM _TradeDtUn INTO @NID, @GoodsSKUID, @SoreID, @L_QTY
  --END
  --CLOSE _TradeDtUn
  --DEALLOCATE _TradeDtUn   
  --循环判断是否缺货(第二套) 
					                                        			    
  DECLARE @aosgCount INT  = 0
  SET @aosgCount = ISNULL((SELECT COUNT(*) FROM #AllOutStockGoods),0)    
  IF @aosgCount > 0
  BEGIN 
          DECLARE @CheckCount INT   --检测成功的细表条数 dt表
		  DECLARE @TradeNid INT 
		  DECLARE _TradeUn CURSOR
		  FOR SELECT ptu.NID
			  FROM  P_TradeUn ptu JOIN #SelRecordTable srt ON  ptu.NID = srt.TradeNid                         
			  ORDER BY ptu.RestoreStock, DATEADD(HOUR,8,ptu.ORDERTIME), ptu.NID
		  OPEN _TradeUn
		  FETCH NEXT FROM _TradeUn INTO @TradeNid
		  WHILE (@@FETCH_STATUS = 0)
		  BEGIN 		
		    --判断，如果订单是占用的，那么判断可用数量 CanUseNum >= 订单数量 L_QTY 就可以了 （操作完以后要更新可用数量 和 占用数量）
		    --      如果订单是未占用的，那么判断(可用数量 CanUseNum - 占用数量 ResNum) >= 订单数量 L_QTY 才可以了 （操作完以后更新可用数量） 
		    	    
		    set @CheckCount = 0
		    --获取检测通过的细表的条数	
		    set @CheckCount = isnull((SELECT count(1)
  					   from 
  						(select TradeNID, storeid,goodsskuid,sum(l_qty) as l_qty
  								FROM P_TradeDtUn
  					    where TradeNID = @TradeNid group by TradeNID, storeid,goodsskuid ) as  ptdu 
  					   inner join  P_TradeUn pt on pt.NID=ptdu.TradeNID 
  					   inner JOIN #AllOutStockGoods aosg ON ptdu.StoreID = aosg.StoreID AND ptdu.GoodsSKUID = aosg.GoodsSKUID
  					   left join #AllOutStockGoods1 aosg1 on ptdu.StoreID = aosg1.StoreID AND ptdu.GoodsSKUID = aosg1.GoodsSKUID
  					   WHERE ptdu.TradeNID = @TradeNid AND ((isnull(pt.RestoreStock,0) = -1 and ptdu.L_QTY <= aosg.CanUseNum )    
  					                                        or (isnull(pt.RestoreStock,0) <> -1 and ptdu.L_QTY <= aosg.CanUseNum - isnull(aosg1.ResNum,0)))),0)	    
		    --如果检测大于0,表示有明细可以通过，标记可以补货的细表为不缺货	
 			if @CheckCount > 0 
  			BEGIN			
  			  
 			  --把明细信息标记成不缺货
			  UPDATE ptdu 
  			  SET L_SHIPPINGAMT = 0 
  			  FROM P_TradeDtUn ptdu 
  			  inner join  P_TradeUn pt on pt.NID=ptdu.TradeNID 
  			  inner JOIN #AllOutStockGoods aosg ON ptdu.StoreID = aosg.StoreID AND ptdu.GoodsSKUID = aosg.GoodsSKUID
  			  left join #AllOutStockGoods1 aosg1 on ptdu.StoreID = aosg1.StoreID AND ptdu.GoodsSKUID = aosg1.GoodsSKUID
			  WHERE ptdu.TradeNID = @TradeNid AND ((isnull(pt.RestoreStock,0) = -1 and ptdu.L_QTY <= aosg.CanUseNum )    
  					                                or (isnull(pt.RestoreStock,0) <> -1 and ptdu.L_QTY <= aosg.CanUseNum - isnull(aosg1.ResNum,0)))	 
  			  	  
  			  --再检查标记，如果都是0，那么表示可以补货，减去可用数量，如果占用的减去占用数量	  
  			  if isnull((SELECT SUM(ISNULL(ptd.L_SHIPPINGAMT,0)) from P_TradeDtUn ptd where ptd.TradeNID = @TradeNid),0) = 0
  			  begin	  
		        --先减去可用数量
		        UPDATE aosg 
			    SET aosg.CanUseNum = aosg.CanUseNum - ptdu.L_QTY 
			    FROM P_TradeDtUn ptdu 
		  	    inner join  P_TradeUn pt on pt.NID=ptdu.TradeNID 
			    inner JOIN #AllOutStockGoods aosg ON ptdu.StoreID = aosg.StoreID AND ptdu.GoodsSKUID = aosg.GoodsSKUID
			    left join #AllOutStockGoods1 aosg1 on ptdu.StoreID = aosg1.StoreID AND ptdu.GoodsSKUID = aosg1.GoodsSKUID
			    WHERE ptdu.TradeNID = @TradeNid AND ((isnull(pt.RestoreStock,0) = -1 and ptdu.L_QTY <= aosg.CanUseNum )    
  					                                        or (isnull(pt.RestoreStock,0) <> -1 and ptdu.L_QTY <= aosg.CanUseNum - isnull(aosg1.ResNum,0)))	 
  				
		        --如果是占用的，那么减去占用数量
		        if isnull((select top 1 RestoreStock from P_TradeUn where NID = @TradeNid),0)= -1
		        begin
		          UPDATE aosg1 
			      SET aosg1.ResNum = aosg1.ResNum - ptdu.L_QTY 
		    	  FROM P_TradeDtUn ptdu 
			      inner join  P_TradeUn pt on pt.NID=ptdu.TradeNID 
			      inner JOIN #AllOutStockGoods1 aosg1 ON ptdu.StoreID = aosg1.StoreID AND ptdu.GoodsSKUID = aosg1.GoodsSKUID
			      WHERE ptdu.TradeNID = @TradeNid 
		        end	
		      end  
  			END 
  			else begin            --否则所有明细记录都标记为缺货
			  UPDATE ptdu 
  			  SET L_SHIPPINGAMT = 1 
  			  FROM P_TradeDtUn ptdu 
  			  where ptdu.TradeNID = @TradeNid  			
  			end      	
  			
  			FETCH NEXT FROM _TradeUn INTO @TradeNid
		  END
		  CLOSE _TradeUn
		  DEALLOCATE _TradeUn 
  END 

  --在缺货管理，生成缺货信息
	----查找派单时缺货是否写入缺货表0 不写入  1 写入
	Declare
		@SaveLogicWayIsOutOfStock int 
	set
		@SaveLogicWayIsOutOfStock =ISNULL((select top 1 ParaValue from B_SysParams 
									where ParaCode ='SaveLogicWayIsOutOfStock'),0)
  
  if @SaveLogicWayIsOutOfStock=1 
  begin
    exec P_CG_OutOfStock @TradeNids_Bak
  end
  SELECT ptd.TradeNID, SUM(ISNULL(ptd.L_SHIPPINGAMT,0)) AS IsOK 
  INTO #ProcessDone
  FROM P_TradeDtUn ptd JOIN #SelRecordTable srt ON  ptd.TradeNID = srt.TradeNid 
                       JOIN P_TradeUn ptu ON ptd.TradeNID = ptu.NID                       
  GROUP BY ptd.TradeNID
   
  --标记不缺货的
  UPDATE ptu
  SET colorFlag = 1
  FROM P_TradeUn ptu JOIN #ProcessDone pd ON ptu.NID = pd.TradeNid
  WHERE pd.IsOK = 0
  --标记缺货的
  UPDATE ptu
  SET colorFlag = 0
  FROM P_TradeUn ptu JOIN #ProcessDone pd ON ptu.NID = pd.TradeNid
  WHERE pd.IsOK > 0
  
  DECLARE @OkCount INT = 0
  IF @aosgCount > 0
  BEGIN 
    SET @OkCount = (SELECT COUNT(*) FROM #ProcessDone WHERE IsOk = 0)
  END 
  SELECT  @OkCount  AS okCount  
  drop table #AllOutStockGoods
  drop table #AllOutStockGoods1   
END
