
CREATE Proc [dbo].[P_CG_OutOfStock] @TradeNids VARCHAR(max) = ''
as
begin
	begin Tran trs_OutOfStock
	  if isnull(@TradeNids,'') = ''
	  begin
		insert into 
			CG_OutofStock(OrderTimeCN,TradeDtNID,TradeNID,StoreID,L_name,ebaysku, sku,l_Qty,L_EBAYITEMTXNID,
							ack,suffix,buyerid,sellerid,goodsname,SHIPTOCOUNTRYNAME,note,
							memo,OutOfStockType,SALESTAX)
		select 
			DateAdd(hour,8,m.ordertime),
			d.nid as TradeDtNID,d.TradeNID,d.StoreID,d.l_name,d.ebaysku,d.SKU,d.L_QTY,d.L_EBAYITEMTXNID,
				m.ack,suffix,buyerid,m.[USER],d.goodsname,m.SHIPTOCOUNTRYNAME,m.NOTE,m.Memo,0,isnull(m.SALESTAX,0)
		from 
			P_TradeDtUn d
		inner join 
			P_TradeUn m on m.NID = d.TradeNID 
		
		where 
			m.FilterFlag=1 and L_SHIPPINGAMT=1 and 
			not exists(select NID from CG_OutofStock 
							where TradeNID=d.TradeNID 
								and isnull(SKU,'')=isnull(d.SKU,'') 
								and isnull(L_EBAYITEMTXNID,'')=isnull(d.L_EBAYITEMTXNID,'') )
	  end else
	  begin
	    SET NOCOUNT ON;		
		CREATE TABLE #SelRecordTable
		(
			TradeNid INT NOT NULL DEFAULT 0,
		) 
		DECLARE @sSQLCmd varchar(8000) = '', @temp varchar(20) = '', @index int = 0
		SET @sSQLCmd = 'insert into #SelRecordTable select ';
		while (PATINDEX('%,%', @TradeNids) > 0)
		begin
		  set @index = PATINDEX('%,%', @TradeNids) - 1
		  set @temp = SubString(@TradeNids,1,@index) 
		  set @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
	     
		  if (LEN(@sSQLCmd)> 7500)
		  begin
			exec(@sSQLCmd)
			SET @sSQLCmd = 'insert into #SelRecordTable select ';
		  end 
		  else 
		  begin 
			if (len(@sSQLCmd) > 35)
			begin         
			 SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
			end else
			begin
			  SET @sSQLCmd = @sSQLCmd + @temp 
			end         
		  end      
		end 
		if (len(@sSQLCmd) > 35)
		exec(@sSQLCmd)
		if (len(@TradeNids) > 0)
		begin
		  SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
		  exec(@sSQLCmd)
		end
		
		--删除库存未关联的订单	
        DELETE FROM #SelRecordTable WHERE TradeNid IN ( SELECT DISTINCT ptdu.TradeNID       
                                                        FROM P_TradeDtUn ptdu JOIN #SelRecordTable srt ON ptdu.TradeNID = srt.TradeNid
                                                        WHERE ISNULL(ptdu.GoodsSKUID,0) = 0 OR ISNULL(ptdu.StoreID,0) = 0) 
		insert into 
			CG_OutofStock(OrderTimeCN,TradeDtNID,TradeNID,StoreID,L_name,ebaysku, sku,l_Qty,L_EBAYITEMTXNID,
							ack,suffix,buyerid,sellerid,goodsname,SHIPTOCOUNTRYNAME,note,
							memo,OutOfStockType,SALESTAX)
		select 
			DateAdd(hour,8,m.ordertime),
			d.nid as TradeDtNID,d.TradeNID,d.StoreID,d.l_name,d.ebaysku,d.SKU,d.L_QTY,d.L_EBAYITEMTXNID,
				m.ack,suffix,buyerid,m.[USER],d.goodsname,m.SHIPTOCOUNTRYNAME,m.NOTE,m.Memo,0,isnull(m.SALESTAX,0)
		from 
			P_TradeDtUn d
		inner join 
			P_TradeUn m on m.NID = d.TradeNID 
	    inner join 
	        #SelRecordTable srt on srt.TradeNid = m.NID 
		
		where 
			m.FilterFlag=1 and L_SHIPPINGAMT=1 and 
			not exists(select NID from CG_OutofStock 
							where TradeNID=d.TradeNID 
								and isnull(SKU,'')=isnull(d.SKU,'') 
								and isnull(L_EBAYITEMTXNID,'')=isnull(d.L_EBAYITEMTXNID,'') )
	  end
	if @@ERROR=0
	  commit tran trs_OutOfStock
	else
	  rollback tran trs_OutOfStock	    	
end

