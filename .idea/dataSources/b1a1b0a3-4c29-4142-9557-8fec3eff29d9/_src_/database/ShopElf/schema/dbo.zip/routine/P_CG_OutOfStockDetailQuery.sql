
CREATE Proc [dbo].[P_CG_OutOfStockDetailQuery]
	@BeginDate	Varchar(30),
	@EndDate	Varchar(30), 
	@StoreID int=0,
	@Sku varchar(100)='',
    @BuyerID varchar(100)='',
    @Tradenid varchar(100)='',
    @OutOfType int = -1,
    @ServiceModth varchar(100)='',
    @salerName varchar(max)='',
    @outofstatusStr varchar(100)='-1',
    @ACK varchar(100)='',
    @IsMoHuSku int = 0	

as
begin
  CREATE TABLE #PCount(Suffix VARCHAR(200) ,
			  primary key (Suffix))
		IF LTRIM(RTRIM(@salerName)) <> ''
		BEGIN
			DECLARE @sSQLCmd VARCHAR(max) = ''
			SET @salerName = REPLACE(@salerName,',',' UNION SELECT ') 
			SET @sSQLCmd = 'INSERT INTO #PCount(Suffix) SELECT '+ @salerName
			EXEC(@sSQLCmd )
		END
		
    declare @outofstatusSqlStr varchar(2000)
	CREATE TABLE #outofstatus
		(
			outofstatus INT NOT NULL DEFAULT 0,
		) 

    set @outofstatusSqlStr = ' insert into #outofstatus '+' select ' + REPLACE(@outofstatusStr,';',' union all select  ')
    exec(@outofstatusSqlStr)
	select 
		o.OrderTimeCN,
		o.createdate,
		DATEDIFF(DAY,o.CreateDate,GETDATE()) as OutStockDays,
		o.sellerID,
		p.ACK,
		o.SUFFIX,
		o.SKU,
		o.eBaySKU,
		o.l_qty,
		o.BUYERID,
		o.SHIPTOCOUNTRYNAME,
		o.SaleMemo,
		o.StockMemo,
		o.PrintMemo,
		o.StoreMemo,
		o.ServiceMemo,
		o.NOTE,
		o.Memo,
		o.StoreID,
		s.StoreName,
		o.L_Name,
		g.GoodsName,
		g.BmpFileName,
		o.StockInNo,
		o.StockOrderNo,
		o.delivDate,
		o.InDate,	
		o.nid,
		o.TradeNID,
		o.TradeDtNID,
		o.serviceMethod,
		ss.SupplierName,
		case when o.DespatchTime IS null then '' else CONVERT(varchar(19),o.DespatchTime,121) end as DespatchTime,
		case when o.GoodsSendTime IS null then '' else CONVERT(varchar(19),o.GoodsSendTime,121) end as GoodsSendTime,
		case when o.OutOfStockType=0 then '派单缺货' else '仓库缺货' end OutOfStockType,
		g.GoodsStatus,
		OutOfStockStatus =case when  o.OutOfStockStatus =0 then '采购未处理' 
								 when  o.OutOfStockStatus =1 then '不采购' 
								  when  o.OutOfStockStatus =2 then '已采购未到货' 
								   when  o.OutOfStockStatus =3 then '已到货未入库'
								   else '已完成' end,
		isnull(kc.Number,0)-isnull(kc.ReservationNum,0) as storecount,
		o.SALESTAX

	from 
		dbo.CG_OutofStock  o
	left outer join 
		P_TradeUn p on p.NID=o.TradeNID
	left outer join 
		B_Store s on s.NID=o.StoreID	
	left outer join 
		B_goodsSKU gs on gs.sku=o.sku	
	left outer join 
		B_goods g on g.NID=gs.GoodsID	
	left outer join 
		KC_CurrentStock kc on kc.GoodsSKUID=gs.NID and kc.StoreID=o.StoreID 
	left outer join
		B_Supplier ss  on ss.nid=g.SupplierID			
	where	
		 CONVERT(varchar(10),o.CreateDate,121) between @BeginDate and @EndDate 
		 --and (@Sku='' or o.SKU like '%'+@Sku + '%')
		 and (((@SKU='' or o.SKU=@SKU) and (@IsMoHuSku=0)) or
	                   ((o.SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
		 
		 and (@StoreID=0 or o.StoreID =@StoreID)
		 and (@BuyerID='' or o.BuyerID =@BuyerID)	
		 and (@Tradenid='' or o.TradeNID =@Tradenid)	
		 and (@OutOfType=-1 or OutOfStockType =@OutOfType)	
		 and (@ServiceModth='' or ServiceMethod =@ServiceModth)	
		 and (@salerName='' or @salerName='0' or o.SUFFIX in (select Suffix from #PCount))	
		 and (@outofstatusStr='-1' or o.OutOfStockStatus  in  (select outofstatus from #outofstatus))
		 and (@ACK='' or p.ACK=@ACK)	
		 
	drop table #outofstatus		
	drop table #PCount  		 
end
