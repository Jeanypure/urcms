CREATE Proc [dbo].[P_CG_OutOfStockQuery]
	@OutOfStockStatus int=0,
	@BeginDate	Varchar(30),
	@EndDate	Varchar(30), 
	@StoreID int=0,
	@Sku varchar(100)='',
    @BuyerID varchar(100)='',
    @Tradenid varchar(100)='',
    @OutOfType int = -1,
    @ServiceModth varchar(100)='',
    @salerName varchar(max)='',
    @outofstatusStr varchar(1000)='-1',
    @IsMoHuSku int = 0   --add by ylq 2015-05-20  增加模糊条件
as
begin
  CREATE TABLE #PCount(Suffix VARCHAR(200) ,
			  primary key (Suffix))
		IF LTRIM(RTRIM(@salerName)) <> ''
		BEGIN
			DECLARE @sSQLCmd VARCHAR(max) = ''
			SET @salerName = REPLACE(@salerName,',',' UNION SELECT ') 
			SET @sSQLCmd = 'INSERT INTO #PCount(Suffix) SELECT '+ @salerName
			EXEC(@sSQLCmd )
		END
		
	Create Table #OutOfStockQuery
	(
		SKU					varchar(200),
		StoreID				int default 0,
		SaleNum				int default 0,
		StockOrderNotInNum	int default 0,
		NotInStockNum		int default 0,
		StoreNum			int default 0,
		StoreZyNum			int default 0,
		LessNum				int default 0,
		qhzyNum				int default 0		
	)	
	Create Table #OutOfStockQuery1
	(
		SKU					varchar(200),
		StoreID				int default 0,
		SaleNum				int default 0,
		StockOrderNotInNum	int default 0,
		NotInStockNum		int default 0,
		StoreNum			int default 0,
		StoreZyNum			int default 0,		
		LessNum				int  default 0,
		qhzyNum				int default 0
	)	
	CREATE TABLE #outofstatus
		(
			outofstatus INT NOT NULL DEFAULT 0,
		) 

    set @outofstatusStr = ' insert into #outofstatus '+' select ' + REPLACE(@outofstatusStr,';',' union all select ')
    PRINT @outofstatusStr
    exec(@outofstatusStr)
	--插入标处理
	insert into #OutOfStockQuery(sku,storeid,saleNum)
	select 
		SKU,
		StoreId,
		sum(l_qty)
	from 
		CG_OutofStock 
	where	
		 OutOfStockStatus=@OutOfStockStatus and
		 CONVERT(varchar(10),CreateDate,121) between @BeginDate and @EndDate 
		 --and (@Sku='' or SKU =@Sku )
		 and (((@SKU='' or SKU=@SKU) and (@IsMoHuSku=0)) or
	                   ((SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
		 and (@StoreID=0 or StoreID =@StoreID)	
		 and (@BuyerID='' or BuyerID =@BuyerID)	
		 and (@Tradenid='' or TradeNID =@Tradenid)	
		 and (@OutOfType=-1 or OutOfStockType =@OutOfType)	
		 and (@ServiceModth='' or ServiceMethod =@ServiceModth)	
		 and (@salerName='' or @salerName='0' or SUFFIX in (select Suffix from #PCount))	
		 and (@outofstatusStr='-1' or OutOfStockStatus  in  (select outofstatus from #outofstatus))	
	 
	group by 
		SKU,storeid
	drop table #outofstatus
				
	--插入缺货占用的
	insert into #OutOfStockQuery(sku,storeid,qhzyNum)
	select 
		d.sku,
		d.StoreID,
		sum(d.L_QTY)
	from 
		P_tradedtun d
	inner join 
		P_tradeun m on m.nid=d.TradeNID
	inner join #OutOfStockQuery oo on oo.SKU=d.SKU and oo.StoreID=d.StoreID and oo.SaleNum>0
	where 
		m.FilterFlag=1 and m.RestoreStock = -1  
	group by 
		d.sku,d.StoreID
		
	--插入采购在途的
	insert into #OutOfStockQuery(sku,storeid,StockOrderNotInNum)
	select 
		gs.sku,
		m.StoreID,
		sum(d.Amount-d.InAmount)
	from 
		CG_StockOrderD  d
	inner join 
		CG_StockOrderM m on m.nid=d.StockOrderNID
	inner join
		b_Goodssku gs on gs.nid = d.goodsskuid
	inner join #OutOfStockQuery oo on oo.SKU=gs.SKU and oo.StoreID=m.StoreID and oo.SaleNum>0		
	where 
		m.CheckFlag<>3 and (d.Amount-d.InAmount)>0 and (ISNULL(m.Archive,0) = 0) 
		--and gs.sku in (select distinct sku from #OutOfStockQuery )
	group by 
		gs.sku,m.StoreID
	--插入到货未入库的
	insert into #OutOfStockQuery (sku,storeid,NotInStockNum)
	select 
		gs.sku,
		m.StoreID,
		sum(d.Amount)
	from 
		CG_StockInD  d
	inner join 
		CG_StockInM m on m.nid=d.StockInNID
	inner join
		b_Goodssku gs on gs.nid = d.goodsskuid
	inner join #OutOfStockQuery oo on oo.SKU=gs.SKU and oo.StoreID=m.StoreID  and oo.SaleNum>0			
	where m.CheckFlag=0  and 
		(@StoreID=0 or m.StoreID =@StoreID) 		
		--and	gs.sku in (select distinct sku from #OutOfStockQuery )
	group by 
		gs.sku,m.StoreID
	--插入库存数量及占用数量
	insert into #OutOfStockQuery(sku,storeid,StoreNum,StoreZyNum)
	select 
		gs.sku,
		d.StoreID,
		sum(d.Number),
		sum(d.ReservationNum)
	from 
		KC_CurrentStock  d
	inner join
		b_Goodssku gs on gs.nid = d.goodsskuid 
	inner join #OutOfStockQuery oo on oo.SKU=gs.SKU and oo.StoreID=d.StoreID  and oo.SaleNum>0			
	where 
		(@StoreID=0 or d.StoreID =@StoreID) 
		--and	gs.sku in (select distinct sku from #OutOfStockQuery )
	group by 
		gs.sku,d.StoreID
			
	--生成汇总
	insert into  #OutOfStockQuery1
		(SKU,storeid,SaleNum,StockOrderNotInNum,NotInStockNum,StoreNum,StoreZyNum,LessNum,qhzyNum)	
	select
		sku,
		storeid,
		sum(isnull(SaleNum,0)),
		sum(isnull(StockOrderNotInNum,0)),
		sum(isnull(NotInStockNum,0)),
		sum(isnull(StoreNum,0)),
		sum(isnull(StoreZyNum,0)),
		sum(isnull(LessNum,0)),
		sum(isnull(qhzyNum,0))
	from 
		#OutOfStockQuery
	group by 
		sku,storeid	
	update
		#OutOfStockQuery1	
	set
		 LessNum =-(StoreNum-StoreZyNum+StockOrderNotInNum+NotInStockNum-SaleNum+qhzyNum)
	 
	select 
		gs.NID AS GoodsSKUID,
		q.sku,
		q.StoreID,
		q.SaleNum,
		q.StockOrderNotInNum,
		q.NotInStockNum,
		q.StoreNum as Number,
		q.StoreZyNum-q.qhzyNum as ReservationNum,
		q.StoreNum-q.StoreZyNum as kyNum,
		
		q.LessNum,
		s.SupplierName,
		g.GoodsName,
		gs.GoodsSKUStatus as GoodsStatus,
		gs.property1,
		gs.property2,
		gs.property3,
		g.Model,
		g.Class,
		g.MinNum,
		g.MaxNum,
		g.BmpFileName,
		g.SalerName,
		g.SalerName2,
		g.Purchaser,
		st.StoreName
	from 	
		#OutOfStockQuery1 q
	left outer join
		b_Goodssku gs on gs.sku=q.sku
	left outer join
		b_Goods g on g.nid=gs.GoodsID
	left outer join
		B_Supplier s  on s.nid=g.SupplierID	
	left outer join 
		B_Store st on st.NID=q.StoreID
	order by 
		sku	 
	
	drop Table #OutOfStockQuery1
	drop Table #OutOfStockQuery	
	drop table #PCount			
END
