

CREATE Proc [dbo].[P_CG_OutOfStock_KC]
	@TradedtNID	int=0,
	@OutofStockFlag int=0
as
begin
	begin Tran trs_OutOfStock_KC
	if @OutofStockFlag=1
	begin
		insert into 
			CG_OutofStock(OrderTimeCN,TradeDtNID,TradeNID,StoreID,L_name,ebaysku, sku,l_Qty,L_EBAYITEMTXNID,
							ack,suffix,buyerid,sellerid,goodsname,SHIPTOCOUNTRYNAME,note,
							memo,OutOfStockType,SALESTAX)
		select 
			DateAdd(hour,8,m.ordertime),
			d.nid as TradeDtNID,d.TradeNID,d.StoreID,d.l_name,d.ebaysku,d.SKU,d.L_QTY,d.L_EBAYITEMTXNID,
				m.ack,suffix,buyerid,m.[USER],d.goodsname,m.SHIPTOCOUNTRYNAME,m.NOTE,m.Memo	,1,isnull(m.SALESTAX,0)	
		from 
			P_TradeDt d
		inner join 
			P_Trade m on m.NID = d.TradeNID 
		
		where 
			d.NID=@TradedtNID and L_SHIPPINGAMT=1 and 
			not exists(select NID from CG_OutofStock 
							where TradeNID=d.TradeNID 
								and isnull(SKU,'')=isnull(d.SKU,'') 
								and isnull(L_EBAYITEMTXNID,'')=isnull(d.L_EBAYITEMTXNID,'') )			
	end
	else
	begin
	  delete from CG_OutofStock where OutOfStockStatus=0 and TradeDtNID=@TradedtNID
	end		
	if @@ERROR=0
	  commit tran trs_OutOfStock_KC
	else
	  rollback tran trs_OutOfStock_KC	    	
end
