CREATE proc [dbo].[P_CG_QueryDataList]
	@iType int,
	@dateType int,
	@BeginDate varchar(20),
	@EndDate varchar(20),
	@SupName varchar(100),
	@PersonName varchar(30),
	@LogisticOrderNo varchar(max),
	@KeyIndex int,
	@SkuKey varchar(1000),
	@OrderNo varchar(100),
	@BargainID varchar(100),
	@Note  varchar(1000),
	@StoreID varchar(32),
	@edt_barcode  varchar(50),
	@edt_alibabaorderid  varchar(50)  
as
begin

  set @EndDate = SUBSTRING(@EndDate,1,10) + ' 23:59:59'
  --开始查询   
   DECLARE @Sql varchar(max),
           @SqlCdt varchar(max), 
           @TmpSql varchar(max),
           @TmpCount int
           
           
        
   CREATE TABLE #LogisticTable
	(
		ColName varchar(50)
	)
	DECLARE @SqlStr VarChar(Max)
	SET @SqlStr = 'insert into #LogisticTable(ColName) select ''' + Replace(@LogisticOrderNo, ',', ''' union select ''' )
    SET @SqlStr = @SqlStr + ''''
 
	EXEC(@SqlStr)
	
   
   set @SqlCdt = ''
   
   if @iType = 0 begin
     set @SqlCdt = @SqlCdt + ' where (c.Archive=0 and  c.checkflag=0) '
   end
   else if @iType = 1 begin
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0  and not exists '+
              ' (select top 1 nid from CG_StockInM(nolock) '+
              ' where CheckFlag=0 and stockorder=c.billnumber  )) ' 
   end
   else if @iType = 99 begin -- 1688订单
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0 and alibabaorderid<>'''')  '
   end
   else if @iType = 98 begin -- 1688订单 供应商未发货
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0 '
     +' and alibabaorderid<>'''' and LogisticOrderNo='''')  '
   end
   else if @iType = 97 begin -- 1688订单 供应商已发货
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0 '
     +' and alibabaorderid<>'''' and LogisticOrderNo<>'''' and logisticsStatus<>''已收货,交易成功'')  '
   end
   else if @iType = 96 begin -- 1688订单 已到货
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0 '
     +' and alibabaorderid<>'''' and LogisticOrderNo<>'''' and logisticsStatus=''已收货,交易成功'')  '
   end
   else if @iType = 95 begin -- 非1688订单
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and c.inflag=0 '
     +' and alibabaorderid='''' ) '
   end
   else if @iType = 2 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and  c.checkflag=1 and exists '+
              ' (select top 1 nid from CG_StockInM(nolock) '+
              ' where CheckFlag=0 and stockorder=c.billnumber  )) '
   end
   else if @iType = 3 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and  c.checkflag=1 and exists '+
              ' (select top 1 nid from CG_StockInM(nolock) '+
              ' where CheckFlag=1 and stockorder=c.billnumber ) and c.inflag=1) '
   end
   else if @iType =  4 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and c.checkflag=3 ) '
   end
   else if @iType = 5 begin
     set @SqlCdt = @SqlCdt + ' where (c.Archive=1) '
   end
   else if @iType = 6 begin
     set @SqlCdt = @SqlCdt + ' where (1=1) '
   end
   
  
  if @dateType = 0 begin 
   if @BeginDate <> '' begin
     set @SqlCdt =  @SqlCdt + ' and (C.MakeDate >= convert(DateTime,''' + @BeginDate + '''))'  
   end
   if @EndDate <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.MakeDate <= convert(DateTime,''' + @EndDate + '''))'
     end
   end
   else if @dateType = 1 begin
    if @BeginDate <> '' begin
     set @SqlCdt =  @SqlCdt + ' and (C.AudieDate >= convert(DateTime,''' + @BeginDate + '''))'  
   end
   if @EndDate <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.AudieDate <= convert(DateTime,''' + @EndDate + '''))'
     end
   end
   else if @dateType = 2 begin
   if @BeginDate <> '' begin
     set @SqlCdt =  @SqlCdt + ' and (C.FinancialTime >= convert(DateTime,''' + @BeginDate + '''))'  
   end
   if @EndDate <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.FinancialTime <= convert(DateTime,''' + @EndDate + '''))'
     end
   end
   if @SupName <> '' and @SupName<>'--多供应商订单--' begin
     set @SqlCdt = @SqlCdt + ' and (G.SupplierName like ''%' + @SupName + '%'')'
   end
   if @SupName='--多供应商订单--' begin
     set @SqlCdt = @SqlCdt + ' and (c.SupplierID = 99999999)'
   end 
   if @PersonName <> '' begin
     set @SqlCdt = @SqlCdt + ' and (bo.PersonName like ''%' + @PersonName + '%'')'
   end
   if @Note <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.Memo like ''%' + @Note + '%'' or C.Note like ''%' + @Note + '%'')'
   end
   if @LogisticOrderNo <> '' begin
     select @TmpCount = COUNT(1) from #LogisticTable
     if @TmpCount = 1 begin
       set @SqlCdt = @SqlCdt + ' and (c.LogisticOrderNo like ''%' + @LogisticOrderNo + '%'')'
     end
     if @TmpCount > 1 begin
       set @SqlCdt = @SqlCdt + ' and (c.LogisticOrderNo in (select ColName from #LogisticTable) ) ';
     end
   end
   
   if @OrderNo <> '' begin
     set @SqlCdt = @SqlCdt  + @OrderNo 
   end
   if @edt_alibabaorderid <> '' begin
     set @SqlCdt = @SqlCdt + ' and (c.alibabaorderid like ''%' + @edt_alibabaorderid + '%'')'
   end
   if @BargainID <> '' begin
     set @SqlCdt = @SqlCdt + ' and (c.BargainID like ''%' + @BargainID + '%'')'
   end
   if (@StoreID <> '') and (@StoreID<>0) begin
     set @SqlCdt = @SqlCdt + ' and (c.StoreID = ' + @StoreID +  ')'
   end
    
   if @edt_barcode<> '' begin 
     set @SqlCdt = @SqlCdt + ' and (exists (select top 1 stockordernid ' +
      ' from CG_StockOrderD(nolock) where c.nid=stockordernid and exists ' +
      ' ( select top 1 gs.NID from B_goodsSKU(nolock) gs '+
            ' left outer join B_Goods(nolock) gg on gg.nid=gs.goodsid '+
            ' where CG_StockOrderD.GoodsSKUID=gs.nid and  gg.barcode = ''' + @edt_barcode + ''' '+
            ' ))) '   
   end
  
  
   if @SkuKey <> '' begin
	if  @KeyIndex = 0 begin
     set @SqlCdt = @SqlCdt + ' and (exists (select top 1 stockordernid ' +
      ' from CG_StockOrderD(nolock) where c.nid=stockordernid and exists ' +
      ' ( select top 1 gs.NID from B_goodsSKU(nolock) gs '+
            ' left outer join B_Goods(nolock) gg on gg.nid=gs.goodsid '+
            ' where CG_StockOrderD.GoodsSKUID=gs.nid and  gs.SKU  Like ''%' + @SkuKey + '%'' ))) '
     end
     if  @KeyIndex = 1 begin
     set @SqlCdt = @SqlCdt + ' and (exists (select top 1 stockordernid ' +
      ' from CG_StockOrderD(nolock) where c.nid=stockordernid and exists ' +
      ' ( select top 1 gs.NID from B_goodsSKU(nolock) gs '+
            ' left outer join B_Goods(nolock) gg on gg.nid=gs.goodsid '+
            ' where CG_StockOrderD.GoodsSKUID=gs.nid and  gg.goodsname Like ''%' + @SkuKey + '%''))) '
     end
     if  @KeyIndex = 2 begin
     set @SqlCdt = @SqlCdt + ' and (exists (select top 1 stockordernid ' +
      ' from CG_StockOrderD(nolock) where c.nid=stockordernid and exists ' +
      ' ( select top 1 gs.NID from B_goodsSKU(nolock) gs '+
            ' left outer join B_Goods(nolock) gg on gg.nid=gs.goodsid '+
            ' where CG_StockOrderD.GoodsSKUID=gs.nid and   gg.GoodsCode Like ''%' + @SkuKey + '%'' ))) '
     end
     if  @KeyIndex = 3 begin
     set @SqlCdt = @SqlCdt + ' and (exists (select top 1 stockordernid ' +
      ' from CG_StockOrderD(nolock) where c.nid=stockordernid and exists ' +
      ' ( select top 1 gs.NID from B_goodsSKU(nolock) gs '+
            ' left outer join B_Goods(nolock) gg on gg.nid=gs.goodsid '+
            ' where CG_StockOrderD.GoodsSKUID=gs.nid and  gg.SalerName Like ''%' + @SkuKey + '%'' ))) '
     end
               
   end
  /*        
  --未完全入库的采购单NID插入到临时表中
 create table #NoInTable
 (  StockNid int,
    InAmount int default 0,
    InMoney numeric(18,2) default 0
 )
 
 create index idx_StockNid1
     on #NoInTable(StockNid) 
   
 insert into #NoInTable(StockNid)
  select distinct A.Nid from CG_StockOrderM A
    left join (
      select a3.billNumber as StockOrder,  a4.GoodsSKUID,
        Sum(case when a2.InStatus = 1 and a1.CheckFlag<>3 then 1 else 0 end) as InStatus  
    from CG_StockOrderM(nolock) a3 
      inner join CG_StockOrderD(nolock) a4 on a3.Nid = a4.StockOrderNID 
      left join CG_StockInM a1 on a1.StockOrder = a3.BillNumber 
      left join CG_StockInD a2 on a1.NID = a2.StockInNID and a2.GoodsSKUID = a4.GoodsSKUID 
    where  a3.CheckFlag = 1  --and a3.Archive = 0    -- and IsNull(a1.CheckFlag,0) <> 3(不需要了） 
			and convert(varchar(10),a3.makedate,121) between @begindate and @enddate 
    group by  a3.billNumber, a4.GoodsSKUID 
    having MIN(a4.Amount) - SUM(case a1.CheckFlag when 3 then 0 else   Isnull(a2.Amount,0) end ) > 0 
    ) C on A.BillNumber = C.StockOrder  
    where  C.InStatus = 0 
     
  -- 更新入库数量和入库金额
 update #NoInTable set 
   InAmount = IsNull((select SUM(IsNull(AMount,0))  
     from CG_StockInD(nolock) A
     inner join CG_StockInM(nolock) B on A.StockInNID = B.NID 
     inner join CG_StockOrderM C on C.BillNumber = B.StockOrder 
     where C.NID = #NoInTable.StockNid and IsNull(B.CheckFlag,0) <> 3),0),
  InMoney = IsNull((select SUM(IsNull(A.Money,0))  
     from CG_StockInD(nolock) A
     inner join CG_StockInM B on A.StockInNID = B.NID 
     inner join CG_StockOrderM C on C.BillNumber = B.StockOrder 
     where C.NID = #NoInTable.StockNid and IsNull(B.CheckFlag,0) <> 3 ),0)
*/   
  --插入订单对应的总数量
 --总单量的已入库数量和未入库数量
   Create Table #OrderNumberTable
 (  StockNid int
 )
  create index idx_StockNid2
     on #OrderNumberTable(StockNid) 
 
  set @TmpSql = '
 insert into #OrderNumberTable
    select  C.Nid
      from CG_StockOrderM C 
      inner join CG_StockOrderD(nolock) D on C.Nid = D.StockOrderNid
       Left Outer join B_Supplier G on G.NID=C.SupplierID	 
   	  Left Outer join B_Person BO on  BO.NID=C.SalerID

      ' + @SqlCdt + ' group by C.Nid '
  Exec (@TmpSql) 
   
  set @Sql =  'select  convert(numeric(18,2),isnull(c.orderMoney,0)-isnull(c.alibabamoney,0)) as alibababalance,'
  +'c.logisticsStatus,c.alibabamoney,c.alibabaorderid,c.NID,C.makeDate, convert(numeric(18,2),PayMoney) as PayMoney,C.billnumber, ' +
  ' SupplierName=case when c.supplierID=99999999 then ''--多供应商订单--'' else G.SupplierName end,G.url,G.[ADDRESS]  AS SupplierADDRESS,G.OfficePhone  AS SupplierOfficePhone,G.Mobile AS SupplierMobile, ' +
    '	C.Memo,BO.PersonName,C.DelivDate,c.Recorder ,c.note, ' +
    ' case C.checkflag    when 1 then ''审核'' ' +
    '   when 3 then ''作废'' else ''未审核'' end as checkflag ,c.archive,' +
    '	C.Audier,C.AudieDate,C.DeptMan,d.Dictionaryname as BalanceName,  ' +
   -- ' AllMoney=(select sum(ISNULL(allmoney,0)) from CG_StockOrderD where StockOrderNID=c.nid), ' +
    ' convert(numeric(18,2),c.orderMoney) as AllMoney, c.OrderAmount as AllNum, ' + 
    --'  AllNum=(select sum(ISNULL(amount,0)) from CG_StockOrderD where StockOrderNID=c.nid),' + 
    ' ExpressFee,ExpressName,bs.StoreName, convert(numeric(18,2),DisCountMoney) as DisCountMoney, ' +
    ' FinancialMan,FinancialTime,C.BargainID,C.LogisticOrderNo, ' +
    ' case when  c.OrderAmount-c.InAmount >0 then 
        c.OrderAmount-c.InAmount  else 0 end as NoInAmount, ' +
    ' case when c.OrderMoney-c.inMoney >0 then 
        round(c.OrderMoney-c.inMoney,2,1) else 0 end as NoInMoney,' +
    ' c.InMoney, ' +
    '  C.ArchiveDate, ' +
    ' c.Phone, bd.DictionaryName,bpc.CategoryName,c.customtag, skucount=(select count(goodsid) from CG_StockOrderD(nolock) where StockOrderNID=C.NID)  ' +
    ' ,c.ScanInfo,c.alibabasellername From 	CG_StockOrderM(nolock) C  ' +
    ' Left Outer join B_Supplier G on G.NID=C.SupplierID	' +
    ' Left Outer join B_Dictionary d on d.NID=C.BalanceID	' +
    ' Left Outer join B_Store bs on bs.NID=C.StoreID	' +
    ' Left Outer join B_Person BO on  BO.NID=C.SalerID '  +
    ' left join #OrderNumberTable k1 on k1.StockNid = C.Nid ' +  
   -- ' left join #NoInTable k2 on k2.StockNid = C.Nid ' + 
    ' LEFT JOIN  B_Dictionary bd ON C.BalanceID = bd.NID ' +
     'LEFT JOIN B_PersonCats bpc ON C.DeptID = bpc.NID ' +
     @SqlCdt + ' order by SupplierName ' 
 
 --print @Sql 
 exec (@Sql) 
     
 drop table #OrderNumberTable
 --drop table #NoInTable
 drop table #LogisticTable
end
