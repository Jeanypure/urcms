CREATE Proc [dbo].[P_CG_QueryDataList_temp]
	@iType int,
	@BeginDate varchar(20),
	@EndDate varchar(20),
	@SupName varchar(100),
	@PersonName varchar(30),
	@LogisticOrderNo varchar(100),
	@SkuKey varchar(1000),
	@OrderNo varchar(100),
	@BargainID varchar(100),
	@Note  varchar(1000)
	
as
begin
  set @EndDate = SUBSTRING(@EndDate,1,10) + ' 23:59:59'
  --开始查询   
   DECLARE @Sql varchar(2000),
           @SqlCdt varchar(1000), 
           @TmpSql varchar(2000)
 
   set @SqlCdt = ''
   
   if @iType = 0 begin
     set @SqlCdt = @SqlCdt + ' where (c.Archive=0 and  c.checkflag=0) '
   end
   else if @iType = 1 begin
     set @SqlCdt = @SqlCdt + ' where ((c.Archive=0 and c.checkflag=1) and k2.StockNid is not Null) '
   end
   else if @iType = 2 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and  c.checkflag=1 and c.billnumber  in  '+
              ' (select isnull(stockorder,'''') from CG_StockInM '+
              ' where CheckFlag=0 group by stockorder )) '
   end
   else if @iType = 3 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and  c.checkflag=1 and c.billnumber  in  '+
              ' (select isnull(stockorder,'''') from CG_StockInM '+
              ' where CheckFlag=1  group by stockorder ) and k2.StockNid is Null ) '
   end
   else if @iType =  4 begin
     set @SqlCdt = @SqlCdt + ' where ( c.Archive=0 and c.checkflag=3 ) '
   end
   else if @iType = 5 begin
     set @SqlCdt = @SqlCdt + ' where (c.Archive=1) '
   end
   else if @iType = 6 begin
     set @SqlCdt = @SqlCdt + ' where (1=1) '
   end
    
   if @BeginDate <> '' begin
     set @SqlCdt =  @SqlCdt + ' and (C.MakeDate >= convert(DateTime,''' + @BeginDate + '''))'  
   end
   if @EndDate <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.MakeDate <= convert(DateTime,''' + @EndDate + '''))'
   end
   if @SupName <> '' begin
     set @SqlCdt = @SqlCdt + ' and (G.SupplierName like ''%' + @SupName + '%'')'
   end
   if @PersonName <> '' begin
     set @SqlCdt = @SqlCdt + ' and (bo.PersonName like ''%' + @PersonName + '%'')'
   end
   if @Note <> '' begin
     set @SqlCdt = @SqlCdt + ' and (C.Memo like ''%' + @Note + '%'' or C.Note like ''%' + @Note + '%'')'
   end
   if @LogisticOrderNo <> '' begin
     set @SqlCdt = @SqlCdt + ' and (c.LogisticOrderNo like ''%' + @LogisticOrderNo + '%'')'
   end
   if @OrderNo <> '' begin
     set @SqlCdt = @SqlCdt + ' and (c.billnumber like ''%' + @OrderNo + '%'')'
   end
   if @BargainID <> '' begin
     set @SqlCdt = @SqlCdt + ' and (c.BargainID like ''%' + @BargainID + '%'')'
   end
   if @SkuKey <> '' begin 
     set @SqlCdt = @SqlCdt + ' and (c.nid in (select stockordernid ' +
      ' from CG_StockOrderD where GoodsSKUID in ' +
      ' ( select gs.NID from B_goodsSKU gs '+
            ' left outer join B_Goods gg on gg.nid=gs.goodsid '+
            ' where gs.SKU  Like ''%' + @SkuKey + '%'' '+
            ' or gg.goodsname Like ''%' + @SkuKey + '%'' '+
            ' or gg.GoodsCode Like ''%' + @SkuKey + '%'' '+
            ' or gg.SalerName Like ''%' + @SkuKey + '%'' '+
            ' ))) '   
   end
        
  --未完全入库的采购单NID插入到临时表中
 create table #NoInTable
 (  StockNid int,
    InAmount int default 0,
    InMoney money default 0
 )
 insert into #NoInTable(StockNid)
  select distinct A.Nid from CG_StockOrderM A
    left join (
      select a3.billNumber as StockOrder,  a4.GoodsSKUID,
        Sum(case when a2.InStatus = 1 and a1.CheckFlag<>3 then 1 else 0 end) as InStatus  
    from CG_StockOrderM a3 
      inner join CG_StockOrderD a4 on a3.Nid = a4.StockOrderNID 
      left join CG_StockInM a1 on a1.StockOrder = a3.BillNumber 
      left join CG_StockInD a2 on a1.NID = a2.StockInNID and a2.GoodsSKUID = a4.GoodsSKUID 
    where  a3.CheckFlag = 1  and a3.Archive = 0    -- and IsNull(a1.CheckFlag,0) <> 3(不需要了）  
    group by  a3.billNumber, a4.GoodsSKUID 
    having MIN(a4.Amount) - SUM(case a1.CheckFlag when 3 then 0 else   Isnull(a2.Amount,0) end ) > 0 
    ) C on A.BillNumber = C.StockOrder  
    where  C.InStatus = 0 
    
  -- 更新入库数量和入库金额
 update #NoInTable set 
   InAmount = IsNull((select SUM(IsNull(AMount,0))  
     from CG_StockInD A
     inner join CG_StockInM B on A.StockInNID = B.NID 
     inner join CG_StockOrderM C on C.BillNumber = B.StockOrder 
     where C.NID = #NoInTable.StockNid and IsNull(B.CheckFlag,0) <> 3),0),
  InMoney = IsNull((select SUM(IsNull(A.Money,0))  
     from CG_StockInD A
     inner join CG_StockInM B on A.StockInNID = B.NID 
     inner join CG_StockOrderM C on C.BillNumber = B.StockOrder 
     where C.NID = #NoInTable.StockNid and IsNull(B.CheckFlag,0) <> 3 ),0)
 
 

  --插入订单对应的总数量
 --总单量的已入库数量和未入库数量
   Create Table #OrderNumberTable
 (  StockNid int,
    OrderAmount int,
    OrderMoney money,
    AllMoney money
 )
  set @TmpSql = '
 insert into #OrderNumberTable
    select C.Nid, Sum(D.Amount), Sum(IsNull(D.AMount,0)*IsNull(D.TaxPrice,0)), Sum(IsNull(AllMoney,0))
      from CG_StockOrderM C 
      inner join CG_StockOrderD D on C.Nid = D.StockOrderNid
       Left Outer join B_Supplier G on G.NID=C.SupplierID	 
   	  Left Outer join B_Person BO on  BO.NID=C.SalerID
   	  left join #NoInTable k2 on k2.StockNid = C.Nid 
      ' + @SqlCdt + ' group by C.Nid '
  Exec (@TmpSql) 
  
   select  * from #NoInTable where StockNid = 52575
  
  set @Sql =  'select c.NID,C.makeDate,PayMoney,C.billnumber, ' +
  ' SupplierName=case when c.supplierID=99999999 then ''--多供应商订单--'' else G.SupplierName end, ' +
    '	C.Memo,BO.PersonName,C.DelivDate,c.Recorder ,c.note, ' +
    ' case C.checkflag    when 1 then ''审核'' ' +
    '   when 3 then ''作废'' else ''未审核'' end as checkflag ,c.archive,' +
    '	C.Audier,C.AudieDate,C.DeptMan,d.Dictionaryname as BalanceName,  ' +
   -- ' AllMoney=(select sum(ISNULL(allmoney,0)) from CG_StockOrderD where StockOrderNID=c.nid), ' +
    ' k1.AllMoney, k1.OrderAmount as AllNum, ' + 
    --'  AllNum=(select sum(ISNULL(amount,0)) from CG_StockOrderD where StockOrderNID=c.nid),' + 
    ' ExpressFee,ExpressName,bs.StoreName,DisCountMoney, ' +
    ' FinancialMan,FinancialTime,C.BargainID,C.LogisticOrderNo, ' +
    ' case when IsNull(k1.OrderAmount,0) - IsNull(k2.InAmount,k1.OrderAmount) >0 then IsNull(k1.OrderAmount,0) - IsNull(k2.InAmount,k1.OrderAmount) else 0 end as NoInAmount, ' +
    ' case when IsNull(k1.OrderMoney,0) - IsNull(k2.InMoney,k1.OrderMoney) >0 then IsNull(k1.OrderMoney,0) - IsNull(k2.InMoney,k1.OrderMoney) else 0 end as NoInMoney,' +
    ' IsNull(k2.InMoney,0) as InMoney, C.ArchiveDate, ' +
    ' c.Phone, bd.DictionaryName,bpc.CategoryName ' +
    ' From 	CG_StockOrderM C  ' +
    ' Left Outer join B_Supplier G on G.NID=C.SupplierID	' +
    ' Left Outer join B_Dictionary d on d.NID=C.BalanceID	' +
    ' Left Outer join B_Store bs on bs.NID=C.StoreID	' +
    ' Left Outer join B_Person BO on  BO.NID=C.SalerID '  +
    ' left join #OrderNumberTable k1 on k1.StockNid = C.Nid ' +  
    ' left join #NoInTable k2 on k2.StockNid = C.Nid ' + 
    ' LEFT JOIN  B_Dictionary bd ON C.BalanceID = bd.NID ' +
     'LEFT JOIN B_PersonCats bpc ON C.DeptID = bpc.NID ' +
     @SqlCdt 
 
 print @Sql 
 exec (@Sql) 
 
 
 drop table #OrderNumberTable
 drop table #NoInTable
 
end

