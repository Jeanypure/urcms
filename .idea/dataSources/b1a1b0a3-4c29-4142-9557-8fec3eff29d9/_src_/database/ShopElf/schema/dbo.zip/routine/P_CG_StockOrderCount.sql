CREATE proc [P_CG_StockOrderCount]
	@BeginDate varchar(20),
	@EndDate varchar(20),
	@SupplierName	varchar(50),
	@SalerName		varchar(50),
	@GoodsName		Varchar(50),
	@StoreName      Varchar(50),
	@CheckFlag		Varchar(2),
	@QueryFlag		smallint  --查询标识，0供应商1采购员2大类3商品4仓库
as
begin
    set @BeginDate = SUBSTRING(@BeginDate,1,10) + ' 00:00:01'
    set @EndDate = SUBSTRING(@EndDate,1,10) + ' 23:59:59'
   
    -- 供应商
    select max( isnull(supplierCode,'')) as supplierCode, isnull(supplierName,'') as supplierName  
    into #B_Suppliertemp
      from B_Supplier group by isnull(supplierName,'') 
 
	create Table #StockOrderCountsup(
		SupplierName	varchar(500),
		SalerID		int,
		GoodsskuID		int,
		Billnumber	varchar(50),
		BillType	smallint,
		cgAmount	Float default 0,
		cgMoney  	numeric(18,2) default 0,
		disquamount	Float default 0,
		disqumoney	numeric(18,2) default 0,
		reamount	Float default 0,
		remoney	    numeric(18,2) default 0,		
		InAmount	Float default 0,
		InMoney	    numeric(18,2) default 0,
		InStatus    INT DEFAULT 0,
		StoreID   int,
		ExpressFee float default 0,
		LineCount  int
	)
	
	create Table #StockOrderCountsaler(
		SupplierName	varchar(500),
		SalerID		int,
		GoodsskuID		int,
		Billnumber	varchar(50),
		BillType	smallint,
		cgAmount	Float default 0,
		cgMoney  	numeric(18,2) default 0,
		disquamount	Float default 0,
		disqumoney	numeric(18,2) default 0,
		reamount	Float default 0,
		remoney	    numeric(18,2) default 0,		
		InAmount	Float default 0,
		InMoney	    numeric(18,2) default 0,
		InStatus    INT DEFAULT 0,
		StoreID   int,
		ExpressFee float default 0,
		LineCount  int
	)
	
	create Table #StockOrderCountcats(
		SupplierName	varchar(500),
		SalerID		int,
		GoodsskuID		int,
		Billnumber	varchar(50),
		BillType	smallint,
		cgAmount	Float default 0,
		cgMoney  	numeric(18,2) default 0,
		disquamount	Float default 0,
		disqumoney	numeric(18,2) default 0,
		reamount	Float default 0,
		remoney	    numeric(18,2) default 0,		
		InAmount	Float default 0,
		InMoney	    numeric(18,2) default 0,
		InStatus    INT DEFAULT 0,
		StoreID   int,
		ExpressFee float default 0,
		LineCount  int
	)
	
	create Table #StockOrderCountstore(
		SupplierName	varchar(500),
		SalerID		int,
		GoodsskuID		int,
		Billnumber	varchar(50),
		BillType	smallint,
		cgAmount	Float default 0,
		cgMoney  	numeric(18,2) default 0,
		disquamount	Float default 0,
		disqumoney	numeric(18,2) default 0,
		reamount	Float default 0,
		remoney	    numeric(18,2) default 0,		
		InAmount	Float default 0,
		InMoney	    numeric(18,2) default 0,
		InStatus    INT DEFAULT 0,
		StoreID   int,
		ExpressFee float default 0,
		LineCount  int
	)
	create Table #StockOrderCount1(
		SupplierName	varchar(500),
		SalerID		int,
		GoodsskuID		int,
		Billnumber	varchar(50),
		BillType	smallint,
		cgAmount	Float default 0,
		cgMoney  	numeric(18,2) default 0,
		disquamount	Float default 0,
		disqumoney	numeric(18,2) default 0,
		reamount	Float default 0,
		remoney	    numeric(18,2) default 0,		
		InAmount	Float default 0,
		InMoney	    numeric(18,2) default 0,
		InStatus    INT DEFAULT 0,
		StoreID   int,
		ExpressFee float default 0,
		StockNid  int
	)	
		--查询采购数量单供应商
	insert into #StockOrderCount1(SupplierName,SalerID,GoodsskuID,Billnumber,cgAmount,cgMoney,StoreID,ExpressFee,StockNid)
	select 
		isnull(g.SupplierName,''),
		om.SalerID,
		od.GoodsskuID,
		om.BillNumber,
		od.Amount as cgamount,
		od.AllMoney as cgallmoney,
		om.StoreID, 
		IsNull(om.ExpressFee,0),
		om.NID 
	from 
		CG_StockOrderD od 
	inner join		
		CG_StockOrderM om  on om.NID=od.StockOrderNID
	inner join  
		B_GoodsSKU gs on gs.NID=od.GoodsSKUID	
    Left Outer join 
		B_Supplier G on G.NID=om.SupplierID
    Left Outer join 
		B_Person p on p.NID=om.salerID
	left Outer join 
	    B_Store st on st.NID = om.StoreID 	
	where	
		om.MakeDate >= @BeginDate and om.MakeDate <= @EndDate  
		and om.SupplierID<>99999999
		and (@CheckFlag='' or om.CheckFlag=@CheckFlag)
		and (@SupplierName='' or g.SupplierName like '%'+@SupplierName+'%')
		and (@SalerName='' or p.PersonName like '%'+@SalerName+'%')	
		and (@StoreName='' or st.StoreName like '%'+@StoreName+'%')	
		and (@GoodsName='' or  GoodsSKUID in
					( select bgs.NID from B_goodssku bgs LEFT JOIN B_Goods bg ON bg.NID = bgs.GoodsID  where (bg.GoodsName  Like '%' + @GoodsName + '%') OR ( bgs.SKU Like '%' + @GoodsName + '%')))

		--查询采购数量多供应商
	insert into #StockOrderCount1(SupplierName,SalerID,GoodsskuID,Billnumber,cgAmount,cgMoney,StoreID,ExpressFee,StockNid)
	select 
		isnull(od.SupplierName,''),
		om.SalerID,
		od.GoodsskuID,
		om.BillNumber,
		od.Amount as cgamount,
		od.AllMoney as cgallmoney,
		om.StoreID,
		IsNull(om.ExpressFee,0),
		om.NID  
	from 
		CG_StockOrderD od 
	inner join		
		CG_StockOrderM om  on om.NID=od.StockOrderNID
	inner join  
		B_GoodsSKU gs on gs.NID=od.GoodsSKUID	
    Left Outer join 
		B_Person p on p.NID=om.salerID	
	left Outer join 
	    B_Store st on st.NID = om.StoreID 	
	
	where	
		om.MakeDate >= @BeginDate and om.MakeDate <= @EndDate  
		and om.SupplierID=99999999
		and (@CheckFlag='' or om.CheckFlag=@CheckFlag)
		and (@SupplierName='' or od.SupplierName like '%'+@SupplierName+'%')
		and (@SalerName='' or p.PersonName like '%'+@SalerName+'%')		
		and (@StoreName='' or st.StoreName like '%'+@StoreName+'%')	
		and (@GoodsName='' or  GoodsSKUID in
					( select bgs.NID from B_goodssku bgs LEFT JOIN B_Goods bg ON bg.NID = 
bgs.GoodsID  where (bg.GoodsName  Like '%' + @GoodsName + '%') OR ( bgs.SKU Like '%' + @GoodsName + '%')))



 
update #StockOrderCount1 set 
    reamount = 0,
    disquamount = B.UnStdQty,
    InAmount = B.Amount,
    InMoney = case when B.AMount=0 then 0 else convert(numeric(18,2),CGMoney / CgAmount * B.Amount) end  
from #StockOrderCount1 A, 
      (select Sum(IsNull(od.UnStdQty,0)) as UnStdQty,
              Sum(IsNull(od.Amount,0)) as Amount,
              om.StockOrder, od.GoodsSkuID
       from CG_StockInD od
          inner join CG_StockInM om  on om.NID=od.StockInNID
       where om.CheckFlag = 1 and om.BillType = 1
       group by om.StockOrder, od.GoodsSKUID) B
   where A.Billnumber = B.StockOrder and A.GoodsskuID = B.GoodsSKUID
  
-- 加订单记录数量  add by ylq 2015-12-22
  create Table #StockOrderLineCountsup(	
      LineCount int,
      stocknid int,
      SupplierName varchar(255)      
      )
        
  insert into #StockOrderLineCountsup
     select distinct 1,StockNid, SupplierName from #StockOrderCount1 where ISNULL(StockNid,0) <> 0     
     
     insert into #StockOrderCountsup
	select 
		a.SupplierName,
		0,
		0,
		'',
		'',
		sum(isnull(cgAmount,0)),
		sum(isnull(cgMoney ,0)),
		sum(isnull(disquamount,0)),
		sum(isnull(disqumoney,0)),
		sum(isnull(reamount,0)),
		sum(isnull(remoney,0)),		
		sum(isnull(InAmount,0)),
		sum(isnull(InMoney,0)),
		0,
		0,
		sum(isnull(ExpressFee,0)),
		0
	from #StockOrderCount1 A
	--left join #StockOrderLineCountsup sc on sc.SupplierName=a.SupplierName
	group by 
		a.SupplierName

		
    create Table #StockOrderLineCountsaler(	
      LineCount int,
      stocknid int,
      salerid int     
      )        
  insert into #StockOrderLineCountsaler
     select distinct 1, StockNid,SalerID from #StockOrderCount1 where ISNULL(StockNid,0) <> 0      

		
	insert into #StockOrderCountsaler
	select 
		'',
		a.SalerID,
		0,
		'',
		'',
		sum(isnull(cgAmount,0)),
		sum(isnull(cgMoney ,0)),
		sum(isnull(disquamount,0)),
		sum(isnull(disqumoney,0)),
		sum(isnull(reamount,0)),
		sum(isnull(remoney,0)),		
		sum(isnull(InAmount,0)),
		sum(isnull(InMoney,0)),
		0,
		0,
		sum(isnull(ExpressFee,0)),
		0
	from #StockOrderCount1 A
	--left join #StockOrderLineCount sc on sc.stocknid=a.StockNid
	group by 		
		a.SalerID
		
	
	create Table #StockOrderLineCountcats(	
      LineCount int,
      stocknid int,
      goodsskuid int           
      )        
  insert into #StockOrderLineCountcats
     select distinct 1, StockNid,goodsskuid from #StockOrderCount1 where ISNULL(StockNid,0) <> 0 	
		
		
	insert into #StockOrderCountcats
	select 
		'',
		0,
		GoodsskuID,
		'',
		'',
		sum(isnull(cgAmount,0)),
		sum(isnull(cgMoney ,0)),
		sum(isnull(disquamount,0)),
		sum(isnull(disqumoney,0)),
		sum(isnull(reamount,0)),
		sum(isnull(remoney,0)),		
		sum(isnull(InAmount,0)),
		sum(isnull(InMoney,0)),
		0,
		0,
		sum(isnull(ExpressFee,0)),
		0
	from #StockOrderCount1 A
	--left join #StockOrderLineCountcats sc on sc.stocknid=a.StockNid
	group by 			    
		GoodsskuID		
		
		
	create Table #StockOrderLineCountstore(	
      LineCount int,
      stocknid int,
      storeid int     
      )        
  insert into #StockOrderLineCountstore
     select distinct 1, StockNid,StoreID from #StockOrderCount1 where ISNULL(StockNid,0) <> 0 	
		
	insert into #StockOrderCountstore
	select 
		'',
		0,
		0,
		'',
		'',
		sum(isnull(cgAmount,0)),
		sum(isnull(cgMoney ,0)),
		sum(isnull(disquamount,0)),
		sum(isnull(disqumoney,0)),
		sum(isnull(reamount,0)),
		sum(isnull(remoney,0)),		
		sum(isnull(InAmount,0)),
		sum(isnull(InMoney,0)),
		0,
		StoreID,
		sum(isnull(ExpressFee,0)),
		0
	from #StockOrderCount1 A
	--left join #StockOrderLineCount sc on sc.stocknid=a.StockNid
	group by 		
		StoreID			
		
		
		
	
	--返回记录
	if @QueryFlag=0 
	begin
		select 
			isnull(s.supplierCode,'') as   supplierCode,
			isnull(c.supplierName,'') as  supplierName,			
			SUM(c.cgAmount) as cgamount,
			convert(numeric(18,2),SUM(c.cgMoney)) as cgmoney,
			SUM(c.reamount)  as reamount,
			convert(numeric(18,2),SUM(c.disquamount)) as disquamount,
			case  when SUM(c.disquamount)=0  then 0 
			      when SUM(c.cgMoney)=0 then 0
			else convert(numeric(18,2),
			     SUM(c.cgMoney)/SUM(c.cgAmount*1.00)*SUM(c.disquamount))
		    end as disqumoney, 
			convert(numeric(18,2),SUM(c.remoney)) as remoney, 		
			SUM(c.InAmount) as inamount,
			convert(numeric(18,2),SUM(c.InMoney)) as inmoney,
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgAmount-c.InAmount) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgAmount-c.InAmount))  
			END  as Noinamount,
			
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgMoney-c.InMoney) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgMoney-c.InMoney))
			END as Noinmoney,
			Sum(c.ExpressFee) As ExpressFee,
			( select  sum(sc.LineCount) from #StockOrderLineCountsup sc where sc.SupplierName=c.SupplierName ) as LineCount 	
		from 
			#StockOrderCountsup c
		left outer  join 
		  #B_Suppliertemp  s on s.supplierName=c.supplierName
		group by 
			c.supplierName,			
			isnull(s.supplierCode,'')
	end	else
	if @QueryFlag=1
	begin
		select 
			s.PersonCode,
			s.PersonName,
			SUM(c.cgAmount) as cgamount,
			convert(numeric(18,2),SUM(c.cgMoney)) as cgmoney,
			SUM(c.reamount)  as reamount,
			convert(numeric(18,2),SUM(c.disquamount)) as disquamount,
			case  when SUM(c.disquamount)=0  then 0 
			      when SUM(c.cgMoney)=0 then 0
			else SUM(c.cgMoney)/SUM(c.cgAmount*1.00)*SUM(c.disquamount) end as disqumoney, 
			convert(numeric(18,2),SUM(c.remoney)) as remoney, 		
			SUM(c.InAmount) as inamount,
			convert(numeric(18,2),SUM(c.InMoney)) as inmoney,
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgAmount-c.InAmount) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgAmount-c.InAmount))  
			END  as Noinamount,
			
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgMoney-c.InMoney) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgMoney-c.InMoney))
			END as Noinmoney,
			Sum(c.ExpressFee) as ExpressFee,
			count(sc.stocknid) as LineCount 	
		from 
			#StockOrderCountsaler c
		inner join 
			B_Person s on s.NID=c.SalerID	
		 left outer join #StockOrderLineCountsaler sc on sc.salerid=c.SalerID		
		group by 
			s.PersonCode,			
			s.PersonName		
	end	else			 
	if @QueryFlag=2
	begin
		select 
			isNull(sc.CategoryName,'未指定类别') as CategoryName,
			SUM(c.cgAmount) as cgamount,
			convert(numeric(18,2),SUM(c.cgMoney)) as cgmoney,
			SUM(c.reamount)  as reamount,
			SUM(c.disquamount) as disquamount,
			case  when SUM(c.disquamount)=0  then 0 
			      when SUM(c.cgMoney)=0 then 0
			else SUM(c.cgMoney)/SUM(c.cgAmount*1.00)*SUM(c.disquamount) end as disqumoney, 
			convert(numeric(18,2),SUM(c.remoney)) as remoney, 		
			SUM(c.InAmount) as inamount,
			convert(numeric(18,2),SUM(c.InMoney)) as inmoney,
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgAmount-c.InAmount) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgAmount-c.InAmount))  
			END  as Noinamount,
			
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgMoney-c.InMoney) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgMoney-c.InMoney))
			END as Noinmoney,
			sum(soc.LineCount) as LineCount 			
		from 
			#StockOrderCountcats c
		inner join 
			B_Goodssku gs on gs.NID=c.GoodsskuID
		inner join 
			B_Goods s on s.NID=gs.goodsid
		left outer join
			B_GoodsCats sc on sc.NID=s.GoodsCategoryID	
		left outer join #StockOrderLineCountcats soc on soc.goodsskuid=c.GoodsskuID		
		group by		     
			sc.CategoryName	
			
	end		else			 
	if @QueryFlag=3
	begin
		select 
		    isNull(sc.CategoryName,'未指定类别') as CategoryName,
			s.GoodsCode,
			s.GoodsName,
			s.Class,
			s.Model,
			s.Unit,
			gs.SKU,
			s.salername,
			s.salername2,
			c.SupplierName,
			SUM(c.cgAmount) as cgamount,
			case SUM(c.cgAmount) when 0 then 0 else SUM(c.cgMoney)/SUM(c.cgAmount*1.00) end as Price,
			SUM(c.reamount)  as reamount,
			SUM(c.disquamount) as disquamount,
			case  when SUM(c.disquamount)=0  then 0 
			      when SUM(c.cgMoney)=0 then 0
			else SUM(c.cgMoney)/SUM(c.cgAmount*1.00)*SUM(c.disquamount) end as disqumoney, 
			convert(numeric(18,2),SUM(c.remoney)) as remoney, 
			convert(numeric(18,2),SUM(c.cgMoney)) as cgmoney,		
			SUM(c.InAmount) as inamount,
			convert(numeric(18,2),SUM(c.InMoney)) as inmoney,

			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgAmount-c.InAmount) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgAmount-c.InAmount)) 
			END  as Noinamount,
			
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgMoney-c.InMoney) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgMoney-c.InMoney))
			END as Noinmoney,
			--add by ylq 2014.11.7  modify by ylq 2015-04-01
			s.minPrice as MinPrice,
			case when IsNull(gs.CostPrice,0) = 0 then s.costPrice else gs.CostPrice end AS CostPrice,
			--add by ylq 2014.11.26
			LocationName = isnull((select max(isnull(bsl.LocationName,'')) 
			               from B_GoodsSKULocation bgs left join B_StoreLocation bsl 
                           on bgs.LocationID =bsl.NID 
                           left join B_GoodsSKU bbb on bgs.GoodsSKUID = bbb.NID
                           where bbb.SKU =  gs.SKU),''),        --库位
			max(tmpk.CGCount) AS CGCount,  -- 采购次数	 		
			--add by wgx 2015.01.05 增加款式123
			gs.property1,gs.property2,gs.property3,
			s.Purchaser,
			sum(soc.LineCount) as LineCount ,gs.SellCount1,gs.SellCount2,gs.SellCount3 	
		from 
			#StockOrderCountcats c
		inner join 
			B_GoodsSKU gs   on gs.NID=c.GoodsskuID
		inner join 
			B_Goods s on s.NID=gs.GoodsID	
		left outer join 
			#B_Suppliertemp   b on b.supplierName=c.supplierName
		left outer join
			B_GoodsCats sc on sc.NID=s.GoodsCategoryID	  --add by ylq 2015-08-12 加类别
		left join 
		   (select Count(*) as CGCount,GoodsskuID from #StockOrderCountcats group by GoodsskuID) tmpk on tmpk.GoodsskuID = c.GoodsskuID
	   left outer join #StockOrderLineCountcats soc on soc.goodsskuid=c.GoodsskuID	
			 --用于库位连接....
	    --LEFT outer JOIN KC_CurrentStock cs ON cs.GoodsSKUID = c.GoodsskuID   
        --LEFT outer JOIN B_GoodsSKULocation bgs ON bgs.GoodsSKUID = c.GoodsskuID and bgs.StoreID=cs.StoreID  
        --left outer join B_StoreLocation l on bgs.LocationID=l.nid   
		group by 
			s.GoodsCode,
			s.GoodsName,
			s.Class,
			s.Model,
			s.Unit,
			s.salername,
			s.salername2,
			gs.SKU,
			gs.CostPrice,
			s.CostPrice,
			s.MinPrice,
			c.SupplierName,
			gs.property1,
			gs.property2,
			gs.property3,
			s.Purchaser,
			sc.CategoryName,			
			gs.SellCount1,gs.SellCount2,gs.SellCount3 
	end	else
	if @QueryFlag=4   -- 仓库 
	begin
	  print ('1')
	  
		select 
			isnull(s.StoreName,'') as   StoreName,
			isnull(c.StoreID,'') as  StoreID,			
			SUM(c.cgAmount) as cgamount,
			convert(numeric(18,2),SUM(c.cgMoney)) as cgmoney,
			SUM(c.reamount)  as reamount,
			SUM(c.disquamount) as disquamount,
			case  when SUM(c.disquamount)=0  then 0 
			      when SUM(c.cgMoney)=0 then 0
			else SUM(c.cgMoney)/SUM(c.cgAmount*1.00)*SUM(c.disquamount) end as disqumoney, 
			convert(numeric(18,2),SUM(c.remoney)) as remoney, 		
			SUM(c.InAmount) as inamount,
			convert(numeric(18,2),SUM(c.InMoney)) as inmoney,
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgAmount-c.InAmount) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgAmount-c.InAmount))  
			END  as Noinamount,
			
			CASE WHEN max(c.InStatus) = 1  THEN 0 
			     WHEN (max(c.InStatus) = 0) AND (SUM(c.cgMoney-c.InMoney) <= 0) THEN 0
			     ELSE convert(numeric(18,2),SUM(c.cgMoney-c.InMoney))
			END as Noinmoney,
			sum(sc.LineCount) as LineCount 		
		from 
			#StockOrderCountstore c
		left outer  join 
			B_Store s on s.Nid=c.StoreID
		left outer join #StockOrderLineCountstore sc on sc.storeid=c.StoreID			
		group by 
			c.StoreID,			
			isnull(s.StoreName,'')
	  end	 
	  
	  
	  
   
  drop table #StockOrderLineCountsup
  drop table #StockOrderLineCountsaler
  drop table #StockOrderLineCountcats
  drop table #StockOrderLineCountstore
  drop table #StockOrderCount1
  drop table #StockOrderCountsup
  drop table #StockOrderCountsaler
  drop table #StockOrderCountcats
  drop table #StockOrderCountstore
	
END
