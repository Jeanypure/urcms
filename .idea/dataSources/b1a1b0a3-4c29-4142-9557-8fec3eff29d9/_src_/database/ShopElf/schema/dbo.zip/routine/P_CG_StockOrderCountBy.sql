 create proc [dbo].[P_CG_StockOrderCountBy]
	@BeginDate		datetime,
	@EndDate		Datetime,
	@SupplierName	varchar(50),
	@SalerName		varchar(50),
	@GoodsName		Varchar(50),
	@CheckFlag		Varchar(2)
as
begin
	create Table #StockOrderCount(
		SupplierID	int,
		Billnumber	varchar(50),
		cgAmount	Float default 0,
		cgMoney	Float default 0,		
		InAmount	Float default 0,
		InMoney	Float default 0			
	)
	--查询采购数量
	insert into #StockOrderCount(SupplierID,Billnumber,cgAmount,cgMoney)
	select 
		om.SupplierID,
		om.BillNumber,
		od.Amount as cgamount,
		od.AllMoney as cgallmoney
	from 
		CG_StockOrderD od 
	inner join		
		CG_StockOrderM om  on om.NID=od.StockOrderNID
    Left Outer join 
		B_Supplier G on G.NID=om.SupplierID
    Left Outer join 
		B_Person p on p.NID=om.salerID	
	where	
		CONVERT(varchar(10),om.MakeDate,121) between @BeginDate and @EndDate
		and (@CheckFlag='' or om.CheckFlag=@CheckFlag)
		and (@SupplierName='' or g.SupplierName like '%'+@SupplierName+'%')
		and (@SalerName='' or p.PersonName like '%'+@SalerName+'%')		
		and (@GoodsName='' or  GoodsID in
					( select NID from B_goods where GoodsName  Like '%' +
							@GoodsName + '%'))
	--查询入库数量，限制在采购中的记录，根据单号
	insert into #StockOrderCount(SupplierID,InAmount,InMoney)
	select 
		om.SupplierID,
		sum(od.Amount) as inamount,
		sum(od.AllMoney) as inallmoney
	from 
		CG_StockInD od 
	inner join		
		CG_StockInM om  on om.NID=od.StockInNID
	where	
		om.StockOrder in (select BillNumber from #StockOrderCount )
	group by 
		om.SupplierID	
	--返回记录
	select 
		s.supplierCode,
		s.supplierName,
		SUM(c.cgAmount) as cgamount,
		SUM(c.cgMoney) as cgmoney,		
		SUM(c.InAmount) as inamount,
		SUM(c.InMoney) as inmoney,
		SUM(c.cgAmount-c.InAmount) as Noinamount,
		SUM(c.cgMoney-c.InMoney) as Noinmoney		
	from 
		#StockOrderCount c
	inner join 
		B_Supplier s on s.NID=c.SupplierID	
	group by 
		s.supplierCode,
		s.supplierName						 

end
