CREATE Proc [dbo].[P_CG_UpdateStockOrderInAmount]
	@StockOrderBillnumber	Varchar(20)='',
	@StockInBillnumber		Varchar(20)=''
as
begin	 
  set nocount on;
  --add by ylq 2015-07-09 把写入采购单的数据写入日志
  declare  @CGNid int
  declare @strVal varchar(1000)
  begin try
  BEGIN TRAN crSave
	  set @CGNid =(select top 1 Nid from CG_StockOrderM where BillNumber = @StockOrderBillnumber)
	  set @strVal = @StockInBillnumber + ',写入入库数量：' 
	  select @strVal = @strVal + gs.Sku + ','  + Convert(varchar(32),Sum(d.Amount)) + ';' 
		 from  CG_StockInD d 
		 inner join B_GoodsSKU gs on gs.NID = d.GoodsSKUID 
		 inner join CG_StockInM m  on m.NID=d.StockInNID  
		 inner join CG_StockOrderM om on om.BillNumber = m.StockOrder
		 inner join CG_StockOrderD od on od.StockOrderNID = om.NID and  od.GoodsSKUID = d.GoodsSKUID 
   		 where m.StockOrder=@StockOrderBillnumber and  m.CheckFlag <> 3 
   		 group by gs.SKU 
   		 order by gs.SKU 
	   	 
	  exec S_WriteCGStockLogs '采购订单',@CGNid, @strVal, 'admin'  	 
	           
		update 
		  OD  
		set   
		  OD.InAmount=isnull((select SUM(amount) from CG_StockInD d 
				inner join CG_StockInM m  on m.NID=d.StockInNID and m.StockOrder=@StockOrderBillnumber
				where m.CheckFlag<>3 and od.GoodsSKUID=d.GoodsSKUID ),0)
		from   
		  CG_StockOrderD OD  
		inner join    
		  CG_StockOrderM OM on om.NID=od.StockOrderNID 
			 and om.BillNumber=@StockOrderBillnumber
		--检测入库金额是否正确
 		update 
		  OD  
		set   
			OD.[money]=case when abs(od.Amount*Price-od.[Money])>0.9999 
							then od.Amount*Price  else OD.[money] end,
			OD.[allmoney]=case when abs(od.Amount*Price-od.[Money])>0.9999 
							then od.Amount*od.TaxPrice  else OD.[allmoney] end
		from   
			CG_StockInD OD 
		inner join 
			CG_StockInM M on m.NID=od.StockInNID 
		where 
			m.BillNumber=@StockInBillnumber
		--更新采购订单相关数量，提升查询速度
		update 
		  OM  
		set   
		  om.InAmount=isnull((select SUM(amount) from CG_StockInD d 
				inner join CG_StockInM m  on m.NID=d.StockInNID and m.StockOrder=@StockOrderBillnumber
				where m.CheckFlag=1),0),
		  om.InMoney=isnull((select SUM(allmoney) from CG_StockInD d 
				inner join CG_StockInM m  on m.NID=d.StockInNID and m.StockOrder=@StockOrderBillnumber
				where m.CheckFlag=1  ),0),
		  om.OrderAmount=(select SUM(Amount) from CG_StockOrderD where StockOrderNID=om.NID ),
		  om.OrderMoney=(select SUM(AllMoney) from CG_StockOrderD where StockOrderNID=om.NID ),
		  om.skucount = (select count(GoodsSKUID ) from CG_StockOrderD where StockOrderNID=om.NID )	
		from   
		  CG_StockOrderM OM 
		 where om.BillNumber=@StockOrderBillnumber
		-- 更新入库状态
		if exists(select 1 from CG_StockOrderM m 
		  inner join CG_StockOrderD d on d.StockOrderNID=m.NID
		  where m.BillNumber=@StockOrderBillnumber
		  and d.InAmount<d.Amount)
		begin
		  update CG_StockOrderM set InFlag=0 where BillNumber=@StockOrderBillnumber
		end	
		else
		begin
		  update CG_StockOrderM set InFlag=1 where BillNumber=@StockOrderBillnumber
		end
		Commit tran crSave        
	End try                     
	Begin catch                 
		If (@@TRANCOUNT<>0)                            
			rollback tran crSave 
		set @strVal=@StockInBillnumber + '审核入库失败,'+ERROR_MESSAGE()
		exec S_WriteCGStockLogs '采购入库单',@CGNid, @strVal, 'admin'                    
	End catch
    set nocount off;
end
