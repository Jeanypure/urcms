
CREATE proc [dbo].[P_CG_UpdateStockOutOfByStockInCheck]
	@BillNumber varchar(50) =''
as
begin
	--取消审核时更新一下
	Update 
		CG_OUTOFSTOCK 
	set
		StockInNo='',
		OUTOFSTOCKSTATUS=3
	where 
		OUTOFSTOCKSTATUS=4	and StockInNo=@BillNumber
	--生成入库临时表
	SELECT 
		SUM(ISNULL(d.AMOUNT,0)) as InAMOUNT,
		d.GoodsSKUID,
		m.StoreID
	into
		#CG_STOCKInD
	FROM 
		CG_STOCKInD D
	INNER JOIN	
		CG_STOCKInM M ON M.NID=D.STOCKInNID 
	WHERE 
		M.BILLNUMBER = @BILLNUMBER						
	group by 
		d.GoodsSKUID,m.StoreID
		
	Declare
		@nid int =0, 
		@goodsskuid int=0 , 
		@storeid int=0,
		@l_Qty int=0,
		@InAMOUNT int = 0,
		@TradeDtNID INT = 0
	
	DECLARE 
		ByStockInCheck CURSOR
	FOR 
		SELECT
			g.nid, 
			gs.nid as goodsskuid,
			g.storeid,
			g.l_Qty,
			g.TradeDtNID
		FROM 
			CG_OUTOFSTOCK  g
		inner join 
			B_GoodsSku gs on gs.sku=g.sku	 
		WHERE 
			g.OUTOFSTOCKSTATUS=3 and gs.nid in (select GoodsSKUID from #CG_STOCKInD)
		order by  --select * from CG_OUTOFSTOCK
			createDate
	  OPEN ByStockInCheck
	  FETCH NEXT FROM ByStockInCheck INTO @nid, @goodsskuid,@storeid, @l_Qty, @TradeDtNID
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
   		SET @InAMOUNT = 
   			(
   				SELECT 
   					Sum(ISNULL(InAMOUNT,0)) 
				FROM 
					#CG_STOCKInD d
				WHERE 
					d.GoodsSKUID=@goodsskuid and d.StoreID=@storeid
			)	 
	    
		IF (@InAMOUNT >= @l_Qty) 
		BEGIN
			UPDATE 
				CG_OUTOFSTOCK 
			SET 
				OutOfStockStatus = 4
			from 
				CG_OUTOFSTOCK g 
			inner join 
				B_GoodsSKU gs on gs.SKU=g.SKU	
			WHERE 
				g.NID = @nid
			--更新剩余数量
			UPDATE 
				#CG_STOCKInD 
			SET 
				InAMOUNT = @InAMOUNT - @l_Qty
			WHERE 
				GoodsSKUID = @goodsskuid and StoreID=@storeid
				
			--冲掉缺货订单产品的缺货标记。
			IF EXISTS(SELECT 1 FROM P_TradeDtUn WHERE NID = @TradeDtNID)
			BEGIN 
				UPDATE P_TradeDtUn
				SET L_SHIPPINGAMT = 0
				WHERE NID = @TradeDtNID
			END ELSE
			BEGIN
				UPDATE P_TradeDt
				SET L_SHIPPINGAMT = 0
				WHERE NID = @TradeDtNID	
			END			
		END      	
  		FETCH NEXT FROM ByStockInCheck INTO @nid, @goodsskuid,@storeid, @l_Qty, @TradeDtNID
	END
	CLOSE ByStockInCheck
	DEALLOCATE ByStockInCheck
	drop Table #CG_STOCKInD
end        

