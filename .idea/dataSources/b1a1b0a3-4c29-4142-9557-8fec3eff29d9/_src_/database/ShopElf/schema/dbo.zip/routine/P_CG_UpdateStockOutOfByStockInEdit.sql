
CREATE proc [dbo].[P_CG_UpdateStockOutOfByStockInEdit]
	@BillNumber varchar(50) =''
as
begin
	--修改时更新一下
	Update 
		CG_OUTOFSTOCK 
	set
		StockInNo='',
		OUTOFSTOCKSTATUS=2
	where 
		OUTOFSTOCKSTATUS=3	and StockInNo=@BillNumber
	--取到货日期
	declare
		@DevDate DateTime
	set
		@DevDate = (
						select 
							top 1 MakeDate 
						from 
							CG_StockInM 
						where 
							BillNumber=@BillNumber
					)
	--生成入库临时表
	SELECT 
		SUM(ISNULL(d.AMOUNT,0)) as InAMOUNT,
		d.GoodsSKUID,
		m.StoreID
	into
		#CG_STOCKInD
	FROM 
		CG_STOCKInD D
	INNER JOIN	
		CG_STOCKInM M ON M.NID=D.STOCKInNID 
	WHERE 
		m.CheckFlag <>3 and 
		M.BILLNUMBER = @BILLNUMBER						
	group by 
		d.GoodsSKUID,m.StoreID
		
	Declare
		@nid int =0, 
		@goodsskuid int=0 , 
		@storeid int=0,
		@l_Qty int=0,
		@InAMOUNT int = 0
	
	DECLARE 
		ByStockInEdit CURSOR
	FOR 
		SELECT
			g.nid, 
			gs.nid as goodsskuid,
			g.storeid,
			g.l_Qty
		FROM 
			CG_OUTOFSTOCK  g
		inner join 
			B_GoodsSku gs on gs.sku=g.sku	 
		WHERE 
			g.OUTOFSTOCKSTATUS=2 and gs.nid in (select GoodsSKUID from #CG_STOCKInD)
		order by  
			createDate
	  OPEN ByStockInEdit
	  FETCH NEXT FROM ByStockInEdit INTO @nid, @goodsskuid,@storeid, @l_Qty
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
   		SET @InAMOUNT = 
   			(
   				SELECT 
   					Sum(ISNULL(InAMOUNT,0)) 
				FROM 
					#CG_STOCKInD d
				WHERE 
					d.GoodsSKUID=@goodsskuid and d.StoreID=@storeid
			)	 
	    
		IF (@InAMOUNT >= @l_Qty) 
		BEGIN
			UPDATE 
				CG_OUTOFSTOCK 
			SET 
				OutOfStockStatus = 3,
				InDate = @DevDate,
				StockInNo = @BillNumber
			from 
				CG_OUTOFSTOCK g 
			inner join 
				B_GoodsSKU gs on gs.SKU=g.SKU	
			WHERE 
				g.NID = @nid
			--更新剩余数量
			UPDATE 
				#CG_STOCKInD 
			SET 
				InAMOUNT = @InAMOUNT - @l_Qty
			WHERE 
				GoodsSKUID = @goodsskuid and StoreID=@storeid
		END      	
  		FETCH NEXT FROM ByStockInEdit INTO @nid, @goodsskuid,@storeid, @l_Qty
	END
	CLOSE ByStockInEdit
	DEALLOCATE ByStockInEdit
	drop Table #CG_STOCKInD
end        
