CREATE proc [dbo].[P_CG_UpdateStockOutOfByStockOrder]
	@BillNumber varchar(50) =''
as
begin
    --下新订单金额
	update 
      OM  
    set   
      om.OrderAmount=(select SUM(Amount) from CG_StockOrderD(nolock) where StockOrderNID=om.NID ),
	  om.OrderMoney=(select SUM(AllMoney) from CG_StockOrderD(nolock) where StockOrderNID=om.NID ),
	  om.skucount = (select count(GoodsSKUID ) from CG_StockOrderD(nolock) where StockOrderNID=om.NID )	
    from   
      CG_StockOrderM OM 
     where om.BillNumber=@BillNumber
     
   --还原已入库的数量

   update 
		od 	
    set   
      InAmount=isnull((select SUM(amount) from CG_StockInD(nolock) d 
	inner join CG_StockInM(nolock) m  on m.NID=d.StockInNID and m.StockOrder=om.billnumber and d.goodsskuid=od.goodsskuid
			where m.CheckFlag=1 ),0)      
	from 
	   CG_StockOrderd od
	inner join CG_StockOrderM om on od.StockOrderNID=om.NID
	where om.billnumber=@BillNumber       
     	
	--修改时更新一下
	Update 
		CG_OUTOFSTOCK 
	set
		StockOrderNo='',
		OUTOFSTOCKSTATUS=0
	where 
		StockOrderNo=@BillNumber and OUTOFSTOCKSTATUS=2	 		
	--取到货日期
	declare
		@DevDate DateTime
	set
		@DevDate = (
						select 
							top 1 DelivDate 
						from 
							CG_StockOrderM(nolock) 
						where 
							BillNumber=@BillNumber
					)
	--生成采购临时表
	SELECT 
		SUM(ISNULL(d.AMOUNT,0)) as OrderAMOUNT,
		d.GoodsSKUID,
		m.StoreID
	into
		#CG_STOCKORDERD
	FROM 
		CG_STOCKORDERD(nolock) D
	INNER JOIN	
		CG_STOCKORDERM(nolock) M ON M.NID=D.STOCKORDERNID 
	WHERE 
		M.BILLNUMBER = @BILLNUMBER						
	group by 
		d.GoodsSKUID,m.StoreID
		
	Declare
		@nid int =0, 
		@goodsskuid int=0 ,
		@storeid int=0, 
		@l_Qty int=0,
		@orderCount int = 0
		
				
	DECLARE 
		ByStockOrder CURSOR
	FOR 
		SELECT
			g.nid, 
			gs.nid as goodsskuid,
			g.storeid,
			g.l_Qty
		FROM 
			CG_OUTOFSTOCK(nolock)  g
		inner join 
			B_GoodsSku(nolock) gs on gs.sku=g.sku	
		inner join  #CG_STOCKORDERD cs on cs.GoodsSKUID=gs.nid
		WHERE 
			--g.StockOrderNo=@BillNumber and g.OUTOFSTOCKSTATUS=0 -- and gs.nid in (select GoodsSKUID  from #CG_STOCKORDERD )
			g.OUTOFSTOCKSTATUS=0  and gs.nid in (select GoodsSKUID  from #CG_STOCKORDERD )
		order by  
			createDate
	  OPEN ByStockOrder
	  FETCH NEXT FROM ByStockOrder INTO @nid, @goodsskuid,@storeid, @l_Qty
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
   		SET @OrderCount = 
   			(
   				SELECT 
   					Sum(ISNULL(OrderAMOUNT,0)) 
				FROM 
					#CG_STOCKORDERD(nolock) d
				WHERE 
					d.GoodsSKUID=@goodsskuid and d.StoreID=@storeid
			)	 
	    
		IF (@OrderCount >= @l_Qty) 
		BEGIN
			UPDATE 
				CG_OUTOFSTOCK 
			SET 
				OutOfStockStatus = 2,
				delivDate = @DevDate,
				StockOrderNo = @BillNumber
			from 
				CG_OUTOFSTOCK(nolock) g 
			--inner join 
			--	B_GoodsSKU(nolock) gs on gs.SKU=g.SKU	
			WHERE 
				g.NID = @nid
			--更新剩余数量
			UPDATE 
				#CG_STOCKORDERD 
			SET 
				OrderAMOUNT = @OrderCount - @l_Qty
			WHERE 
				GoodsSKUID = @goodsskuid and StoreID=@storeid
		END      	
  		FETCH NEXT FROM ByStockOrder INTO @nid, @goodsskuid,@storeid, @l_Qty
	END
	CLOSE ByStockOrder
	DEALLOCATE ByStockOrder
	drop Table #CG_STOCKORDERD	
end                                                
