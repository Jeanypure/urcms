CREATE PROCEDURE P_CheckPaiDanEnable
AS
BEGIN
	DECLARE @PaiDanEnable VARCHAR(10), @rMsg VARCHAR(100)
	DECLARE @StopPaiDanTime TIME  , @NowTime TIME 	
	DECLARE @rFlag INT 
	SET @rFlag = 0
	SET @PaiDanEnable = ''
	SET @rMsg = ''
	SET @PaiDanEnable = (SELECT paravalue FROM B_SysParams WHERE ParaCode = 'PaiDanEnable')
	IF @PaiDanEnable = '1'
	BEGIN
	  SET @StopPaiDanTime = (SELECT paravalue FROM B_SysParams WHERE ParaCode = 'StopPaiDanTime')
      SET  @NowTime = GETDATE()	
      IF (@NowTime > @StopPaiDanTime)
      BEGIN
      	SET @rFlag = 1
      	SET @rMsg = '不能将订单转至仓库,已经超过指定时间"'+convert(varchar(8),@StopPaiDanTime) +'";请下次提前!'
      END
	END
	SELECT @rFlag AS rFlag, @rMsg AS rMsg
END 
