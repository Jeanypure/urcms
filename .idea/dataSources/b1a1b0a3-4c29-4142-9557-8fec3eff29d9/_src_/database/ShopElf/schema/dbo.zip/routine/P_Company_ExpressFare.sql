--公司的物流费用
CREATE PROCEDURE [dbo].[P_Company_ExpressFare]
(
@BeginDate varchar(20),
@EndDate varchar(20),
@wlCompany varchar(20)=''
)
AS
BEGIN
SET NOCOUNT ON

create table #Tempfaretable(
pingtai varchar(50),
ExpressFare float,
--CLOSINGDATE VARCHAR,
wlway VARCHAR(100),
wlCompany VARCHAR(100)
)

INSERT INTO  #Tempfaretable   
select 
							case WHEN m.TRANSACTIONTYPE='AE_COMMON'
							THEN 'SMT'
							 WHEN m.TRANSACTIONTYPE='SMT'
							THEN 'SMT'
							 WHEN m.TRANSACTIONTYPE='Amazon'
							THEN 'Amazon'
							 WHEN m.TRANSACTIONTYPE='Amazon01'
							THEN 'Amazon'
							 WHEN m.TRANSACTIONTYPE='cart'
							THEN 'cart'
							 WHEN m.TRANSACTIONTYPE='eBay'
							THEN 'eBay'
							 WHEN m.TRANSACTIONTYPE='lazada'
							THEN 'lazada'
							 WHEN m.TRANSACTIONTYPE='sendmoney'
							THEN 'sendmoney'
							 WHEN m.TRANSACTIONTYPE='Wish Cart'
							THEN 'Wish'
							 WHEN m.TRANSACTIONTYPE='Wish'
							THEN 'Wish'
							 WHEN m.TRANSACTIONTYPE='shopee Cart'
							THEN 'Shopee'
						 WHEN m.TRANSACTIONTYPE='Shopee'
							THEN 'Shopee'
					   WHEN m.TRANSACTIONTYPE='线下交易'
							THEN '线下交易'
			       WHEN m.TRANSACTIONTYPE='Tophatter'
							THEN 'Tophatter'
          WHEN m.TRANSACTIONTYPE='9.9Buy'
					 		THEN '9.9Buy'
							ELSE 'elsepingtai'
							end as pingtai ,
            sum(m.ExpressFare) as ExpressFare ,
           -- convert(varchar(10),m.CLOSINGDATE,121) as CLOSINGDATE,
            l.name as wlway,
            CASE WHEN l.name ='4PX海外仓美东'
            THEN '4PX(海外仓)'
            WHEN l.name='4PX海外美东仓'
            THEN '4PX(海外仓)'
            WHEN l.name='DHL'
            THEN '佳成国际快递'
            WHEN l.name='DHL普通小包'
            THEN '德国小包DHL'
            WHEN l.name='EMS'
            THEN '佳成国际快递'
            WHEN l.name='E邮宝'
            THEN '金华E邮宝'
            WHEN l.name='E邮宝线下（常州）'
            THEN '铭志物流'
            WHEN l.name='FBW WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='LWE马来西亚东'
            THEN '利威供应链'
            WHEN l.name='LWE马来西亚西'
            THEN '利威供应链'
            WHEN l.name='LWE新加坡小包'
            THEN '利威供应链'
            WHEN l.name='WISH邮挂号'
            THEN 'wish邮'
            WHEN l.name='wish邮南京'
            THEN '铭志物流'
            WHEN l.name='WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='国内快递'
            THEN '顺丰快递运费'
            WHEN l.name='佳成专线'
            THEN '佳成国际快递'
            WHEN l.name='捷德宝'
            THEN '捷买送物流'
            WHEN l.name='顺丰俄罗斯小包挂号'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺丰俄罗斯小包平邮'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺邮宝挂号'
            THEN '顺友物流'
            WHEN l.name='顺邮宝平邮'
            THEN '顺友物流'		
            WHEN l.name='土耳其平邮'
            THEN '捷买送物流'
            WHEN l.name='香港平邮'
            THEN '三态物流'
            WHEN l.name='新加坡挂号'
            THEN '4PX(递四方物流)'
            WHEN l.name='新加坡平邮+'
            THEN '4PX(递四方物流)'
            WHEN l.name='中国邮政挂号小包'
            THEN 'SMT小包平邮+'
            WHEN l.name='中国邮政平常小包+(义乌)'
            THEN 'SMT小包平邮+'
            WHEN l.name='中邮挂号(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮挂号(常熟)'
            THEN '铭志物流'
            WHEN l.name='中邮平邮(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮平邮(常熟)'
            THEN '燕文专线快递'
            WHEN l.name='中邮小包平邮义乌'
            THEN '金华邮局小包'
            WHEN l.name='万邑通线上平邮'
            THEN '万邑通'

						WHEN l.name='利威供应链'
            THEN 'LWE物流'
						WHEN l.name='LWE印尼小包'
            THEN 'LWE物流'						
						WHEN l.name='FBA-US'
            THEN '亚马逊-佳成物流'
						WHEN l.name='UPS快运'
            THEN '亚马逊-佳成物流'
						WHEN l.name='线下E邮宝 上海'
            THEN '亚马逊-燕文快递'
						WHEN l.name='中邮小包(上海)'
            THEN '亚马逊-燕文快递'

            ELSE '物流方式找不到物流公司'
            End as wlCompany--物流公司  
   -- into #Tempfaretable
FROM P_Trade_His m 
            left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID
            left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
            left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE 
            WHERE 
					convert(varchar(10),m.CLOSINGDATE,121) BETWEEN @BeginDate AND @EndDate
            group by m.TRANSACTIONTYPE,l.name--,convert(varchar(10),m.CLOSINGDATE,121) 
UNION
select 
							case WHEN m.TRANSACTIONTYPE='AE_COMMON'
							THEN 'SMT'
							 WHEN m.TRANSACTIONTYPE='SMT'
							THEN 'SMT'
							 WHEN m.TRANSACTIONTYPE='Amazon'
							THEN 'Amazon'
							 WHEN m.TRANSACTIONTYPE='Amazon01'
							THEN 'Amazon'
							 WHEN m.TRANSACTIONTYPE='cart'
							THEN 'cart'
							 WHEN m.TRANSACTIONTYPE='eBay'
							THEN 'eBay'
							 WHEN m.TRANSACTIONTYPE='lazada'
							THEN 'lazada'
							 WHEN m.TRANSACTIONTYPE='sendmoney'
							THEN 'sendmoney'
							 WHEN m.TRANSACTIONTYPE='Wish Cart'
							THEN 'Wish'
							 WHEN m.TRANSACTIONTYPE='Wish'
							THEN 'Wish'
							 WHEN m.TRANSACTIONTYPE='shopee Cart'
							THEN 'Shopee'
						 WHEN m.TRANSACTIONTYPE='Shopee'
							THEN 'Shopee'
					   WHEN m.TRANSACTIONTYPE='线下交易'
							THEN '线下交易'
			      WHEN m.TRANSACTIONTYPE='Tophatter'
							THEN 'Tophatter'
            WHEN m.TRANSACTIONTYPE='9.9Buy'
							THEN '9.9Buy'
							ELSE 'elsepingtai'
							end as pingtai ,
            sum(m.ExpressFare) as ExpressFare ,
            --convert(varchar(10),m.CLOSINGDATE,121) as CLOSINGDATE,
            l.name as wlway,
            CASE WHEN l.name ='4PX海外仓美东'
            THEN '4PX(海外仓)'
            WHEN l.name='4PX海外美东仓'
            THEN '4PX(海外仓)'
            WHEN l.name='DHL'
            THEN '佳成国际快递'
            WHEN l.name='DHL普通小包'
            THEN '德国小包DHL'
            WHEN l.name='EMS'
            THEN '佳成国际快递'
            WHEN l.name='E邮宝'
            THEN '金华E邮宝'
            WHEN l.name='E邮宝线下（常州）'
            THEN '铭志物流'
            WHEN l.name='FBW WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='LWE马来西亚东'
            THEN '利威供应链'
            WHEN l.name='LWE马来西亚西'
            THEN '利威供应链'
            WHEN l.name='LWE新加坡小包'
            THEN '利威供应链'
            WHEN l.name='WISH邮挂号'
            THEN 'wish邮'
            WHEN l.name='wish邮南京'
            THEN '铭志物流'
            WHEN l.name='WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='国内快递'
            THEN '顺丰快递运费'
            WHEN l.name='佳成专线'
            THEN '佳成国际快递'
            WHEN l.name='捷德宝'
            THEN '捷买送物流'
            WHEN l.name='顺丰俄罗斯小包挂号'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺丰俄罗斯小包平邮'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺邮宝挂号'
            THEN '顺友物流'
            WHEN l.name='顺邮宝平邮'
            THEN '顺友物流'		
            WHEN l.name='土耳其平邮'
            THEN '捷买送物流'
            WHEN l.name='香港平邮'
            THEN '三态物流'
            WHEN l.name='新加坡挂号'
            THEN '4PX(递四方物流)'
            WHEN l.name='新加坡平邮+'
            THEN '4PX(递四方物流)'
            WHEN l.name='中国邮政挂号小包'
            THEN 'SMT小包平邮+'
            WHEN l.name='中国邮政平常小包+(义乌)'
            THEN 'SMT小包平邮+'
            WHEN l.name='中邮挂号(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮挂号(常熟)'
            THEN '铭志物流'
            WHEN l.name='中邮平邮(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮平邮(常熟)'
            THEN '燕文专线快递'
            WHEN l.name='中邮小包平邮义乌'
            THEN '金华邮局小包'
            WHEN l.name='万邑通线上平邮'
            THEN '万邑通'
            ELSE '物流方式找不到物流公司'
            End as wlCompany--物流公司  
    --into #TempfaretablePTrade
FROM P_Trade m 
            left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID
            left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
            left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE 
            WHERE 
					convert(varchar(10),m.CLOSINGDATE,121) BETWEEN @BeginDate AND @EndDate
            group by m.TRANSACTIONTYPE,l.name--,convert(varchar(10),m.CLOSINGDATE,121)


select  wlCompany as 'wlCompany',
CAST(round(isnull(SUM( eBay),0),2) as decimal(8,2) ) as 'eBay',
CAST(round(isnull(SUM( Wish),0),2) as NUMERIC(8,2)) as 'Wish',
CAST(round(isnull(SUM( Amazon),0),2) as NUMERIC(8,2)) as 'Amazon',
CAST(round(isnull(SUM( SMT),0),2) as NUMERIC(8,2)) as 'SMT',
CAST(round(isnull(SUM( Shopee),0),2) as NUMERIC(8,2)) as 'Shopee' 
INTO #Temptempfeetable
FROM #Tempfaretable 
--行 列转换
pivot(
SUM( ExpressFare) for pingtai
in(eBay,Wish,Amazon,SMT,Shopee,elsePT)
) as newfare
group by  wlCompany
order by  wlCompany

---------
select ttft.*,
isnull(e.expressFare,0) as 'FactFee'
INTO #TheLastTemp
from  #Temptempfeetable ttft
LEFT JOIN express e ON e.wlCompany=ttft.wlCompany

--SELECT * from #Temptempfeetable

SELECT 
tpf.*,
SUM(tpf.eBay+tpf.Wish+tpf.SMT+tpf.Amazon+tpf.Shopee) as total 
into #totalColTempFee
 from #Temptempfeetable tpf
GROUP BY tpf.wlCompany,tpf.eBay,tpf.Wish,tpf.SMT,tpf.Amazon,tpf.Shopee

--select * from #totalColTempFee
CREATE TABLE #wahaha(
wlCompany VARCHAR(50),
eBay FLOAT,
Wish FLOAT,
Amazon Float,
SMT FLOAT,
Shopee FLOAT,
total float
)
INSERT into #wahaha
SELECT 
tpf.*,
SUM(tpf.eBay+tpf.Wish+tpf.SMT+tpf.Amazon+tpf.Shopee) as total 
 from #Temptempfeetable tpf
GROUP BY tpf.wlCompany,tpf.eBay,tpf.Wish,tpf.SMT,tpf.Amazon,tpf.Shopee
UNION 
select
aaa.wlCompany,
sum(aaa.eBay) as eBay,
sum(aaa.Wish) as Wish,
sum(aaa.Amazon) as Amazon,
sum(aaa.SMT) as SMT,
sum(aaa.Shopee) as Shopee,
isnull(sum(aaa.huizong),0) as 'total'
 from (select
case wlCompany
WHEN '随便' THEN '随便'
ELSE '汇总' END
  as wlCompany,
sum(eBay) as eBay,
sum(Wish) as Wish,
sum(Amazon) as Amazon,
sum(SMT) as SMT,
sum(Shopee) as Shopee,
SUM(eBay+Wish+SMT+Amazon+Shopee) as 'huizong'
FROM #Temptempfeetable
group by wlCompany) aaa
where ISNULL(@wlCompany,'')='' or wlCompany=@wlCompany
group by wlCompany

select whh.*,e.expressFare as fare from #wahaha whh
LEFT JOIN express e ON e.wlCompany=whh.wlCompany
where ISNULL(@wlCompany,'')='' or whh.wlCompany=@wlCompany


drop table #Tempfaretable
drop TABLE  #Temptempfeetable
drop table #TheLastTemp
drop table #wahaha

END