
create Procedure [dbo].[P_EvaluateTotal_ypmy_rjf]
  @CheckType int,
   @StartDate DateTime,
  @EndDate  DateTime
As
begin
 if @CheckType=1
 begin
    -- 物流方式
     create table #Evaluatetemp(
  logicsWayNID int ,-- 物流方式id
  Positivenum int,--好评数量
  Neutralnum int,--中评数量
  Negativenum int,--差评数量
  OrderAMT money null-- 订单金额(rmb)
  )
   -- 好评 正常表
   insert #Evaluatetemp(logicsWayNID,Positivenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid 
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 异常表 
     insert #Evaluatetemp(logicsWayNID,Positivenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1 
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 历史表 
     insert #Evaluatetemp(logicsWayNID,Positivenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')      
 
   -- 中评 正常表
   insert #Evaluatetemp(logicsWayNID,Neutralnum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 中评 异常表 
     insert #Evaluatetemp(logicsWayNID,Neutralnum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2 
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 中评 历史表 
     insert #Evaluatetemp(logicsWayNID,Neutralnum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2 
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')     
   
    -- 差评 正常表
   insert #Evaluatetemp(logicsWayNID,Negativenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 差评 异常表 
     insert #Evaluatetemp(logicsWayNID,Negativenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3 
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 差评 历史表 
     insert #Evaluatetemp(logicsWayNID,Negativenum,OrderAMT)
   select logicsWayNID,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3  
      and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
 -- 查数据  
   select 
   bl.name as MoreType,
   SUM(ISNULL(m.Positivenum,0)) as 好评数,
   SUM(ISNULL( m.Neutralnum,0))  as	中评数,
    SUM(ISNULL(m.Negativenum,0))  as	差评数,
   SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) as	总评价数,
       -- 好评率=好评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Positivenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
   as	好评率,
   -- 中差评率=（中评数+差评数）/（好评数+中评数+差评数）
     convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else (SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))
   +SUM(ISNULL(m.Negativenum,0)))  end ))
     as	中差评率,
   -- 差评率=差评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Negativenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
  as	差评率,
   SUM(ISNULL(m.OrderAMT,0)) as	'总成交额(￥)',
   -- 客单价（￥）=总成交额(￥)/总评价数
   case when ( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) )=0 then 0
   else SUM(ISNULL(m.OrderAMT,0))/( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) ) end as	'客单价(￥)'
   from #Evaluatetemp m
   left join B_LogisticWay bl on bl.NID=m.logicsWayNID
   group by bl.name

 end
 else if @CheckType=2
 begin
  -- 国家
  create table #Evaluatetempgj(
  CountryZnName varchar(100) ,-- 国家中文名
  Positivenum int,--好评数量
  Neutralnum int,--中评数量
  Negativenum int,--差评数量
  OrderAMT money null-- 订单金额(rmb)
  )
   -- 好评 正常表
   insert #Evaluatetempgj(CountryZnName,Positivenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 异常表 
     insert #Evaluatetempgj(CountryZnName,Positivenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 历史表 
  
     insert #Evaluatetempgj(CountryZnName,Positivenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
 and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
   -- 中评 正常表
      insert #Evaluatetempgj(CountryZnName,Neutralnum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
 and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 中评 异常表
        insert #Evaluatetempgj(CountryZnName,Neutralnum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121) 
and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 中评 历史表 
      insert #Evaluatetempgj(CountryZnName,Neutralnum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
   and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
    -- 差评 正常表
        insert #Evaluatetempgj(CountryZnName,Negativenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 差评 异常表 
          insert #Evaluatetempgj(CountryZnName,Negativenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')  
  -- 差评 历史表 
         insert #Evaluatetempgj(CountryZnName,Negativenum,OrderAMT)
   select bc.CountryZnName,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_Country bc on bc.CountryCode=p.SHIPTOCOUNTRYCODE
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
 -- 查数据  
   select 
   m.CountryZnName as MoreType,
   SUM(ISNULL(m.Positivenum,0)) as 好评数,
   SUM(ISNULL( m.Neutralnum,0))  as	中评数,
    SUM(ISNULL(m.Negativenum,0))  as	差评数,
   SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) as	总评价数,
       -- 好评率=好评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Positivenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
    as	好评率,
   -- 中差评率=（中评数+差评数）/（好评数+中评数+差评数）
     convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else (SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))
   +SUM(ISNULL(m.Negativenum,0)))  end ))
    as	中差评率,
   -- 差评率=差评数/（好评数+差评数）
   convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Negativenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
   as	差评率,
   SUM(ISNULL(m.OrderAMT,0)) as	'总成交额(￥)',
   -- 客单价（￥）=总成交额(￥)/总评价数
   case when ( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) )=0 then 0
   else SUM(ISNULL(m.OrderAMT,0))/( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) ) end as	'客单价(￥)'
   from #Evaluatetempgj m
   group by m.CountryZnName
 end
 else if @CheckType=3
 begin
   --itemid 
    create table #Evaluatetempitemid(
  ItemID varchar(100) ,-- itemid,
  CURRENCYCODE varchar(100), -- 币种
  [User] varchar(100), -- 卖家ID
  Positivenum int,--好评数量
  Neutralnum int,--中评数量
  Negativenum int,--差评数量
  OrderAMT money null-- 订单金额(rmb)
  )
    -- 好评 正常表
   insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Positivenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 异常表 
   insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Positivenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 历史表
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Positivenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
	  
	  -- 中评 正常表
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Neutralnum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 中评 异常表
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Neutralnum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 中评 历史表 
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Neutralnum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
    -- 差评 正常表
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Negativenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 差评 异常表 
   insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Negativenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 差评 历史表 
     insert #Evaluatetempitemid(ItemID,CURRENCYCODE,[User],Negativenum,OrderAMT)
   select m.ItemID,p.CURRENCYCODE,p.[user],1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
	  
	-- 查数据  
   select 
   m.ItemID as MoreType,
   SUM(ISNULL(m.Positivenum,0)) as 好评数,
   SUM(ISNULL( m.Neutralnum,0))  as	中评数,
    SUM(ISNULL(m.Negativenum,0))  as	差评数,
   SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) as	总评价数,
       -- 好评率=好评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Positivenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
    as	好评率,
   -- 中差评率=（中评数+差评数）/（好评数+中评数+差评数）
     convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else (SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))
   +SUM(ISNULL(m.Negativenum,0)))  end ))
   as	中差评率,
   -- 差评率=差评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Negativenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
  as	差评率,
   SUM(ISNULL(m.OrderAMT,0)) as	'总成交额(￥)',
   -- 客单价（￥）=总成交额(￥)/总评价数
   case when ( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) )=0 then 0
   else SUM(ISNULL(m.OrderAMT,0))/( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) ) end as	'客单价(￥)',
   MAX(ISNULL(m.CURRENCYCODE,'')) as 币种,
   MAX(ISNULL(m.[User],'')) as 卖家ID
   from #Evaluatetempitemid m
   group by m.ItemID     
  
 end
 else if @CheckType=4
 begin
   -- sku
    create table #Evaluatetempsku(
  SKU varchar(100) ,-- sku,
  Positivenum int,--好评数量
  Neutralnum int,--中评数量
  Negativenum int,--差评数量
  OrderAMT money null-- 订单金额(rmb)
  )
    -- 好评 正常表
   insert #Evaluatetempsku(m.sku,Positivenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 异常表 
   insert #Evaluatetempsku(m.sku,Positivenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal') 
  -- 好评 历史表
   insert #Evaluatetempsku(m.sku,Positivenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=1
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
	  
	  -- 中评 正常表
     insert  #Evaluatetempsku(m.sku,Neutralnum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 中评 异常表
     insert  #Evaluatetempsku(m.sku,Neutralnum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 中评 历史表 
     insert  #Evaluatetempsku(m.sku,Neutralnum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=2
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
    -- 差评 正常表
     insert #Evaluatetempsku(m.sku,Negativenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 差评 异常表 
     insert #Evaluatetempsku(m.sku,Negativenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_TradeUn p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
  -- 差评 历史表 
     insert #Evaluatetempsku(m.sku,Negativenum,OrderAMT)
   select m.SKU,1,p.AMT*ISNULL(bcc.ExchangeRate,1) 
   from P_EbayEvaluate m
   inner join P_Trade_His p on p.NID=m.tradenid
   left join B_CurrencyCode bcc on  bcc.CURRENCYCODE=p.CURRENCYCODE	
   where ISNULL(m.CommentType,0)=3
   and Convert(varchar(10),M.CommentTime,121) 
      between Convert(varchar(10),@StartDate,121) 
	  and Convert(varchar(10),@EndDate,121)
	  and (p.ADDRESSOWNER='ebay' or p.ADDRESSOWNER='paypal')
	  
	-- 查数据  
   select 
   m.SKU as MoreType,
   SUM(ISNULL(m.Positivenum,0)) as 好评数,
   SUM(ISNULL( m.Neutralnum,0))  as	中评数,
    SUM(ISNULL(m.Negativenum,0))  as	差评数,
   SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) as	总评价数,
       -- 好评率=好评数/（好评数+差评数）
 convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Positivenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
  as	好评率,
   -- 中差评率=（中评数+差评数）/（好评数+中评数+差评数）
   convert(numeric(8,2),(case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else (SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))
   +SUM(ISNULL(m.Negativenum,0)))  end ))
   as	中差评率,
   -- 差评率=差评数/（好评数+差评数）
  convert(numeric(8,2), (case when (SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))=0 then 0 
   else SUM(ISNULL(m.Negativenum,0))*100.00/(SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL(m.Negativenum,0)))  end ))
   as	差评率,
   SUM(ISNULL(m.OrderAMT,0)) as	'总成交额(￥)',
   -- 客单价（￥）=总成交额(￥)/总评价数
   case when ( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) )=0 then 0
   else SUM(ISNULL(m.OrderAMT,0))/( SUM(ISNULL(m.Positivenum,0))+SUM(ISNULL( m.Neutralnum,0))+SUM(ISNULL(m.Negativenum,0)) ) end as	'客单价(￥)',
   MAX(ISNULL(bg.SalerName,'')) as '业绩归属人1',
   MAX(ISNULL(bg.SalerName2,'')) as '业绩归属人2'
   from #Evaluatetempsku m
   left join B_GoodsSKU bgs on bgs.SKU=m.SKU
   left join B_Goods bg on bg.NID=bgs.GoodsID
   group by m.SKU     
  
 end
end
