CREATE PROCEDURE [dbo].[P_ExceptionTradeToException] @NID INT = 0,
                                             @ExceptTag INT = 0,
                                             @ExceptionName VARCHAR(200) = '',
                                             @BatchNum VARCHAR(100) = ''
AS
BEGIN
	DECLARE @OrigFilterFlag INT = 0 , @ErrorCount INT = 0, @Result INT = 0
	BEGIN TRANSACTION
	    SET @OrigFilterFlag =  ISNULL((SELECT TOP 1 FilterFlag FROM P_TradeUn WHERE NID = @NID),0)
	    
		UPDATE p_tradeUn
		SET FilterFlag = @ExceptTag
			,PROTECTIONELIGIBILITYTYPE= @ExceptionName
			,BatchNum = @BatchNum
		WHERE nid = @NID
		SET @ErrorCount = @ErrorCount + @@ERROR 
		--如果缺货转其它，取消占用库存
		IF @OrigFilterFlag = 1 
		BEGIN
			exec P_KC_FreeReservationNumUn @NID
		end		
		--如果原订单是缺货订单，并且转入了退货或取消订单，则...
		IF ((@OrigFilterFlag = 1) AND @ExceptTag IN (2,3))
		BEGIN
		  --将缺货未完成，强制变成完成。 
		  UPDATE CG_OutofStock 
		  SET OutOfStockStatus = 4
		  WHERE TradeNID = @NID AND OutOfStockStatus <> 4
		  SET @ErrorCount = @ErrorCount + @@ERROR 
		END ELSE 
		IF (@ExceptTag = 1) AND (@OrigFilterFlag <> 1)
		BEGIN
		  --将完成订单，强制变成待采购(暂时没考虑是否库存充足)
		  UPDATE CG_OutofStock 
		  SET OutOfStockStatus = 0
		  WHERE TradeNID = @NID AND OutOfStockStatus = 4	
		  SET @ErrorCount = @ErrorCount + @@ERROR 
		END
	IF @ErrorCount = 0 
	BEGIN 
	  COMMIT TRANSACTION
	END ELSE 
    BEGIN 
      ROLLBACK TRANSACTION
      SET @Result = 1
    END 
    --SELECT @Result AS Result
END

