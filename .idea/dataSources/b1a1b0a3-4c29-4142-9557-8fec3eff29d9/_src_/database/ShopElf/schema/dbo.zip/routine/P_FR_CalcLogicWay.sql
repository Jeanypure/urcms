CREATE proc [P_FR_CalcLogicWay]
	                         @TradeNID INT ,
	                         @TableFlag INT = 0 --0:P_trade; 1: P_TradeUn
as
begin
	set nocount on
	Create Table #CalcLogicWay
		(
			LogicWayNID int,
			Itype int default 0 ,
			CountryCode varchar(5) default '',
			ConditionValue	money default 0 ,
			ConditionValue2 money default 0,
			ShopLogisticWay Nvarchar(max) default '',
			StoreNid int default -1 ,
			LogicWayRuleID  int default 0,
			nid int default 0
		)
	--查询设置的
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,
		lws.IType,
		lws.CountryCode,
		lws.ConditionValue,
		lws.ConditionValue2,
		lws.ShopLogisticWay,
		lws.StoreNid,
		lwrs.nid ,
		lws.NID 
	from 
	    B_LogisticWayRuleSet lwrs 
	    inner join  B_LogisticWaySet lws on lwrs.nid =lws.LogisticWayRuleID
	where 
		exists (select top 1  NID from B_LogisticWay 
		   where lwrs.LogisticWayNID =nid and AutoOrder=1  and used =0 )
	    and lwrs.used =0
 
    --插入各个没有设置信息的类型
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,1,'ALL',0,0,'',-1 , lwrs.nid ,0
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and  Itype=1)	
	 and exists (select top 1 NID from B_LogisticWay where lwrs.LogisticWayNID=nid and  AutoOrder=1  and used =0 )

	
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,2,'',0,9999999,'',-1,lwrs.nid ,0
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID =LogicWayRuleID and Itype=2)			
        and exists (select top 1 NID from B_LogisticWay where lwrs.LogisticWayNID =nid and AutoOrder=1  and used =0 )
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,3,'',0,9999999,'',-1 ,lwrs.nid ,0
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and  Itype=3)			
        and exists (select  top 1 NID from B_LogisticWay where lwrs.LogisticWayNID=nid and AutoOrder=1  and used =0 )
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,4,'',0,0,'ALL',-1,lwrs.nid ,0   
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and Itype=4)
		and exists (select top 1 NID from B_LogisticWay where lwrs.LogisticWayNID=nid and  AutoOrder=1  and used =0 )			
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,5,'',0,0,'ALL',-1 ,lwrs.nid,0   
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and  Itype=5)
		and exists  (select top 1  NID from B_LogisticWay where lwrs.LogisticWayNID=nid and AutoOrder=1  and used =0 )		
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,6,'',0,0,'ALL',-1,lwrs.nid  ,0    
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and Itype=6)
		and  exists (select top 1 NID from B_LogisticWay where lwrs.LogisticWayNID=nid and AutoOrder=1  and used =0 )		
	--add by ylq 2015-06-23 	
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,7,'',0,0,'ALL',-1 ,lwrs.nid ,0
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and Itype=7)
		and  exists (select top 1  NID from B_LogisticWay where lwrs.LogisticWayNID=nid and AutoOrder=1  and used =0 )
				
	insert into #CalcLogicWay	
	select 
		lwrs.LogisticWayNID,8,'',0,9999999,'',-1,lwrs.nid ,0
	from 
		B_LogisticWayRuleSet lwrs
	where 
		used =0 and
		 not exists (select top 1  LogicWayRuleID from #CalcLogicWay where lwrs.NID=LogicWayRuleID and Itype=8)
		and exists (select top 1 NID from B_LogisticWay where lwrs.LogisticWayNID=nid and AutoOrder=1  and used =0 )			
		
		
		
	--查找订单信息
	declare
		@CountryCode varchar(5) = '',
		@ShopLogicWay nvarchar(max)='',
		@AmtRMB	money =0,
		@TotalWeight	float=0,
		@OldLogisticWayNID INT=0,	--原单物流
		@OldTrackNo varchar(50)='', --old trackno 
		@LogisticWayNID INT=0,		--new	
		@DefaultExpressNID int=0,
		@DefaultStoreNid int=0,--判断满足这个仓库后，再匹配物流方式条件
		@DefaultSendStoreNid int=0,--匹配物流方式条件后，默认的发货仓库
		@ADDRESSOWNER  varchar(50) = '',
		@skus  nvarchar(max) = '',		
		@Suffix  varchar(200) = '',	
		@IsCharged varchar(50) = '',                   --是否带电
		@ChargedName varchar(50) = '带电商品',          --带电的显示名称，这里定义常量，下次如果要改这个名字，那么就在这里修改
		@iCount int  = 0,	
		
		@IsPowder varchar(50) = '',  --是否粉末
		@PowderName varchar(50) = '粉末商品',   --粉末的显示名称
		@IsLiquid varchar(50) = '', --是否液体
		@LiquidName varchar(50) = '液体商品',    --液体的显示名称
		@IsMagnetism varchar(50) = '', --是否带磁
		@MagnetismName varchar(50) = '带磁商品',    --液体的显示名称
		
		@SHIPTOZIP varchar(50)='',          --收货邮编
		@SHIPTOCOUNTRYCODE varchar(50)='',   -- 国家代码 判断TW 台湾的
		@SHIPPINGAMTRMB money=0                  --买家运费
	--查找USD的汇率
	Declare
		@ExchangeRate float, @ExchangeRateUS float , @CURRENCYCODE VARCHAR(10) = ''
	IF EXISTS(SELECT top 1 nid FROM P_trade(nolock) WHERE NID = @TradeNID)
	 SET @CURRENCYCODE= (SELECT TOP 1  CURRENCYCODE
	                       FROM P_Trade(nolock) WHERE NID = @TradeNID)
	ELSE 
	 SET @CURRENCYCODE= (SELECT TOP 1  CURRENCYCODE
	                       FROM P_TradeUn(nolock) WHERE NID = @TradeNID)	
	IF ISNULL(@CURRENCYCODE,'') = ''
	 SET @CURRENCYCODE = 'USD'
	 
	
	set
		@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE=@CURRENCYCODE),0)	
 	if @ExchangeRate=0
 	  set 	@ExchangeRate=1	
 	  
 	--美元汇率
 	set
		@ExchangeRateUS =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 	if @ExchangeRateUS=0
 	  set 	@ExchangeRateUS=1	  
 	 
 	--判断是在正常表操作,还是异常表  
 	set @IsCharged = 'zzzzzzz'   --add by ylq 2015-07-24 因为找不到，所以确保删除, 原先是空格，导致可能不删
 	set @IsPowder = 'zzzzzzz'    --add by ylq 2015-07-24 因为找不到，所以确保删除, 原先是空格，导致可能不删
 	set @IsLiquid = 'zzzzzzz'     --add by ylq 2015-07-24 因为找不到，所以确保删除, 原先是空格，导致可能不删
 	set @IsMagnetism='zzzzzzz'    --add cf 
 	IF ISNULL(@TableFlag,0) =0 
 	BEGIN 		
		select 
			@CountryCode	=isnull(shiptocountrycode,'ALL'),
			@ShopLogicWay	=isnull(CUSTOM,'ALL'),
			@AmtRMB			=ISNULL(AMT,0)*@ExchangeRate,
			@ADDRESSOWNER   =isnull(ADDRESSOWNER,''),
			@SHIPTOCOUNTRYCODE=isnull(SHIPTOCOUNTRYCODE,''),
			@TotalWeight	=isnull(TotalWeight,0)*1000,
			--@skus=dbo.Ex_GetOrderSKUSNoQty(nid),
			@Suffix=SUFFIX,
			@SHIPTOZIP=isnull(SHIPTOZIP,''),
			@SHIPPINGAMTRMB =ISNULL(SHIPPINGAMT,0)*@ExchangeRate,
			@OldLogisticWayNID=ISNULL(logicsWayNID,0),
			@OldTrackNo = ISNULL(TrackNo,'')
		from 
			p_trade(nolock)
		where 
			nid=@TradeNID
		
		--检测是否有带电的商品	
		if exists (select top 1  d.NID from p_tradedt(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsCharged = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsCharged = @ChargedName
		end  
		--add by ylq 2015-07-01  检测是否是粉末的商品
		if exists (select d.NID from p_tradedt(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsPowder = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsPowder = @PowderName
		end   
		-- 检测是否液体的商品
		if exists (select top 1 d.NID from p_tradedt(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsLiquid = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsLiquid = @LiquidName
		end   
		-- 检测是否带磁商品
		if exists (select top 1 d.NID from p_tradedt(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsMagnetism = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsMagnetism = @MagnetismName
		end 
		
		-- add by ylq 2015-06-23 
		select @iCount = COUNT(*) from ( select StoreID from P_TradeDt(nolock) where TradeNID = @TradeNID group by StoreID ) A
		if @iCount = 1 begin
		  set @DefaultStoreNid = (select top 1 StoreId from P_TradeDt(nolock) where TradeNID = @TradeNID)
		end
		else begin
		  set @DefaultStoreNid = -2 
		end;
		-- ----------------------------------------------------------         
    END ELSE 
    BEGIN
    	select 
			@CountryCode	=isnull(shiptocountrycode,'ALL'),
			@ShopLogicWay	=isnull(CUSTOM,'ALL'),
			@AmtRMB			=ISNULL(AMT,0)*@ExchangeRate,
			@ADDRESSOWNER   =isnull(ADDRESSOWNER,''),
			@SHIPTOCOUNTRYCODE=isnull(SHIPTOCOUNTRYCODE,''),
			@TotalWeight	=isnull(TotalWeight,0)*1000,
			--@skus=dbo.Ex_GetOrderSKUSNoQty(nid),
			@Suffix=SUFFIX,
			@SHIPTOZIP=isnull(SHIPTOZIP,''),
			@SHIPPINGAMTRMB =ISNULL(SHIPPINGAMT,0)*@ExchangeRate,
			@OldLogisticWayNID=ISNULL(logicsWayNID,0),
			@OldTrackNo = ISNULL(TrackNo,'')
		from 
			p_tradeun
		where 
			nid=@TradeNID	
			
		--检测是否有带电的商品	
		if exists (select top 1 d.NID from p_tradedtun(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsCharged = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsCharged = @ChargedName
		end    
		--add by ylq 2015-06-24  检测是否是粉末的商品
		if exists (select top 1 d.NID from p_tradedtun(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsPowder = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsPowder = @PowderName
		end   
		-- 检测是否液体的商品
		if exists (select top 1  d.NID from p_tradedtun(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsLiquid = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsLiquid = @LiquidName
		end   
		-- 检测是否带磁商品
		if exists (select top 1 d.NID from p_tradedtun(nolock) d left join B_GoodsSKU(nolock) gs on d.SKU = gs.SKU 
		           left join B_Goods(nolock) g on gs.GoodsID = g.NID where g.IsMagnetism = 1  and d.TradeNID=@TradeNID)	
		begin
		  set @IsMagnetism = @MagnetismName
		end 
		
		-- add by ylq 2015-06-23 
	 
		select @iCount = COUNT(*) from ( select StoreID from p_tradedtun(nolock) where TradeNID = @TradeNID group by StoreID ) A
		if @iCount = 1 begin
		  set @DefaultStoreNid = (select top 1 StoreId from p_tradedtun(nolock) where TradeNID = @TradeNID)
		end
		else begin
		  set @DefaultStoreNid = -2   
		end;
		-- ----------------------------------------------------------      
		  	
    END		
      
     SET @ADDRESSOWNER  = RTRIM(LTRIM(LOWER(@ADDRESSOWNER)))
     SET @Suffix  = RTRIM(LTRIM(LOWER(@Suffix)))     
    	 
	--删除记录
	--add by ylq 2015-06-23 
	Delete 
		#CalcLogicWay
	where
		Itype =7
		and (isnull(StoreNid,-1)<> -1 and  isnull(StoreNid,'')<>@DefaultStoreNid )
	-- end add
	
			
	Delete 
		#CalcLogicWay
	where
		Itype =1
		and (isnull(CountryCode,'ALL')<> 'ALL' and  isnull(CountryCode,'')<>@CountryCode )
	--删除不符合邮编规则的记录 --------
	Delete 
		#CalcLogicWay
	where
		Itype =1 and isnull(CountryCode,'ALL')<> 'ALL'  and nid in ( 
	          select logisticwaysetid from B_LogisticWayRulePostCode  
                where logisticwaysetid not in 
                 (select logisticwaysetid from B_LogisticWayRulePostCode where 
                     @SHIPTOZIP >=   postcodeS   and  @SHIPTOZIP < postcodeE 
                   group by logisticwaysetid) group by logisticwaysetid)
	---------------------------------------
		
	Delete 
		#CalcLogicWay
	where
		Itype = 2 and not 
		(@AmtRMB >= isnull(ConditionValue,0) and 
		 @AmtRMB < isnull(ConditionValue2,0))
				
	Delete 
		#CalcLogicWay
	where
		Itype = 3 and not 
		(@TotalWeight >=  isnull(ConditionValue,0) and
		 @TotalWeight <  isnull(ConditionValue2,0))
		

	/*if (isnull(@ShopLogicWay,'ALL') <> 'ALL') and (ISNULL(@ADDRESSOWNER,'') = 'amazon11')
	begin
		Delete 
			#CalcLogicWay
		where
			Itype = 4 and	 isnull(ShopLogisticWay,'ALL')<>isnull(@ShopLogicWay,'ALL')
    end
    */
	
	Delete 
		#CalcLogicWay
	where
		Itype = 4 and	(isnull(ShopLogisticWay,'ALL')<> 'ALL' and  isnull(ShopLogisticWay,'ALL')<>isnull(@ShopLogicWay,'ALL'))


	--Delete 
	--	#CalcLogicWay
	--where
	--	Itype = 5 and	(isnull(ShopLogisticWay,'ALL')<> 'ALL' and  
	--		((select count(nid) from p_tradedt where CHARINDEX(','+sku+',', ','+isnull(ShopLogisticWay,'ALL')+',')>0 and TradeNID=@TradeNID)
	--			<>
	--		(select count(nid) from p_tradedt where TradeNID=@TradeNID ) )
	--		  )
    
    --这里除了判断SKU,是否在,或者SKU是否带电 并且物流方式里设置了带电
    if (@IsCharged = @ChargedName) or    --带电的判断,增加是否带电的判断
       (@IsPowder = @PowderName) or   --粉末的判断
       (@IsLiquid = @LiquidName)   --液体的判断
       or (@IsMagnetism = @MagnetismName) --带磁
    begin
	  Delete 
		#CalcLogicWay
	  where
		Itype = 5 and isnull(ShopLogisticWay,'ALL')<> 'ALL' 
		    and  (not exists 
			       (select nid from p_tradedt 
			        where (CHARINDEX(','+sku+',', ','+isnull(ShopLogisticWay,'ALL')+',')>0  
			        and TradeNID=@TradeNID)
			       )   
			     )
			and CHARINDEX(',' + @IsCharged + ',', ','+isnull(ShopLogisticWay,'ALL')+',') <= 0 
			and CHARINDEX(',' + @IsPowder + ',', ','+isnull(ShopLogisticWay,'ALL')+',') <= 0   
			and CHARINDEX(',' + @IsLiquid + ',', ','+isnull(ShopLogisticWay,'ALL')+',') <= 0       
			and CHARINDEX(',' + @IsMagnetism + ',', ','+isnull(ShopLogisticWay,'ALL')+',') <= 0 
    end
    else begin                       --不带电的判断,普通判断
      Delete 
		#CalcLogicWay
	  where
		Itype = 5 and isnull(ShopLogisticWay,'ALL')<> 'ALL' 
		    and  (not exists 
			       (select nid from p_tradedt(nolock) 
			        where (CHARINDEX(','+sku+',', ','+isnull(ShopLogisticWay,'ALL')+',')>0  
			        and TradeNID=@TradeNID)
			       )  
			     )
    end			     
			
			
	if 	exists(select itype from #CalcLogicWay where CHARINDEX(','+@Suffix+',', ','+isnull(ShopLogisticWay,'ALL')+',')>0 )
	begin	

		Delete 
			#CalcLogicWay
		where
			Itype = 6 and	CHARINDEX(','+@Suffix+',', ','+isnull(ShopLogisticWay,'ALL')+',') = 0 and isnull(ShopLogisticWay,'ALL')<> 'ALL' 
			
	end	
	else
	begin

		Delete 
			#CalcLogicWay
		where
			Itype = 6 and	(isnull(ShopLogisticWay,'ALL')<> 'ALL' and  isnull(ShopLogisticWay,'ALL')<>isnull(@Suffix,'ALL'))	
	end
	
	 Delete 
		#CalcLogicWay
	where
		Itype = 8 and not
		 (@SHIPPINGAMTRMB >= isnull(ConditionValue,0) and 
		  @SHIPPINGAMTRMB < isnull(ConditionValue2,0))	
	-------------------------eub规则 start-------------------------------------
    
	--检查第一条如果是EUB，并用单品价格—+单品运费规则是否>=5美金
	set @AmtRMB =0 
	IF ISNULL(@TableFlag,0) =0 
	BEGIN 		
		--判断是否拆分过
		select 
			@AmtRMB			=Max(case when L_QTY<>0  then ISNULL(l_AMT+L_ShipFee,0)*@ExchangeRate/(case when isnull(L_TAXAMT,0)=0 then L_QTY else isnull(L_TAXAMT,0) end) 
					else ISNULL(l_AMT+L_ShipFee,0)*@ExchangeRate end)
		from 
			P_TradeDt(nolock)
		where 
			TradeNID=@TradeNID		
	end
	else
	begin
		--判断是否拆分过
		select 
			@AmtRMB			=Max(case when L_QTY<>0  then ISNULL(l_AMT+L_ShipFee,0)*@ExchangeRate/(case when isnull(L_TAXAMT,0)=0 then L_QTY else isnull(L_TAXAMT,0) end) 
					else ISNULL(l_AMT+L_ShipFee,0)*@ExchangeRate end)
		from 
			P_TradeDtUn(nolock)
		where 
			TradeNID=@TradeNID		
	end	
	
--select  'rmb',	@AmtRMB		
	if @AmtRMB < 5*@ExchangeRateUS
	begin
	  Delete 
		c
	  from  #CalcLogicWay c
	  inner join B_LogisticWayRuleSet l on l.nid=c.LogicWayRuleID 
	  where c.Itype = 2 and  l.eub=1 
	end  
	-------------------------eub规则 end----------------------------------------	
	
	--查找剩余的，数量是Type类型的，目前是7个，按顺序排序，取第一个
	-- 有重量或金额多条记录重叠时有错误，要汇总才可以
	select LogicWayNID,LogicWayRuleID,Itype  
		into #CalcLogicWay1  
	from #CalcLogicWay 
	group by   LogicWayNID ,LogicWayRuleID,Itype	

	select 
		TOP 1 @LogisticWayNID = isnull(c.LogicWayNID,0),
		@DefaultExpressNID =isnull(l.DefaultExpressNID,0) ,
		@DefaultSendStoreNid=isnull(l.DefaultStoreNID,0) 
		--isnull(AllLogicSet.LogisticWayNID,0)
	FROM 		
		#CalcLogicWay1 c
	inner join 
		B_LogisticWay l on l.NID= c.LogicWayNID	
	inner join B_LogisticWayRuleSet lwrs on lwrs.nid =c.LogicWayRuleID 
	    
	where 
		l.AutoOrder=1 
	group by isnull(c.LogicWayNID,0),isnull(c.LogicWayRuleID,0),
	isnull(l.DefaultExpressNID,0),isnull(l.DefaultStoreNID,0),lwrs.AutoNo 		
	having count(Itype)>7
	order by   lwrs.AutoNo 
		
	if @LogisticWayNID<> 0 
	begin
	--  set @LogisticWayNID=ISNULL((select ParaValue from B_SysParams where ParaCode ='DefaultExpress'),0)	
	  IF ISNULL(@TableFlag,0) =0 
	  begin
	    --add by ylq 2015-06-06 如果以前有物流方式跟现在不一样，则跟踪号清空
	    if (@OldLogisticWayNID <> @LogisticWayNID
	       and @OldTrackNo <> '' and not (@ADDRESSOWNER='shopee' and @SHIPTOCOUNTRYCODE='TW')  )  
	    begin 
	      update P_Trade set TrackNo = '' where NID=@TradeNID  
	      exec S_WriteTradeLogs @TradeNID,'物流方式改变，跟踪号清空', 'admin'
	    end
		-- end add 
	    update P_Trade set logicsWayNID= @LogisticWayNID,ExpressNID=@DefaultExpressNID where NID=@TradeNID
	    if @DefaultSendStoreNid<>0 
	      update P_Tradedt set StoreID=@DefaultSendStoreNid where tradeNID=@TradeNID
		
		BEGIN TRY
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt(nolock) where tradenid=pt.nid),0),
				pt.ExpressFare=isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0)
			FROM P_Trade pt
			WHERE pt.NID = @TradeNID
				    
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt(nolock) where tradenid=pt.NID),0),
				pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-ISNULL((select sum(costprice) from p_tradedt(nolock) where tradenid=pt.nid),0)-
				ExpressFare),0)
			FROM P_Trade pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNID
		END TRY
		BEGIN CATCH
		END CATCH	    
	  end
	  ELSE 
	  begin
	    --add by cf 物流方式跟现在不一样，则跟踪号清空
	    if (@OldLogisticWayNID <> @LogisticWayNID
	       and @OldTrackNo <> '' and  not (@ADDRESSOWNER='shopee' and @SHIPTOCOUNTRYCODE='TW'))  begin 
	      update P_Tradeun set TrackNo = '' where NID=@TradeNID  
	      exec S_WriteTradeLogs @TradeNID,'物流方式改变，跟踪号清空', 'admin'
	    end
		-- end add 

	  	update P_TradeUn set logicsWayNID= @LogisticWayNID,ExpressNID=@DefaultExpressNID where NID=@TradeNID
		BEGIN TRY
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from P_TradeDtUn(nolock) where tradenid=pt.nid),0),
				pt.ExpressFare=isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0)
			FROM P_Tradeun pt
			WHERE pt.NID = @TradeNID
				    
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from P_TradeDtUn(nolock) where tradenid=pt.NID),0),
				pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-ISNULL((select sum(costprice) from P_TradeDtUn(nolock) where tradenid=pt.nid),0)-
				ExpressFare),0)
			FROM P_Tradeun pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNID
		END TRY
		BEGIN CATCH
		END CATCH	  	
	  end
	end
	else
	begin
	  IF ISNULL(@TableFlag,0) =0 
	  begin
	    update P_Trade set logicsWayNID= 0,ExpressNID=0 where NID=@TradeNID   
	  end
	  ELSE 
	  begin
	  	update P_TradeUn set logicsWayNID= 0,ExpressNID=0 where NID=@TradeNID
	  end	  
	end
	drop table #CalcLogicWay1
	drop table #CalcLogicWay
	--store 
		--BEGIN TRY
		--	exec  P_FR_CalcStore @TradeNID,0
		--END TRY
		--BEGIN CATCH
		--END CATCH		
	set nocount off
end
