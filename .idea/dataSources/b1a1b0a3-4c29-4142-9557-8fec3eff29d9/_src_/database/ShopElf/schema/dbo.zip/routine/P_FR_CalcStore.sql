
--P_FR_CalcStore 9730,0
create proc [dbo].[P_FR_CalcStore]
	                         @TradeNID INT ,
	                         @TableFlag INT = 0 --0:P_trade; 1: 
as
begin
	set nocount on
	declare @StoreCount int = 0,@StoreID int= 0, @DefStoreID int
	--查找国家
	Declare 
		@CountryCode varchar(10),
		@State			varchar(100),
		@SHIPTOZIP       varchar(50)
	Create Table #CalcStore
		(
			StoreID int,
			CountryCode varchar(5) default '',
			States	varchar(4000)
		)	
	Create Table #Store
		(
			StoreID int	)	
  DECLARE @RestoreStock INT 
  SET @RestoreStock = 0				
	select 
		top 1 
		@CountryCode=shiptocountrycode ,
		@State		=SHIPTOSTATE,
		@RestoreStock=RestoreStock,
		@SHIPTOZIP=SHIPTOZIP
	from P_Trade 
	where NID=@TradeNID	
  
  IF   (@RestoreStock = -1) --占用
  BEGIN 
  	RETURN;
  END  	
	--查询设置的
	insert into #CalcStore	
	select 
	     
		sr.StoreID,
		sr.CountryCode,
		sr.States
	from 
		B_StoreRole sr left join B_StoreRolePostCode srp on 

sr.NID =srp.StoreRoleID  
	where 
		sr.CountryCode = @CountryCode and ((srp.postcodeS is 

null) or (@SHIPTOZIP between srp.postcodeS and srp.postcodeE))
	--删除设置州，但不是当前州的记录	
	delete #CalcStore	
	where 	isnull(States,'')<> '' 
		 and	CHARINDEX(','+@State+',', ','+isnull

(States,'')+',') = 0 		
 		 
	select  @StoreCount=count(storeid) from #CalcStore

	--判断记录数量,大小0时，
	if isnull(@StoreCount,0)>0  --直接更新后退出
	begin
		set @StoreID=(select top 1  storeid from #CalcStore)
		update P_TradeDt 
		set StoreID=isnull(@StoreID,0) 
		where TradeNID=@TradeNID
		--add by ylq 2016-08-22  自动匹配有货的
		exec P_FR_CalcStore_Next @TradeNID
		return
	end
	
	--判断商品中的发货仓库（ylq 2015-11-11)
	update P_TradeDt set StoreID = B.StoreID
	  from P_TradeDt A, 
	  (select tmp2.StoreID, tmp4.GoodsSKUID from B_GoodsSKU tmp1 
	    inner join B_GOODS tmp2 on tmp1.GoodsID = tmp2.NID  
	    inner join B_Store tmp3 on tmp2.StoreID = tmp3.NID 
	    inner join P_TradeDt tmp4 on tmp4.GoodsSKUID = tmp1.NID 
	    where tmp4.TradeNID = @TradeNID
	  ) B where A.TradeNID = @TradeNID and A.GoodsSkuID = 

B.GoodsSkuID 
	
	--如果还有空的，则更新默认仓库
	set @DefStoreID = -1
	select @DefStoreID =  IsNull(A.Nid,-1) from B_Store A
	  inner join B_SysParams B on A.StoreName = B.ParaValue
	  where B.ParaCode = 'DefaultSendStock'
	  
	 
	if @DefStoreID <> -1 begin
	  update P_TradeDt set StoreID = @DefStoreID
	      where TradeNID = @TradeNID and IsNull(StoreID,0) = 0 
	  
	end   
	--add by ylq 2016-08-22  自动匹配有货的
	exec P_FR_CalcStore_Next @TradeNID 
	  
	 --  后面都不需要了  
	 /*
	insert into #Store
	select 
	    isnull(g.StoreID,0) as StoreID
	from 
		P_tradedt d 
	inner join 
		P_trade m on m.NID=d.TradeNID 
	inner join 
		B_GoodsSKU gs on gs.SKU=d.SKU
	inner join 
		B_Goods g on g.nid=gs.goodsid	
	where 
		m.NID=@TradeNID
	group by 
		isnull(g.StoreID,0)
	select @StoreCount=count(storeid) from #Store

	if isnull(@StoreCount,0)=1  --直接更新后退出
	begin
		set @StoreID=(select top 1  storeid from #Store)
		update P_TradeDt 
		set StoreID=@StoreID 
		where TradeNID=@TradeNID		
		return
	end
	
	*/
	
	drop table #CalcStore
	drop table #Store

	set nocount off
end
