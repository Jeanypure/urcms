
Create Procedure P_FR_CalcStore_Next
    @TradeNID INT
as
begin
  DECLARE @piPeiHaveGoods int, @LineCount int,
     @oldStoreID int, @NewStoreID  int
	  
  set @piPeiHaveGoods = (select CONVERT(int, IsNull(paraValue,0)) from B_SysParams where ParaCode = 'PiPeiHaveGoodsStore')
  if (@piPeiHaveGoods = 1) begin
    select top 1  @oldStoreID = storeid from p_tradedt  where tradenid = @TradeNid; --取没更新时的仓库ID
	 set @NewStoreID = @oldStoreID
     select @LineCount = COUNT(1) from P_TradeDt 
		 where TradeNID = @TradeNid group by GoodsSkuID
		 
			  select B.StoreID, Sum(1) as LineCount into #TabStore
				   from 
				   ( select   GoodsSkuID,SUM(L_Qty) as L_Qty from P_TradeDt A
					 where TradeNID = @TradeNid 
					 group By  GoodsSkuID
				   ) A
				   inner join KC_CurrentStock B on A.GoodsSKUID = B.GoodsSKUID
				   inner join B_Store sto on sto.NID = B.StoreID 
				   where sto.IsVirtual = 0 and (B.Number - B.ReservationNum) >= A.L_QTY 
				   group by B.StoreID 
			       
			   if not EXISTS (select 1 from #TabStore where StoreID = @oldStoreID 
			             having COUNT(1) >= @LineCount)
			   begin 
			       if EXISTS (select 1 from #TabStore where LineCount >= @LineCount)
			       begin 
				      update P_TradeDt set StoreID = (select top 1 StoreID from #TabStore where LineCount >= @LineCount)
				      where TradeNID = @TradeNid 
				   end     
			   end    
			   drop table #TabStore   
			 end
  
  end
