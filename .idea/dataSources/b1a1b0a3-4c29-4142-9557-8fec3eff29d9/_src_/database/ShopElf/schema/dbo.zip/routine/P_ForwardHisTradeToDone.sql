CREATE PROCEDURE [dbo].[P_ForwardHisTradeToDone] @TradeNids VARCHAR(MAX) = '',
                                         @BatchNum VARCHAR(50) = '', 
                                         @Operator VARCHAR(50) = ''
AS 
BEGIN                      
    
    CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
    DECLARE @sSQLCmd varchar(8000) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    WHILE (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
     
      IF (LEN(@sSQLCmd)> 7500)
      BEGIN
        exec(@sSQLCmd)
        SET @sSQLCmd = 'insert into #SelRecordTable select ';
      END 
      ELSE 
      BEGIN 
        IF (len(@sSQLCmd) > 35)
        BEGIN         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        END ELSE
        BEGIN
          SET @sSQLCmd = @sSQLCmd + @temp 
        END         
      END      
    END 
    IF (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
	

	DECLARE @ErrorCount INT=0  , @LogMsg VARCHAR(100) = '', @NID VARCHAR(20) = '0'

	BEGIN TRAN turntohis

	UPDATE P_Trade_His 
	SET ExpressStatus=1 
	    ,FilterFlag=100
	    ,BatchNum=@BatchNum
	WHERE nid IN (SELECT TradeNid FROM #SelRecordTable)
	
	SET IDENTITY_INSERT P_Trade ON 
	INSERT INTO P_Trade([NID]
	                     ,[RECEIVERBUSINESS]
	                     ,[RECEIVEREMAIL]
	                     ,[RECEIVERID]
	                     ,[EMAIL]
	                     ,[PAYERID]
	                     ,[PAYERSTATUS]
	                     ,[COUNTRYCODE]
	                     ,[PAYERBUSINESS]
	                     ,[SALUTATION]
	                     ,[FIRSTNAME]
	                     ,[MIDDLENAME]
	                     ,[LASTNAME]
	                     ,[SUFFIX]
	                     ,[ADDRESSOWNER]
	                     ,[ADDRESSSTATUS]
	                     ,[SHIPTONAME]
	                     ,[SHIPTOSTREET]
	                     ,[SHIPTOSTREET2]
	                     ,[SHIPTOCITY]
	                     ,[SHIPTOSTATE]
	                     ,[SHIPTOZIP]
	                     ,[SHIPTOCOUNTRYCODE]
	                     ,[SHIPTOCOUNTRYNAME]
	                     ,[SHIPTOPHONENUM]
	                     ,[TRANSACTIONID]
	                     ,[PARENTTRANSACTIONID]
	                     ,[RECEIPTID]
	                     ,[TRANSACTIONTYPE]
	                     ,[PAYMENTTYPE]
	                     ,[ORDERTIME]
	                     ,[AMT]
	                     ,[CURRENCYCODE]
	                     ,[FEEAMT]
	                     ,[SETTLEAMT]
	                     ,[TAXAMT]
	                     ,[EXCHANGERATE]
	                     ,[PAYMENTSTATUS]
	                     ,[PENDINGREASON]
	                     ,[REASONCODE]
	                     ,[PROTECTIONELIGIBILITY]
	                     ,[PROTECTIONELIGIBILITYTYPE]
	                     ,[INVNUM]
	                     ,[CUSTOM]
	                     ,[NOTE]
	                     ,[SALESTAX]
	                     ,[BUYERID]
	                     ,[CLOSINGDATE]
	                     ,[MULTIITEM]
	                     ,[TIMESTAMP]
	                     ,[SHIPDISCOUNT]
	                     ,[INSURANCEAMOUNT]
	                     ,[CORRELATIONID]
	                     ,[ACK]
	                     ,[VERSION]
	                     ,[BUILD]
	                     ,[SHIPPINGAMT]
	                     ,[HANDLINGAMT]
	                     ,[SHIPPINGMETHOD]
	                     ,[SHIPAMOUNT]
	                     ,[SHIPHANDLEAMOUNT]
	                     ,[SUBJECT]
	                     ,[EXPECTEDECHECKCLEARDATE]
	                     ,[Guid]
	                     ,[BUSINESS]
	                     ,[User]
	                     ,[TotalWeight]
	                     ,[ExpressNID]
	                     ,[ExpressFare]
	                     ,[logicsWayNID]
	                     ,[SelFlag]
	                     ,[TrackNo]
	                     ,[ExpressFare_Close]
	                     ,[ExpressStatus]
	                     ,[EvaluateStatus]
	                     ,[TransMail]
	                     ,[FilterFlag]
	                     ,[PrintFlag]
	                     ,[ShippingStatus]
	                     ,[MergeFlag]
	                     ,[Memo]
	                     ,[AdditionalCharge]
	                     ,[InsuranceFee]
	                     ,[AllGoodsDetail]
	                     ,[CheckOrder]
	                     ,[GoodItemIDs]
	                     ,[BatchNum] 
	                     ,[PackingMen]
	                     ,[PackageMen] 
	                     ,[PaidanDate] 
	                     ,[PaidanMen] 
	                     ,[ScanningMen] 
	                     ,[WeighingMen] 
	                     ,[ScanningDate] 
	                     ,[WeighingDate] 
						,[OrigPackingMen]
						,[OrigPackageMen]
						,[GoodsCosts]
						,[ProfitMoney]
						,[doorplate]	                     
	                     ) 
	SELECT		         [NID]
	                     ,[RECEIVERBUSINESS]
	                     ,[RECEIVEREMAIL]
	                     ,[RECEIVERID]
	                     ,[EMAIL]
	                     ,[PAYERID]
	                     ,[PAYERSTATUS]
	                     ,[COUNTRYCODE]
	                     ,[PAYERBUSINESS]
	                     ,[SALUTATION]
	                     ,[FIRSTNAME]
	                     ,[MIDDLENAME]
	                     ,[LASTNAME]
	                     ,[SUFFIX]
	                     ,[ADDRESSOWNER]
	                     ,[ADDRESSSTATUS]
	                     ,[SHIPTONAME]
	                     ,[SHIPTOSTREET]
	                     ,[SHIPTOSTREET2]
	                     ,[SHIPTOCITY]
	                     ,[SHIPTOSTATE]
	                     ,[SHIPTOZIP]
	                     ,[SHIPTOCOUNTRYCODE]
	                     ,[SHIPTOCOUNTRYNAME]
	                     ,[SHIPTOPHONENUM]
	                     ,[TRANSACTIONID]
	                     ,[PARENTTRANSACTIONID]
	                     ,[RECEIPTID]
	                     ,[TRANSACTIONTYPE]
	                     ,[PAYMENTTYPE]
	                     ,[ORDERTIME]
	                     ,[AMT]
	                     ,[CURRENCYCODE]
	                     ,[FEEAMT]
	                     ,[SETTLEAMT]
	                     ,[TAXAMT]
	                     ,[EXCHANGERATE]
	                     ,[PAYMENTSTATUS]
	                     ,[PENDINGREASON]
	                     ,[REASONCODE]
	                     ,[PROTECTIONELIGIBILITY]
	                     ,[PROTECTIONELIGIBILITYTYPE]
	                     ,[INVNUM]
	                     ,[CUSTOM]
	                     ,[NOTE]
	                     ,[SALESTAX]
	                     ,[BUYERID]
	                     ,[CLOSINGDATE]
	                     ,[MULTIITEM]
	                     ,[TIMESTAMP]
	                     ,[SHIPDISCOUNT]
	                     ,[INSURANCEAMOUNT]
	                     ,[CORRELATIONID]
	                     ,[ACK]
	                     ,[VERSION]
	                     ,[BUILD]
	                     ,[SHIPPINGAMT]
	                     ,[HANDLINGAMT]
	                     ,[SHIPPINGMETHOD]
	                     ,[SHIPAMOUNT]
	                     ,[SHIPHANDLEAMOUNT]
	                     ,[SUBJECT]
	                     ,[EXPECTEDECHECKCLEARDATE]
	                     ,[Guid]
	                     ,[BUSINESS]
	                     ,[User]
	                     ,[TotalWeight]
	                     ,[ExpressNID]
	                     ,[ExpressFare]
	                     ,[logicsWayNID]
	                     ,[SelFlag]
	                     ,[TrackNo]
	                     ,[ExpressFare_Close]
	                     ,[ExpressStatus]
	                     ,[EvaluateStatus]
	                     ,[TransMail]
	                     ,[FilterFlag]
	                     ,[PrintFlag]
	                     ,[ShippingStatus]
	                     ,[MergeBillID]
	                     ,[Memo]
	                     ,[AdditionalCharge]
	                     ,[InsuranceFee]
	                     ,[AllGoodsDetail]
	                     ,[CheckOrder]
	                     ,[GoodItemIDs] 
	                     ,[BatchNum] 
	                     ,[PackingMen]
	                     ,[PackageMen] 
	                     ,[PaidanDate] 
	                     ,[PaidanMen] 
	                     ,[ScanningMen] 
	                     ,[WeighingMen] 
	                     ,[ScanningDate] 
	                     ,[WeighingDate]  
						,[OrigPackingMen]
						,[OrigPackageMen]
						,[GoodsCosts]
						,[ProfitMoney]
						,[doorplate]	                     
	FROM P_Trade_His 
	WHERE ExpressStatus=1 AND FilterFlag=100 
	
	SELECT @ErrorCount=@@Error
	
	  
	INSERT INTO P_TradeDt([TradeNID]
	                      ,[L_EBAYITEMTXNID]
	                      ,[L_NAME]
	                      ,[L_NUMBER]
	                      ,[L_QTY]
	                      ,[L_SHIPPINGAMT]
	                      ,[L_HANDLINGAMT]
	                      ,[L_CURRENCYCODE]
	                      ,[L_AMT]
	                      ,[L_OPTIONSNAME]
	                      ,[L_OPTIONSVALUE]
	                      ,[L_TAXAMT]
	                      ,[SKU]
	                      ,[CostPrice]
	                      ,[AliasCnName]
	                      ,[AliasEnName]
	                      ,[Weight]
	                      ,[DeclaredValue]
	                      ,[OriginCountry]
	                      ,[OriginCountryCode]
	                      ,[BmpFileName]
	                      ,[GoodsName]
	                      ,[GoodsSKUID]
	                      ,[StoreID]
                        ,[eBaySKU] --增加字段
                        ,[L_ShipFee]
                        ,[L_TransFee]
                        ,[L_ExpressFare]
                        ,[BuyerNote]
                        )
	SELECT                [TradeNID]
	                      ,[L_EBAYITEMTXNID]
	                      ,[L_NAME]
	                      ,[L_NUMBER]
	                      ,[L_QTY]
	                      ,[L_SHIPPINGAMT]
	                      ,[L_HANDLINGAMT]
	                      ,[L_CURRENCYCODE]
	                      ,[L_AMT]
	                      ,[L_OPTIONSNAME]
	                      ,[L_OPTIONSVALUE]
	                      ,[L_TAXAMT]
	                      ,[SKU]
	                      ,[CostPrice]
	                      ,[AliasCnName]
	                      ,[AliasEnName]
	                      ,[Weight]
	                      ,[DeclaredValue]
	                      ,[OriginCountry]
	                      ,[OriginCountryCode]
	                      ,[BmpFileName]
	                      ,[GoodsName]
	                      ,[GoodsSKUID]
	                      ,[StoreID] 
                        ,[eBaySKU] --增加字段
                        ,[L_ShipFee]
                        ,[L_TransFee]
                        ,[L_ExpressFare] 
                        ,[BuyerNote]                 
	FROM P_TradeDt_His 
	WHERE TradeNID IN (SELECT NID 
	                   FROM P_Trade_His WHERE ExpressStatus=1 AND FilterFlag=100 ) 

	SELECT @ErrorCount=@@Error +@ErrorCount  
	
	DELETE 
	FROM P_TradeDt_His 
	WHERE TradeNID IN (SELECT NID 
	                   FROM P_Trade_His WHERE ExpressStatus=1 AND FilterFlag=100 ) 
 
	SELECT @ErrorCount=@@Error +@ErrorCount  
	 
	DELETE 
	FROM P_Trade_His 
	WHERE ExpressStatus=1 AND FilterFlag=100 

	SELECT @ErrorCount=@@Error +@ErrorCount   
	 
	IF @ErrorCount=0 
	BEGIN 
		DECLARE _WriteLog CURSOR
		FOR SELECT srt.TradeNid
		FROM #SelRecordTable srt                        
		OPEN _WriteLog
		FETCH NEXT FROM _WriteLog INTO @NID
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
  			EXEC S_WriteTradeLogs @NID,'订单反归档成功！',@Operator
  		   FETCH NEXT FROM _WriteLog INTO @NID
		END
		CLOSE _WriteLog
		DEALLOCATE _WriteLog 	
		COMMIT TRAN turntohis 
	END  
	ELSE 
	BEGIN 
		ROLLBACK TRAN turntohis 
	END  
	
	DROP TABLE #SelRecordTable
	
	SELECT ErrorCount= @ErrorCount 
END
