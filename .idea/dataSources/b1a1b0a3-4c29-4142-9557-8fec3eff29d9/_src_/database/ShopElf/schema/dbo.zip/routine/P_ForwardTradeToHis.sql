
CREATE PROCEDURE [dbo].[P_ForwardTradeToHis] @TradeNids VARCHAR(MAX) = '',
                                     @BatchNum VARCHAR(50) = '', 
                                     @Operator VARCHAR(50) = ''
AS 
BEGIN                      
    
    CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
    DECLARE @sSQLCmd varchar(8000) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    WHILE (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
     
      IF (LEN(@sSQLCmd)> 7500)
      BEGIN
        exec(@sSQLCmd)
        SET @sSQLCmd = 'insert into #SelRecordTable select ';
      END 
      ELSE 
      BEGIN 
        IF (len(@sSQLCmd) > 35)
        BEGIN         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        END ELSE
        BEGIN
          SET @sSQLCmd = @sSQLCmd + @temp 
        END         
      END      
    END 
    IF (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
	

	DECLARE @ErrorCount INT=0  , @LogMsg VARCHAR(100) = '', @NID VARCHAR(20) = '0'

	BEGIN TRAN turntohis
	
	UPDATE p_trade 
	SET ExpressStatus=1 
	    ,FilterFlag=200
	    ,BatchNum=@BatchNum
	WHERE nid IN (SELECT TradeNid FROM #SelRecordTable)
	
	  
	DELETE FROM  P_TradeDt_His  
	WHERE TradeNID IN (SELECT NID 
					   FROM P_Trade 
					   WHERE FilterFlag = 200)  
	SELECT @ErrorCount=@@Error  
	INSERT INTO P_TradeDt_His   
	SELECT * FROM P_TradeDt 
	WHERE TradeNID IN (SELECT NID 
					   FROM P_Trade 
					   WHERE FilterFlag = 200)  
	SELECT @ErrorCount=@@Error +@ErrorCount   
	DELETE FROM P_TradeDt 
	WHERE TradeNID IN (SELECT NID 
					   FROM P_Trade 
					   WHERE FilterFlag = 200)  
	SELECT @ErrorCount=@@Error +@ErrorCount   
	DELETE FROM P_Trade_His 
	WHERE  nid IN (SELECT nid 
				   FROM P_trade 
				   WHERE FilterFlag = 200)  
	SELECT @ErrorCount=@@Error +@ErrorCount   
	INSERT INTO P_Trade_His 
	SELECT * FROM P_trade 
	WHERE FilterFlag = 200 
	SELECT @ErrorCount=@@Error +@ErrorCount  
	DELETE FROM P_trade WHERE FilterFlag = 200  
	SELECT @ErrorCount=@@Error +@ErrorCount   
	IF @ErrorCount=0 
	BEGIN 
		DECLARE _WriteLog CURSOR
		FOR SELECT srt.TradeNid
		FROM #SelRecordTable srt                        
		OPEN _WriteLog
		FETCH NEXT FROM _WriteLog INTO @NID
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
  			EXEC S_WriteTradeLogs @NID,'订单归档成功！',@Operator
  		   FETCH NEXT FROM _WriteLog INTO @NID
		END
		CLOSE _WriteLog
		DEALLOCATE _WriteLog 	
		COMMIT TRAN turntohis 
	END  
	ELSE 
	BEGIN 
		ROLLBACK TRAN turntohis 
	END  
	
	DROP TABLE #SelRecordTable
	
	SELECT ErrorCount= @ErrorCount 
END

