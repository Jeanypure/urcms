CREATE PROCEDURE [P_ForwardTradeUnToHis] @TradeNids VARCHAR(MAX) = '',
                                     @BatchNum VARCHAR(50) = '', 
                                     @Operator VARCHAR(50) = ''
AS 
BEGIN                      
    
    CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
    DECLARE @sSQLCmd varchar(8000) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    WHILE (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index-1) 
     
      IF (LEN(@sSQLCmd)> 7500)
      BEGIN
        exec(@sSQLCmd)
        SET @sSQLCmd = 'insert into #SelRecordTable select ';
      END 
      ELSE 
      BEGIN 
        IF (len(@sSQLCmd) > 35)
        BEGIN         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        END ELSE
        BEGIN
          SET @sSQLCmd = @sSQLCmd + @temp 
        END         
      END      
    END 
    IF (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
	--删除p_tradeun 不存在的记录，因为二人同时转时，数据会在下面删除掉
	
	delete #SelRecordTable where exists (select top 1  nid from P_TradeUn_His where NID =#SelRecordTable.TradeNid)
	DECLARE @ErrorCount INT=0  , @LogMsg VARCHAR(100) = '', @NID VARCHAR(20) = '0'

	BEGIN TRAN turntohis
	
	UPDATE p_tradeun 
	SET BatchNum=@BatchNum
	WHERE nid IN (SELECT TradeNid FROM #SelRecordTable)  
	--加上原表P_TradeDtUn记录判断，否则
	DELETE FROM  P_TradeDtUn_His  
	WHERE TradeNID IN (SELECT TradeNid FROM #SelRecordTable )  
	select @ErrorCount=@@Error  
	INSERT INTO P_TradeDtUn_His   
	SELECT * FROM P_TradeDtUn 
	WHERE TradeNID IN (SELECT TradeNid FROM #SelRecordTable)  
	select @ErrorCount=@@Error +@ErrorCount  
	delete from P_TradeUn_His
	WHERE NID IN (SELECT TradeNid FROM #SelRecordTable)
	select @ErrorCount=@@Error +@ErrorCount 
	INSERT INTO P_TradeUn_His 
	SELECT * FROM P_tradeUn 
	WHERE NID IN (SELECT TradeNid FROM #SelRecordTable) 
	 select @ErrorCount=@@Error +@ErrorCount 
	DELETE FROM P_TradeDtUn 
	WHERE TradeNID IN (SELECT TradeNid FROM #SelRecordTable)  
	select @ErrorCount=@@Error +@ErrorCount 
	DELETE FROM P_TradeUn 
	WHERE NID IN (SELECT TradeNid FROM #SelRecordTable)  
	select @ErrorCount=@@Error +@ErrorCount  
	IF @ErrorCount=0 
	BEGIN 
		DECLARE _WriteLog CURSOR
		FOR SELECT srt.TradeNid
		FROM #SelRecordTable srt                        
		OPEN _WriteLog
		FETCH NEXT FROM _WriteLog INTO @NID
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
  			EXEC S_WriteTradeLogs @NID,'异常订单归档成功！',@Operator
  		   FETCH NEXT FROM _WriteLog INTO @NID
		END
		CLOSE _WriteLog
		DEALLOCATE _WriteLog 	
		COMMIT TRAN turntohis 
	END  
	ELSE 
	BEGIN 
		ROLLBACK TRAN turntohis 
	END  
	
	DROP TABLE #SelRecordTable
	
	SELECT ErrorCount= @ErrorCount
END 
