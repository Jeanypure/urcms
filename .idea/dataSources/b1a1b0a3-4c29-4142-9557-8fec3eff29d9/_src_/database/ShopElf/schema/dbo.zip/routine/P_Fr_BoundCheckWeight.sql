
create Proc [dbo].[P_Fr_BoundCheckWeight]
    @LogisticWayID	int,
	@fallWeight		Float,  --重量为G,
	@TradeNID	int=0,
	@fPackWeight numeric(18,4) = 0.0
as
begin
	--查找国家所在大区
	declare
		@BeginWeight int,
		@BeginMoneyGoods money,
		@BeginMoneyFile money,		
		@AddWeight	int,
		@AddMoney	money,
		@tmpWeight  int,
		@AllShippingCost	money,
		@FareID int,
		@Discount int,--折扣
		@SurchargeRate float,--燃油附加费率
		@allWeight float,
		@PackWeight float,
		@GoodsWeight float,--商品信息重量合计
		@RateWeightBetween int,
		@ReturnMsg varchar(200),
	    @IsEub INT = 0,  --是否是E邮宝
	    @MaxWeight float,  --最大限制重量
	    @ServiceCode varchar(32), --物流方式服务代码
	    @LittleWeight float,
	    @StepWeight float,
	    @NetWeight float,
	    @TmpCount int
	    
    --add by ylq 2015-07-09  是否是小重量型
    set @LittleWeight=ISNULL((select CAST(ParaValue as float) from B_SysParams where ParaCode = 'WeighLittle'),0)    
	set @StepWeight =ISNULL((select CAST(ParaValue as float) from B_SysParams where ParaCode = 'WeighLittleValue'),0)    
	
	--最大重量限制的判断    
	set @MaxWeight=ISNULL((select CAST(ParaValue as float) from B_SysParams where ParaCode = 'CalcShippingCost_MaxWeight'),20)    
	if   @fallWeight>@MaxWeight
	begin
		set @ReturnMsg = '重量大于' + CAST(@MaxWeight as varchar(50)) + 'KG，请确认'
		select @ReturnMsg as ErrorMsg,	0 as IsPass	--  0代表不允许过~~~ modify by ylq 2016-02-02		
		return	
	end		
 
   set  @allWeight=@fallWeight*1000	
   set @PackWeight = @fPackWeight * 1000

	--查找订单的重量合计
	set @GoodsWeight=ISNULL((select sum(weight*1000)from p_tradedt where tradenid=@tradenid),0)
	if isnull(@GoodsWeight,0)=0
	  set @GoodsWeight=0
	--查找重量区间范围
	set @RateWeightBetween =ISNULL((select ParaValue from B_SysParams where ParaCode ='RateWeightBetween'),0)
 
	SET @IsEub = (SELECT ISNULL(EUB,0) FROM B_LogisticWay WHERE NID = @LogisticWayID)
	set @ServiceCode = (select ISNULL(ServiceCode,'0') from B_LogisticWay WHERE NID = @LogisticWayID)

	--计算,参考官方 http://shipping.ebay.cn/express/e-packet/2684.html
	declare @AutoCalcEUB int =0
	set @AutoCalcEUB=(select top 1 paravalue from B_SysParams where ParaCode = 'AutoCalcEUB')  	
	if ISNULL(@IsEub,0) IN (1,2) and isnull(@AutoCalcEUB,0)=0 
	BEGIN
	  if (upper(ISNULL(@ServiceCode,'0')) = 'E-PARCEL') begin  --E-parcel  如果物流方式是UBI,则不做重量上限判断 modify YLQ 2016-05-25  小谢要求    --'
	    if (@allWeight <=0)begin
	      select '重量小于等于0，不能发E邮宝' as ErrorMsg,	0 as IsPass;
		  return 0;
	    end	  
	  end
	  else begin   
	    if (ISNULL(@ServiceCode,'0') = '1') or (ISNULL(@ServiceCode,'0') = '2')
	    begin
	       if (@allWeight > 10000 or @allWeight <=0)begin
	         select '重量大于10000克或者小于等于0，不能发E邮宝' as ErrorMsg,	0 as IsPass;
			 return 0;
	       end
	    end
	    else begin 
			if (@allWeight > 2000 or @allWeight <=0) 
			begin
				select '重量大于2000克或者小于等于0，不能发E邮宝' as ErrorMsg,	0 as IsPass;
				return 0;
			end
		end
	  end 
	end

   set @NetWeight = @allWeight   -  @PackWeight  
   
	if (@LittleWeight <> 0) and 
	   (@NetWeight <= @LittleWeight) begin
	  if  @TradeNID<>0 and ( @StepWeight < abs(@GoodsWeight - @NetWeight) ) begin
	    set @ReturnMsg='实际重量['+CAST(@NetWeight as varchar(20))+']超过商品理论重量['+ CONVERT(varchar(32),@GoodsWeight) + 
	        ']+最大差值[' + CONVERT(varchar(32), @StepWeight) + ']（小重量计算), 请确认！'	        
	  end 
	end
	else begin  
		if @RateWeightBetween<>0 and @GoodsWeight <> 0
		begin
			if  @TradeNID<>0 and  (abs(@NetWeight-@GoodsWeight)/@GoodsWeight * 100 > @RateWeightBetween)
			begin
			  set @ReturnMsg='实际重量['+CAST(@NetWeight as varchar(20))+']超过或低于商品理论重量['+CAST(@GoodsWeight as varchar(20))+']的'+CAST( @RateWeightBetween as varchar(10))+'%，请确认！'
			end 
		end	
	end

	select @ReturnMsg as ErrorMsg,	1 as IsPass
end
