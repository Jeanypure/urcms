create proc [dbo].[P_GetSmtOnlineACK]
AS
BEGIN
  -- 取每个国家的1个单子
  set nocount on;
  select 
  * from (
  select 
   
   m.SUFFIX,m.ACK,m.SHIPTOCOUNTRYCODE,
   row_number() over(partition by m.SHIPTOCOUNTRYCODE order by m.nid  desc) rn 
  from P_Trade m with(nolock)
  where m.ADDRESSOWNER='aliexpress'
  and m.AMT>=5 
  union all
  select 
   m.SUFFIX,m.ACK,m.SHIPTOCOUNTRYCODE,
   row_number() over(partition by m.SHIPTOCOUNTRYCODE order by m.nid  desc) rn 
  from P_Trade m with(nolock)
  where m.ADDRESSOWNER='aliexpress'
  and m.AMT<5 
  ) a
  where a.rn<=1
  set nocount off;
end
