
Create PROCEDURE [dbo].[P_HD_QryDataAndPrint] 
  @Nid  int,
  @TrackNo varchar(32)
AS
BEGIN	
	SET NOCOUNT ON;	
  
    DECLARE @FromAddrCount INT = 0,@FromAddrNID INT  = 0
    DECLARE @strWhere varchar(100) 
    if @Nid <= 0 begin
      set @strWhere = 'm.TrackNo = ''' + @TrackNo + ''''
    end
    else begin
      set @strWhere = 'm.Nid = ' + CONVERT(varchar(32),@Nid) 
    end

    SET @FromAddrCount = (SELECT ISNULL(COUNT(1),0) FROM B_HabitSet)
    IF (@FromAddrCount = 0)
    BEGIN      
      SET @FromAddrNID = 0
    END ELSE 
    IF (@FromAddrCount = 1)
    BEGIN
      SET @FromAddrNID = (SELECT TOP 1 HabitSetID FROM B_HabitSet)	
    END ELSE 
    BEGIN    	
      SET @FromAddrNID = dbo.F_SE_GetSenderAddressNID(@Nid,0)
    END

    --查询中国DHL小包的系统参数,挂入每个订单
    DECLARE @DHLUSER_SH varchar(500)         --DHL上海发货账号        
    set @DHLUSER_SH = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-User-SHANGHAI'),'')
    DECLARE @DHLUSER_HK varchar(500)         --DHL深圳香港发货账号
    set @DHLUSER_HK = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-User-XIANGGANG-SHENZHEN'),'')
    DECLARE @DHLPRE_SH varchar(500)          --DHL上海发货前缀 
    set @DHLPRE_SH = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Prefix-SHANGHAI'),'')
    DECLARE @DHLPRE_HK varchar(500)          --DHL深圳香港发货前缀
    set @DHLPRE_HK = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Prefix-XIANGGANG-SHENZHEN'),'')
    DECLARE @DHLSign varchar(500)            --DHL签名
    set @DHLSign = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Signature'),'')
       
    DECLARE  @sSQLCmd varchar(max)
    
    set @sSQLCmd =' SELECT '+
      		'm.*,dateadd(hour,8,m.ordertime) as OrderTimeCN,  e.name as expressname, '+ 
      		'l.name as logicsWayName, m.expressnid as expressID, l.nId as logicsWayID, '+ 
           'l.code as logicsWayCode, '+ 
           'l.FileName as printfilename, '+
           'c.CountryZnName, '+
           'l.eub, '+
           'l.ServiceCode, '+
           'l.remark as logicsWayRemark,' + 
           'ZoneCode=case when isnull((select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between  isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''') ),'''')='''' then  '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  ) '+
					'else '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''')  ) '+					
					'end	, '  +				
           ' bhs.EmaillEn AS FromEmaillEn '+    
			',bhs.EMaill   AS FromEMaill '+ 
			',bhs.MobileEn AS FromMobileEn '+     
			',bhs.Mobile   AS FromMobile '+ 
			',bhs.PhoneEn  AS FromPhoneEn '+
			',bhs.Phone    AS FromPhone '+  
			',bhs.PostCodeEn AS    FromPostCodeEn '+   
			',bhs.PostCode AS FromPostCode '+     
			',bhs.StreetEn AS FromStreetEn '+     
			',bhs.Street AS  FromStreet  '+
			',bhs.AreasEn AS FromAreasEn '+
			',bhs.AreasCode AS     FromAreasCode '+    
			',bhs.Areas AS   FromAreas '+  
			',bhs.CityEn AS  FromCityEn  '+
			',bhs.CityCode AS FromCityCode  '+    
			',bhs.City AS    FromCity  '+  
			',bhs.ProvinceEn AS    FromProvinceEn '+   
			',bhs.ProvinceCode AS  FromProvinceCode '+ 
			',bhs.Province AS FromProvince '+     
			',bhs.CountryEn AS     FromCountryEn '+    
			',bhs.Country AS FromCountry '+
			',bhs.CompanyEn AS     FromCompanyEn '+    
			',bhs.Company AS FromCompany '+
			',bhs.ContactEn AS     FromContactEn '+    
			',bhs.Contact AS FromContact '+
			',bhs.HabitSetID AS    FromHabitSetID  '+  
			',bhs.EbayUrl AS FromEbayUrl '+
			',bhs.EBayUserID AS    FromEBayUserID  '+  
			',bhs.EMSPickUpType AS FromEMSPickUpType ' + 
			',bhs.AddrName AS FromAddrName, ' +
			'isnull(c.Area,'''') as Area, '+  
			'''' + @DHLUSER_SH + ''' as DHLUSER_SH, ' +    
			'''' + @DHLUSER_HK + ''' as DHLUSER_HK, ' +    
			'''' + @DHLPRE_SH + ''' as DHLPRE_SH, ' +    
			'''' + @DHLPRE_HK + ''' as DHLPRE_HK, ' +    
			'''' + @DHLSign + ''' as DHLSign, ' +    
			'[StockMemoTotal] ,[StoreMemoTotal] ,[SaleMemoTotal] ,[ServiceMemoTotal] , [PrintMemoTotal] ' +                
		' FROM P_Trade m '+    
 
					   'LEFT JOIN T_express e ON e.nid=m.expressnid  '+  
					   ' LEFT JOIN CG_OutofStock_Total coost on coost.TradeNid= m.nid '+
					  ' LEFT JOIN B_Country c ON c.CountryCode=m.SHIPTOCOUNTRYCODE '+  
					   'LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID ' +
	 				  ' LEFT JOIN B_HabitSet bhs  ON bhs.HabitSetID = ' + convert(varchar(32),@FromAddrNID ) +   
	    ' where ' + @strWhere  
		 	  

		EXEC(@sSQLCmd)					   
      
END	

