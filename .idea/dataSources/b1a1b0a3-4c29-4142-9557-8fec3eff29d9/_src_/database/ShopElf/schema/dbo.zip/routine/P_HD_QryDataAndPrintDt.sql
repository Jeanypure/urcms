 
create PROCEDURE [dbo].[P_HD_QryDataAndPrintDt]
    (@TradeNid int)
AS
BEGIN
  SET NOCOUNT ON 
  DECLARE @sSQLCmd varchar(MAx) = '', @temp varchar(20) = '', @index int = 0
     
  SELECT  d.NID, d.TradeNID, d.L_EBAYITEMTXNID, d.L_NAME, d.L_NUMBER, d.L_QTY,d.L_SHIPPINGAMT, d.L_HANDLINGAMT,
		        d.L_CURRENCYCODE, d.L_AMT, d.L_OPTIONSNAME,d.L_OPTIONSVALUE, d.L_TAXAMT, d.SKU, d.CostPrice,
			    d.AliasCnName,d.AliasEnName, d.Weight,d.DeclaredValue, d.OriginCountry, d.OriginCountryCode, 
			    d.BmpFileName, d.GoodsName,d.GoodsSKUID,d.StoreID,d.eBaySku, LocationName,gs.property1 as Goodscolor,
			    gs.property2, gs.property3,bg.GoodsCategoryID,bg.CategoryCode,bg.GoodsCode,bg.ShopTitle, bg.BarCode,
			    bg.FitCode,bg.MultiStyle,bg.Material,bg.Class,bg.Model,bg.Unit,bg.Style,bg.Brand,bg.Quantity,
			    bg.SalePrice,bg.CostPrice AS OrigCostPrice ,	 bg.[Used],bg.BmpUrl,bg.MaxNum,bg.MinNum,bg.GoodsCount,
			    bg.SupplierID,bg.SellCount,bg.SellDays,bg.Notes,bg.SampleFlag,bg.SampleCount,bg.SampleMemo,bg.CreateDate,
			    bg.GroupFlag,bg.SalerName,ISNULL(kc.Number,0) as kcnum,bg.HSCODE,d.BuyerNote,gs.SKUName,
			    case when bg.IsCharged = 1 then '是' else '否' end as IsChargedName,
		       case when bg.IsPowder = 1 then '是' else '否' end as IsPowderName,
		       case when bg.IsLiquid = 1 then '是' else '否' end as IsLiquidName,
		       bg.Season
		FROM P_TradeDt d  
		                 LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID   
						 LEFT JOIN B_Goods bg ON gs.GoodsID = bg.NID 
						 LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID AND d.StoreID = bgs.StoreID 
						 LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID 
						 left outer join KC_CurrentStock kc on kc.StoreID=d.StoreID and kc.GoodsSKUID=d.GoodsSKUID 
						    	and kc.goodsskuid<>0 and kc.storeid<>0 
		where d.TradeNID = @TradeNid 				    	
		ORDER BY d.TradeNID, LocationName
    
    
END

