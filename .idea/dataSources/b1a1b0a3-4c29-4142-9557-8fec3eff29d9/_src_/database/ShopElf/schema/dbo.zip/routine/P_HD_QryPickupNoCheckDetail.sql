
CREATE Proc [dbo].[P_HD_QryPickupNoCheckDetail]
    @PickUpNo		Varchar(50)='' 
as
begin  

  select  ptd.NID, 
			ptd.TradeNID,ptd.L_EBAYITEMTXNID, ptd.L_NAME, ptd.L_NUMBER,  ptd.L_SHIPPINGAMT, 
			ptd.L_HANDLINGAMT, ptd.L_CURRENCYCODE, ptd.L_AMT,ptd.L_OPTIONSNAME,ptd.L_OPTIONSVALUE, 
			ptd.L_TAXAMT,   ptd.CostPrice, ptd.AliasCnName ,ptd.AliasEnName, 
			ptd.Weight, ptd.DeclaredValue, ptd.OriginCountry,ptd.OriginCountryCode, ptd.BmpFileName, 
			ptd.GoodsName ,ptd.GoodsSKUID, ptd.StoreID,rtrim(ptd.eBaySKU) AS eBaySKU, 0 as Number,
			0 as ReservationNum,0 as CanUseNum,   
			g.class,g.model,gs.property1,gs.property2,gs.property3 ,g.unit,g.PackName,
       A.PickUpNo, A.Sku, A.PosNo, ptd.L_QTY as L_Qty, ptd.L_QTY as L_Qty1, A.CheckFlag ,
       0 as CheckNum, ptd.L_QTY as NoCheckNum,
       (select top 1  bl.locationname from B_GoodsSKULocation bgs 
			inner join B_storelocation bl on bl.nid=bgs.LocationID 
            where bgs.StoreID = ptd.StoreID and bgs.GoodsSKUID=ptd.GoodsSKUID) as locationname
   into #TmpData 
     from P_TradePickup A
        inner join P_TradeDt(noLock) ptd on ptd.TradeNid = A.TradeNid and A.Sku = ptd.Sku 
        inner join P_Trade(noLock) pm on pm.NID = A.TradeNID
        left join B_GoodsSKU gs on gs.NID = ptd.GoodsSKUID 
        left join b_Goods g on g.NID = gs.GoodsID     
     where A.pickupNo = @PickUpNo and A.CheckFlag = 0 and pm.FilterFlag = 22
     
  select * from #TmpData
  
end
