
create Proc [dbo].[P_HD_QryPickupNoCheckMain] 
	@PickUpNo		Varchar(50)='',
	@OrderFlag   int = 0
as
begin
  create table #PickBatchTab
    (
      TradeNid int  NOT NULL,
      PickupNo varchar(50) Not Null,
      PosNo    int not Null
    )
    
  insert into #PickBatchTab
     select distinct TradeNid, PickUpNo, PosNo from P_TradePickup
         where PickUpNo = @PickUpNo and CheckFlag = 0

  create Table #NidTable
  (
     Nid int,
     L_Qty float 
   )
  
insert into #NidTable
select TradeNid, SUM(L_Qty) as L_Qty from 
(
  select A.TradeNid, GoodsSKUID, SUM(A.L_Qty) as L_Qty  from P_TradeDt(noLock) A
    inner join P_Trade(noLock) B on A.TradeNID = B.NID 
    inner join #PickBatchTab C on C.TradeNID = B.NID  
    where B.FilterFlag = 22 
    group by A.TradeNID, GoodsSKUID 
 ) A group by TradeNid  
 
  SELECT  
       distinct  CONVERT(varchar(32),'') as IsFinish,  0 as TmpbCheck, 0 as ErrFlag, tmpM.L_QTY as L_QTY, tmpNo.PickupNo, tmpno.PosNo,
				m.NID,m.SHIPTONAME,m.TrackNo,m.NOTE,m.SUBJECT,m.Memo,m.SUFFIX,
				m.RECEIVERBUSINESS,
			 dateadd(hour,8,m.ordertime) as OrderTimeCN,m.SelFlag, 
			 e.name as expressname, 
			 l.name as logicsWayName,
			 l.code as logicsWayCode, 
			 l.FileName as printfilename,
			 c.CountryZnName,
			 l.eub, m.PackingMen,
			 m.expressnid as expressID, m.logicsWayNID as  logicsWayID,m.ExpressFare,
		      m.SHIPTOCOUNTRYCODE,m.TotalWeight,m.AllGoodsDetail  
  into #TmpData  
               FROM P_Trade(noLock)  m 
               inner join P_TradeDt dt on dt.TradeNID = m.NID 
               inner join #NidTable tmpM on TmpM.Nid = m.NID 
               inner join #PickBatchTab tmpNo on tmpNo.TradeNid = m.NID 
               LEFT JOIN T_express e on e.nid=m.expressnid  
               LEFT JOIN B_Country c on c.CountryCode=m.SHIPTOCOUNTRYCODE  
               LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID  
  
	if @OrderFlag = 0 begin -- 啥都没选，按订单数量
	  select * from #TmpData order by L_QTY, NID 
	end
	else if @OrderFlag = 1 begin   -- 1的话只按物流方式,数量排序
	  select * from #TmpData order by logicsWayName,L_QTY, NID  
	end 
	else if @OrderFlag = 2 begin   -- 2的话，按订单时间排序
	  select * from #TmpData order by OrderTimeCN
	end
	else if @OrderFlag = 3 begin   -- 3的话，按物流方式，交易时间排序
	  select * from #TmpData order by logicsWayName,OrderTimeCN
	end
 
   
   drop table #NidTable 
   drop table #TmpData
   drop table #PickBatchTab
end

