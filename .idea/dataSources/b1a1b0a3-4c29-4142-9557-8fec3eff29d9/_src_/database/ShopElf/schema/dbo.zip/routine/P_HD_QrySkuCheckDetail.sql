create Proc [dbo].[P_HD_QrySkuCheckDetail]
	@Nid	int,
	@sku    varchar(100)='',
	@IsBatch int = 0,
	@iMin int = 0,
	@iMax int = 999999 
as
begin   
  if @IsBatch = 1 begin 
  
    create Table #TmpTrade
     (
       TradeNID int not Null,
       Qty  int 
     )
   
	   insert into #TmpTrade(TradeNID)
		select TradeNid from 
		(
		select TradeNid, GoodsSKUID, SUM(A.L_Qty) as L_Qty from P_TradeDt(noLock) A
			inner join P_Trade(noLock) B on A.TradeNID = B.NID 
			where  FilterFlag=22 and b.nid in (select tradenid from p_tradedt where sku=@sku)
			group by TradeNID, GoodsSKUID 
		 ) A group by TradeNid having COUNT(TradeNID) = 1 and SUM(A.L_Qty) >= @iMin and Sum(A.L_Qty) <= @iMax  
 
		/* select distinct dt.TradeNID from P_TradeDt(noLock) dt
		 inner join P_Trade(noLock) m on m.NID=dt.TradeNID
		 where SALESTAX = 1 and dt.SKU = @sku and  --只有一条记录
		 FilterFlag=9  
		 And IsNull(IsPacking,0)=1 And IsNull(IsChecked,0)=0 AND IsNull(IsPackage,0) <> -1 --modify by 2015-05-13 根据未核单跟踪获取
        */
           
		SELECT ptd.NID, 
			ptd.TradeNID,ptd.L_EBAYITEMTXNID, ptd.L_NAME, ptd.L_NUMBER, ptd.L_QTY, ptd.L_SHIPPINGAMT, 
			ptd.L_HANDLINGAMT, ptd.L_CURRENCYCODE, ptd.L_AMT,ptd.L_OPTIONSNAME,ptd.L_OPTIONSVALUE, 
			ptd.L_TAXAMT, rtrim(ptd.SKU) AS SKU, ptd.CostPrice, ptd.AliasCnName ,ptd.AliasEnName, 
			ptd.Weight, ptd.DeclaredValue, ptd.OriginCountry,ptd.OriginCountryCode, ptd.BmpFileName, 
			ptd.GoodsName ,ptd.GoodsSKUID, ptd.StoreID,rtrim(ptd.eBaySKU) AS eBaySKU, 0 as Number,
			0 as ReservationNum,0 as CanUseNum,   
			g.class,g.model,gs.property1,gs.property2,gs.property3 ,g.unit,g.PackName,
		    --加货位
		    LocationName = (select top 1 LocationName from B_StoreLocation A  
                             inner join B_GoodsSKULocation B on A.NID = B.LocationID  
                             where B.GoodsSKUID = ptd.GoodsSkuID ) 
		 FROM P_TradeDt(noLock) ptd  
		 inner join  #TmpTrade B on  ptd.TradeNID = B.TradeNID    
		 LEFT outer JOIN  b_goodssku gs ON gs.sku =ptd.sku  
		 LEFT outer JOIN  b_goods  g ON g.nid = gs.goodsid 
		 where ptd.SKU = @sku 
		 order by ptd.L_QTY,ptd.TradeNID  
		 
    drop table #TmpTrade
  end
  else begin
    SELECT ptd.NID, 
        ptd.TradeNID,ptd.L_EBAYITEMTXNID, ptd.L_NAME, ptd.L_NUMBER, ptd.L_QTY, ptd.L_SHIPPINGAMT, 
        ptd.L_HANDLINGAMT, ptd.L_CURRENCYCODE, ptd.L_AMT,ptd.L_OPTIONSNAME,ptd.L_OPTIONSVALUE, 
        ptd.L_TAXAMT, rtrim(ptd.SKU) AS SKU, ptd.CostPrice, ptd.AliasCnName ,ptd.AliasEnName, 
        ptd.Weight, ptd.DeclaredValue, ptd.OriginCountry,ptd.OriginCountryCode, ptd.BmpFileName, 
        ptd.GoodsName ,ptd.GoodsSKUID, ptd.StoreID,rtrim(ptd.eBaySKU) AS eBaySKU, 0 as Number,
        0 as ReservationNum,0 as CanUseNum,   
        g.class,g.model,gs.property1,gs.property2,gs.property3 ,g.unit,g.PackName,
         --加货位
		LocationName = (select top 1 LocationName from B_StoreLocation A  
                             inner join B_GoodsSKULocation B on A.NID = B.LocationID  
                             where B.GoodsSKUID = ptd.GoodsSkuID )  
     FROM P_TradeDt ptd    
     LEFT outer JOIN  b_goodssku gs ON gs.sku =ptd.sku  
     LEFT outer JOIN  b_goods  g ON g.nid = gs.goodsid 
     WHERE ptd.TradeNID= @Nid  
  
  end
  
end

