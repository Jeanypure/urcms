--增加仓库权限
create Proc [P_HD_QrySkuCheckMain] 
	@sku		Varchar(100)='',
	@OrderFlag   int = 0,
	@LogisticWayName varchar(1000) = '',
	@iMin int = 0,
	@iMax int = 999999,
	@userid int =0, --当前用户ID admin传0
	@storeQxFlag int=0
as
begin
 
  CREATE TABLE #ColTable
	(
		ColName varchar(50)
	)
	DECLARE @SqlStr VarChar(Max)
	if @LogisticWayName <> '' begin 
	  SET @SqlStr = 'insert into #ColTable(ColName) select ''' + Replace(@LogisticWayName, ',', ''' union select ''')
	  SET @SqlStr = @SqlStr + '''' 
	  --print @SqlStr
	  EXEC(@SqlStr)
	end
	
  create Table #NidTable
  (
     Nid int,
     L_Qty float 
  )
  
	if @userid=0 
	begin
		insert into #NidTable
		select TradeNid, SUM(L_Qty) as L_Qty from 
		(
			select TradeNid, Sku, SUM(A.L_Qty) as L_Qty  from P_TradeDt(noLock) A
			inner join P_Trade(noLock) B on A.TradeNID = B.NID 
			where  FilterFlag=22 and b.nid in (select tradenid from p_tradedt(nolock) where sku=@sku)
			group by TradeNID, Sku
		 ) A group by TradeNid 
		   having COUNT(TradeNID) = 1 and SUM(A.L_Qty) >= @iMin and Sum(A.L_Qty) <= @iMax  
	end else
	begin
	    if @storeQxFlag=1
	    begin
			insert into #NidTable
			select TradeNid, SUM(L_Qty) as L_Qty from 
			(
				select TradeNid, Sku, SUM(A.L_Qty) as L_Qty  from P_TradeDt(noLock) A
				inner join P_Trade(noLock) B on A.TradeNID = B.NID 
				inner join S_userSuffix(nolock) us on us.suffix=b.SUFFIX and userid=@userid
				inner join S_storePurview sp on sp.PersonID=@userid and a.StoreID=sp.StoreID
				where  FilterFlag=22 and b.nid in (select tradenid from p_tradedt(nolock) where sku=@sku)
				group by TradeNID, Sku
			 ) A group by TradeNid 
			   having COUNT(TradeNID) = 1 and SUM(A.L_Qty) >= @iMin and Sum(A.L_Qty) <= @iMax  
		 end else
	    begin
			insert into #NidTable
			select TradeNid, SUM(L_Qty) as L_Qty from 
			(
				select TradeNid, Sku, SUM(A.L_Qty) as L_Qty  from P_TradeDt(noLock) A
				inner join P_Trade(noLock) B on A.TradeNID = B.NID 
				inner join S_userSuffix(nolock) us on us.suffix=b.SUFFIX and userid=@userid
				where  FilterFlag=22 and b.nid in (select tradenid from p_tradedt(nolock) where sku=@sku)
				group by TradeNID, Sku
			 ) A group by TradeNid 
			   having COUNT(TradeNID) = 1 and SUM(A.L_Qty) >= @iMin and Sum(A.L_Qty) <= @iMax  
		 end		 
	end 

  SELECT  0 as TmpbCheck, tmpM.L_QTY as Qty, 
				m.NID,m.SHIPTONAME,m.TrackNo,m.NOTE,m.SUBJECT,m.Memo,m.SUFFIX,
				m.RECEIVERBUSINESS,
			 dateadd(hour,8,m.ordertime) as OrderTimeCN,m.SelFlag, 
			 e.name as expressname, 
			 l.name as logicsWayName,
			 l.code as logicsWayCode, 
			 l.FileName as printfilename,
			 c.CountryZnName,
			 l.eub, m.PackingMen,
			 m.expressnid as expressID, m.logicsWayNID as  logicsWayID,m.ExpressFare,
		      m.SHIPTOCOUNTRYCODE,m.TotalWeight 
  into #TmpData  
               FROM P_Trade(noLock)  m 
               inner join P_TradeDt(noLock) dt on dt.TradeNID = m.NID 
               inner join #NidTable tmpM on TmpM.Nid = m.NID 
               LEFT JOIN T_express e on e.nid=m.expressnid  
               LEFT JOIN B_Country c on c.CountryCode=m.SHIPTOCOUNTRYCODE  
               LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID  
               Left join #ColTable tmp1 on tmp1.ColName = l.name 
              where  dt.SKU = @sku and  --只有一条记录  主表SALESTAX = 1 不准
                   -- add by ylq 2015-11-06下面这段话可过滤可不过滤，因为inner join #NidTable 已经做了过滤，不知道速度怎么样
                   FilterFlag=22 --modify by 2015-05-13 根据未核单跟踪获取
                   and ((@LogisticWayName = '') or (tmp1.ColName is not null))
                    
	if @OrderFlag = 0 begin -- 啥都没选，按订单数量
	  select * from #TmpData order by Qty, NID 
	end
	else if @OrderFlag = 1 begin   -- 1的话只按物流方式,数量排序
	  select * from #TmpData order by logicsWayName,Qty, NID  
	end 
	else if @OrderFlag = 2 begin   -- 2的话，按订单时间排序
	  select * from #TmpData order by OrderTimeCN
	end
	else if @OrderFlag = 3 begin   -- 3的话，按物流方式，交易时间排序
	  select * from #TmpData order by logicsWayName,OrderTimeCN
	end
 
   
   drop table #NidTable 
   drop table #ColTable
   drop table #TmpData
end
