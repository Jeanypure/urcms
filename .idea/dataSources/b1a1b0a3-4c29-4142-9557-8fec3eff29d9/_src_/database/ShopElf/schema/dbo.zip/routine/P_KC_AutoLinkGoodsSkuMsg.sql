
CREATE PROCEDURE [dbo].[P_KC_AutoLinkGoodsSkuMsg] @TradeNID VARCHAR(10) = ''	
AS
BEGIN
    --获取配货信息是否用SKUNAME 0 不使用 1 使用
	declare
		@OrdersGoodsNameIsSKUName int=0 
	set 
	    @OrdersGoodsNameIsSKUName = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='OrdersGoodsNameIsSKUName')	

	  IF ISNULL(@TradeNID,'') = '' 
	   RETURN
	  SET NOCOUNT ON
	   	   
	  DECLARE @Store11ID int=0
	  SET @Store11ID=(SELECT nid 
	                  FROM B_Store WHERE StoreName in (SELECT ParaValue FROM B_SysParams WHERE ParaCode='DefaultSendStock') )
	  SET @Store11ID=ISNULL(@Store11ID,0)
		
		
	  UPDATE 
		     D
	  SET      
			 D.AliasCnName=case when isnull(g.AliasCnName,'') <>'' then g.AliasCnName else D.AliasCnName end,
			 d.AliasEnName=case when isnull(g.AliasEnName,'') <>'' then g.AliasEnName else D.AliasEnName end,
			 d.BmpFileName=case when isnull(d.BmpFileName,'') <> '' then d.BmpFileName else g.BmpFileName end,
			 d.DeclaredValue=case when d.DeclaredValue<>0 then d.DeclaredValue  else  isnull(g.DeclaredValue,0) end,
			 d.Weight= case when d.Weight<>0 then d.Weight else   isnull(g.Weight,0)*d.L_QTY/1000 end,			 
			 d.OriginCountry=g.OriginCountry,
			 d.OriginCountryCode=g.OriginCountryCode,
			 d.StoreID=CASE WHEN isnull(g.StoreID,0) = 0 THEN @Store11ID 
			                ELSE  g.StoreID 
			           END,
			 d.GoodsSKUID=isnull(gs.NID,0),
			 d.GoodsName = CASE WHEN ISNULL(g.MultiStyle,0) = 0  THEN  g.GoodsName 
			        		    ELSE 
				                  case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
				                  else ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
				                       ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,'') 
				                  end                           
				                END 	
	  FROM 
			P_TradeDt D	 
		left outer join B_GoodsSKU gs on gs.SKU=d.SKU
		left outer join B_Goods g on g.NID=gs.GoodsID		
	  WHERE 	
			TradeNID=@TradeNID	
	
      UPDATE pt
	  SET TotalWeight = ISNULL((SELECT SUM(isnull(ptd.[Weight],0)) 
	  						    FROM P_TradeDt ptd 
							    WHERE TradeNID = pt.NID),0)
	  FROM P_Trade pt
	  WHERE pt.NID = @TradeNID
		--组合品单独考虑 cuifeng	
		update
			 d
		set
			d.[Weight]=isnull(g.[Weight],0)/1000.00,
			d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end,
			d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
			d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
		from 
			P_TradeDt d 
		inner join B_GoodsSKULinkShop gss on gss.ShopSKU=d.ebaySKU	
		inner join B_GoodsSKU gs on gs.SKU=gss.SKU			
		inner join B_Goods g on g.NID=gs.GoodsID				
		where	
			d.TradeNID=@TradeNID	and  d.L_EBAYITEMTXNID <> '' and g.GroupFlag=1		  
		--组合品单独考虑 cuifeng	
		update
			 d
		set
			d.[Weight]=isnull(g.[Weight],0)/1000.00,
			d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end,
			d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
			d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
		from 
			P_TradeDt d
		inner join B_GoodsSKU gs on gs.SKU=d.ebaySKU
		inner join B_Goods g on g.NID=gs.GoodsID				
		where
			d.TradeNID=@TradeNID and  d.L_EBAYITEMTXNID <> '' and g.GroupFlag=1	
			
			
		--把订单购买总数量\SKU个数求求和	
		DECLARE @MULTIITEM INT = 0,@SALESTAX INT = 0
		
		SET @MULTIITEM = (SELECT SUM(ISNULL(L_QTY,0)) FROM P_TradeDt WHERE TradeNID = @TradeNID)
		
		--SET @SALESTAX = (SELECT COUNT(*) FROM P_TradeDt WHERE TradeNID = @TradeNID)	--这里有问题，万一两个相同的sku呢
	    --add by ylq 2015-11-13  取SKU个数
	    set @SALESTAX = isnull((select sum(1) from (select sku from P_TradeDt 
					where TradeNID=@TradeNID group by sku ) as aa),0)			
	     
		UPDATE P_Trade
		SET MULTIITEM  = ISNULL(@MULTIITEM,0),SALESTAX  =  ISNULL(@SALESTAX,0)							  
		FROM P_Trade
		WHERE NID = @TradeNID			
				  
END

