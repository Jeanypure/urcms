--P_KC_CalcGoodsCostPriceAVG 1,'67890'
 --select * from KC_Cal_StockByAVG order by DMakeDate
CREATE  Procedure [dbo].[P_KC_CalcGoodsCostPriceAVG]
	@PriceFlag  int=0,--1是原入库价，0是商品信息成本价
	@fSku varchar(50)=''
As
begin

	--set Nocount on
	declare @GoodsSkuID int=0
	set @GoodsSkuID=ISNULL((select top 1 nid from b_goodssku where sku=@fsku),0)
	if @fSku <>'' and @GoodsSkuID=0	
	begin
	  select 'error'= @fSku +'查询不到'
	  return 
	end
	if @fSku='' set @GoodsSkuID=0	
	IF   EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KC_CalcGoodsSKU]') AND type in (N'U'))
	begin
		drop table KC_CalcGoodsSKU

	end
			CREATE TABLE [dbo].[KC_CalcGoodsSKU](
				[RowNO] [int] NULL,
				[GoodsSKUID] [int] NULL,
				[StoreID]	[int] null
			) ON [PRIMARY]	
			Declare 
				@fgoodsskuid int,
				@CurRow int,
				@fStoreId int
			select distinct GoodsSKUID,StoreID into #T_GoodsSKUNID 
			from KC_CurrentStock 
			where (GoodsSKUID= @GoodsSkuID or @GoodsSkuID=0) and
				GoodsSKUID not in (select GoodsSKUID from KC_CalcGoodsSKU)
				
			select 'Goods SKU store Count'=count(*) from #T_GoodsSKUNID 
			set @CurRow=1
			Declare 
				GoodsSKUCur Cursor For Select GoodsSKUID,StoreID from #T_GoodsSKUNID
			Open GoodsSKUCur
			Fetch Next From GoodsSKUCur Into @fgoodsskuid,@fStoreId
			While (@@Fetch_Status=0)
			begin
				update KC_CurrentStock set Number=0,[Money] =0,Price=0 
				where (GoodsSKUID= @GoodsSkuID and StoreID =@fStoreId)			
			  print 'Row='+cast(@CurRow as varchar(10)) +'----GoodsSKUID=' +cast(@fgoodsskuid as varchar(10)) 
			  exec P_KC_CalcGoodsCostPriceBySKUAVG  @PriceFlag,@fgoodsskuid,@fStoreId
			  insert into KC_CalcGoodsSKU 
			  select '0',@fgoodsskuid,@fStoreId
			  set @CurRow=@CurRow +1
			  Fetch Next From GoodsSKUCur Into @fgoodsskuid,@fStoreId
			end
			Close GoodsSKUCur
			Deallocate GoodsSKUCur
	--set nocount off		
end


