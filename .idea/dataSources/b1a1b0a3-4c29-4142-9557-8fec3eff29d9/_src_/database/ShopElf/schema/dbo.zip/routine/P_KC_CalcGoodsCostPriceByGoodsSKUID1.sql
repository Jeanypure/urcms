create Procedure [dbo].[P_KC_CalcGoodsCostPriceByGoodsSKUID1]
	@PriceFlag  int=0,--1是原入库价，0是商品信息成本价
	@GoodsSkuID int=0
As
begin
   set nocount on
	truncate table KC_Cal_StockInDetail

/*入库记录数--start*/
	/*--rk采购入库*/
		insert into 
			KC_Cal_StockInDetail(BillType,DMakeDate,SBillNumber,GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			1,m.makedate,m.billnumber,d.goodsskuid,m.storeid,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType=1 and  M.CheckFlag = 1  and d.GoodsSKUID=@GoodsSkuID
	/*--rk入库退回*/
		insert into 
			KC_Cal_StockInDetail(BillType,DMakeDate,SBillNumber,GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			2,m.makedate,m.billnumber,d.goodsskuid,m.storeid,
			NIAmount= -IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then -IsNull(D.Money,0) else -isnull(gs.costprice,0)*d.Amount end
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType=2 and M.CheckFlag = 1  and d.GoodsSKUID=@GoodsSkuID	
						
	/*--rk其它入库*/
		insert into 
			KC_Cal_StockInDetail(BillType,DMakeDate,SBillNumber,GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			3,m.makedate,m.billnumber,d.goodsskuid,m.storeid,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType=3 and M.CheckFlag = 1  and d.GoodsSKUID=@GoodsSkuID			
		
	/*调拔的--rk*/
		insert into 
			KC_Cal_StockInDetail(BillType,DMakeDate,SBillNumber,GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			4,m.makedate,m.billnumber,d.goodsskuid,m.StoreInID,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
		left outer join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID					
		Where 
			M.CheckFlag =1	  and d.GoodsSKUID=@GoodsSkuID
	/*盘点的--rk*/
		insert into 
			KC_Cal_StockInDetail(BillType,DMakeDate,SBillNumber,GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			5,m.makedate,m.billnumber,d.goodsskuid,m.StoreID,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 
		left outer join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID					
		Where 
			M.CheckFlag =1 and Amount>0   and d.GoodsSKUID=@GoodsSkuID
/*入库记录数--end*/	
	update 
		KC_Cal_StockInDetail
	set
		NBaAmount=NIAmount,
		NBaMoney=NIMoney
/*出库记录数--start*/	
	truncate table KC_Cal_StockOutDetail
		--出库表
		insert into 
			KC_Cal_StockOutDetail(BillType,NDID,DMakeDate,SBillNumber,GoodsSkuID,StoreID,NOAmount,TradeDTNid)
		Select 
			1,d.nid,m.makedate,m.billnumber,d.GoodsSKUID,m.StoreID, d.Amount,isnull(m.TradeNid,0)
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 				
		Where 
			M.CheckFlag =1	  and d.GoodsSKUID=@GoodsSkuID
	/*调拔的--ck*/
		insert into 
			KC_Cal_StockOutDetail(BillType,NDID,DMakeDate,SBillNumber,GoodsSkuID,StoreID,NOAmount,TradeDTNid)
		Select 
			2,d.nid,m.makedate,m.billnumber,d.GoodsSKUID,m.StoreOutID, d.Amount,0
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
				
		Where 
			M.CheckFlag =1	  and d.GoodsSKUID=@GoodsSkuID
			
	/*盘点的--ck*/
		insert into 
			KC_Cal_StockOutDetail(BillType,NDID,DMakeDate,SBillNumber,GoodsSkuID,StoreID,NOAmount,TradeDTNid)
		Select 
			3,d.nid,m.makedate,m.billnumber,d.GoodsSKUID,m.StoreID, abs(d.Amount),0
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 				
		Where 
			M.CheckFlag =1 and d.Amount <0  and d.GoodsSKUID=@GoodsSkuID
						
/*出库记录数--end*/

		if @PriceFlag=0 --以商品信息的成本 单价更新
		begin
			/*清空记录中的金额及单价*/
			update KC_CurrentStock set Price=0 ,Money =0 where GoodsSKUID=@GoodsSkuID
			update CK_StockOutD set Price=0,Money=0 where GoodsSKUID=@GoodsSkuID
			update  KC_StockChangeD set Price =0,Money=0 where GoodsSKUID=@GoodsSkuID
			--update KC_StockCheckD set Price=0 ,Money=0
			--update KC_StockCheckD set Price=0 ,Money=0
			--update CG_StockInD set Price=0 ,Money=0,TaxMoney=0,TaxPrice=0,AllMoney=0

			/*其它为0的记录都是无入库的，商品信息中的进价更新*/

			update CK_StockOutD set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =CK_StockOutD.GoodsSKUID ),0)
			where GoodsSKUID=@GoodsSkuID										 
				--where Price =0
			update KC_StockChangeD set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =KC_StockChangeD.GoodsSKUID ),0)
			 where GoodsSKUID=@GoodsSkuID
				--where Price =0
			--update KC_StockCheckD set Price=isnull((select top 1 costprice from B_Goods where NID=KC_StockCheckD.GoodsID ),0)
				--where Price =0
			update KC_CurrentStock set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =KC_CurrentStock.GoodsSKUID ),0)
			 where GoodsSKUID=@GoodsSkuID
				--where Price =0
				

			--update CG_StockInD set Price=isnull((select top 1 costprice from B_Goods where NID=CG_StockInD.GoodsID ),0),
			--taxPrice=isnull((select top 1 costprice from B_Goods where NID=CG_StockInD.GoodsID ),0)
				--where Price =0
					
			update CK_StockOutD set Money=Amount*Price  where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_StockChangeD set Money=Amount*Price where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_StockCheckD set Money=Amount*Price where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_CurrentStock set Money=Number*Price where GoodsSKUID=@GoodsSkuID
				--where Money=0
			--update CG_StockInD set Money=amount*Price,AllMoney=Amount*Price

			--更新订单价格
			/*清空记录中的金额及单价*/
			update P_TradeDt set CostPrice=0   where GoodsSKUID=@GoodsSkuID
			update P_TradeDt_His set CostPrice=0   where GoodsSKUID=@GoodsSkuID
			update P_TradeDtUn set CostPrice=0  where GoodsSKUID=@GoodsSkuID
			update P_Trade_bdt set CostPrice=0  where GoodsSKUID=@GoodsSkuID


			--更新为0的
			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDt d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			 where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0
				
			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDt_His d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			 where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0

			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDtUn d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0

			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_Trade_bdt d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0		
		end
		else--以入库价格，先进先出更新
		begin	
			Declare 
				@NInAmount Float,
				@NDID		int,
				@Billnumber varchar(20),
				@NID		int,
				@WhileCount int,
 				@BillType	int,
				@BillTypeIn int,
				@TempAmount float,
				@NInPrice money,
				@NinMoney money,
				@TempInMomey money,		
				@NBaAmount Float,
				@NBaMoney Money,
				@NBaPrice money,
				@NOAmount float,
				@fgoodsskuid int,
				@StoreID int,
				@TradeDTNid int
			set  @WhileCount=0
			Declare 
				OutRecCur Cursor For Select BillType,NDID,goodsskuid,storeid, Isnull(NoAmount,0),TradeDTNid From KC_Cal_StockOutDetail 
				order by Dmakedate FOR UPDATE 
			Open OutRecCur
			Fetch Next From OutRecCur Into @BillType,@NDID,@fgoodsskuid,@StoreID,@NOAmount,@TradeDTNid
			While (@@Fetch_Status=0)
			begin
			  
				set @WhileCount = @WhileCount+1
				  
				--判断入库是否够结存数量
				set @TempAmount = @NOAmount		
				set @TempInMomey=0
				while @TempAmount > 0 
				begin
				  if @WhileCount<100000	
				  begin			
					select 
						top 1 
							@NID	=NID,
							@Billnumber=SBillNumber,
							@BillTypeIn=Billtype,
							@NBaAmount=NBaAmount,
							@NInPrice=NIPrice,
							@NinMoney=NIMoney,
							@NBaMoney=NBaMoney
					from 
						KC_Cal_StockInDetail 
					where 
						NBaAmount>0 and GoodsSKUID=@fgoodsskuid and StoreID=@StoreID
					order by DMakeDate	
												
					if ISNULL(@NBaAmount,0) =0--无入库记录,以成本价更新
					begin
						set @NInPrice=isnull((select costprice from B_GoodsSKU where NID=@fgoodsskuid),0)
						set @TempInMomey=@NOAmount*@NInPrice
						set @TempAmount=0
					end
					else
					begin
			
						if ISNULL(@NInPrice,0) =0  --取明细表成本
						begin
						  set @NInPrice=isnull((select costprice from B_GoodsSKU where NID=@fgoodsskuid),0)
						end		
						if ISNULL(@NInPrice,0) =0 --如果上面为零取主表成本
						begin
						  set @NInPrice=isnull((select costprice from B_Goods where NID in (select goodsid from b_goodssku where nid=@fgoodsskuid)),0)
						end											
						----判断其它入库，采购退回，调拔入库，盘点入库价格》*****start*****-----
						----如果下面一条是上面三种类型 ，直接取KC_Cal_StockInDetail表中当前记录的单价更新上一条记录，第一条除外
						declare		@NextNID	int=0,
									@NextBillTypeIn int =0	
						--取下一条，看是什么出库类别					
						select 
							top 1 
								@NextNID	=NID,
								@NextBillTypeIn=Billtype
						from 
							KC_Cal_StockInDetail 
						where 
							NBaAmount>0 and GoodsSKUID=@fgoodsskuid and StoreID=@StoreID and NID<>@NID 
						order by DMakeDate													
						if @NextBillTypeIn in (2,3,4,5) 
						begin
							update 
								KC_Cal_StockInDetail 
							set
								NIPrice = @NInPrice,
								NIMoney = NIAmount*@NInPrice,
								NBaMoney= NIAmount*@NInPrice
							where
								NID=@NextNID
						end
						----判断其它入库，采购退回，调拔入库，盘点入库价格》*****end*****-----		
						if @TempAmount>@NBaAmount
						begin
							update 
								KC_Cal_StockInDetail 
							set 
								NoAmount=NIAmount,
								NoMoney=@NinMoney,
								NBaAmount=0,
								NBaMoney=0
							where
								NID=@NID
							set @TempAmount=@TempAmount - @NBaAmount
							set @TempInMomey=@TempInMomey+@NBaMoney
						end
						else
						begin			
							update 
								KC_Cal_StockInDetail 
							set 
								NoAmount=NoAmount+@TempAmount,
								NoMoney=NoMoney+@TempAmount*@NInPrice,
								NBaAmount=NIAmount-NoAmount-@TempAmount,
								NBaMoney=NIMoney-NoMoney-@TempAmount*@NInPrice
							where
								NID=@NID	
							set @TempInMomey=@TempInMomey+@TempAmount*@NInPrice	
							set @TempAmount=0													
						end
					end
				  end				
				end 		
				if @BillType=1
				begin
				    insert into KC_CalGoodsOutRec(billtype,NDID,TradeDTNid,nomoney)
				    values(1,@NDID,@TradeDTNid,@TempInMomey)
				    --update KC_Cal_StockOutDetail set NoMoney=@TempInMomey where BillType=1 and NDID=@NID
					--update CK_StockOutD set Price=case when Amount<>0 then  @TempInMomey/Amount else 0 end,[Money]=@TempInMomey where NID=@NDID
					--update P_TradeDt set CostPrice=@TempInMomey where NID=@TradeDTNid and GoodsSKUID=@fgoodsskuid
					--update P_TradeDtUn set CostPrice=@TempInMomey where NID=@TradeDTNid and GoodsSKUID=@fgoodsskuid
					--update P_TradeDt_His set CostPrice=@TempInMomey where NID=@TradeDTNid and GoodsSKUID=@fgoodsskuid								
				end
				if @BillType=2
				    insert into KC_CalGoodsOutRec(billtype,NDID,nomoney)
				    values(2,@NDID,@TempInMomey)				
				   --update KC_Cal_StockOutDetail set  NoMoney=@TempInMomey where BillType=2 and NDID=@NID
					--update KC_StockChangeD set Price=case when Amount<>0 then  @TempInMomey/Amount else 0 end,[Money]=@TempInMomey where NID=@NDID
				if @BillType=3
				    insert into KC_CalGoodsOutRec(billtype,NDID,nomoney)
				    values(3,@NDID,@TempInMomey)					
                   --update KC_Cal_StockOutDetail set  NoMoney=@TempInMomey where BillType=3 and NDID=@NID					
					--update KC_StockCheckD set Price=case when Amount<>0 then  abs(@TempInMomey/Amount) else 0 end,[Money]=-abs(@TempInMomey) where NID=@NDID	
	
			  Fetch Next From OutRecCur Into @BillType,@NDID,@fgoodsskuid,@StoreID,@NOAmount,@TradeDTNid
			end
			Close OutRecCur
			Deallocate OutRecCur
			

			
			--更新库存结存表
			select 
				goodsskuid,
				storeid,
				SUM(isnull(nbaamount,0)) as nbaamount ,
				SUM(isnull(NBaMoney,0)) as NBaMoney
			into #KC_Cal_StockInDetail
			from 
				KC_Cal_StockInDetail 
			group by 
				goodsskuid,
				storeid
			update 
				kc
			set
				kc.Price= case when ic.NBaAmount=0 then 0 else ic.NBaMoney/ic.NBaAmount end,
				kc.Money= case when ic.NBaAmount=0 then 0 else ic.NBaMoney end
			from 
				KC_CurrentStock kc
			inner join 
				#KC_Cal_StockInDetail ic on ic.StoreID=kc.StoreID and ic.GoodsSKUID=kc.GoodsSKUID 
		end
	set nocount off	
end		

