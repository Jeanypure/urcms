CREATE Procedure [P_KC_CalcGoodsCostPriceBySKUAVGpy]
	@PriceFlag  int=0,--1是原入库价，0是商品信息成本价
	@GoodsSkuID int=0,
	@ffStoreId   int =0
As
begin
	set nocount on
	truncate table KC_Cal_StockByAVG

	/*入库记录数--start*/
	/*--rk采购入库*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DMakeDate,SBillNumber,DTNID,
								GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			0,1,m.AudieDate,m.billnumber,d.NID, d.goodsskuid,m.storeid,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money    ,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType=1 and  M.CheckFlag = 1 and d.Amount<>0
			and d.GoodsSKUID=@GoodsSkuID
			and m.StoreID=@ffStoreId 
		/*--rk入库退回*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DMakeDate,SBillNumber,DTNID,
					GoodsskuID,StoreID,NoAmount,NoMoney)
		Select 
			2,5,m.AudieDate,m.billnumber,d.NID,d.goodsskuid,m.storeid,
			NIAmount= ABS( IsNull(D.Amount,0)),
			d.[money]
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType=2 and M.CheckFlag = 1   and d.Amount<>0
			and d.GoodsSKUID=@GoodsSkuID	
			and m.StoreID=@ffStoreId 
						
	/*--rk其它入库*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DMakeDate,SBillNumber,DTNID,
					GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			0,3,m.AudieDate,m.billnumber,d.NID,d.goodsskuid,m.storeid,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money    ,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 	
		left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID			
		Where 
			m.BillType in (3,4) and M.CheckFlag = 1   and d.Amount<>0
			and d.GoodsSKUID=@GoodsSkuID	and m.StoreID=@ffStoreId 	
		
	/*调拔的--rk*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DMakeDate,SBillNumber,DTNID,
				GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney,NoAmount)--NoAmount 存出库的仓库ID
		Select 
			0,4,m.AudieDate,m.billnumber,d.NID,d.goodsskuid,m.StoreInID,
			NIAmount= IsNull(D.Amount,0),
			inprice,[inmoney],
			m.StoreOutID
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
		left outer join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID					
		Where 
			M.CheckFlag =1	   and d.Amount<>0
			and d.GoodsSKUID=@GoodsSkuID and m.StoreInID=@ffStoreId 
	/*盘点的--rk*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DMakeDate,SBillNumber,DTNID,
				GoodsskuID,StoreID,NIAmount,NIPrice,NIMoney)
		Select 
			0,5,m.AudieDate,m.billnumber,d.NID,d.goodsskuid,m.StoreID,
			NIAmount= IsNull(D.Amount,0),
			NIPrice= case when @PriceFlag=1 then IsNull(D.Price,0) else isnull(gs.costprice,0) end,
			NIMoney= case when @PriceFlag=1 then IsNull(D.Money,0) else isnull(gs.costprice,0)*d.Amount end
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 
		left outer join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID					
		Where 
			M.CheckFlag =1 and Amount>0   and d.GoodsSKUID=@GoodsSkuID  and m.StoreID=@ffStoreId 
/*入库记录数--end*/	
	update 
		KC_Cal_StockByAVG
	set
		NBaAmount=NIAmount,
		NBaMoney=NIMoney
/*出库记录数--start*/	
		--出库表
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DTNID,DMakeDate,SBillNumber, 
				GoodsSkuID,StoreID,NOAmount)
		Select 
			2,1,d.nid,m.AudieDate,m.TradeNid,d.GoodsSKUID,m.StoreID, d.Amount
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 				
		Where 
			M.CheckFlag =1	   and d.Amount<>0
			and d.GoodsSKUID=@GoodsSkuID  and m.StoreID=@ffStoreId 
	/*调拔的--ck*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DTNID,DMakeDate,SBillNumber,GoodsSkuID,StoreID,NOAmount)
		Select 
			2,2,d.nid,DATEADD(SS,-1, m.AudieDate),m.billnumber,d.GoodsSKUID,m.StoreOutID, d.Amount --出库排在前面
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
		Where 
			M.CheckFlag =1	 and d.Amount<>0 
			 and d.GoodsSKUID=@GoodsSkuID  and m.StoreoutID=@ffStoreId 
			
	/*盘点的--ck*/
		insert into 
			KC_Cal_StockByAVG(SortOrder,BillType,DTNID,DMakeDate,SBillNumber,GoodsSkuID,StoreID,NOAmount)
		Select 
			2,3,d.nid,m.AudieDate,m.billnumber,d.GoodsSKUID,m.StoreID, abs(d.Amount)
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 				
		Where 
			M.CheckFlag =1 and d.Amount <0  and d.GoodsSKUID=@GoodsSkuID  and m.StoreID=@ffStoreId 
						
/*出库记录数--end*/

		if @PriceFlag=0 --以商品信息的成本 单价更新
		begin
			/*清空记录中的金额及单价*/
			update KC_CurrentStock set Price=0 ,Money =0 where GoodsSKUID=@GoodsSkuID  
			update CK_StockOutD set Price=0,Money=0 where GoodsSKUID=@GoodsSkuID
			update  KC_StockChangeD set Price =0,[Money]=0,inPrice =0,[inMoney]=0 where GoodsSKUID=@GoodsSkuID
			--update KC_StockCheckD set Price=0 ,Money=0
			--update KC_StockCheckD set Price=0 ,Money=0
			--update CG_StockInD set Price=0 ,Money=0,TaxMoney=0,TaxPrice=0,Money    =0

			/*其它为0的记录都是无入库的，商品信息中的进价更新*/

			update CK_StockOutD set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =CK_StockOutD.GoodsSKUID ),0)
			where GoodsSKUID=@GoodsSkuID										 
				--where Price =0
			update KC_StockChangeD set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =KC_StockChangeD.GoodsSKUID ),0)
			 where GoodsSKUID=@GoodsSkuID
				--where Price =0
			--update KC_StockCheckD set Price=isnull((select top 1 costprice from B_Goods where NID=KC_StockCheckD.GoodsID ),0)
				--where Price =0
			update KC_CurrentStock set Price=isnull((select top 1 case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end 
										 from B_GoodsSKU s 
										 inner join B_goods g on g.NID=s.GoodsID   where s.NID =KC_CurrentStock.GoodsSKUID ),0)
			 where GoodsSKUID=@GoodsSkuID
				--where Price =0
				

			--update CG_StockInD set Price=isnull((select top 1 costprice from B_Goods where NID=CG_StockInD.GoodsID ),0),
			--taxPrice=isnull((select top 1 costprice from B_Goods where NID=CG_StockInD.GoodsID ),0)
				--where Price =0
					
			update CK_StockOutD set Money=Amount*Price  where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_StockChangeD set [Money]=Amount*Price,
				[inprice]=price+PackPersonFee+PackMaterialFee+HeadFreight+Tariff,
				[inMoney]=Amount*(price+PackPersonFee+PackMaterialFee+HeadFreight+Tariff) where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_StockCheckD set Money=Amount*Price where GoodsSKUID=@GoodsSkuID
				--where Money=0
			update KC_CurrentStock set Money=Number*Price where GoodsSKUID=@GoodsSkuID
				--where Money=0
			--update CG_StockInD set Money=amount*Price,Money    =Amount*Price

			--更新订单价格
			/*清空记录中的金额及单价*/
			update P_TradeDt set CostPrice=0   where GoodsSKUID=@GoodsSkuID
			update P_TradeDt_His set CostPrice=0   where GoodsSKUID=@GoodsSkuID
			update P_TradeDtUn set CostPrice=0  where GoodsSKUID=@GoodsSkuID
			update P_Trade_bdt set CostPrice=0  where GoodsSKUID=@GoodsSkuID


			--更新为0的
			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDt d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			 where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0
				
			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDt_His d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			 where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0

			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_TradeDtUn d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0

			update d
			set d.CostPrice=(case when IsNull(s.CostPrice,0)<>0 
									then IsNull(s.CostPrice,0) else IsNull(g.CostPrice,0) end )*d.L_QTY
			from P_Trade_bdt d 
			left outer join B_GoodsSKU s on s.SKU=d.SKU
			left outer join B_Goods g on g.NID = s.GoodsID 
			where d.GoodsSKUID=@GoodsSkuID
			--where d.CostPrice =0	
			select GoodsSKUID,StoreID,SUM(NIAmount-case when BillType=4 then 0 else NoAmount end ) as bbamount 
			into #bbamount
			from 	KC_Cal_StockByAVG where GoodsSKUID=@GoodsSkuID 
			group by GoodsSKUID,StoreID
			
			update KC
			set kc.Number=b.bbamount,kc.Money=kc.Price*b.bbamount
			from KC_CurrentStock  kc 
			inner join #bbamount b on b.GoodsSKUID=kc.GoodsSKUID and b.StoreID=kc.StoreID 
			drop table #bbamount	
		end
		else--以移动平均更新
		begin	
		   	
						if not exists(select nid from KC_CurrentStock where StoreID=@ffStoreId and GoodsSKUID=@GoodsSkuID)	
						begin
  							  insert into KC_CurrentStock(StoreID,GoodsID, GoodsSKUID,Number,Price,[Money])
  							  select @ffStoreId,GoodsID, @goodsSKUID,0,0 ,0 from B_GoodsSKU where NID=@GoodsSkuID
						end		
			Declare 
				@RowRec     int,
				@DTNID		int,
				@SortOrder	int,
				@Billnumber varchar(20),
				@MakeDate	datetime,
				@WhileCount int,
 				@BillType	int,
				@BillTypeIn int,
				@TempAmount money,
				@NInAmount money,
				@NInPrice money,
				@NReturnInPrice money,
				@NinMoney money,
				@TempInMomey money,		
				@NBaAmount money,
				@NBaMoney money,
				@NBaPrice money,		
				@NOAmount money,
				@NOMoney money,
				@fgoodsskuid int,
				@StoreID int,
				@TradeDTNid int
			set		@WhileCount=0
			set		@RowRec=0 --判断是否是第一条记录
			set		@NBaAmount	=0
			set		@NBaMoney	=0
			set		@NOMoney = 0;
			set @NReturnInPrice = 0;
	
			Declare 
				OutRecCur Cursor For Select SortOrder,BillType,DTNID,goodsskuid,storeid,
							 NIAmount,NIPrice,NIMoney,Isnull(NoAmount,0),nomoney,SBillNumber,dmakedate
					From KC_Cal_StockByAVG 
				order by Dmakedate,SortOrder FOR UPDATE 
			Open OutRecCur
			Fetch Next From OutRecCur Into @SortOrder,@BillType,@DTNID,@fgoodsskuid,@StoreID,
						@NInAmount,@NInPrice,@NinMoney,@NOAmount,@nomoney,@Billnumber,@MakeDate
			While (@@Fetch_Status=0)
			begin		
			    set @RowRec = @RowRec +1
			    if @RowRec =1 
			    begin
					if @SortOrder=0  and @BillType in (5,4) --第一条盘点入库，成本读入
					begin
						
						set	@NBaAmount=@NInAmount
						set	@NBaMoney = @NinMoney
						if @NinMoney=0 --入库为空，取商品信息
						begin
							set	@NBaMoney = isnull((select top 1 case when gs.costprice=0 then g.costprice else gs.costprice end
										from B_GoodsSKU(nolock) gs inner join B_Goods(nolock) g on g.NID=gs.GoodsID where gs.NID=@GoodsSkuID ),0 )*@NBaAmount
							set @NBaPrice = (case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end) 			
							--update KC_StockCheckD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 	and GoodsSKUID =@GoodsSkuID
							  if @BillType=4 
							  begin
							    --cf 取出库时的成本价
							    set @NBaPrice = ISNULL((select top 1 price from KC_StockChangeD(nolock) where NID=@DTNID),0) ;
	  							update KC_StockChangeD set [inMoney] = Amount*(@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff),
	  								inPrice=@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff 
	  							where NID=@DTNID 	and GoodsSKUID =@GoodsSkuID
							  end
							  else begin
								update KC_StockCheckD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID and GoodsSKUID =@GoodsSkuID							
							  end								
						end		
						set @NBaPrice =(case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end)									
						update kc_currentstock set Price = @NBaPrice ,Number=@NBaAmount,[money]=@NBaMoney where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID						
						
					end
					else
					if @SortOrder=0 and @BillType in (1,3) --入库和其它入库
					begin	

						set	@NBaAmount=@NInAmount
						
						set	@NBaMoney = @NinMoney 		
						if @NinMoney=0 --入库为空，取商品信息
						begin
							set	@NBaMoney = isnull((select top 1 case when gs.costprice=0 then g.costprice else gs.costprice end
										from B_GoodsSKU(nolock) gs inner join B_Goods(nolock) g on g.NID=gs.GoodsID where gs.NID=@GoodsSkuID ),0 )*@NBaAmount
							set @NBaPrice = (case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end) 								
							update CG_StockInD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID and GoodsSKUID =@GoodsSkuID and Price=0
						end								
						set @NBaPrice =(case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end)

						update kc_currentstock set Price = @NBaPrice ,Number=@NBaAmount,[money]=@NBaMoney where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID						
									
					
					end
					else
					if @SortOrder=2 --所有出库					
					begin
						set	@NBaAmount=  -@NoAmount
						set	@NBaMoney = - isnull((select top 1 case when gs.costprice=0 then g.costprice else gs.costprice end
									from B_GoodsSKU(nolock) gs inner join B_Goods(nolock) g on g.NID=gs.GoodsID where gs.NID=@GoodsSkuID ),0 )*ABS(@NoAmount)
						set @NBaPrice =(case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end) 			
						if @BillType=1 
						begin
							update CK_StockOutD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 
							update P_TradeDt set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
							update P_TradeDtUn set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
							update P_TradeDt_His set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
						end
						else
						if @BillType=3
						begin
							update KC_StockCheckD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 							
						end	
						else
						if @BillType=2
						begin
							update KC_StockChangeD set [Money] = Amount*@NBaPrice,Price=@NBaPrice,
							[inMoney] = Amount*(@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff),
	  								inPrice=@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff 
							 where NID=@DTNID 							
						end	
						else
						if @BillType=5
						begin
			
							update CG_StockInD set [Money] = abs(Amount*@NBaPrice),Price=@NBaPrice,TaxPrice=@NBaPrice where NID=@DTNID 							
						end								
						update kc_currentstock set Price = @NBaPrice ,Number=@NBaAmount,[money]=@NBaMoney where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID	
					end
					if @NBaAmount =0 
					begin
						set  @NBaMoney =0
					end
					else
					begin
						if @NBaMoney=0 
						set	@NBaMoney = isnull((select top 1 case when gs.costprice=0 then g.costprice else gs.costprice end
									from B_GoodsSKU(nolock) gs inner join B_Goods(nolock) g on g.NID=gs.GoodsID where gs.NID=@GoodsSkuID ),0 )*@NBaAmount
					end
				
			    end
			    else
			    begin
			    
					if @SortOrder=0 and @BillType in (1,3) --入库和其它入库
					begin
						set	@NBaAmount=isnull((select number from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) 
						if @NBaAmount<0 
						begin
							set @NBaAmount=@NBaAmount+@NInAmount 
							if @BillType=1
							begin
								set	@NBaMoney = @NBaAmount*@NInPrice 
								set @NBaPrice = @NInPrice					
							end
						end
						else
						begin
							set @NBaAmount=@NBaAmount+@NInAmount 
							set	@NBaMoney = isnull((select [money] from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) + @NinMoney 
							set @NBaPrice = (case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end) 							
						
						end
						if @BillType=3
						begin 
							set	@NBaAmount=isnull((select number from kc_currentstock  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) 
							if @NBaAmount<=0 
							begin 
			
								set @NBaPrice = isnull((select top 1 NIPrice from KC_Cal_StockByAVG 
												where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID and NIPrice <>0 
													and SortOrder=0  and BillType in  (1,3,4) and DMakeDate<@MakeDate
													 order by dmakedate desc ),0)
								set	@NBaMoney = @NBaAmount*@NInPrice
							end
							else
							begin
								set	@NBaMoney = isnull((select [money] from kc_currentstock  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) 
								  set @NBaPrice = (case when  @NBaAmount =0.0000 then 0.0000 else @NBaMoney/(@NBaAmount*1.0000) end)
						
							end
							--if @Billnumber='RQD201205215'
							--select @NBaAmount,@NBaPrice 					  
						  if @NBaPrice=0 
						    set @NBaPrice=isnull((select top 1 NIPrice from KC_Cal_StockByAVG 
												where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID and NIPrice <>0 
													and SortOrder=0  and BillType in  (1,3) and DMakeDate<@MakeDate
													 order by dmakedate desc ),0)						  
					
					   	  update CG_StockInD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID and GoodsSKUID =@GoodsSkuID						
						  set @NBaAmount=@NBaAmount+@NInAmount
						  set @NBaMoney = @NBaAmount*@NBaPrice
						end  
						--if @Billnumber='RQD201205215'
						--select @NBaPrice,@NBaAmount,@NBaMoney
						update kc_currentstock set Price = @NBaPrice ,Number=@NBaAmount,[money]=@NBaMoney where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID							
					end
					else
					if @SortOrder=0 and @BillType in (4,5) --调拔和盘点
					begin
		
						if  @BillType=4 
						begin
						  --cf @NOAmount	 in storeid
						  --set @NBaPrice = ISNULL((select top 1 price from kc_currentstock where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) ;
						  --if @NBaPrice=0
						    set @NBaPrice = ISNULL((select top 1 price from KC_StockChangeD(nolock) where NID=@DTNID),0) ;
						end
						else
						begin
						  set @NBaPrice = ISNULL((select top 1 price from kc_currentstock(nolock) where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) ;
						end	
											
						set	@NBaAmount=isnull((select Number from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) + @NInAmount
						set	@NBaMoney = isnull((select [money] from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) + @NBaPrice*@NInAmount 	
						update kc_currentstock set Price=case when @NBaAmount=0 then @NBaPrice else @NBaMoney/@NBaAmount end,Number=@NBaAmount,[money]=@NBaMoney 
						where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID													
						if @BillType=4 
						begin					
							update KC_StockChangeD set [Money] = Amount*@NBaPrice,Price=@NBaPrice,
								[inMoney] = Amount*(@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff),
	  								inPrice=@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff 							
							 where NID=@DTNID 							
						end
						else
						begin
							update KC_StockCheckD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 							
						end			
					end
					else
					if @SortOrder=2 --所有出库					
					begin	
	  
						if @BillType=2 --调拔出库
						begin											
							set @NBaPrice = ISNULL((select top 1 price from kc_currentstock(nolock) where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) ;--@StoreID
						end
						else
						begin
							set @NBaPrice = ISNULL((select top 1 price from kc_currentstock(nolock) where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) ;
						end
						set	@NBaAmount=	isnull((select [number] from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) - @NoAmount
						set	@NBaMoney = isnull((select [money] from kc_currentstock(nolock)  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) - @NBaPrice*@NoAmount 	
                        --ru ku tuihui dan rrd 
                        if @Billtype=5 
                        begin
							--query before in stock price
						
						  
						    set @NReturnInPrice=isnull((select top 1 NIPrice from KC_Cal_StockByAVG 
												where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID and NIPrice <>0 
													and SortOrder=0  and BillType=1 and DMakeDate<@MakeDate
													 order by dmakedate desc ),0)	
--select @Billnumber,	@NReturnInPrice,@NoAmount,@NReturnInPrice*@NoAmount,@DTNID												 
							if @NReturnInPrice*@NoAmount=0	
							begin						
								set	@NBaMoney = isnull((select [money] from kc_currentstock  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) - @nomoney 
								update CG_StockInD set [Money] = abs(Amount*@NBaPrice),[allMoney] = abs(Amount*@NBaPrice),
									Price=@NBaPrice,TaxPrice=@NBaPrice where NID=@DTNID 		
							end else
							begin
							  set	@NBaMoney = isnull((select [money] from kc_currentstock  where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID),0) - @NReturnInPrice*@NoAmount 	
							  update CG_StockInD set [Money] = abs(Amount*@NReturnInPrice),[allMoney] = abs(Amount*@NReturnInPrice),
									Price=@NReturnInPrice,TaxPrice=@NReturnInPrice where NID=@DTNID 	
							end						
					
                        end
						update kc_currentstock set Number=@NBaAmount,[money]=@NBaMoney 
						where GoodsSKUID=@GoodsSkuID and StoreID=@StoreID	
										
						if @BillType=1 
						begin
							update CK_StockOutD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 
							update P_TradeDt set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
							update P_TradeDtUn set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
							update P_TradeDt_His set CostPrice=L_QTY*@NBaPrice where TradeNID=@Billnumber and GoodsSKUID=@GoodsSkuID
						end
						else
						if @BillType=3
						begin
							update KC_StockCheckD set [Money] = Amount*@NBaPrice,Price=@NBaPrice where NID=@DTNID 							
						end	
						else
						if @BillType=2
						begin
							update KC_StockChangeD set [Money] = Amount*@NBaPrice,Price=@NBaPrice,
								[inMoney] = Amount*(@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff),
	  								inPrice=@NBaPrice+PackPersonFee+PackMaterialFee+HeadFreight+Tariff 								
							 where NID=@DTNID 							
						end	
						-- rrd not calc
						--else
						--if @BillType=5
						--begin
							
							--update CG_StockInD set [Money    ] = abs(Amount*@NBaPrice),[Money] = abs(Amount*@NBaPrice),Price=@NBaPrice,TaxPrice=@NBaPrice where NID=@DTNID 							
						--end																				
					end 				
					if @NBaAmount=0 
					  set @NBaMoney =0
			    end
			  Fetch Next From OutRecCur Into @SortOrder,@BillType,@DTNID,@fgoodsskuid,@StoreID,
						@NInAmount,@NInPrice,@NinMoney,@NOAmount,@nomoney,@Billnumber,@MakeDate
			end
			Close OutRecCur
			Deallocate OutRecCur
		
			--更新库存结存表
			update 
				kc
			set
				kc.Number=@NBaAmount,
				kc.Price= case when @NBaAmount=0 then 0 else @NBaMoney/@NBaAmount end,
				kc.[Money]= @NBaMoney
			from 
				KC_CurrentStock kc
			where kc.StoreID=@StoreID and GoodsSKUID=@GoodsSkuID 
	end
	set nocount off	
end
-----------------------------------end 库存预警--更多功能--计算出库成本 end---------------------------------------------------
