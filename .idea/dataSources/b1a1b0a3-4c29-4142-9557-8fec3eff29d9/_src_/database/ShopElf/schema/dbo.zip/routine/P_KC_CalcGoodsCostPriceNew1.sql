 --P_KC_CalcGoodsCostPriceNew1 1,''
create  Procedure [P_KC_CalcGoodsCostPriceNew1]
	@PriceFlag  int=0,--1是原入库价，0是商品信息成本价
	@fSku varchar(50)=''
As
begin
	set Nocount on
	exec P_KC_CalcGoodsCostPriceAVGpy @PriceFlag,@fSku
	set nocount off		
end	
