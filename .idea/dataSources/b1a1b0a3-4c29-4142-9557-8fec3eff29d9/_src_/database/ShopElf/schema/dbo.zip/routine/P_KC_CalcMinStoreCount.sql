CREATE proc [P_KC_CalcMinStoreCount]
	@Flag int=0
as
begin
	--查找销售时间范围
    Declare @SellDay1 int=5
    declare @SellDay2 int=15
    declare @SellDay3 int=30  
        
	select  @SellDay1= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='1' and ISNUMERIC(DictionaryName)=1
	select  @SellDay2= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='2' and ISNUMERIC(DictionaryName)=1
	select  @SellDay3= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='3' and ISNUMERIC(DictionaryName)=1			    
    if @SellDay1=0
      set @SellDay1=5
    if @SellDay2=0
      set @SellDay2=15
    if @SellDay3=0
      set @SellDay3=30    
	--查询销售数量1的每天平均销量
    Declare @Day1Average Money=0
    declare @Day2Average Money=0
    declare @Day3Average Money=0  	
   	
	select
		sku,
		storeid,
		SUM(SellCount1) as SellCount,		
		SUM(SellCount1) as SellCount1,
		SUM(SellCount2) as SellCount2,
		SUM(SellCount3) as SellCount3,				
		case when datediff(dd,MIN(devdate),Max(maxdate))=0 then 1 else datediff(dd,MIN(devdate),Max(maxdate))+1 end as selldays,
		cast(0.0001 as float) as MinCount,
		cast(0.0001 as float) as MaxCount		
		Into #GoodsSKUSellCount
	from (
		select 
			pd.sku,
			pd.StoreID,
			--Min(DateAdd(hour,8,pm.ordertime)) as MinDate,
			MIN(case when ISNULL(DevDate,'')='' then CreateDate else devdate end) as devdate,
			GETDATE() as MaxDate,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,			
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3				
		from 
			P_TradeDt(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_Trade(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			KC_CurrentStock (nolock) kc on kc.StoreID=pd.StoreID and kc.GoodsSKUID=pd.GoodsSKUID
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			ISNULL(pd.SKU,'') <> '' 
			and DateAdd(hour,8,pm.ordertime) between DateAdd(DD,-@SellDay3,GETDATE())  and GETDATE()
		group by 
			pd.sku,pd.StoreID
		union all
		select 
			pd.sku,pd.StoreID,
			--Min(DateAdd(hour,8,pm.ordertime)) as MinDate,
			MIN(case when ISNULL(DevDate,'')='' then CreateDate else devdate end) as devdate,
			GETDATE() as MaxDate,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,			
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3				
		from 
			P_TradeDtUn(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_TradeUn(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			KC_CurrentStock (nolock) kc on kc.StoreID=pd.StoreID and kc.GoodsSKUID=pd.GoodsSKUID			
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			pm.FilterFlag in (0,1,2,4) and
			ISNULL(pd.SKU,'') <> '' 
			and DateAdd(hour,8,pm.ordertime) between DateAdd(DD,-@SellDay3,GETDATE())  and GETDATE()
		group by 
			pd.sku,pd.StoreID			
		union all
		select 
			pd.sku,pd.StoreID,
			--Min(DateAdd(hour,8,pm.ordertime)) as MinDate,
			MIN(case when ISNULL(DevDate,'')='' then CreateDate else devdate end) as devdate,
			GETDATE() as MaxDate,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,			
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3	
            
		from 
			P_TradeDt_his(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_Trade_his(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			KC_CurrentStock (nolock) kc on kc.StoreID=pd.StoreID and kc.GoodsSKUID=pd.GoodsSKUID			
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			ISNULL(pd.SKU,'') <> '' 
			and DateAdd(hour,8,pm.ordertime) between DateAdd(DD,-@SellDay3,GETDATE())  and GETDATE()
		group by 
			pd.sku,pd.StoreID ) 
	as ftable
	group by SKU,StoreID
	--update kc_Currentstock
	Update 
		kc_Currentstock 
	set
		SellCount1=0,
		sellcount2=0,
		sellcount3=0	
			
	Update 
		g
	set
		g.SellCount1=gsc.SellCount1,
		g.sellcount2=gsc.SellCount2,
		g.sellcount3=gsc.SellCount3					
	from 
		kc_Currentstock g 
	inner join 
		B_Goodssku gs on gs.nid=g.goodsskuid
	inner join 
		#GoodsSKUSellCount gsc on gs.sku=gsc.sku and g.storeid=gsc.storeid	
	--更新GoodsID对应sellcount
	--SKU汇总
	select
		sku,
		SUM(SellCount1) as SellCount,		
		SUM(SellCount1) as SellCount1,
		SUM(SellCount2) as SellCount2,
		SUM(SellCount3) as SellCount3,				
		max(selldays) as selldays,
		cast(0.0001 as float) as MinCount,
		cast(0.0001 as float) as MaxCount	
		into #GoodsSKUSellCount1
	from 
		#GoodsSKUSellCount 
	group by 
		sku			
	Update 
		B_GoodsSKU 
	set
		sellcount=0,
		SellCount1=0,
		sellcount2=0,
		sellcount3=0	
			
	Update 
		g
	set
		g.sellcount=gs.SellCount,
		g.SellCount1=gs.SellCount1,
		g.sellcount2=gs.SellCount2,
		g.sellcount3=gs.SellCount3					
	from 
		B_GoodsSKU g ,#GoodsSKUSellCount1 gs
	where 
		isnull(g.sku,'')=gs.sku -- and isnull(gs.SellCount,0) <>0
	
	update 
		#GoodsSKUSellCount
	set
		MinCount =  case when (selldays=0) then 0.000 
						when selldays<@SellDay1 then ((SellCount1/(selldays*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00) 
						when @SellDay1<=selldays and selldays<@SellDay2 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00)
						when @SellDay2<=selldays and selldays<@SellDay3 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00) 
						else ((SellCount1/(@SellDay1*1.00) + SellCount2/(@SellDay2*1.00) + SellCount3/(@SellDay3*1.00))/3.00)  end
		,MaxCount =  case when (selldays=0) then 0.000 
						when selldays<@SellDay1 then ((SellCount1/(selldays*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.00))/3.00)
						when @SellDay1<=selldays and selldays<@SellDay2 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00)
						when @SellDay2<=selldays and selldays<@SellDay3 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00)
						else ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00)  end	
	update 
		#GoodsSKUSellCount1
	set
		MinCount =  case when (selldays=0) then 0.000 
						when selldays<@SellDay1 then ((SellCount1/(selldays*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00) 
						when @SellDay1<=selldays and selldays<@SellDay2 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00)
						when @SellDay2<=selldays and selldays<@SellDay3 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00) 
						else ((SellCount1/(@SellDay1*1.00) + SellCount2/(@SellDay2*1.00) + SellCount3/(@SellDay3*1.00))/3.00)  end
		,MaxCount =  case when (selldays=0) then 0.000 
						when selldays<@SellDay1 then ((SellCount1/(selldays*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.00))/3.00)
						when @SellDay1<=selldays and selldays<@SellDay2 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(selldays*1.000) + SellCount3/(selldays*1.000))/3.00)
						when @SellDay2<=selldays and selldays<@SellDay3 then ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00)
						else ((SellCount1/(@SellDay1*1.000) + SellCount2/(@SellDay2*1.000) + SellCount3/(@SellDay3*1.000))/3.00)  end	

--更新GoodsID对应sellcount
	if @Flag=1 
	begin
		update B_goodssku set maxnum=0
		Update gs
		set
			/*gs.MinNum=round(( case when gss.MinCount*isnull(g.StockDays,1)<1 then 1 
						else gss.MinCount*isnull(g.StockDays,1)  end),0)
			,*/gs.MaxNum=round(( case when isnull(g.SellDays,0)=0 then 0 
						when gss.MinCount*isnull(g.SellDays,1)<1 then 1 
						else gss.MinCount*isnull(g.SellDays,1)  end),0)					
		from 
			#GoodsSKUSellCount1 gss
		inner  join 
			B_goodssku gs on gss.SKU=gs.SKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID 
		where
			isnull(g.SellDays,0) <> 0
		--update goods
		Update 
			g
		set
			/*gs.MinNum=round(( case when gss.MinCount*isnull(g.StockDays,1)<1 then 1 
						else gss.MinCount*isnull(g.StockDays,1)  end),0)
			,*/g.MaxNum=round(( case when isnull(g.SellDays,0)=0 then 0 
						when gss.MinCount*isnull(g.SellDays,1)<1 then 1 
						else gss.MinCount*isnull(g.SellDays,1)  end),0)					
		from 
			#GoodsSKUSellCount gss
		inner  join 
			B_goodssku gs on gss.SKU=gs.SKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID 	
		where
			isnull(g.SellDays,0) <> 0				
		--按仓库更新上限下限	
		update kc_Currentstock set KcMaxNum=0			
		Update 
			g
		set
			g.KcMaxNum=round(( case when isnull(g.SellDays,0)+isnull(gg.SellDays,0)=0 then 0 
					when gss.MaxCount*isnull((case when isnull(g.SellDays,0)=0 then  gg.SellDays else g.SellDays end),1)
							<1 then 1 
						else gss.MaxCount*isnull((case when isnull(g.SellDays,0)=0 then  gg.SellDays else g.SellDays end),1)  end),0)						
		from 
			kc_Currentstock g 
		inner join 
			B_Goodssku gs on gs.nid=g.goodsskuid
		inner join 
			B_Goods gg on gg.nid=gs.GoodsID			
		inner join 
			#GoodsSKUSellCount gss on gs.sku=gss.sku and g.storeid=gss.storeid				
	end
	if @Flag=0
	begin
	   update B_goodssku set MinNum=0 
		Update 
			gs
		set
			gs.MinNum=round(( case when isnull(g.StockDays,0)=0 then  0 
			when gss.MinCount*isnull(g.StockDays,1)<1 then 1 
						else gss.MinCount*isnull(g.StockDays,1)  end),0)
			/*,gs.MaxNum=round(( case when gss.MinCount*isnull(g.SellDays,1)<1 then 1 
						else gss.MinCount*isnull(g.SellDays,1)  end),0)	*/				
		from 
			#GoodsSKUSellCount gss
		inner  join 
			B_goodssku gs on gss.SKU=gs.SKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID 
		where
			isnull(g.StockDays,0)<>0	
		--update goods
		Update 
			g
		set
			g.MinNum=round(( case when isnull(g.StockDays,0)=0 then  0 
							when gss.MinCount*isnull(g.StockDays,1)<1 then 1 
						else gss.MinCount*isnull(g.StockDays,1)  end),0)
			/*,gs.MaxNum=round(( case when gss.MinCount*isnull(g.SellDays,1)<1 then 1 
						else gss.MinCount*isnull(g.SellDays,1)  end),0)	*/				
		from 
			#GoodsSKUSellCount gss
		inner  join 
			B_goodssku gs on gss.SKU=gs.SKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID 
		where 	
			isnull(g.StockDays,0)<>0		
		--按仓库更新上限下限	
		update kc_Currentstock set KcMinNum=0				
		Update 
			g
		set
			g.KcMinNum=round(( case when isnull(g.StockDays,0)+isnull(gg.StockDays,0)=0 then  0 
									when gss.MinCount*isnull((case when isnull(g.StockDays,0)=0 then  gg.StockDays else g.StockDays end),1)
							<1 then 1   
						else gss.MinCount*isnull((case when isnull(g.StockDays,0)=0 then  gg.StockDays else g.StockDays end),1)  end),0)						
		from 
			kc_Currentstock g 
		inner join 
			B_Goodssku gs on gs.nid=g.goodsskuid
		inner join 
			B_Goods gg on gg.nid=gs.GoodsID			
		inner join 
			#GoodsSKUSellCount gss on gs.sku=gss.sku and g.storeid=gss.storeid				

	end
	drop table #GoodsSKUSellCount	

end
