create Procedure [dbo].[P_KC_CalcSKUBalCount]
	@StoreID int,
	@GoodsSKUID int
As
begin
		Declare @BalanceAmount Money
		Set @BalanceAmount=0					
/*生成前期数--start*/
	/*--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount + ISNULL(sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),0)
		
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 				
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
	/*--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(-IsNull(D.Amount,0)),0)
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 			
	/*调拔的--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0)		
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		Where 
			m.StoreInID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
	/*调拔的--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(-IsNull(D.Amount,0)),0)
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		Where 
			m.StoreOutID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
	/*盘点--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0)		
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	and d.Amount>0
	/*盘点的--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0)
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 		and d.Amount<0
		select isnull(@BalanceAmount,0) as BalanceAmount       
end		

