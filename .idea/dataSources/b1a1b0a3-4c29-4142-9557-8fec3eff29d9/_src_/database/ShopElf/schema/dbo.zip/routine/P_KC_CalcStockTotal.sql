create Procedure [dbo].[P_KC_CalcStockTotal]
as
begin	

	IF   EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KC_CalcStockTotal]') AND type in (N'U'))
	drop table KC_CalcStockTotal
		/*生成商品表结构*/		
		Create Table  KC_CalcStockTotal
		(
			  GoodsSKUID Int, /*ID*/
			  GoodsID int,
			  StoreID int,
			  FAmount Float Default 0, /*前期数量*/
			  FMoney Money Default 0,  /*前期金额*/
			  IAmount Float Default 0,  /*本期收入数量*/
			  IMoney Money Default 0,  /*本期收入金额*/
			  OAmount Float Default 0,  /*本期发出数量*/
			  OMoney Money Default 0,  /*本期发出成本金额*/
			  zyAmount float default 0,
			  BAmount Float Default 0,  /*结存数量*/
			  BPrice money default 0,
			  BMoney Money Default 0   /*结存金额*/
		)
						
/*生成所有入库数--start*/
	/*--rk*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeid as storeid,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		Where 
			(M.CheckFlag =1)
		group by 
			D.GoodsSKUID,m.StoreID
	/*--ck*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeid as storeid,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		Where 
			(M.CheckFlag =1) 
		group by 
			D.GoodsSKUID,m.StoreID		
	/*调拔的--rk*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeinid,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		Where 
			(M.CheckFlag =1)
		group by 
			D.GoodsSKUID,m.StoreInID
	/*调拔的--ck*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeoutid,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 

		Where 
			(M.CheckFlag =1) 
		group by 
			D.GoodsSKUID,m.storeoutid
	/*盘点的--rk*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeid,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			(M.CheckFlag =1) and 	IsNull(D.Amount,0) >0 
		group by 
			D.GoodsSKUID,StoreID
	/*盘点的--ck*/
		insert into 
			KC_CalcStockTotal(GoodsSKUID,storeid,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			m.storeid,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			(M.CheckFlag =1) and IsNull(D.Amount,0)	<0 
		group by 
			D.GoodsSKUID,StoreID	
					
/*入出库数--end*/					

--生成占用数量
	insert into KC_CalcStockTotal(GoodsSKUID,StoreID,zyAmount)
	
	select d.goodsskuid,d.storeid,SUM(d.l_qty) as l_qty 
	from P_TradeDt  d 
	inner join P_Trade m on m.NID=d.TradeNID
	where m.FilterFlag>5 and m.FilterFlag<100
	group by d.GoodsSKUID,d.StoreID
	
/*更新本期发生数*/
		
		select 
			GoodsSKUID,
			GoodsID = 0,
			StoreID,
			FAmount  = sum(IsNull(FAmount,0)),
			FMoney   = sum(IsNull(FMoney,0)),
			IAmount   = sum(IsNull(IAmount,0)),
			IMoney   = sum(IsNull(IMoney,0)),
			OAmount   = sum(IsNull(OAmount,0)),
			OMoney  = sum(IsNull(OMoney,0)),
			Zyamount=SUM(isnull(zyAmount,0)),
			BAmount = sum(IsNull(BAmount,0)),
			BPrice = CAST(0.00 as float),
			BMoney  = sum(IsNull(BMoney,0))
		into
			#KC_CalcStockTotal
		from    
			KC_CalcStockTotal
		group by 
			GoodsSKUID,StoreID
		/*余额*/
		Update 
			#KC_CalcStockTotal 
		Set 
			BAmount	=IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0),
			BMoney		= Case when (IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0))<>0 then
										 IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0) else 0 end
		
		update #KC_CalcStockTotal 
		set
			BPrice = BMoney/BAmount
		where 
			isnull(BAmount,0) <>0
		update #KC_CalcStockTotal 
		set GoodsID=isnull((select top 1 GoodsID from B_GoodsSKU where B_GoodsSKU.NID = #KC_CalcStockTotal.GoodsSKUID),0)
		
		--注意之前做做好数据库的备份,更新时，备份好库存表后再去掉注释
		truncate Table kc_currentstock
		
		insert into KC_CurrentStock(GoodsID,GoodsSKUID,StoreID,Number,ReservationNum,Money,Price)
		select 
			GoodsID,GoodsSKUID,StoreID,BAmount,zyAmount,BMoney,BPrice
		from #KC_CalcStockTotal
		
end

