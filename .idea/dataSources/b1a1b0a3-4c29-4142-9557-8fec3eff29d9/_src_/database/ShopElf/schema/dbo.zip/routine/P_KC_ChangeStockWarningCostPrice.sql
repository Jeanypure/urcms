CREATE PROCEDURE P_KC_ChangeStockWarningCostPrice @GoodsSKUID VARCHAR(50) = '0',
                                                  @StoreID VARCHAR(50) = '0', 
                                                  @NewPrice NUMERIC(10,2) = 0, 
                                                  @CurrName VARCHAR(100)=0
AS
BEGIN	
	DECLARE  @ErrorCount INT = 0, @StoreName VARCHAR(100) = '', @GoodsSKU VARCHAR(100)= '',@Logs VARCHAR(2000) = '',@OrigPrice VARCHAR(10) = '0'
	SELECT TOP 1 @StoreName = StoreName FROM B_Store WHERE NID = @StoreID
	SELECT TOP 1 @GoodsSKU = SKU FROM B_GoodsSKU  WHERE NID = @GoodsSKUID
	SELECT TOP 1 @OrigPrice = Price FROM KC_CurrentStock WHERE GoodsSKUID = @GoodsSKUID AND StoreID = @StoreID
	 
	BEGIN TRANSACTION	  
	  UPDATE  KC_CurrentStock
	  SET Price = @NewPrice,[Money] = Number * @NewPrice
	  WHERE GoodsSKUID = @GoodsSKUID AND StoreID = @StoreID 
	  
	  SET @ErrorCount = @ErrorCount + @@ERROR 	  
	  
	IF @ErrorCount = 0 
	BEGIN 
	  COMMIT TRANSACTION
	  SET @Logs = '成功修改商品SKU:'+ISNULL(@GoodsSKU,'')+'；所属仓库:'+ ISNULL(@StoreName,'')+'价格:'+@OrigPrice+'-->'+convert(varchar(20), @NewPrice)
	  EXEC S_WriteTradeLogs 0,@Logs,@CurrName
	END ELSE 
    BEGIN 
      ROLLBACK TRANSACTION
      SET @Logs = '修改价格'+@OrigPrice+'-->'+convert(varchar(20), @NewPrice)+'失败商品SKU:'+ISNULL(@GoodsSKU,'')+'；所属仓库:'+ ISNULL(@StoreName,'')
	  EXEC S_WriteTradeLogs 0,@Logs,@CurrName
    END 
END 

