

create PROCEDURE [dbo].[P_KC_CheckReservationNum_Package]
                     @TradeNID INT
                     
AS
BEGIN
  DECLARE @CurrCount INT, @LessSotck INT , @AllowNegativeStock INT 
  DECLARE @GoodsSKUID INT , @SoreID INT , @ReservationNum INT
  SET  @LessSotck = 0
  

  DECLARE _TradeDtUn CURSOR
  FOR SELECT GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY
      FROM P_TradeDt ptd 
      WHERE ptd.TradeNID = @TradeNID
      GROUP BY ptd.GoodsSKUID, ptd.StoreID
  OPEN _TradeDtUn
  FETCH NEXT FROM _TradeDtUn INTO @GoodsSKUID, @SoreID, @ReservationNum
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
  	IF NOT EXISTS (SELECT 1 
  	               FROM KC_CurrentStock kcs 
  	               WHERE kcs.GoodsSKUID = @GoodsSKUID)
  	SET  @LessSotck = 1  
  	SET @CurrCount = isnull((
  						SELECT 
  							ISNULL(Number,0) - ISNULL(ReservationNum,0)+ @ReservationNum
                      FROM KC_CurrentStock kcs 
                      WHERE kcs.GoodsSKUID = @GoodsSKUID AND kcs.StoreID = @SoreID),0)	                  
    IF (@CurrCount < @ReservationNum) 
    SET  @LessSotck = 1 	
  	FETCH NEXT FROM _TradeDtUn INTO @GoodsSKUID, @SoreID, @ReservationNum
  END
  CLOSE _TradeDtUn
  DEALLOCATE _TradeDtUn

  IF @LessSotck = 0 
  BEGIN
  	UPDATE P_Trade SET colorFlag = 1 WHERE NID = @TradeNID
  END ELSE
  BEGIN
  	UPDATE P_Trade SET colorFlag = 0 WHERE NID = @TradeNID
  END
  SELECT @LessSotck AS result 
END 


