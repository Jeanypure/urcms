--P_KC_CheckReservationNum_Un 8822
create PROCEDURE [dbo].[P_KC_CheckReservationNum_Un]
                     @TradeNID INT
                     
AS
BEGIN
  DECLARE @CurrCount INT, @LessSotck INT , @AllowNegativeStock INT 
  DECLARE @GoodsSKUID INT , @SoreID INT , @ReservationNum INT , @IncDeclareValue INT 
  DECLARE @GoodsName VARCHAR(50), @ReturnStr VARCHAR(5000), @StoreName VARCHAR(100)
  SET  @LessSotck = 0
  SET  @AllowNegativeStock = 0
  SET  @ReturnStr = ''
  SET  @GoodsName = ''  
  SET  @IncDeclareValue =0
  SET  @StoreName =''
    
  DECLARE @RestoreStock INT 
  SET @RestoreStock = 0
  SET @RestoreStock = ISNULL((SELECT RestoreStock FROM P_trade WHERE NID = @TradeNID),0)
  
  --IF   (@RestoreStock = -1)
  --BEGIN 
  --	SELECT @LessSotck AS result , @ReturnStr AS Msg
  --  RETURN 
  --END  
    
  Begin TRY
	  UPDATE P_tradedt SET GoodsSKUID = 0 WHERE TradeNID = @TradeNID  
	  SET  @IncDeclareValue = ISNULL((SELECT ParaValue FROM B_SysParams WHERE ParaCode = 'IncDeclareValue'),0)
	  IF (@IncDeclareValue = 1)
	  BEGIN 
		  UPDATE ptd
		  SET ptd.GoodsSKUID = ISNULL(bgs.NID,0), 
		   ptd.AliasCnName=case when isnull(ptd.AliasCnName,'')='' then  isnull(bg.AliasCnName,'') else ptd.AliasCnName end,
		   ptd.AliasEnName = case when isnull(ptd.AliasEnName,'')='' then  isnull(bg.AliasEnName,'') else ptd.AliasEnName end, 
		   ptd.BmpFileName = case when isnull(ptd.BmpFileName,'')='' then  isnull(bg.BmpFileName,'') else ptd.BmpFileName end, 
			   ptd.CostPrice = (case when isnull(bgs.CostPrice,0)<>0 
							then isnull(bgs.CostPrice,0) else 
							isnull(bg.CostPrice ,0) end)*ptd.L_QTY,
			   --ptd.DeclaredValue=ptd.L_QTY*isnull(bg.DeclaredValue,0),
			    ptd.Weight= case when isnull(ptd.weight,0)=0 then 
		  (case when isnull(bgs.weight,0)=0 then  (isnull(bg.weight,0)*ptd.L_QTY)/1000.000 
		   else  (isnull(bgs.weight,0)*ptd.L_QTY)/1000.000 end)
		  else ptd.weight end,
			   ptd.goodsName= case when isnull(ptd.goodsname,'')='' then  isnull(bg.goodsname,'') else ptd.goodsname end, 
			   ptd.OriginCountry=bg.OriginCountry,
			   ptd.OriginCountryCode=bg.OriginCountryCode
			   FROM P_TradeDt ptd inner JOIN B_GoodsSKU bgs ON ptd.SKU = bgs.SKU 
							 inner JOIN B_Goods bg     ON bgs.GoodsID = bg.NID
							 --LEFT JOIN B_StoreLocation bsl ON bg.LocationID = bsl.NID
		   WHERE (ptd.TradeNID = @TradeNID) AND ((ptd.GoodsSKUID = 0) OR (ptd.StoreID = 0)) 
	   END ELSE
	   BEGIN 
   		  UPDATE ptd
		  SET ptd.GoodsSKUID = ISNULL(bgs.NID,0), 
			--ptd.StoreID = ISNULL(bsl.StoreID,0),
		   ptd.AliasCnName=case when isnull(ptd.AliasCnName,'')='' then  isnull(bg.AliasCnName,'') else ptd.AliasCnName end,
		   ptd.AliasEnName = case when isnull(ptd.AliasEnName,'')='' then  isnull(bg.AliasEnName,'') else ptd.AliasEnName end, 
		   ptd.BmpFileName = case when isnull(ptd.BmpFileName,'')='' then  isnull(bg.BmpFileName,'') else ptd.BmpFileName end, 
			   ptd.CostPrice = (case when isnull(bgs.CostPrice,0)<>0 
							then isnull(bgs.CostPrice,0) else 
							isnull(bg.CostPrice ,0) end)*ptd.L_QTY,
			   --ptd.DeclaredValue=isnull(bg.DeclaredValue,0),
			    ptd.Weight= case when isnull(ptd.weight,0)=0 then 
		  (case when isnull(bgs.weight,0)=0 then  (isnull(bg.weight,0)*ptd.L_QTY)/1000.000 
		   else  (isnull(bgs.weight,0)*ptd.L_QTY)/1000.000 end)
		  else ptd.weight end,
			   ptd.goodsName= case when isnull(ptd.goodsname,'')='' then  isnull(bg.goodsname,'') else ptd.goodsname end,       
			   ptd.OriginCountry=bg.OriginCountry,
			   ptd.OriginCountryCode=bg.OriginCountryCode
			   FROM P_TradeDt ptd inner JOIN B_GoodsSKU bgs ON ptd.SKU = bgs.SKU 
							 inner JOIN B_Goods bg     ON bgs.GoodsID = bg.NID
							 --LEFT JOIN B_StoreLocation bsl ON bg.LocationID = bsl.NID
		   WHERE (ptd.TradeNID = @TradeNID) AND ((ptd.GoodsSKUID = 0) OR (ptd.StoreID = 0)) 
			   
	   END  	
	     --申报价值过大时，按设定上限平分申报价值
	     EXEC AVERAGE_DECLARE_VALUE_MAX @TradeNID			  
		----第一条有交易ID的取组合品重量
		update
			 d
		set
			d.[Weight]=isnull(g.[Weight],0)/1000.00 
			--d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end,
			--d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
			--d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
		from 
			P_TradeDt d
		inner join 
			B_GoodsSKU gs on gs.SKU=d.eBaySKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID
		where
			d.TradeNID=@TradeNID and g.GroupFlag=1 and d.L_EBAYITEMTXNID <> '' 	 
			and ISNULL(d.Weight,0) = 0 
	--modify by ylq 2015-08-13
		update
			 d
		set
			--d.[Weight]=isnull(g.[Weight],0)/1000.00,
			d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end 
			--d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
			--d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
		from 
			P_TradeDt d
		inner join 
			B_GoodsSKU gs on gs.SKU=d.eBaySKU
		inner join 
			B_Goods g on g.NID=gs.GoodsID
		where
			d.TradeNID=@TradeNID and g.GroupFlag=1 and d.L_EBAYITEMTXNID <> ''
			and ISNULL(d.DeclaredValue,0) = 0
 	 
	  
	  SET @AllowNegativeStock = (SELECT ISNULL(bsp.ParaValue,0) FROM B_SysParams bsp WHERE bsp.ParaCode = 'AllowNegativeStock')

	  IF (@AllowNegativeStock = 1)
	  BEGIN
 		SELECT @LessSotck AS result , @ReturnStr AS Msg
 		RETURN 
	  END 
	  -------------------------------------------------------------------------------
	  --add ylq 2016-08-13  如果单个仓库设置为允许，也过
	  if not EXISTS  (select Top 1 A.StoreID from P_TradeDt A
	       inner join B_Store B on A.StoreID = B.NID
	       where TradeNID=@TradeNID and ISNULL(B.IsNegativeStock,0) = 0)
	  BEGIN
	    SELECT @LessSotck AS result , @ReturnStr AS Msg
 		RETURN 
	  END
	  -----------------------------------------------------
	  
	  
	  DECLARE _TradeDt CURSOR
	  FOR SELECT GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY, sku
		  FROM P_TradeDt ptd 
		  WHERE ptd.TradeNID = @TradeNID
		  GROUP BY ptd.GoodsSKUID, ptd.StoreID, ptd.sku
	  OPEN _TradeDt
	  FETCH NEXT FROM _TradeDt INTO @GoodsSKUID, @SoreID, @ReservationNum, @GoodsName
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN
  		IF @GoodsSKUID = 0
  		BEGIN 		
  		  SET  @ReturnStr = @ReturnStr + '商品SKU: ' + IsNull(@GoodsName,'') +'的GoodsSKUID为0;'	
  		  IF (@LessSotck = 0)
  		   SET @LessSotck = 2
  		   --cuifeng 20150420 如果为0返回
 			SELECT @LessSotck AS result , @ReturnStr AS Msg
 			RETURN   		   
  		END 
  		IF @SoreID = 0
  		BEGIN 		
  		  SET  @ReturnStr = @ReturnStr + '仓库为空;'	
  		  IF (@LessSotck = 0)
  		   SET @LessSotck = 2
  		   --cuifeng 20150420 如果为0返回
 			SELECT @LessSotck AS result , @ReturnStr AS Msg
 			RETURN   		   
  		END   		
  		SET @StoreName = ISNULL((SELECT StoreName FROM B_Store WHERE NID = @SoreID),'')
  		IF NOT EXISTS (SELECT GoodsSKUID
  					   FROM KC_CurrentStock kcs 
  					   WHERE kcs.StoreID=@SoreID AND kcs.GoodsSKUID = @GoodsSKUID)
  		BEGIN
  		  --生成一条记录
  		  insert into KC_CurrentStock(StoreID,GoodsID, GoodsSKUID,Number,Price,[Money])
  		  select @SoreID,isnull(g.nid,0), @goodsSKUID,0,0 ,
  				0
  		  from B_GoodsSKU gs 
  		  inner join B_goods g on g.NID=gs.GoodsID
  		  where gs.NID=@GoodsSKUID
  		  SET  @ReturnStr = @ReturnStr + '商品SKU: ' + IsNull(@GoodsName,'') +'在其对应"'+@StoreName+'"库存为0;'	
  		  IF (@LessSotck = 0)
  		   SET @LessSotck = 3
  		END                       
   		SET @CurrCount = (SELECT Sum(ISNULL(Number,0)) - Sum(ISNULL(ReservationNum,0)) 
						  FROM KC_CurrentStock kcs 
						  WHERE kcs.GoodsSKUID = @GoodsSKUID AND kcs.StoreID = @SoreID)	 
	    if @RestoreStock=-1 --缺货 占用的，补上数量
	    begin
			declare @quehuozy int
			set @quehuozy=ISNULL((select sum(l_qty) from p_tradedtun
									where GoodsSKUID=@GoodsSKUID and StoreID=@SoreID and  tradenid in
									 (select nid from p_tradeun where RestoreStock=-1 and FilterFlag = 1  )),0)
			set @CurrCount = @CurrCount+ @ReservationNum+ isnull(@quehuozy,0)
	    end   

		IF (@CurrCount < @ReservationNum) 
		BEGIN
		  SET  @ReturnStr = @ReturnStr + '商品SKU: ' + IsNull(@GoodsName,'') +'仓库"'+@StoreName+'"存储数量不足;'	
		  --标记缺货
			UPDATE P_TradeDt SET L_SHIPPINGAMT = 1 WHERE GoodsSKUID = @GoodsSKUID AND StoreID = @SoreID AND TradeNID = @TradeNID 
	       
		  IF (@LessSotck = 0)
  		   SET @LessSotck = 1
		END    			
  		FETCH NEXT FROM _TradeDt INTO @GoodsSKUID, @SoreID, @ReservationNum, @GoodsName
	  END
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt
	  SELECT @LessSotck AS result , IsNull(@ReturnStr,'') AS Msg
	End Try
	Begin CATCH
	  CLOSE _TradeDt
	  DEALLOCATE _TradeDt	
	  SELECT -1 AS result , 'SQL语句出错:'+ERROR_MESSAGE() AS Msg
	End  Catch
END 
