
CREATE Proc [dbo].[P_KC_CurrentStock]
	@TableName	Varchar(30),
	@UserName	Varchar(30),
	@checkFlag	smallint,
	@RecID		int
as
begin
	--创建临时表,保存明细记录
	create table #CurrentStock(
		StoreID		int,
		GoodsID		int,
		GoodsSKUID	int,
		Price		float,
		Amount		Float,
		CostMoney	Float		
	)
	declare 
		@CancelFlag int,
		@BillType   int=0
	declare @UpdateError int
	declare @AudieDate datetime
	declare	@BillNumber	varchar(20)
	declare @Logs		varchar(500)
	declare @operator	varchar(30)
	set @operator = @UserName;	--保存操作人
	set @Logs = '';	
	set	@UpdateError = 0
	if 	@checkFlag=0
	begin
		set @CancelFlag=-1
		set @AudieDate=null
		set @UserName=''
	end	
	else
	begin
	 	set @CancelFlag=1 	
		set @AudieDate=GETDATE()	 	
	end 	
	 		
	begin tran CurrentStock	
	--判断表，生成记录明细
	if LOWER(@TableName) ='cg_stockinm' --入库单
	begin
		--2013-02-20 陈卫 修改: 当nid不存在(修改单据时nid改变),或者已审核/返审核过的 直接回滚事务,防止重复操作
		if exists (select top 1 * from CG_StockInM where nid = @recID and CheckFlag = @checkFlag) 
			or not exists(select top 1 * from CG_StockInM where nid = @recID)
		begin
			rollback tran CurrentStock
			select errorcount=-1;
			return;
		end
		select @BillNumber = BillNumber from CG_StockInM where nid = @recID
		
		update
			CG_StockInM
		set
			CheckFlag=@checkFlag,
			Audier = @UserName,
			AudieDate = @AudieDate
		where
			NID = @RecID	
		insert into 
			#CurrentStock
		select
			m.StoreID	,
			d.GoodsID		,
			D.GoodsSKUID	,
			d.Price		,
			d.Amount*@CancelFlag*(case when m.BillType=2 then -1 else 1 end)		,
			d.Money*@CancelFlag*(case when m.BillType=2 then -1 else 1 end) as  CostMoney	
		from
			CG_StockInD d
		inner join
			CG_StockInM m on m.NID=d.StockInNID
		where
			m.NID=@RecID	
				
		set @BillType=1	
		--2013-02-20 陈卫 修改:增加记录操作日志
		if @CheckFlag = 1
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [审核] 入库单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		else if @CheckFlag = 0
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [反审核] 入库单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'

		INSERT INTO S_Log (USERID ,MODName  ,DOTYPE,dotime,DoContent)
    		VALUES(@operator,'入库单','审核/反审核',convert(varchar(19),getdate(),121),isnull(@Logs,''))
	end
	if LOWER(@TableName) ='ck_stockoutm' --出库单
	begin
		if exists (select top 1 * from ck_stockoutm where nid = @recID and CheckFlag = @checkFlag)
			or not exists(select top 1 * from ck_stockoutm where nid = @recID)
		begin
			rollback tran CurrentStock
			select errorcount=-1;
			return;
		end
		select @BillNumber = BillNumber from ck_stockoutm where nid = @recID
		
		update
			CK_StockOutM
		set
			CheckFlag=@checkFlag,
			Audier = @UserName,
			AudieDate = @AudieDate
		where
			NID = @RecID		
		insert into 
			#CurrentStock
		select
			m.StoreID	,
			d.GoodsID		,
			D.GoodsSKUID,
			d.Price		,
			-d.Amount*@CancelFlag		,
			-d.Money*@CancelFlag as  CostMoney	
		from
			CK_StockOutD d
		inner join
			CK_StockOutM m on m.NID=d.StockOutNID
		where
			m.NID=@RecID	
		set @BillType=2
		
		if @CheckFlag = 1
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [审核] 出库单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		else if @CheckFlag = 0
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [反审核] 出库单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'

		INSERT INTO S_Log (USERID ,MODName  ,DOTYPE,dotime,DoContent)
    		VALUES(@operator,'出库单','审核/反审核',convert(varchar(19),getdate(),121),isnull(@Logs,''))
    		
								 
	end	
	if LOWER(@TableName) ='kc_stockchangem' --调拔单入库
	begin
		if exists (select top 1 * from kc_stockchangem where nid = @recID and CheckFlag = @checkFlag)
			or not exists(select top 1 * from kc_stockchangem where nid = @recID)
		begin
			rollback tran CurrentStock
			select errorcount=-1;
			return;
		end
		select @BillNumber = BillNumber from kc_stockchangem where nid = @recID
		
		update
			KC_StockChangeM
		set
			CheckFlag=@checkFlag,
			Audier = @UserName,
			AudieDate = @AudieDate
		where
			NID = @RecID		
		insert into --入库
			#CurrentStock
		select
			m.StoreInID	,
			d.GoodsID		,
			D.GoodsSKUID,
			d.InPrice		,
			d.Amount*@CancelFlag		,
			d.inmoney*@CancelFlag as  CostMoney	
		from
			KC_StockChangeD d
		inner join
			KC_StockChangeM m on m.NID=d.StockChangeNID
		where
			m.NID=@RecID
		insert into --出库
			#CurrentStock
		select
			m.StoreOutID	,
			d.GoodsID		,
			d.GoodsSKUID as GoodsSKUID	,
			d.Price		,
			-d.Amount*@CancelFlag		,
			-d.Money*@CancelFlag as  CostMoney	
		from
			KC_StockChangeD d
		inner join
			KC_StockChangeM m on m.NID=d.StockChangeNID
		where
			m.NID=@RecID						 
		set @BillType=3
		
		if @CheckFlag = 1
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [审核] 调拨单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		else if @CheckFlag = 0
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [反审核] 调拨单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		INSERT INTO S_Log (USERID ,MODName  ,DOTYPE,dotime,DoContent)
    		VALUES(@operator,'调拨单','审核/反审核',convert(varchar(19),getdate(),121),isnull(@Logs,''))
	end		
	if LOWER(@TableName) ='kc_stockcheckm' --盘点
	begin
		if exists (select top 1 * from kc_stockcheckm where nid = @recID and CheckFlag = @checkFlag)
			or not exists(select top 1 * from kc_stockcheckm where nid = @recID)
		begin
			rollback tran CurrentStock
			select errorcount=-1;
			return;
		end
		select @BillNumber = BillNumber from kc_stockcheckm where nid = @recID
		
		update
			KC_StockCheckM
		set
			CheckFlag=@checkFlag,
			Audier = @UserName,
			AudieDate = @AudieDate
		where
			NID = @RecID
				
		update d
		set 	d.price= case when d.Price=0 and isnull(k.Price,0)<>0 then  k.Price 
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice<>0  then gs.CostPrice
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice=0  then g.CostPrice
				else d.Price end
		from
			KC_StockCheckD d
		inner join
			KC_StockCheckM m on m.NID=d.StockCheckNID
		inner join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID
		inner join 
			B_Goods g on g.NID=gs.GoodsID			
		left outer join 
			KC_CurrentStock k on k.StoreID=m.StoreID and k.GoodsSKUID=d.GoodsSKUID
		where
			m.NID=@RecID 
			
		update d
		set 	d.PDMoney=d.Price*PDAmount,
			d.[Money]= d.Price*PDAmount-ZHMoney
		from
			KC_StockCheckD d
		where
			d.StockCheckNID=@RecID 	
							
		insert into 
			#CurrentStock
		select
			m.StoreID	,
			d.GoodsID,
			D.GoodsSKUID,
			d.Price,
			case when @checkFlag=0 then d.ZhAmount else  d.PDAmount end,
			case when @checkFlag=0 then d.zhAmount*d.Price else d.PDAmount*d.Price end as  CostMoney	
		from
			KC_StockCheckD d
		inner join
			KC_StockCheckM m on m.NID=d.StockCheckNID
		inner join 
			B_GoodsSKU gs on gs.NID=d.GoodsSKUID
		left outer join 
			KC_CurrentStock k on k.StoreID=m.StoreID and k.GoodsSKUID=d.GoodsSKUID
		where
			m.NID=@RecID --and Amount <>0	
		set @BillType=4
	
		if @CheckFlag = 1
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [审核] 盘点单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		else if @CheckFlag = 0
			set @Logs = convert(varchar(20),getdate(),120) + ' ['+@operator+'] [反审核] 盘点单 ['+cast(@recID as varchar(12))+']['+@BillNumber+']'
		INSERT INTO S_Log (USERID ,MODName  ,DOTYPE,dotime,DoContent)
    		VALUES(@operator,'盘点单','审核/反审核',convert(varchar(19),getdate(),121),isnull(@Logs,''))
	end			
	select @UpdateError=@@ERROR
	--在库存表中不存的记录插入
	insert into 
		KC_CurrentStock(StoreID,GoodsID,GoodsSKUID)
	select
		ISNULL(c.storeid,0),
		ISNULL(c.goodsid,0),
		ISNULL(C.GoodsSKUID,0)
	from
		#CurrentStock c 
	where
		not exists   (
			select nid from KC_CurrentStock s 
			where c.GoodsSKUID=s.GoodsSKUID and c.StoreID=s.StoreID ) --and c.GoodsID=s.GoodsID cuifeng 20120616
	--判断是否是销售出库，如果是更新库存表中的最后销售日期
	DECLARE		@SALEDATE DATETIME
	DECLARE		@TRADENID INT
	SET 
		@SALEDATE = null
	if LOWER(@TableName) ='ck_stockoutm' --出库单
	begin

		set
			@TradeNid = isnull((select top 1 tradenid from CK_StockOutM where NID=@RecID),0)
		if @TradeNid <>0 
		set 
			@SaleDate = GETDATE()
    end		
    --占用转到历史记录中
    if @checkFlag=1
    begin
		Insert into KC_ReserveDetail_His(NID, BillType, 
				BillNID, GoodsSKUID, StoreID, Amount, 
				UseFlag, UseDate, CancelDate, MakeUser)
		select 
			NID, BillType, BillNID, GoodsSKUID, 
			StoreID, Amount, UseFlag, UseDate, 
			CancelDate, MakeUser
		from 
			KC_ReserveDetail 
		where 
			BillType=@BillType and BillNID=@RecID
		delete
				KC_ReserveDetail
		where
			BillType=@BillType and BillNID=@RecID			
    end	
    else
    if @checkFlag=0 
    begin
		Insert into KC_ReserveDetail(BillType, 
				BillNID, GoodsSKUID, StoreID, Amount, 
				UseFlag, UseDate, CancelDate, MakeUser)
		select 
			 BillType, BillNID, GoodsSKUID, 
			StoreID, Amount, UseFlag, UseDate, 
			CancelDate, MakeUser
		from 
			KC_ReserveDetail_His 
		where 
			BillType=@BillType and BillNID=@RecID
			
		delete
				KC_ReserveDetail_His
		where
			BillType=@BillType and BillNID=@RecID			
    end	
    if LOWER(@TableName) ='kc_stockcheckm' --盘点  
    begin  	  

		update
			 KC
		set
			kc.SaleDate=@SaleDate,
			kc.Number=ISNULL(c.Amount,0),
			--kc.ReservationNum = case when @CheckFlag=1 and c.Amount < 0 then  kc.ReservationNum+c.Amount 
			--					when @CheckFlag=0 and c.Amount > 0 then kc.ReservationNum+c.Amount 
			--					 else kc.ReservationNum end,
			kc.Money=ISNULL(c.CostMoney,0),
			kc.Price=ISNULL((case when c.Amount<>0 then
					c.CostMoney/(c.Amount*1.0000)
					else 0 end	),0)
		from 
			KC_CurrentStock kc,#CurrentStock c
		where 
			kc.GoodsSKUID=c.GoodsSKUID and
			kc.StoreID=c.StoreID 
	end
	else
	begin
		update
			 KC
		set
			kc.SaleDate=@SaleDate,
			kc.Number=ISNULL(kc.Number,0)+ISNULL(c.Amount,0),
			kc.ReservationNum = case when @CheckFlag=1 and c.Amount < 0 then  kc.ReservationNum+c.Amount 
								when @CheckFlag=0 and c.Amount > 0 then kc.ReservationNum+c.Amount 
								 else kc.ReservationNum end,
			kc.Money=ISNULL(kc.[Money],0)+ISNULL(c.CostMoney,0),
			kc.Price=ISNULL((case when kc.Number+c.Amount<>0 then
					(kc.Money+c.CostMoney)/((kc.Number+c.Amount)*1.0000)
					else 0 end	),0)
		from 
			KC_CurrentStock kc,#CurrentStock c
		where 
			kc.GoodsSKUID=c.GoodsSKUID and
			kc.StoreID=c.StoreID 	
	end
	select @UpdateError=@UpdateError+@@ERROR	
	
	UPDATE 
		 KC
	SET  kc.[Money]=ISNULL(kc.Price,0)*kc.Number
	FROM 
		KC_CurrentStock kc JOIN  #CurrentStock c ON kc.GoodsSKUID=c.GoodsSKUID and kc.StoreID=c.StoreID
		
	select @UpdateError=@UpdateError+@@ERROR
	
	if @UpdateError=0
	begin
	  commit tran CurrentStock
	end  
	else 
	begin 
	  rollback tran CurrentStock	
	end
	select @UpdateError as errorcount
end	
