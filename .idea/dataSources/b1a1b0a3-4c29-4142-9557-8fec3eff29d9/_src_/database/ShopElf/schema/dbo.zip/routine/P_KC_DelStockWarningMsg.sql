CREATE PROCEDURE [P_KC_DelStockWarningMsg] @GoodsSKUID VARCHAR(50) = '0',
                                         @StoreID VARCHAR(50) = '0', 
                                         @CurrName VARCHAR(100)=0
AS
BEGIN	
	DECLARE  @ErrorCount INT = 0, @StoreName VARCHAR(100) = '', @GoodsSKU VARCHAR(100)= '',@Logs VARCHAR(2000) = ''
	SELECT TOP 1 @StoreName = StoreName FROM B_Store WHERE NID = @StoreID
	SELECT TOP 1 @GoodsSKU = SKU FROM B_GoodsSKU  WHERE NID = @GoodsSKUID
	
	BEGIN TRANSACTION
	  
	  DELETE FROM KC_CurrentStock WHERE GoodsSKUID = @GoodsSKUID AND StoreID = @StoreID 
	  SET @ErrorCount = @ErrorCount + @@ERROR 	  
	IF @ErrorCount = 0 
	BEGIN 
	  COMMIT TRANSACTION
	  SET @Logs = '成功删除商品SKU:'+ISNULL(@GoodsSKU,'')+'；所属仓库:'+ ISNULL(@StoreName,'')
	  --EXEC S_WriteTradeLogs 0,@Logs,@CurrName
	  insert into S_Log(USERID, MODName, DOTYPE, DOTIME, DoContent, LOGINIP)
	  values(@CurrName,'库存预警','删除',convert(varchar(19),GETDATE(),121),@Logs,'1.1.1.1')
	END ELSE 
    BEGIN 
      ROLLBACK TRANSACTION
      SET @Logs = '删除失败商品SKU:'+ISNULL(@GoodsSKU,'')+'；所属仓库:'+ ISNULL(@StoreName,'')
	  --EXEC S_WriteTradeLogs 0,@Logs,@CurrName
	  insert into S_Log(USERID, MODName, DOTYPE, DOTIME, DoContent, LOGINIP)
	  values(@CurrName,'库存预警','删除',convert(varchar(19),GETDATE(),121),@Logs,'1.1.1.1')
    END 
END 
