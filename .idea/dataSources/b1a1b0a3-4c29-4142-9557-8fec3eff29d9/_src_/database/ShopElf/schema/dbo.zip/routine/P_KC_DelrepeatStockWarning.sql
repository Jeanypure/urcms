create Procedure [dbo].[P_KC_DelrepeatStockWarning]
As
BEGIN
  -- 删除重复的库存预警数据 并计算
  create table #Skutemp(sku varchar(200) default '')
  -- 把重复的sku 放入到零时表 下面计算库存成本用
   insert into #Skutemp
   select sku from B_GoodsSKU where NID in (select kc.GoodsSKUID from KC_CurrentStock kc group by kc.StoreID,kc.GoodsSKUID having COUNT(1)>1)

	while exists( select kc.StoreID,kc.GoodsSKUID from KC_CurrentStock kc group by kc.StoreID,kc.GoodsSKUID having COUNT(1)>1)
	begin
	  delete from KC_CurrentStock 
	  where NID in (select MAX(NID) from KC_CurrentStock kc group by kc.StoreID,kc.GoodsSKUID having COUNT(1)>1)
	end
   --KC_CurrentStock表索引
	declare @ErrorCount int=0
	exec SP_DropIndex 'KC_CurrentStock'
	set @ErrorCount=@ErrorCount+@@ERROR
	if @ErrorCount=0
	begin
		CREATE NONCLUSTERED INDEX IX_KC_CurrentStock_GID ON dbo.KC_CurrentStock
			(
			GoodsSKUID
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE NONCLUSTERED INDEX IX_KC_CurrentStock_SID ON dbo.KC_CurrentStock
			(
			StoreID
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

		CREATE UNIQUE NONCLUSTERED INDEX IX_KC_CurrentStock_LHID ON dbo.KC_CurrentStock
			(
			StoreID,
			GoodsSKUID
			) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	end
--  计算库存成本和数量
  declare @SKU varchar(200)=''
  declare rong cursor  
  for select sku  from #Skutemp
  --打开游标：
   open rong
  -- 提取数据：
  fetch next from rong into @SKU
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
	print '计算:'+@SKU
	exec P_KC_CalcGoodsCostPriceNew1 1,@SKU
	FETCH next from rong INTO @SKU
  END
  close rong
  DEALLOCATE rong
  drop table #Skutemp
end
