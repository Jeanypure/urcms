 
CREATE  PROCEDURE [dbo].[P_KC_DestoryBindingGoods] 
    @NID int = 0,
    @SKUIDs varchar(1000) = ''
    
AS
BEGIN
  if @SKUIDs = '' begin
    DELETE FROM B_GoodsSKULocation WHERE LocationID = @NID
    UPDATE B_GoodsSKU SET LocationID = null WHERE LocationID = @NID 
    UPDATE B_Goods SET LocationID = null WHERE LocationID = @NID 
  end
  else begin 
	CREATE TABLE #SKUIDTable
	(
		SKUID varchar(50)
	)
    DECLARE @SqlStr VarChar(Max)
    SET @SqlStr = 'insert into #SKUIDTable(SKUID) select ' + Replace(@SKUIDs, ',', ' union select ')
    EXEC(@SqlStr)
	
    DELETE FROM B_GoodsSKULocation  WHERE LocationID = @NID
        and GoodsSKUID in (select SKUID from #SKUIDTable)
    
    UPDATE B_GoodsSKU SET LocationID = null WHERE LocationID = @NID 
        and NID in (select SKUID from #SKUIDTable)
 
    UPDATE B_Goods SET LocationID = null WHERE LocationID = @NID 
      and NID in (select GoodsID from B_GoodsSKU A
        inner join  #SKUIDTable B on A.NID = B.SKUID)
         
  
  end
  
END
