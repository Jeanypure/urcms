
Create proc [dbo].[P_KC_FBAStockInList]
    @CheckState varchar(20),
	@BeginDate varchar(20),
	@EndDate varchar(20),	
	@sellersku varchar(1000),
	@billno varchar(100),
	@suffix varchar(100)	 
as
begin 
  --开始查询   
   DECLARE @Sqlcdt varchar(max)         
        
   set @SqlCdt = 'select 0 as selflag, m.[NID],m.[CheckFlag],m.[BillNumber],m.[MakeDate],m.[ShipFromAddress],m.[LabelPrepPreference] ' +
    ',m.[SufFix],m.[Memo],m.[Audier],m.[AudieDate],m.[Recorder] ' +
    ' ,d.[StockInNID],d.[SellerSKU],d.[ASIN],d.[Condition],d.[Quantity] ' +
    ',d.[QuantityInCase],d.[Remark] into #temp ' +
    ' From  KC_FBAStockInD D    ' +
    ' inner join KC_FBAStockInM M on D.StockInNid=M.nid  '  
    
   
     set @SqlCdt =  @SqlCdt + 'where (M.MakeDate >= ''' + @BeginDate + ''')'   
 
     set @SqlCdt = @SqlCdt + ' and (M.MakeDate <= ''' + @EndDate + ''')'
	 
	 set @SqlCdt = @SqlCdt + ' and m.checkflag in (' + @CheckState + ')'
     
     
   if @suffix <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.suffix=''' + @suffix + ''' '
     end
     
  if @billno <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.billnumber like ''%' + @billno + '%'' '
     end
     
   if @sellersku <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.nid in (select distinct stockinnid from KC_FBAStockInD cd where cd.sellersku  like ''%' + @sellersku + '%'') '
   end 
   
   
   set  @SqlCdt = @SqlCdt + '   order by m.nid select * from #temp drop table #temp '      
 
 print @sqlcdt
 exec (@SqlCdt) 
     
 
end
