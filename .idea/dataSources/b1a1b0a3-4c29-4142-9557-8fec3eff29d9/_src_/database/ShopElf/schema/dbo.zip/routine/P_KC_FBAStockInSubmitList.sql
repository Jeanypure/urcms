
CREATE proc [dbo].[P_KC_FBAStockInSubmitList]
    @CheckState varchar(20),
	@BeginDate varchar(20),
	@EndDate varchar(20),	
	@sellersku varchar(1000),
	@billno varchar(100),
	@suffix varchar(100)	 
as
begin 
  --开始查询   
   DECLARE @Sqlcdt varchar(max)         
        
   set @SqlCdt = 'select 0 as selflag, S.[NID],'+
    'case S.[CheckFlag] when 0 then ''未确认'' when 1 then ''已确认'' when 2 then ''已取消'' when 3 then ''已发货''  else ''已到货'' end as checkflag '+
    ',m.[BillNumber],m.[MakeDate],m.[ShipFromAddress],m.[LabelPrepPreference] ' +
    ',m.[SufFix],m.[Memo],m.[Audier],m.[AudieDate],m.[Recorder] ' +
    ' ,S.[StockInNID],S.[SellerSKU],S.[Shipmentid],S.[QuantityShipped],S.[QuantityReceived] ' +
    ',S.[QuantityInCase],d.[QuantityInCase] as QuantityInCasePlan,d.[Quantity],d.[Remark] into #temp ' +    
    ' From  KC_FBAStockInSubmit S    ' +    
    ' inner join KC_FBAStockInM M on S.StockInNid=M.nid  '  +
    ' inner join  KC_FBAStockInD D on D.StockInNid=M.nid and D.goodsskuid=S.goodsskuid    ' 
    
   
     set @SqlCdt =  @SqlCdt + 'where (M.MakeDate >= ''' + @BeginDate + ''')'   
 
     set @SqlCdt = @SqlCdt + ' and (M.MakeDate <= ''' + @EndDate + ''')'
	 
	 if (@CheckState = 0) or (@CheckState = 1) or (@CheckState = 2) or (@CheckState = 3) or (@CheckState = 4)  begin
	 set @SqlCdt = @SqlCdt + ' and S.checkflag =' + @CheckState
	 end
	 
	 
     
     
   if @suffix <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.suffix=''' + @suffix + ''' '
     end
     
  if @billno <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.billnumber like ''%' + @billno + '%'' '
     end
     
   if @sellersku <> '' begin
     set @SqlCdt = @SqlCdt + ' and m.nid in (select distinct stockinnid from KC_FBAStockInD cd where cd.sellersku  like ''%' + @sellersku + '%'') '
   end 
   
   
   set  @SqlCdt = @SqlCdt + '   order by m.nid select * from #temp drop table #temp '      
 
 print @sqlcdt
 exec (@SqlCdt) 
     
 
end
