CREATE PROCEDURE [dbo].[P_KC_FreeReservationNum]
                     @TradeNID INT
                     
AS
BEGIN
	
	
	
  DECLARE @ReturnFlag INT 
  DECLARE @Nid int =0, @GoodsSKUID INT , @SoreID INT , @ReservationNum INT, @RestoreStock INT 
  DECLARE  @ReturnStr VARCHAR(5000)
  SET  @ReturnFlag = 0
  SET  @RestoreStock = 0
  SET  @ReturnStr = ''
  /*cuifeng 20120616
  --如果开启了不判断库存，则不执行	
  DECLARE @AllowNegativeStock INT 
  SET @AllowNegativeStock =ISNULL((SELECT bsp.ParaValue 
                                   FROM B_SysParams bsp 
                                   WHERE bsp.ParaCode ='AllowNegativeStock'),0)
  IF (@AllowNegativeStock = 1)
  BEGIN
  	SELECT @ReturnFlag AS result , @ReturnStr AS Msg
  	RETURN;
  END
  */
  --没做过库存占用的，不进行扣除
  SET @RestoreStock = ISNULL((SELECT top 1  pt.RestoreStock
                              FROM P_Trade pt
                              WHERE pt.NID = @TradeNID),0) 
  IF (@RestoreStock <> -1)
  BEGIN
  	SELECT @ReturnFlag AS result , @ReturnStr AS Msg
  	RETURN;
  END
  
  DECLARE _TradeDt CURSOR
  FOR SELECT ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY
      FROM P_TradeDt ptd 
      WHERE ptd.TradeNID = @TradeNID
      GROUP BY ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID
  OPEN _TradeDt
  FETCH NEXT FROM _TradeDt INTO @Nid,@GoodsSKUID, @SoreID, @ReservationNum
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
  	UPDATE 
  		KC_CurrentStock
    SET  
		ReservationNum = ReservationNum - @ReservationNum
    WHERE 
		GoodsSKUID = @GoodsSKUID AND StoreID = @SoreID
	--去除占用记录	
	delete 
		KC_ReserveDetail
	where
		BillType=5 and BillNID=	@Nid and 
		GoodsSKUID=@GoodsSKUID and
		StoreID =@SoreID

			                         	
  	FETCH NEXT FROM _TradeDt INTO @Nid,@GoodsSKUID, @SoreID, @ReservationNum
  END
  CLOSE _TradeDt
  DEALLOCATE _TradeDt
	--占用标记
  UPDATE P_trade   SET RestoreStock = 0 WHERE NID = @TradeNID
  set @ReturnStr ='订单号['+cast(@TradeNID as varchar(20))+ ']取消占用成功'  
  SELECT @ReturnFlag AS result , @ReturnStr AS Msg
END 
