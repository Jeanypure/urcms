CREATE PROCEDURE [dbo].[P_KC_FreeReservationNumUn]
                     @TradeNID INT
                     
AS
BEGIN
	
  DECLARE @ReturnFlag INT 
  DECLARE @Nid int =0, @GoodsSKUID INT , @SoreID INT , @ReservationNum INT, @RestoreStock INT 
  DECLARE  @ReturnStr VARCHAR(5000)
  SET  @ReturnFlag = 0
  SET  @RestoreStock = 0
  SET  @ReturnStr = ''
  --没做过库存占用的，不进行扣除
  SET @RestoreStock = ISNULL((SELECT top 1  pt.RestoreStock
                              FROM P_Tradeun pt
                              WHERE pt.NID = @TradeNID),0) 
  IF (@RestoreStock <> -1)
  BEGIN
    set @ReturnStr= '订单号['+cast(@TradeNID as varchar(20))+']未占用,不用取消！'; 
  	SELECT @ReturnFlag AS result , @ReturnStr AS Msg
  	RETURN;
  END
  
  DECLARE _TradeDt CURSOR
  FOR SELECT ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY
      FROM P_TradeDtun ptd 
      WHERE ptd.TradeNID = @TradeNID
      GROUP BY ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID
  OPEN _TradeDt
  FETCH NEXT FROM _TradeDt INTO @Nid,@GoodsSKUID, @SoreID, @ReservationNum
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
  	UPDATE 
  		KC_CurrentStock
    SET  
		ReservationNum = ReservationNum - @ReservationNum
    WHERE 
		GoodsSKUID = @GoodsSKUID AND StoreID = @SoreID
	--去除占用记录	
	delete 
		KC_ReserveDetail
	where
		BillType=5 and BillNID=	@Nid and 
		GoodsSKUID=@GoodsSKUID and
		StoreID =@SoreID

			                         	
  	FETCH NEXT FROM _TradeDt INTO @Nid,@GoodsSKUID, @SoreID, @ReservationNum
  END
  CLOSE _TradeDt
  DEALLOCATE _TradeDt
	--占用标记
  UPDATE P_tradeUn   SET RestoreStock = 0 WHERE NID = @TradeNID
  set @ReturnStr ='订单号['+cast(@TradeNID as varchar(20))+ ']取消占用成功'
  SELECT @ReturnFlag AS result , @ReturnStr AS Msg
END 

