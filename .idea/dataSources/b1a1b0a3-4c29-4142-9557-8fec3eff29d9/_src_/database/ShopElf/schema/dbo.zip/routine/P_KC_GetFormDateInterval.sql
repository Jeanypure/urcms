CREATE PROCEDURE P_KC_GetFormDateInterval @KeyWord VARCHAR(100) = ''
AS
BEGIN
   DECLARE @Interval INT  = 0
   IF ISNULL(@KeyWord,'') <> ''
   BEGIN 	
	 SET @Interval = (SELECT TOP 1 ISNULL(bd.FitCode,0) FitCode
	                  FROM B_DictionaryCats bdc JOIN B_Dictionary bd ON bdc.NID = bd.CategoryID 
	                  WHERE bdc.CategoryName = '默认日期间隔' and bd.DictionaryName=@KeyWord)
   END  
   SELECT @Interval AS Interval
END
