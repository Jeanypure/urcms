
CREATE  PROCEDURE [dbo].[P_KC_GetGoodsMsgByStoreLocation] @LocationID int = 0
AS
BEGIN
  SELECT GoodsSKUID 
  INTO #Temp
  FROM B_GoodsSKULocation 
  WHERE LocationID = @LocationID
  
  SELECT T.GoodsSKUID, bg.GoodsName,bg.Material,bg.Model,bg.Class,bg.Unit,bg.Brand, bgs.SKU, bgs.property1, bgs.property2, bgs.property3 
  FROM #Temp t JOIN B_GoodsSKU bgs ON t.GoodsSKUID = bgs.NID
               JOIN B_Goods bg     ON bg.NID = bgs.GoodsID              
END

