
/*SKU改为模糊查询*/
CREATE PROCEDURE [dbo].[P_KC_GetStoreLocationMsg] @whereStr VARCHAR(8000) = '',
@sku varchar(8000)=''
AS
if @sku=''
BEGIN
  SELECT  g.nid,g.used,g.LocationName,g.LocationOrder,g.[Address],g.Memo, c.StoreName as StoreCateName  ,
                     CASE WHEN ISNULL(bgs.LocationID,0) > 0 THEN '在用' ELSE '空闲' END AS LocationStatus

  FROM B_StoreLocation g 
       LEFT JOIN  B_Store c on c.NID=g.StoreID  
       left join (select distinct  bgs.LocationID, bgs.StoreID from B_GoodsSKULocation bgs
           inner join B_GoodsSKU gs on bgs.GoodsSKUID = gs.NID 
           inner join B_GOODS g on g.NID = gs.GoodsID 
           group by bgs.LocationID, bgs.StoreID
           ) bgs on bgs.LocationID = g.NID  and G.StoreID = bgs.StoreID  
  WHERE (ISNULL(@whereStr,'') = '' )  OR ( (g.StoreCode like '%'+@whereStr+'%') or  (g.LocationName like '%'+@whereStr+'%') or  (c.StoreName like '%'+@whereStr+'%') )
  -- GROUP BY     g.nid,g.used,g.LocationName,g.LocationOrder,g.[Address],g.Memo, c.StoreName
END
else
begin
 SELECT  g.nid,g.used,g.LocationName,g.LocationOrder,g.[Address],g.Memo, c.StoreName as StoreCateName  ,
                     CASE WHEN ISNULL(max(bgs.NID),0) > 0 THEN '在用' ELSE '空闲' END AS LocationStatus

  FROM B_StoreLocation g  
     LEFT JOIN  B_Store c on c.NID=g.StoreID  
     LEFT JOIN B_GoodsSKULocation bgs ON g.NID = bgs.LocationID
     left join B_GoodsSKU bs on bs.NID=bgs.GoodsSKUID
  WHERE ((ISNULL(@whereStr,'') = '' )  OR ( (g.StoreCode like '%'+@whereStr+'%') or  (g.LocationName like '%'+@whereStr+'%') or  (c.StoreName like '%'+@whereStr+'%') ))
  --and bs.SKU=@sku
  --modified by ylq 2014-11-03  改成模糊查询
  and (bs.SKU like '%' + @sku + '%')
  GROUP BY     g.nid,g.used,g.LocationName,g.LocationOrder,g.[Address],g.Memo, c.StoreName
end
