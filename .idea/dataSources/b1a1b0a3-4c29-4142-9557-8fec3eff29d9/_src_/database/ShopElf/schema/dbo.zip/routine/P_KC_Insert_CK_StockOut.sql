

CREATE PROCEDURE [dbo].[P_KC_Insert_CK_StockOut]
                     @TradeNid INT = 0, 
                     @TradeDTNid INT = 0, 
                     @StoreID INT = 0 , 
                     @GoodsSKUID INT = 0 ,
                     @SaleCount INT = 0 ,
                     @Money  NUMERIC(18,4)= 0,
                     @Recorder VARCHAR(30) = ''                    
AS
BEGIN
	--TradeNid 主表ID，TrGoodsSKUID 保存 @GoodsSKUID ，一个SKU在ck中是一条记录
  if not  exists (select nid from CK_StockOutM where CheckFlag=1 and TradeNid=@TradeNid and TrGoodsSKUID=@GoodsSKUID) 
  begin
	  --增加出库记录
	  DECLARE 
		  @BillNumber VARCHAR(50),
		  @SKU VARCHAR(50) , 
		  @MakeDate VARCHAR(30), 
		  @GoodsID INT , 
		  @StockOutNID INT , 
		  @Price NUMERIC(18,4),
		 @ErrCount int
	  set @ErrCount =0 
	  BEGIN TRANSACTION TR_Insert_CK_StockOut
		  EXEC  P_S_CodeRuleGet 22317 , @BillNumber OUTPUT
	  set @ErrCount =@ErrCount +@@ERROR   
		  SET @MakeDate = CONVERT(VARCHAR(30), GETDATE(), 120) 

		  IF (IsNull(@BillNumber,'') = '')
		  SET  @BillNumber = @MakeDate
		  
		  SET @GoodsID = ISNULL((SELECT bgs.GoodsID FROM B_GoodsSKU bgs WHERE bgs.NID = @GoodsSKUID ),0)

		  INSERT INTO  CK_StockOutM (BillType,CheckFlag, BillNumber, MakeDate,SupplierID , SalerID,StoreID,memo,DeptMan,StockMan,Recorder,TradeNid,TrGoodsSKUID)
		  VALUES (3,0, @BillNumber, @MakeDate, 0, 0,@StoreID, '发货出库('+convert(VARCHAR(10), @TradeNid)+')', '', '',@Recorder,@TradeNid,@GoodsSKUID) 
		  set @ErrCount =@ErrCount +@@ERROR 		 
		  SET @StockOutNID = SCOPE_IDENTITY()-- @@identity
			--查找成本计价方法 0 库存平均价，1商品成本 价
			Declare
				@CalcCostFlag int 
			set
				@CalcCostFlag =ISNULL((select top 1 ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)
				
		DECLARE @DtSKU VARCHAR(100) = '', @OrigGoodsSKUID INT = 0
		
		--判断一下Dt表的SKU和 真正产品的是否一样
		
		SET @DtSKU = (SELECT TOP 1 SKU   FROM P_TradeDt WHERE GoodsSKUID = @GoodsSKUID AND TradeNID = @TradeNid)
		
		SET @OrigGoodsSKUID =  (SELECT TOP 1 NID FROM B_GoodsSKU WHERE SKU = ISNULL(@DtSKU,'')) 
		
		IF (ISNULL(@OrigGoodsSKUID,0) <> 0)
		BEGIN
		  IF (@OrigGoodsSKUID <> @GOODSSKUID)
		  BEGIN
		  	UPDATE P_TradeDt  	
		  	SET	GoodsSKUID = @OrigGoodsSKUID 	
		  	WHERE NID = @TradeDTNid AND TradeNID = @TradeNid
			set @ErrCount =@ErrCount +@@ERROR 		  			  	
		 -- 	DECLARE @temp VARCHAR(20) = '',@Logs VARCHAR(2000) = ''
		 -- 	SET @temp = CONVERT(VARCHAR(20),@TradeNid)
		 -- 	SET @Logs = '系统发现SKUID不一致由原自动调整:'+ CONVERT(VARCHAR(20),@GOODSSKUID)+'-->'+ CONVERT(VARCHAR(20),@OrigGoodsSKUID)
		 -- 	SET @GOODSSKUID = @OrigGoodsSKUID
		 --   EXEC S_WriteTradeLogs @temp,@Logs ,'system' 	
			--set @ErrCount =@ErrCount +@@ERROR 			    	   
		  END
		END
		
		IF @CALCCOSTFLAG=0 
		BEGIN					  
		 --取库存成本价
		  SET  @PRICE = (SELECT top 1 ISNULL(PRICE,0) FROM KC_CURRENTSTOCK KCS  WHERE STOREID = @STOREID AND GOODSSKUID = @GOODSSKUID)
		END
		  --如果库存成本价格为0，取商品信息中的成本价
		  IF (ISNULL(@Price,0) =0) or @CalcCostFlag=1
		  begin
		    SET  @Price = (SELECT TOP 1 case when IsNull(bgs.CostPrice,0)<>0 
									then IsNull(bgs.CostPrice,0) else IsNull(bg.CostPrice,0) end 
									FROM B_GoodsSKU bgs JOIN B_Goods bg ON bgs.GoodsID = bg.NID AND bgs.NID = @GoodsSKUID)
		  end

		  SET  @Money  = ISNULL(@PRICE,0) * @SaleCount
		  
		  --更新出库成本价 cuifeng
		  update 
			P_tradedt 
		  set 
			costprice=ISNULL(@PRICE,0)*l_qty
		  where
			tradenid=@TradeNid and goodsskuid=@goodsskuid
		set @ErrCount =@ErrCount +@@ERROR 			 
		  INSERT INTO CK_StockOutD(stockOutnid,GoodsID, goodsSKUID,Amount, price,Money)
		  VALUES(@StockOutNID, @GoodsID, @GoodsSKUID, @SaleCount, @Price, @Money)
		set @ErrCount =@ErrCount +@@ERROR 			  
		  EXEC P_KC_CurrentStock 'CK_StockOutM', @Recorder, 1, @StockOutNID 
		set @ErrCount =@ErrCount +@@ERROR 			  
		  --因其它出库没占用，要手工转过去
			Insert into KC_ReserveDetail_His(nid,BillType, 
					BillNID, GoodsSKUID, StoreID, Amount, 
					UseFlag, UseDate, CancelDate, MakeUser)
			select 
				nid, BillType, BillNID, GoodsSKUID, 
				StoreID, Amount, UseFlag, UseDate, 
				CancelDate, MakeUser
			from 
				KC_ReserveDetail 
			where 
				BillType=5 and BillNID=@TradeNid
		set @ErrCount =@ErrCount +@@ERROR 				
			delete
					KC_ReserveDetail
			where
				BillType=5 and BillNID=@TradeNid	
		set @ErrCount =@ErrCount +@@ERROR 					  
		  /* cuifeng 20120616
		 -- 取消库存占用， 减少库存
		  UPDATE KC_CurrentStock
		  SET  	
  			ReservationNum = ReservationNum - @SaleCount
		  WHERE StoreID = @StoreID AND GoodsID = @GoodsID AND GoodsSKUID = @GoodsSKUID
	  */
	  IF @ErrCount<>0
	  BEGIN
		ROLLBACK TRANSACTION TR_Insert_CK_StockOut
		--SELECT @SKU = SKU FROM B_GoodsSKU WHERE NID = @GoodsSKUID
		--INSERT INTO [P_TradeLogs]
		--	   ([TradeNID] ,[Operator] ,[Logs])
		--VALUES (@TradeNid,'SYSTEM', '订单商品"'+@SKU+'"库存扣除失败！')
	  END
	  ELSE 
		COMMIT TRANSACTION TR_Insert_CK_StockOut
  end	
  
  BEGIN TRANSACTION TR_Insert_CK_StockOut1
    UPDATE CG_OutofStock
    SET	  OutOfStockStatus = 4
    WHERE TradeNID = @TradeNid AND OutOfStockStatus < 4
  IF @@ERROR<>0
  BEGIN
	ROLLBACK TRANSACTION TR_Insert_CK_StockOut1
	--INSERT INTO [P_TradeLogs]
	--		   ([TradeNID] ,[Operator] ,[Logs])
	--VALUES (@TradeNid,'SYSTEM', '将订单"'+@TradeNid+'"的缺货信息变成完成【失败】！')
  END
  ELSE 
	COMMIT TRANSACTION	 TR_Insert_CK_StockOut1
END 
