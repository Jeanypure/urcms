
CREATE Proc [dbo].[P_KC_OutCheckReservationNum]
	@TableName	Varchar(30),
	@RecID		int
as
begin

	declare 
		@ErrorMsg varchar(8000)='',
		@UpdateError int=0,
		@AllowFuChuKu int=0
		
    set @AllowFuChuKu = (select top 1 ISNULL(ParaValue,0) from B_SysParams  where ParaCode = 'AllowNegativeStock')
   
	begin tran ReserveStock	
	
	if @AllowFuChuKu = 0 begin 
	  create table #OutCheckReservationNum
		(
			GoodsSKUID	int,
			sku	varchar(100),
			StoreID	int,
			Amount	numeric(10,4)
		)	
	
		--判断表，生成记录明细
		if LOWER(@TableName) ='cg_stockinm' --入库单退回
		begin
			--生成占用数量
			insert into #OutCheckReservationNum
			select
				D.GoodsSKUID,
				gs.sku,
				m.StoreID,
				sum(abs(d.Amount)) as amount
			from
				CG_StockInD d
			inner join
				CG_StockInM m on m.NID=d.StockInNID
			inner join 
				B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			where
				m.NID=@RecID  and m.CheckFlag <>3
			group by 
				D.GoodsSKUID,
				gs.sku,
				m.StoreID
		end

		if LOWER(@TableName) ='ck_stockoutm' --出库单
		begin
			--生成占用数量
			insert into #OutCheckReservationNum
			select
				D.GoodsSKUID,
				gs.sku,
				m.StoreID,
				sum(abs(d.Amount)) as amount
			from
				CK_StockOutD d
			inner join
				CK_StockOutM m on m.NID=d.StockOutNID
			inner join 
				B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			where
				m.NID=@RecID  and m.CheckFlag <>3
			group by 
				D.GoodsSKUID,
				gs.sku,
				m.StoreID
													 
		end	
		if LOWER(@TableName) ='kc_stockchangem' --调拔单出库
		begin
			--生成占用数量
			insert into #OutCheckReservationNum
			select
				D.GoodsSKUID,
				gs.sku,
				m.StoreOutID,
				sum(abs(d.Amount)) as amount
			from
				KC_StockChangeD d
			inner join
				KC_StockChangeM m on m.NID=d.StockChangeNID
			inner join 
				B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			where
				m.NID=@RecID  and m.CheckFlag <>3
			group by 
				D.GoodsSKUID,
				gs.sku,
				m.StoreOutID
				
		end		
		if LOWER(@TableName) ='kc_stockcheckm' --盘点出库
		begin
			--生成占用数量
			insert into #OutCheckReservationNum
			select
				D.GoodsSKUID,
				gs.sku,
				m.StoreID,
				sum(abs(d.Amount)) as amount
			from
				KC_StockCheckD d
			inner join
				KC_StockCheckM m on m.NID=d.StockCheckNID
			inner join 
				B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			where
				m.NID=@RecID and isnull(d.Amount,0)<0   and m.CheckFlag <>3 
			group by 
				D.GoodsSKUID,
				gs.sku,
				m.StoreID
		end		
		--判断出库数量多于库存数量的	
		SELECT 
			@ERRORMSG=@ERRORMSG+ OC.SKU +','
		FROM 
			#OUTCHECKRESERVATIONNUM OC
		INNER JOIN 
			KC_CURRENTSTOCK KC ON KC.GOODSSKUID=OC.GOODSSKUID AND KC.STOREID=OC.STOREID
		WHERE
			KC.NUMBER-OC.AMOUNT<0
			--modify by ylq 2016-08-13 排除掉负库存的仓库
			and OC.StoreID in (select Nid from B_Store where ISNULL(IsNegativeStock,0) = 0)
 
		IF ISNULL(@ERRORMSG, '')<>''
		BEGIN
			SET @ERRORMSG = CHAR(13)+CHAR(10)+ SUBSTRING(@ERRORMSG, 1, LEN(@ERRORMSG)-1) + '可用库存不足'
			SET @UPDATEERROR=1
		END
		
	  drop table #OutCheckReservationNum
	end
		
	
	if @UpdateError=0
	begin
	  commit tran ReserveStock
	end  
	else 
	begin 
	  rollback tran ReserveStock	
	end
	select @UpdateError as errorcount,@ERRORMSG as errormsg
end
