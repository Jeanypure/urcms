CREATE PROCEDURE [P_KC_ReCalcOutStockAmount] @BillNumber VARCHAR(100) = ''
AS
BEGIN
  IF ISNULL(@BillNumber,'') <> ''
  BEGIN 
	  UPDATE cmd
	  SET cmd.StockAmount = CASE WHEN  isnull(kcs.Number,0) - isnull(kcs.ReservationNum,0) + isnull(cmd.Amount,0) <0  THEN 0 
	                            ELSE   isnull(kcs.Number,0) - isnull(kcs.ReservationNum,0) + isnull(cmd.Amount,0)
	                        END
	  FROM CK_StockOutD cmd JOIN CK_StockOutM cmm ON cmd.StockOutNID =  cmm.NID 
		   LEFT JOIN KC_CurrentStock kcs ON cmd.GoodsSKUID = kcs.GoodsSKUID AND kcs.StoreID = cmm.StoreID
	  WHERE cmm.BillNumber = @BillNumber and cmm.CheckFlag<>3
  END 
END
