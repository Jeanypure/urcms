CREATE PROCEDURE [dbo].[P_KC_Reservation]
                     @TradeNID INT 
AS
BEGIN
  DECLARE @CurrCount INT , @AllowNegativeStock INT , @GoodsSKUID INT ,   @SoreID INT , @ReservationNum INT
 /*cuifeng 20120616
  SET  @AllowNegativeStock = 0
  SET  @AllowNegativeStock = (SELECT top 1 ISNULL(bsp.ParaValue,0) FROM B_SysParams bsp WHERE bsp.ParaCode = 'AllowNegativeStock')
  IF   (@AllowNegativeStock = 1)
  BEGIN 
  	SELECT 0 AS result 
  	RETURN;
  END  */
  
  DECLARE @RestoreStock INT ,
	@NID int=0
  SET @RestoreStock = 0
  SET @RestoreStock = ISNULL((SELECT RestoreStock FROM P_trade WHERE NID = @TradeNID),0)
  
  IF   (@RestoreStock = -1) --占用
  BEGIN 
  	SELECT 0 AS result 
  	RETURN;
  END  
-- cuifeng 20120616
  DECLARE _TradeDt CURSOR
  FOR SELECT ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY
	  FROM P_TradeDt ptd 
	  WHERE ptd.TradeNID = @TradeNID
	  GROUP BY ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID
  OPEN _TradeDt
  FETCH NEXT FROM _TradeDt INTO @NID,@GoodsSKUID, @SoreID, @ReservationNum
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
  	UPDATE 
  		KC_CurrentStock
    SET  
		ReservationNum = ReservationNum + @ReservationNum
    WHERE 
		GoodsSKUID = @GoodsSKUID AND StoreID = @SoreID
	--形成占用记录	
		--形成新的占用记录
		if @GoodsSKUID<>0 and 	@SoreID <>0 and @ReservationNum<> 0 
		begin
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select 
				5	,
				@NID,
				@GoodsSKUID	,
				@SoreID,
				@ReservationNum,
				0,
				'system'	
		end			
    FETCH NEXT FROM 
		_TradeDt 
	INTO @NID,@GoodsSKUID, @SoreID, @ReservationNum
  END 
  CLOSE _TradeDt
  DEALLOCATE _TradeDt  

  --占用标记
  UPDATE P_trade   SET RestoreStock = -1 WHERE NID = @TradeNID
  --cuifeng 更新缺货的派单时间

  update CG_OutofStock 
  set 
		DespatchTime = GETDATE(),
		GoodsSendTime= (case when ServiceMethod='有货先寄' then GETDATE() else null end ) 
  where 
	TradeDtNID in (select NID from P_TradeDt where TradeNID=@TradeNID 
					union 
					select NID from P_TradeDtUn where TradeNID=@TradeNID )		
  
END
