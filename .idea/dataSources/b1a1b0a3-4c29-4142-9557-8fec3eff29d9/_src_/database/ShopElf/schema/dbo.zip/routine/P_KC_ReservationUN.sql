CREATE PROCEDURE [P_KC_ReservationUN]
                     @TradeNID INT 
AS
BEGIN
  DECLARE 
	  @ErrCount INT , 
	  @AllowNegativeStock INT , 
	  @GoodsSKUID INT ,   
	  @SoreID INT ,
	  @ReservationNum INT,
	  @RMsg varchar(2000)
  
  DECLARE @RestoreStock INT ,
	@NID int=0
  SET @RestoreStock = 0
  SET @RestoreStock = ISNULL((SELECT RestoreStock FROM P_tradeUn WHERE NID = @TradeNID),0)
  
  IF   (@RestoreStock = -1) --占用
  BEGIN 
  	select RMsg= '订单号['+cast(@TradeNID as varchar(20))+']已经占用过！'; 
  	RETURN;
  END  
  IF   (@GoodsSKUID = 0) --0
  BEGIN 
  	select RMsg= '订单号['+cast(@TradeNID as varchar(20))+']SKUId为0，不能占用！'; 
  	RETURN;
  END    
  --检测有没有仓库Id为0的
  set @RMsg='';
	select
		@RMsg=@RMsg+ '订单号['+cast(d.TradeNID as varchar(20))+',SKU:'+ d.sku +']没有指定仓库，不能占用;'+char(13)
	from P_TradeDtUn d
	where isnull(d.StoreID,0) =0  and d.TradeNID=@TradeNID

	if isNull(@RMsg, '')<>''
	BEGIN
		select RMsg= @RMsg;
		RETURN
	END
-- cuifeng 20120616
	set @ErrCount=0;
	begin tran ReservationUN
  DECLARE _TradeDt CURSOR
  FOR SELECT ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID, SUM(L_QTY) AS L_QTY
	  FROM P_TradeDtUn ptd 
	  WHERE ptd.TradeNID = @TradeNID
	  GROUP BY ptd.TradeNID,ptd.GoodsSKUID, ptd.StoreID
  OPEN _TradeDt
  FETCH NEXT FROM _TradeDt INTO @NID,@GoodsSKUID, @SoreID, @ReservationNum
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
	IF NOT EXISTS (SELECT GoodsSKUID
  					   FROM KC_CurrentStock kcs 
  					   WHERE kcs.StoreID=@SoreID AND kcs.GoodsSKUID = @GoodsSKUID)
  	BEGIN 		
  		  --生成一条记录
  		  insert into KC_CurrentStock(StoreID,GoodsID, GoodsSKUID,Number,Price,[Money])
  		  select @SoreID,isnull(g.nid,0), @goodsSKUID,0,0 ,
  				0
  		  from B_GoodsSKU gs 
  		  inner join B_goods g on g.NID=gs.GoodsID
  		  where gs.NID=@GoodsSKUID
  	END  
  	
  	UPDATE 
  		KC_CurrentStock
    SET  
		ReservationNum = ReservationNum + @ReservationNum
    WHERE 
		GoodsSKUID = @GoodsSKUID AND StoreID = @SoreID
	set @ErrCount = @ErrCount +@@ERROR
	--形成占用记录	
		--形成新的占用记录
		if @GoodsSKUID<>0 and 	@SoreID <>0 and @ReservationNum<> 0 
		begin
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select 
				5	,
				@NID,
				@GoodsSKUID	,
				@SoreID,
				@ReservationNum,
				0,
				'system'	
			set @ErrCount = @ErrCount +@@ERROR	
		end			
    FETCH NEXT FROM 
		_TradeDt 
	INTO @NID,@GoodsSKUID, @SoreID, @ReservationNum
  END 
  CLOSE _TradeDt
  DEALLOCATE _TradeDt  
  
	if @ErrCount =0
	begin
		commit tran ReservationUN
		--占用标记
		UPDATE P_tradeUn   SET RestoreStock = -1 WHERE NID = @TradeNID
		set @RMsg ='订单号['+cast(@TradeNID as varchar(20))+ ']缺货占用成功'
	end
	else
	begin
		rollback Tran ReservationUN
		set @RMsg = '订单号['+cast(@TradeNID as varchar(20)) +']缺货占用失败'
	end
	select  @RMsg as Rmsg 
END

