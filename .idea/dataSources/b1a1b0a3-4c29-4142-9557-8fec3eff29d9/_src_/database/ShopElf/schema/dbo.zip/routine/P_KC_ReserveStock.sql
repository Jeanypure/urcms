--占用库存
CREATE Proc [dbo].[P_KC_ReserveStock]
	@TableName	Varchar(30),
	@UserName	Varchar(30),
	@RecID		int
as
begin

	declare @UpdateError int
	set	@UpdateError = 0
		
	begin tran ReserveStock	
	--判断表，生成记录明细
	if LOWER(@TableName) ='cg_stockinm' --入库单退回
	begin
		--扣除原库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum-r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=1 and BillNID=@RecID 
			--and k.ReservationNum-r.amount>=0
		--删除原占用记录		
		delete
			KC_ReserveDetail
		where
			Billtype=1 and
			BillNID = @RecID	
		--形成新的占用记录	
		insert into 
			KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
		select
			1	,
			m.NID,
			D.GoodsSKUID	,
			m.StoreID,
			abs(d.Amount),
			0,
			@UserName	
		from
			CG_StockInD d
		inner join
			CG_StockInM m on m.NID=d.StockInNID
		where
			m.NID=@RecID  and m.CheckFlag <>3
		--更新库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum+r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=1 and BillNID=@RecID
	end

	if LOWER(@TableName) ='ck_stockoutm' --出库单
	begin
		--扣除原库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum-r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=2 and BillNID=@RecID 
			--and k.ReservationNum-r.amount>=0	
		delete
			KC_ReserveDetail
		where
			Billtype=2 and
			BillNID = @RecID	
			
		insert into 
			KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
		select
			2	,
			m.NID,
			D.GoodsSKUID	,
			m.StoreID,
			abs(d.Amount),
			0,
			@UserName	
		from
		
			CK_StockOutD d
		inner join
			CK_StockOutM m on m.NID=d.StockOutNID
		where
			m.NID=@RecID and m.CheckFlag <>3
		--更新库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum+r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=2 and BillNID=@RecID
												 
	end	
	if LOWER(@TableName) ='kc_stockchangem' --调拔单出库
	begin
		--扣除原库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum-r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=3 and BillNID=@RecID 
			--and k.ReservationNum-r.amount>=0	
		delete
			KC_ReserveDetail
		where
			Billtype=3 and
			BillNID = @RecID	
			
		insert into 
			KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
		select
			3	,
			m.NID,
			D.GoodsSKUID	,
			m.StoreOutID ,
			abs(d.Amount),
			0,
			@UserName	
		from
			KC_StockChangeD d
		inner join
			KC_StockChangeM m on m.NID=d.StockChangeNID
		where
			m.NID=@RecID  and m.CheckFlag <>3					 
		--更新库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum+r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=3 and BillNID=@RecID									 
	end		
	if LOWER(@TableName) ='kc_stockcheckm' --盘点出库
	begin
		--扣除原库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum-r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=4 and BillNID=@RecID 
			--and k.ReservationNum-r.amount>=0	
		delete
			KC_ReserveDetail
		where
			Billtype=4 and
			BillNID = @RecID	
		--增加重新计算账存数量功能
  /*		begin try
			update 
				KC_StockCheckD
			set
				ZhAmount=case when dbo.Ex_KC_CalcSKUBalCount(m.StoreID,d.GoodsSKUID)<>-999999 then 
							 dbo.Ex_KC_CalcSKUBalCount(m.StoreID,d.GoodsSKUID) else ZhAmount end,
				PDMoney=PDAmount*(case when d.Price=0 and isnull(k.Price,0)<>0 then  k.Price 
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice<>0  then gs.CostPrice
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice=0  then g.CostPrice
				else d.Price end),
				--金额为0时，取库存成本价
				Price = case when d.Price=0 and isnull(k.Price,0)<>0 then  k.Price 
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice<>0  then gs.CostPrice
				 when d.Price=0 and isnull(k.Price,0)=0 and gs.CostPrice=0  then g.CostPrice
				else d.Price end,
				ZHMoney=case when dbo.Ex_KC_CalcSKUBalMoney(m.StoreID,d.GoodsSKUID)<>-999999 then 
							 dbo.Ex_KC_CalcSKUBalMoney(m.StoreID,d.GoodsSKUID) else ZhAmount end							 	
											 
			from 
				KC_StockCheckD d 
			inner join 
				KC_StockCheckM m on m.NID=d.StockCheckNID 
			left outer join 
				KC_CurrentStock k on k.GoodsSKUID=d.GoodsSKUID and m.StoreID=k.StoreID
			inner join 
				B_GoodsSKU gs on gs.NID=d.GoodsSKUID 
		    inner join 
				B_Goods g on g.NID=gs.GoodsID					
			where
				m.NID=	@RecID and m.CheckFlag <> 3
				
			update 
				KC_StockCheckD
			set
				Amount= PDAmount-ZhAmount,
				[Money]	=PDMoney-ZhMoney 
			from 
				KC_StockCheckD d 
			inner join 
				KC_StockCheckM m on m.NID=d.StockCheckNID 
			where
				m.NID=	@RecID and m.CheckFlag <> 3	
		END TRY
		BEGIN CATCH
		END CATCH				
	*/
		insert into 
			KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
		select
			4	,
			m.NID,
			D.GoodsSKUID	,
			m.StoreID,
			abs(d.Amount),
			0,
			@UserName	
		from
			KC_StockCheckD d
		inner join
			KC_StockCheckM m on m.NID=d.StockCheckNID
		where
			m.NID=@RecID and isnull(d.Amount,0)<0 and m.CheckFlag <>3
		--更新库存占用数量
		update 
			k
		set 
			k.ReservationNum = k.ReservationNum+r.amount
		from 
			KC_CurrentStock k 
		inner join 
			KC_ReserveDetail r on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
		where 
			r.Billtype=4 and BillNID=@RecID								 
	end		
		
	select @UpdateError=@@ERROR
	if @UpdateError=0
	begin
	  commit tran ReserveStock
	end  
	else 
	begin 
	  rollback tran ReserveStock	
	end
	select @UpdateError as errorcount
end
