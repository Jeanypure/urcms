CREATE PROCEDURE [dbo].[P_KC_RestoreStockReservation]
                     @TradeID VARCHAR(10) = ''                     
AS
BEGIN 
 -- 取消库存占用， 减少库存
  DECLARE @GoodsSKUID INT , @SoreID INT , @QTY INT
  DECLARE _PTradeDt CURSOR
  FOR 
     SELECT ptd.L_QTY, ptd.GoodsSKUID, ptd.StoreID 
     FROM P_TradeDtUn ptd
     WHERE ptd.TradeNID = @TradeID
  OPEN _PTradeDt
  FETCH NEXT FROM _PTradeDt INTO @QTY, @GoodsSKUID, @SoreID
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
  	 UPDATE KC_CurrentStock 
     SET  	
  	   ReservationNum = ReservationNum - @QTY
    WHERE  StoreID = @SoreID AND GoodsSKUID = @GoodsSKUID
  	FETCH NEXT FROM _PTradeDt INTO @QTY, @GoodsSKUID, @SoreID
  END 
  CLOSE _PTradeDt
  DEALLOCATE _PTradeDt   
 END 
