CREATE PROCEDURE [dbo].[P_KC_SaleUnInventory]
                     @StartDate VARCHAR(20) ,
                     @EndDate   VARCHAR(20)
AS
BEGIN
	--1.指定时间段内销售的产品SKU和名称
	SELECT * 
	INTO #SaleGoodsSKU
	FROM (
	SELECT ptd.SKU,MAX(DATEADD(hour,8,m.ORDERTIME)) as OrderTime, '' as GoodsName -- ptd.GoodsName
	FROM P_TradeDt ptd 
	inner join P_Trade m on m.NID=ptd.TradeNID
	where DATEADD(hour,8,m.ORDERTIME) >= @StartDate 
	GROUP BY ptd.SKU, ptd.GoodsName 
	UNION 
	SELECT ptd.SKU,MAX(DATEADD(hour,8,m.ORDERTIME)) as OrderTime, '' as GoodsName
	FROM P_TradeDtun ptd 
	inner join P_Tradeun m on m.NID=ptd.TradeNID
	where DATEADD(hour,8,m.ORDERTIME) >= @StartDate 
	GROUP BY ptd.SKU, ptd.GoodsName
	 ) cc
	--2.已经做过盘点单的SKU					
	SELECT bgs.SKU
	INTO #InventoryGoodsSKU 
	FROM B_GoodsSKU bgs
	WHERE bgs.NID IN (SELECT DISTINCT  kscd.GoodsSKUID 
                      FROM KC_StockCheckD kscd)
    --3.销售未盘点的SKU和名称
    SELECT SKU,OrderTime, GoodsName
    INTO #SaleUnInventory  
    FROM #SaleGoodsSKU 
    WHERE SKU NOT IN (SELECT SKU FROM #InventoryGoodsSKU )
	--4.返回查询结果						
    SELECT sui.SKU,b.GoodsCode,b.goodsname, b.model, b.class,sui.ordertime, 
			gs.property1, gs.property2, gs.property3, 0 AS sNumber, 0 AS InventoryNum,
			CAST('' as varchar(20)) as LocationName 
    FROM #SaleUnInventory sui LEFT JOIN  B_GoodsSKU gs ON sui.SKU = gs.SKU				
		                      LEFT JOIN  B_Goods b     ON b.NID = gs.GoodsID
	order by sui.OrderTime	                      
    --5.删除临时表
    DROP TABLE #SaleGoodsSKU
    DROP TABLE #InventoryGoodsSKU
    DROP TABLE #SaleUnInventory		                      	
END 
