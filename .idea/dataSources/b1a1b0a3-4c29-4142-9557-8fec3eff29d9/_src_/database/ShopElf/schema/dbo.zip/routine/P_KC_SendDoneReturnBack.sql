
CREATE PROCEDURE [dbo].[P_KC_SendDoneReturnBack]
                     @TradeID VARCHAR(10) = ''  
                     ,@Recorder VARCHAR(30) = ''
                     ,@WillToFilterFlag int =999                   
AS
BEGIN 
/*
--如果开启了不判断库存，则不执行	
  DECLARE @AllowNegativeStock INT 
  SET @AllowNegativeStock =ISNULL((SELECT bsp.ParaValue 
                                   FROM B_SysParams bsp 
                                   WHERE bsp.ParaCode ='AllowNegativeStock'),0)
  IF (@AllowNegativeStock = 1)
  BEGIN
  	RETURN;
  END
  	*/
 -- 进行苦存占用， 还原库存数量
  DECLARE 
	@NID	int=0,
	@GoodsSKUID INT , 	
	@StoreID INT , 
	@QTY INT , 
	@InStockType INT 
  DECLARE @BillNumber VARCHAR(50),@SKU VARCHAR(50) , 
	  @MakeDate VARCHAR(30), 
	  @GoodsID INT , 
	  @StockoutNID INT , 
	  @Price NUMERIC(18,4),
	  @Money  NUMERIC(18,4)
  
  --cf SET @InStockType = ISNULL((SELECT TOP 1 NID FROM B_Dictionary WHERE DictionaryName = '驳回入库' AND FitCode = 'ReturnBack' ),0)
  
  declare @error	int;
  DECLARE _PSendBackTradeDt CURSOR  
  FOR 
  --   SELECT ptd.nid,ptd.tradenid,ptd.GoodsSKUID, ptd.StoreID ,sum(ptd.L_QTY) as l_qty 
  --   FROM P_TradeDt ptd
  --   WHERE ptd.TradeNID = @TradeID
  --   group by 
		--ptd.tradenid,ptd.GoodsSKUID, ptd.StoreID 
	--cf 	
     SELECT 
		isnull(ptd.tradenid,0) as tradenid,
		isnull(ptd.GoodsSKUID,0) as GoodsSKUID, 
		isnull(ptd.StoreID,0) as StoreID ,
		sum(ptd.L_QTY) as l_qty 
     FROM P_TradeDt ptd
     WHERE ptd.TradeNID = @TradeID	
     group by 
		isnull(ptd.tradenid,0),
		isnull(ptd.GoodsSKUID,0),
		isnull(ptd.StoreID,0)
  --   union 
  --   SELECT 
		--isnull(ptd.tradenid,0) as tradenid,
		--isnull(ptd.GoodsSKUID,0) as GoodsSKUID, 
		--isnull(ptd.StoreID,0) as StoreID ,
		--sum(ptd.L_QTY) as l_qty 
  --   FROM P_TradeDt_His ptd
  --   WHERE ptd.TradeNID = @TradeID	
  --   group by 
		--isnull(ptd.tradenid,0),
		--isnull(ptd.GoodsSKUID,0),
		--isnull(ptd.StoreID,0)
  OPEN _PSendBackTradeDt
  FETCH NEXT FROM _PSendBackTradeDt INTO @nid,@GoodsSKUID, @StoreID,@QTY
  WHILE (@@FETCH_STATUS = 0)
  BEGIN  	
	--还原库存的逻辑: 订单存在出库记录的,才需要进行库存还原操作  		
	--需要对 CK_StockOutM.TradeNid 建议索引,加快查询和更新的速度		
	--保留使用TradeNid,增加BillType,增加goodsskuid查询
	SET @StockoutNID = ISNULL((SELECT Max(nid) FROM CK_StockOutM  
				WHERE CheckFlag=1 and  BillType=3 and isnull(TradeNid,0) = @TradeID and isnull(TrGoodsskuID,0) = @GoodsSKUID),0) 
	if @StockoutNID <> 0 and @StockoutNID is not null
	begin		  		  
		BEGIN TRANSACTION
		set @error = 0;
		 --还原占用数
		 UPDATE KC_CurrentStock 
		 SET  	
		
		   ReservationNum = IsNull(ReservationNum,0) + (case when @WillToFilterFlag>5 and @WillToFilterFlag<100  then  IsNull(@QTY,0) else 0 end )   ,
  		   Number = ISNULL(number,0) + IsNull(@QTY,0) ,
  		   [Money]= [money]+isnull((select sum(d.Money) from CK_StockOutD d 
  							inner join CK_StockOutM m on m.NID=d.StockOutNID
  							where CheckFlag=1 and d.GoodsSKUID=KC_CurrentStock.GoodsSKUID and m.StoreID=KC_CurrentStock.StoreID
  									and isnull(m.TradeNid,0) = @TradeID and d.GoodsSKUID=@GoodsSKUID),0)
		 WHERE  StoreID = @StoreID AND GoodsSKUID = @GoodsSKUID
		 --更新单价
  		 UPDATE KC_CurrentStock 
		 SET  	
  		   Price=case when Number <>0 then [money]/Number else 0 end
		 WHERE  StoreID = @StoreID AND GoodsSKUID = @GoodsSKUID
		 set @error += @@ERROR;
		
		--增加占用库存
		Insert into KC_ReserveDetail(BillType, 
				BillNID, GoodsSKUID, StoreID, Amount, 
				UseFlag,  MakeUser)
		select 
			 5, @nid,@GoodsSKUID, @StoreID,@QTY, 0,'system'
		set @error += @@ERROR;
		
		delete
				KC_ReserveDetail_His
		where
			BillType=5 and 
			BillNID=@nid 	and
			GoodsSKUID=@GoodsSKUID and
			StoreID =@StoreID
		set @error += @@ERROR;
		
		--作废单据,去除流水帐,增加BillType条件
		update CK_StockOutM set CheckFlag=3,Memo=isnull(Memo,'') + '--'+@Recorder+'于驳回订单' where NID = @StockoutNID and  BillType=3	
		set @error += @@ERROR;
		
		IF @@ERROR<>0
		BEGIN
		  ROLLBACK TRANSACTION
		  SELECT @SKU = SKU FROM B_GoodsSKU WHERE NID = @GoodsSKUID
		  INSERT INTO [P_TradeLogs]  ([TradeNID] ,[Operator] ,[Logs])
		  VALUES (@TradeID,'SYSTEM', '订单商品"'+@SKU+'"订单驳回时库存数、占用数还原失败！')
		END
		ELSE 
		  COMMIT TRANSACTION
	end
			
		 --还原库存数量
		 /*cuifeng 修改
         EXEC  P_S_CodeRuleGet 22332 , @BillNumber OUTPUT
           
		  SET @MakeDate = CONVERT(VARCHAR(30), GETDATE(), 120) 

		  IF (IsNull(@BillNumber,'') = '')
		  SET  @BillNumber = @MakeDate
		  
		  SET @GoodsID = ISNULL((SELECT bgs.GoodsID FROM B_GoodsSKU bgs WHERE bgs.NID = @GoodsSKUID ),0)


		  INSERT INTO  CG_StockInM (BillType,CheckFlag,InvoiceFlag, BillNumber, MakeDate,SupplierID , SalerID,StoreID,memo,DeptMan,StockMan,Recorder,StockOrder)
		  VALUES (3,0,0, @BillNumber, @MakeDate, @InStockType, 0,@StoreID, '驳回入库('+@TradeID+')', '', '',@Recorder,@TradeID) 
		 
		  SET @StockInNID = SCOPE_IDENTITY()-- @@identity
		 --取库存成本价
		  SET  @Price = (SELECT IsNull(Price,0) 
		                 FROM KC_CurrentStock kcs  
		                 WHERE StoreID = @StoreID AND GoodsID = @GoodsID AND GoodsSKUID = @GoodsSKUID)
		                 
		  SET  @Money  = @Price * @QTY
		 
		  INSERT INTO CG_StockInD(StockInNID,GoodsID, goodsSKUID,Amount, price,MONEY,TaxPrice,AllMoney)
		  VALUES(@StockInNID, @GoodsID, @GoodsSKUID, @QTY, @Price, @Money,@Price,@Money )
		  */
		  /*2013-11-19 陈卫注释掉
		  --cf 取原出库单号
		  SET @StockoutNID = ISNULL((SELECT Max(nid) FROM CK_StockOutM  WHERE CheckFlag=1 and ((isnull(TradeNid,0) = @TradeDTID) OR (Memo LIKE '%('+@TradeID+')')) ),0)
		  --作废单据
		  update CK_StockOutM set CheckFlag=3,Memo=Memo + '--'+@Recorder+'于驳回订单' where NID = @StockoutNID
          */	
  	FETCH NEXT FROM _PSendBackTradeDt INTO @NID, @GoodsSKUID, @StoreID,@QTY
  END  
  CLOSE _PSendBackTradeDt
  DEALLOCATE _PSendBackTradeDt
END
