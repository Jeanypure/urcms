
CREATE Procedure [dbo].[P_KC_StockDetail]
  @StartDate DateTime,
  @EndDate DateTime,
 -- @GoodsID int,
  @GoodsSKUID int,  
  @StoreID int ,
  @ICheck varchar(2)  /*审核*/
As
begin
	--更新goodsID
 /*   if @GoodsSKUID=0
    begin
		update 
			cd 
		set
			cd.GoodsID=isnull(gs.GoodsID,0)
		from 
			CG_StockInD cd
		inner join 
			B_GoodsSKU gs on gs.NID=cd.GoodsSKUID
		where 
			gs.GoodsID=@GoodsID	
		update 
			cd 
		set
			cd.GoodsID=isnull(gs.GoodsID,0)
		from 
			CK_StockOutD cd
		inner join 
			B_GoodsSKU gs on gs.NID=cd.GoodsSKUID
		where 
			gs.GoodsID=@GoodsID				
	end
	else
	begin
		update 
			cd 
		set
			cd.GoodsID=isnull(gs.GoodsID,0)
		from 
			CK_StockOutD cd
		inner join 
			B_GoodsSKU gs on gs.NID=cd.GoodsSKUID
		where 
			cd.GoodsSKUID=@GoodsSKUID	
		update 
			cd 
		set
			cd.GoodsID=isnull(gs.GoodsID,0)
		from 
			CG_StockInD cd
		inner join 
			B_GoodsSKU gs on gs.NID=cd.GoodsSKUID
		where 
			cd.GoodsSKUID=@GoodsSKUID			
	end	
	*/
		/*生成商品表结构*/		
		Create Table  #StockDetail
		(
			INo	int	,
			DAudieDate	datetime	,
			SBillNumber	varchar(40)	,
			SMeory	varchar(300)	,			
			GoodsID	int	,
			NIAmount	money Default 0	,
			NIOAmount	money Default 0	,
			NIPrice	money Default 0	,
			NIMoney	money Default 0	,
			NOAmount	money Default 0	,
			NOOAmount	money Default 0	,
			NCostPrice	money Default 0	,
			NCostMoney	money Default 0	,
			BAmount	money Default 0	,
			BPrice	money Default 0	,
			BMoney	money Default 0	,
			InOut	int		
		)	
		/*生成商品表结构*/		
		Create Table  #StockDetail1
		(
			[NID] [int] IDENTITY(1,1) NOT NULL,		
			INo	int	,
			DMakeDate	datetime	,
			SBillNumber	varchar(40)	,
			SMeory	varchar(300)	,			
			GoodsID	int	,
			NIAmount	money Default 0	,
			NIOAmount	money Default 0	,
			NIPrice	money Default 0	,
			NIMoney	money Default 0	,
			NOAmount	money Default 0	,
			NOOAmount	money Default 0	,
			NCostPrice	money Default 0	,
			NCostMoney	money Default 0	,
			BAmount	money Default 0	,
			BPrice	money Default 0	,
			BMoney	money Default 0	,
			InOut	int		
		)	
	--解决排序乱问题
    CREATE CLUSTERED INDEX #StockDetail1_nid ON #StockDetail1
	(
	NID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
						
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int/*ID*/
		)				

		Declare @BalanceDate varchar(7)
		Declare @NowStartDate SmallDateTime
		Declare @BalanceAmount Money,@BalanceMoney Money
		Set @BalanceDate= Convert(varchar(7),@StartDate,20)
		Set @NowStartDate= @BalanceDate+'-01'
		
		/*取前期数(1,取累计数表,2,取当月表)*/
		Declare @jAmount Float,@jMoney Money,@JPrice Money
		/*生成仓库查询*/
		insert into #store 
		select  nid from B_store 
		where	(@StoreID=0 or NID=@StoreID) 
		
		Set @BalanceAmount=0
		Set @BalanceMoney=0						
/*生成前期数--start*/
	/*--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount + ISNULL(sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end),0) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)
	/*--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(-IsNull(D.Amount,0)),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(-IsNull(D.Money,0)),0) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)		
	/*调拔的--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(IsNull(D.inMoney,0)),0) 			
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)
	/*调拔的--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(-IsNull(D.Amount,0)),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(-IsNull(D.Money,0)) ,0)
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)
	/*盘点--rk*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(IsNull(D.Money,0)),0) 			
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and	
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and 
			--(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)
	/*盘点的--ck*/
		Select 
			@BalanceAmount	= @BalanceAmount +	ISNULL(sum(IsNull(D.Amount,0)),0),
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(IsNull(D.Money,0)),0) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 
			--d.GoodsID=@GoodsID and	
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and 
			--(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)            
		/*生成前期记录*/
		if @BalanceAmount <> 0 Set @JPrice=@BalanceMoney/@BalanceAmount Else Set @JPrice=0		
        --if (@BalanceAmount <> 0) or  (@BalanceMoney<>0)为空时也插入
		Insert #StockDetail(INo,SBillNumber,SMeory,BAmount,BPrice,BMoney) 
		Values(0,'','上期余额',Isnull(@BalanceAmount,0),@JPrice,Isnull(@BalanceMoney,0))			
/*生成前期数--end*/					

/*生成本期数--start*/
	/*--rk*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NIAmount,NIOAmount,NIPrice,NIMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NIAmount= case when M.BillType =2 then -IsNull(D.Amount,0) when M.BillType =1 then IsNull(D.Amount,0) else 0  end,
			NIOAmount= case when M.BillType in (3,4) then IsNull(D.Amount,0) else 0  end,	
			NIPrice= IsNull(D.Price,0),
			NIMoney= case when M.BillType =2 then -IsNull(D.Money,0)  else IsNull(D.Money,0)  end,
			inout = 1 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and	(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
				
	/*--ck*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NOAmount,NOOAmount,NCostPrice,NCostMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NOAmount= case when M.BillType <>3 then IsNull(D.Amount,0) else 0 end,
			NOOAmount= case when M.BillType =3 then IsNull(D.Amount,0) else 0  end,	
			NCostPrice= IsNull(D.Price,0),
			NCostMoney= IsNull(D.Money,0),
			inout = 2 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)			
	/*调拔的--rk*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NIOAmount,NIPrice,NIMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NIOAmount= IsNull(D.Amount,0),	
			NIPrice= IsNull(D.inPrice,0),
			NIMoney= IsNull(D.inMoney,0),
			inout = 1 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and (@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)	
	/*调拔的--ck*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NOOAmount,NCostPrice,NCostMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NOOAmount= IsNull(D.Amount,0),	
			NCostPrice= IsNull(D.Price,0),
			NCostMoney= IsNull(D.Money,0),
			inout = 2 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM   M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and	(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)						
	/*盘点的--rk*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NIOAmount,NIPrice,NIMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NIOAmount= IsNull(D.Amount,0),	
			NIPrice= IsNull(D.Price,0),
			NIMoney= IsNull(D.Money,0),
			inout = 1 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and	
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and 
			--(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)	
	
	/*盘点的--ck*/
		insert into 
			#StockDetail(INo,DAudieDate,SBillNumber,GoodsID,SMeory,NOOAmount,NCostPrice,NCostMoney,InOut)
		Select 
			d.nid,m.AudieDate,m.billnumber,d.goodsid,m.memo,
			NOOAmount= IsNull(-D.Amount,0),	
			NCostPrice= IsNull(D.Price,0),
			NCostMoney= IsNull(-D.Money,0),
			inout = 2 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM   M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		Where 
			M.CheckFlag =1 and 		
			--d.GoodsID=@GoodsID and	
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and 
			--(@GoodsSKUID=0 or 
			D.GoodsSKUID=@GoodsSKUID and				
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)	
				
/*生成本期数--end*/	
		delete 
			#StockDetail 
		where
			IsNull(NIAmount,0) = 0 and IsNull(NOAmount,0) = 0 and 
			IsNull(NIOAmount,0) = 0 and IsNull(NOOAmount,0) = 0  and INo <>0
                        and IsNull(NIMoney,0) = 0  and ISNULL(NCostMoney,0) = 0 
		
		Update 
			#StockDetail 
		Set 
			BAmount = IsNull(NIAmount,0) +IsNull(NIOAmount,0) - IsNull(NOAmount,0)-IsNull(NOOAmount,0) ,
			BMoney  = IsNull(NIMoney,0) - IsNull(NCostMoney,0) 
		Where 
			INo <>0
		/*更新余额*/
		insert into  #StockDetail1(INo,dmakedate,SBillNumber,SMeory,GoodsID,NIAmount,NIOAmount,NIPrice,NIMoney,NOAmount,NOOAmount,NCostPrice,NCostMoney,BAmount,BPrice,BMoney,InOut)
		select *  from #StockDetail order by DAudieDate,InOut 	
		Declare 
			@BAmount Float,@BMoney Money,@AmountSum Float,@MoneySum Money,@BPrice Money ,@Ino int
		set 
			@AmountSum=0
		Set 
			@MoneySum=0
		Declare 
			AmountCur Cursor For Select Isnull(BAmount,0),Isnull(BMoney,0),Ino From #StockDetail1  FOR UPDATE 
		Open AmountCur
		Fetch Next From AmountCur Into @BAmount,@BMoney,@Ino
		While (@@Fetch_Status=0)
		begin
		     Set @AmountSum=@AmountSum+@BAmount
		     Set @MoneySum=@MoneySum+@BMoney

		  if (@AmountSum = 0) or (@MoneySum = 0) Set @BPrice=0 Else Set @BPrice=@MoneySum/@AmountSum
		
		  --if @AmountSum=0   /*当数量为零时，金额单价都为零*/
                  --              begin
                  --                  set @BPrice=0
                  --                  set @MoneySum=0
                  --              end
		  --if @Ino<>1
		  Update #StockDetail1 Set BAmount=@AmountSum,BMoney=@MoneySum,BPrice=@BPrice Where Current Of AmountCur
		  Fetch Next From AmountCur Into @BAmount,@BMoney,@Ino
		end
		Close AmountCur
		Deallocate AmountCur
		/*生成本期合计数
		Declare @NIAmount Float,@NIOAmount Float,@NIMoney Money,@NOAmount Float
		Declare @NOOAmount Float,@NCostMoney Money
		Select @NIAmount=Sum(NIAmount),@NIOAmount=Sum(NIOAmount),@NIMOney=Sum(NIMoney),
		  @NOAmount=Sum(NOAmount),@NOOAmount=Sum(NOOAmount),@NCostMoney=Sum(NCostMoney) From #StockDetail1
		  
		Insert #StockDetail1(DAudieDate,SBillNumber,SMeory,NIAmount,NIOAmount,
		  NIMoney,NOAmount,NOOAmount,NCostMoney) 
		Values(Convert(varchar(10),DateAdd(Day,1,@EndDate),20),'','本期合计',@NIAmount,
		    @NIOAmount,@NIMoney,@NOAmount,@NOOAmount,@NCostMoney)*/
		
		Select * From #StockDetail1 order by dmakedate,InOut 
		drop table #StockDetail
		drop table #StockDetail1		
		drop table #Store
end
