
CREATE proc [dbo].[P_KC_StockTotal]
  @MoreStoreID varchar(500),
  @GoodsCatsCode varchar(200),
  @DateType int,
  @StartDate DateTime,--变成审核时间
  @EndDate  DateTime,--变成审核时间
  @KeyStr varchar(100),
  @ICheck varchar(2),  /*审核*/
  @GoodsUsed varchar(32),  --商品停用情况
  @GoodsStatus varchar(50)
As
begin

   /*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/,
			  primary key (GoodsSKUID)
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int/*ID*/,
			  StoreName varchar(100) 
			   primary key (StoreID)
		)				
		/*生成商品表结构*/		
		Create Table  #StockTotal
		(
			  GoodsSKUID Int, /*ID*/
			  FAmount Float Default 0, /*前期数量*/
			  FMoney Money Default 0,  /*前期金额*/
			  IAmount Float Default 0,  /*本期收入数量*/
			  IMoney Money Default 0,  /*本期收入金额*/
			  OAmount Float Default 0,  /*本期发出数量*/
			  OMoney Money Default 0,  /*本期发出成本金额*/
			  BAmount Float Default 0,  /*结存数量*/
			  BMoney Money Default 0   /*结存金额*/
		)
		
		Create Table #StoreTab
    (
      Nid int
    )
   
   DECLARE @SqlStr VarChar(Max), @LocCount int, @StoreID int, @TmpUsed1 int, @TmpUsed2 int,@flag varchar(2)
   
--按审核日期查询
if (@DateType = 0) begin    
    
    
    if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end	
		
    
    
	if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
	
	
        /*生成商品查询*/
		insert into #Goods 
		select distinct  s.NID 
			from B_GoodsSKU s
			inner join B_Goods G on g.NID = s.GoodsID
		where  (isnull(g.goodsCode,'') like '%'+@KeyStr+'%' 
				or isnull(g.goodsName,'') like '%'+@KeyStr+'%' 
				or isnull(s.SKU,'') like '%'+@KeyStr+'%'  )	
		-- add by ylq 2016-03-25  加停售条件		
		and ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2)) 
		and (@GoodsStatus='' or s.GoodsSKUStatus=@GoodsStatus) 		
		
		/*
		/*生成仓库查询*/
		insert into #store 
		select  NID from B_store 
		where	(@StockID=0 or NID = @StockID ) 
		*/
		
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
									
/*生成前期数--start*/
	/*--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121) --dmakedate1
		group by 
			D.GoodsSKUID
	/*--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)  --2
		group by 
			D.GoodsSKUID			
	/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.inmoney,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)  --3
		group by 
			D.GoodsSKUID
	/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)   --4
		group by 
			D.GoodsSKUID
	/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)    --5
		group by 
			D.GoodsSKUID
	/*盘点的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and
            Convert(varchar(10),M.AudieDate,121)< Convert(varchar(10),@StartDate,121)   --6
		group by 
			D.GoodsSKUID			
/*生成前期数--end*/					
/*生成本期数--start*/
	/*--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)     --7
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)  --8
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID			
	/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.inmoney,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)   --9
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)   --10
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)   --11
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(-D.Amount,0)),
			FMoney	= sum(IsNull(-D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and	
            Convert(varchar(10),M.AudieDate,121) between Convert(varchar(10),@StartDate,121)   --12
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
			
/*生成本期数--end*/	
		
/*更新本期发生数*/
		
		select 
			GoodsSKUID,
			FAmount  = sum(IsNull(FAmount,0)),
			FMoney   = sum(IsNull(FMoney,0)),--case when sum(IsNull(FAmount,0))=0 then 0 else sum(IsNull(FMoney,0)) end,
			IAmount   = sum(IsNull(IAmount,0)),
			IMoney   = sum(IsNull(IMoney,0)),
			OAmount   = sum(IsNull(OAmount,0)),
			OMoney  = sum(IsNull(OMoney,0)),
			BAmount = sum(IsNull(BAmount,0)),
			BMoney  = sum(IsNull(BMoney,0))
		into
			#BAccount1
		from    
			#StockTotal
		group by 
			GoodsSKUID
		/*余额*/
		Update 
			#BAccount1 
		Set 
			BAmount	=IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0),
			BMoney	= IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0)-- Case when (IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0))<>0 then
						--				 IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0) else 0 end
		
		--如果选择了仓库那么，查询库位，否则库位为空
		
		set @StoreID= -1
		set @LocCount = (select COUNT(*) from #Store) 
		if @LocCount = 1 begin
		  set @StoreID = (select StoreID from #Store)
		end
		
		set @flag = (select ParaValue from B_SysParams where FirstType = '库存采购参数' and ParaCode='CalCostFlag')
		
		-----------------------------------------------
		if @flag=0
		begin
		Select 
			c.GoodsSKUID,
			c.FAmount,
			c.FMoney,  
			c.IAmount ,
			c.IMoney, 
			c.OAmount ,
			c.OMoney, 
			c.BAmount,
			c.BMoney, 
			S.GoodsCode,s.GoodsName,gs.SKU,s.Barcode,S.Model,s.Class,s.Unit,bs.SupplierName,
			gs.property1,gs.property2,gs.property3, s.Brand, s.Material,s.Style,s.Purchaser,
			s.DevDate,s.SalerName,s.SalerName2, 
			--库存周转率  出库金额/((期初金额+期末金额)/2)
			
			round((case when (isnull(c.FMoney,0) + isnull(c.BMoney,0)) <= 0.0001 
			    then c.OMoney/9999999 else  IsNull(c.OMoney,0)/((c.FMoney + c.BMoney)/2) end),2) as StoreRate, 
		   
		   
		    LocationName = case when @LocCount <> 1 then '' else 
		      (select top 1 gl.LocationName from B_GoodsSKULocation bgs 
		           left outer join B_StoreLocation gl on bgs.LocationID=gl.nid
		           where gl.StoreID = @StoreID and gl.StoreID <> 0 
		           and bgs.GoodsSkuID = gs.Nid 
		      ) end,
		    
			case when ISNULL(gs.CostPrice,0) = 0 then ISNULL(s.CostPrice,0) 
			     else ISNULL(gs.CostPrice,0 ) end as CostPrice
		From
	 		#BAccount1 C
		Inner Join 
			B_GoodsSKU(noLock) gs On gS.NID=C.GoodsSKUID		 	
		Inner Join 
			B_goods(noLock) s On S.NID=gs.GoodsID
		left join B_Supplier bs on bs.NID=s.SupplierID
		left join B_GoodsCats gc on gc.NID=s.GoodsCategoryID	
		where isnull(gc.CategoryCode,'') like  @GoodsCatsCode + '%'
		order by 
			S.goodsCode
			
	
		end
		else if @flag=1	
		begin
		Select 	 
			c.GoodsSKUID,   
			c.FAmount, 
			FMoney=c.FAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,
			case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end as aa, 
			'11' as ww,  
			c.IAmount ,
			IMoney=c.IAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,  
			c.OAmount ,
			OMoney=c.OAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end, 
			c.BAmount,
			BMoney=c.BAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end, 
			S.GoodsCode,s.GoodsName,gs.SKU,s.Barcode,S.Model,s.Class,s.Unit,bs.SupplierName,
			gs.property1,gs.property2,gs.property3, s.Brand, s.Material,s.Style,s.Purchaser,
			s.DevDate,s.SalerName,s.SalerName2, 
			--库存周转率  出库金额/((期初金额+期末金额)/2)
			
			round((case when (isnull(c.FAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,0) + isnull(c.BAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,0)) <= 0.0001 
			    then c.OAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end/9999999 else  IsNull(c.OAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,0)/((c.FAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end + c.BAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end)/2) end),2) as StoreRate, 
		   
		   
		    LocationName = case when @LocCount <> 1 then '' else 
		      (select top 1 gl.LocationName from B_GoodsSKULocation bgs 
		           left outer join B_StoreLocation gl on bgs.LocationID=gl.nid
		           where gl.StoreID = @StoreID and gl.StoreID <> 0 
		           and bgs.GoodsSkuID = gs.Nid 
		      ) end,
		    
			case when ISNULL(gs.CostPrice,0) = 0 then ISNULL(s.CostPrice,0) 
			     else ISNULL(gs.CostPrice,0 ) end as CostPrice
		From
	 		#BAccount1 C
		Inner Join 
			B_GoodsSKU(noLock) gs On gS.NID=C.GoodsSKUID		 	
		Inner Join 
			B_goods(noLock) s On S.NID=gs.GoodsID
		left join B_Supplier bs on bs.NID=s.SupplierID
		left join B_GoodsCats gc on gc.NID=s.GoodsCategoryID	
		where isnull(gc.CategoryCode,'') like  @GoodsCatsCode + '%'
		order by 
			S.goodsCode
	end
					
	    Drop Table #Store
		Drop Table #Goods
		Drop Table #StockTotal
		Drop Table #BAccount1	
end

--按制单日期查询
if (@DateType = 1) begin	    
    
    if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end	    
    
	if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
	
	
        /*生成商品查询*/
		insert into #Goods 
		select distinct  s.NID 
			from B_GoodsSKU s
			inner join B_Goods G on g.NID = s.GoodsID
		where  (isnull(g.goodsCode,'') like '%'+@KeyStr+'%' 
				or isnull(g.goodsName,'') like '%'+@KeyStr+'%' 
				or isnull(s.SKU,'') like '%'+@KeyStr+'%'  )	
		-- add by ylq 2016-03-25  加停售条件		
		and ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2)) 
		and (@GoodsStatus='' or s.GoodsSKUStatus=@GoodsStatus) 
				
		
		/*
		/*生成仓库查询*/
		insert into #store 
		select  NID from B_store 
		where	(@StockID=0 or NID = @StockID ) 
		*/
		
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
									
/*生成前期数--start*/
	/*--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121) --dmakedate1
		group by 
			D.GoodsSKUID
	/*--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)  --2
		group by 
			D.GoodsSKUID			
	/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.inmoney,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)  --3
		group by 
			D.GoodsSKUID
	/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)   --4
		group by 
			D.GoodsSKUID
	/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)    --5
		group by 
			D.GoodsSKUID
	/*盘点的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)   --6
		group by 
			D.GoodsSKUID			
/*生成前期数--end*/					
/*生成本期数--start*/
	/*--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)     --7
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)  --8
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID			
	/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.inMoney,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)   --9
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)   --10
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,IAmount,IMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)   --11
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,OAmount,OMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(-D.Amount,0)),
			FMoney	= sum(IsNull(-D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag =1 and 		
			--(@ICheck='' or M.CheckFlag =@ICheck) and 
			(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121)   --12
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
			
/*生成本期数--end*/	
		
/*更新本期发生数*/
		
		select 
			GoodsSKUID,
			FAmount  = sum(IsNull(FAmount,0)),
			FMoney   = sum(IsNull(FMoney,0)),--case when sum(IsNull(FAmount,0))=0 then 0 else sum(IsNull(FMoney,0)) end,
			IAmount   = sum(IsNull(IAmount,0)),
			IMoney   = sum(IsNull(IMoney,0)),
			OAmount   = sum(IsNull(OAmount,0)),
			OMoney  = sum(IsNull(OMoney,0)),
			BAmount = sum(IsNull(BAmount,0)),
			BMoney  = sum(IsNull(BMoney,0))
		into
			#BAccount
		from    
			#StockTotal
		group by 
			GoodsSKUID
		/*余额*/
		Update 
			#BAccount 
		Set 
			BAmount	=IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0),
			BMoney	= IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0)-- Case when (IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0))<>0 then
						--				 IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0) else 0 end
		
		--如果选择了仓库那么，查询库位，否则库位为空
		
		set @StoreID= -1
		set @LocCount = (select COUNT(*) from #Store) 
		if @LocCount = 1 begin
		  set @StoreID = (select StoreID from #Store)
		end
		
		set @flag = (select ParaValue from B_SysParams where FirstType = '库存采购参数' and ParaCode='CalCostFlag')
		
		-----------------------------------------------
		if @flag=0
		begin
		Select 
		
			c.GoodsSKUID,
			c.FAmount,
			c.FMoney,  
			c.IAmount ,
			c.IMoney, 
			c.OAmount ,
			c.OMoney, 
			c.BAmount,
			c.BMoney, 
			S.GoodsCode,s.GoodsName,gs.SKU,s.Barcode,S.Model,s.Class,s.Unit,bs.SupplierName,
			gs.property1,gs.property2,gs.property3, s.Brand, s.Material,s.Style,s.Purchaser,
			s.DevDate,s.SalerName,s.SalerName2, 
			--库存周转率  出库金额/((期初金额+期末金额)/2)
			
			round((case when (isnull(c.FMoney,0) + isnull(c.BMoney,0)) <= 0.0001 
			    then c.OMoney/9999999 else  IsNull(c.OMoney,0)/((c.FMoney + c.BMoney)/2) end),2) as StoreRate, 
		   
		   
		    LocationName = case when @LocCount <> 1 then '' else 
		      (select top 1 gl.LocationName from B_GoodsSKULocation bgs 
		           left outer join B_StoreLocation gl on bgs.LocationID=gl.nid
		           where gl.StoreID = @StoreID and gl.StoreID <> 0 
		           and bgs.GoodsSkuID = gs.Nid 
		      ) end,
		    
			case when ISNULL(gs.CostPrice,0) = 0 then ISNULL(s.CostPrice,0) 
			     else ISNULL(gs.CostPrice,0 ) end as CostPrice
		From
	 		#BAccount C
		Inner Join 
			B_GoodsSKU(noLock) gs On gS.NID=C.GoodsSKUID		 	
		Inner Join 
			B_goods(noLock) s On S.NID=gs.GoodsID
		left join B_Supplier bs on bs.NID=s.SupplierID
		left join B_GoodsCats gc on gc.NID=s.GoodsCategoryID	
		where isnull(gc.CategoryCode,'') like  @GoodsCatsCode + '%'
		order by 
			S.goodsCode
			
	
		end
		else if @flag=1 
		
		begin
		print '111'
		Select 	
		    
			c.GoodsSKUID,   
			c.FAmount, 
			FMoney=c.FAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,
			case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end as aa, 
			'11' as ww,  
			c.IAmount ,
			IMoney=c.IAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,  
			c.OAmount ,
			OMoney=c.OAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end, 
			c.BAmount,
			BMoney=c.BAmount*case when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end, 
			S.GoodsCode,s.GoodsName,gs.SKU,s.Barcode,S.Model,s.Class,s.Unit,bs.SupplierName,
			gs.property1,gs.property2,gs.property3, s.Brand, s.Material,s.Style,s.Purchaser,
			s.DevDate,s.SalerName,s.SalerName2, 
			--库存周转率  出库金额/((期初金额+期末金额)/2)
			
			round((case when (isnull(c.FAmount*case when gs.CostPrice<>0 then gs.CostPrice else
			 s.CostPrice end,0) + isnull(c.BAmount*case when gs.CostPrice<>0 then 
			 gs.CostPrice else s.CostPrice end,0)) <= 0.0001 
			    then c.OAmount*case when gs.CostPrice<>0 then gs.CostPrice else 
			    s.CostPrice end/9999999 else  IsNull(c.OAmount*case when
			     gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end,0)/((c.FAmount*case 
			     when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end + c.BAmount*case 
			     when gs.CostPrice<>0 then gs.CostPrice else s.CostPrice end)/2) end),2) as StoreRate, 
		   
		   
		    LocationName = case when @LocCount <> 1 then '' else 
		      (select top 1 gl.LocationName from B_GoodsSKULocation bgs 
		           left outer join B_StoreLocation gl on bgs.LocationID=gl.nid
		           where gl.StoreID = @StoreID and gl.StoreID <> 0 
		           and bgs.GoodsSkuID = gs.Nid 
		      ) end,
		    
			case when ISNULL(gs.CostPrice,0) = 0 then ISNULL(s.CostPrice,0) 
			     else ISNULL(gs.CostPrice,0 ) end as CostPrice
		From
	 		#BAccount C
		Inner Join 
			B_GoodsSKU(noLock) gs On gS.NID=C.GoodsSKUID		 	
		Inner Join 
			B_goods(noLock) s On S.NID=gs.GoodsID
		left join B_Supplier bs on bs.NID=s.SupplierID
		left join B_GoodsCats gc on gc.NID=s.GoodsCategoryID	
		where isnull(gc.CategoryCode,'') like  @GoodsCatsCode + '%'
		order by 
			S.goodsCode
		end	
		Drop Table #Store
		Drop Table #Goods
		Drop Table #StockTotal
		Drop Table #BAccount
		end
end
