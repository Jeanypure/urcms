
create Procedure [dbo].[P_KC_StockTotalSummary_rjf]
  @StartDate DateTime,
  @EndDate  DateTime,
  @StockID int,
  @SKU varchar(100),
  @KeyStr varchar(100),
  @GoodsCatsCode varchar(200)
  
  
As
begin
  declare @ICheck VARCHAR(30)
  set @ICheck='1'
  --商品类别
 set @GoodsCatsCode=ISNULL(( select CategoryCode from B_GoodsCats where NID=@GoodsCatsCode),'')
   
		/*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/,
			  primary key (GoodsSKUID)
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int/*ID*/,
			   primary key (StoreID)
		)				
		/*生成商品表结构*/		
		Create Table  #StockTotal
		(
			  GoodsSKUID Int, /*ID*/
			  FAmount Float Default 0, /*前期数量*/
			  FMoney Money Default 0,  /*前期金额*/
			  -- 入库
			  CGInQty  Float Default 0,--   '数量(采购入库)
			  CGInMoney  Money Default 0,--   '金额(采购入库)
			  ReturnQty  Float Default 0,--   '数量(销售退货)
			  ReturnMoney  Money Default 0,--   '金额(销售退货)
			  OtherInQty  Float Default 0,--   '数量(其他入库)
			  OtherInMoney  Money Default 0,--   '金额(其他入库)
			  PDInQty  Float Default 0,--   '数量(盘点入库)
			  PDInMoney  Money Default 0,--   '金额(盘点入库)
			  DBInQty  Float Default 0,--   '数量(调拨入库)
			  DBInMoney  Money Default 0,--   '金额(调拨入库)
			  
			  SaleOutQty  Float Default 0,--   '数量(销售出库)
			  SaleOutMoney  Money Default 0,--   '金额(销售出库)
			  CGReturnQty  Float Default 0,--   '数量(采购退货)
			  CGReturnMoney  Money Default 0,--   '金额(采购退货)
			  OtherOutQty  Float Default 0,--   '数量(其他出库)
			  OtherOutMoney  Money Default 0,--   '金额(其他出库)
			  PDOutQty  Float Default 0,--   '数量(盘点出库)
			  PDOutMoney  Money Default 0,--   '金额(盘点出库)
			  DBOutQty  Float Default 0,--   '数量(调拨出库)
			  DBOutMoney  Money Default 0,--   '金额(调拨出库)
			  
		)
        /*生成商品查询*/
		insert into #Goods 
		select distinct  s.NID 
			from B_GoodsSKU s
			inner join B_Goods G on g.NID = s.GoodsID
		where  (isnull(g.goodsCode,'') like '%'+@KeyStr+'%' 
				or isnull(g.goodsName,'') like '%'+@KeyStr+'%' 
				or isnull(s.SKU,'') like '%'+@KeyStr+'%'  )	
		and (@SKU='' or  isnull(s.SKU,'')=@SKU)
		/*生成仓库查询*/
		insert into #store 
		select  NID from B_store 
		where	(@StockID=0 or NID = @StockID ) 
									
/*生成前期数--start*/
	/*--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(case when M.BillType =2 then -IsNull(D.Amount,0) else IsNull(D.Amount,0) end),
			FMoney	= sum(case when M.BillType =2 then -IsNull(D.Money,0) else IsNull(D.Money,0) end) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID
	/*--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID			
	/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID
	/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(-IsNull(D.Amount,0)),
			FMoney	= sum(-IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID
	/*盘点的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,FAmount,FMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and (IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and
            Convert(varchar(10),M.MakeDate,121)< Convert(varchar(10),@StartDate,121)
		group by 
			D.GoodsSKUID			
/*生成前期数--end*/	
				
/*生成本期数--start*/
	-- 采购入库
		insert into 
			#StockTotal(GoodsSKUID,CGInQty,CGInMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
			and isnull(BillType,0)=1
		group by 
			D.GoodsSKUID
-- 销售退货
insert into 
		#StockTotal(GoodsSKUID,ReturnQty,ReturnMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
			and isnull(BillType,0)=3
			and m.Memo like '退货入库%'
		group by 
			D.GoodsSKUID
--其他入库start
insert into 
		#StockTotal(GoodsSKUID,OtherInQty,OtherInMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
			and isnull(BillType,0)=3
		group by 
			D.GoodsSKUID

--end
-- 盘点入库
/*盘点的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,PDInQty,PDInMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0)) and	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID

-- 调拨入库
/*调拔的--rk*/
		insert into 
			#StockTotal(GoodsSKUID,DBInQty,DBInMoney )
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreInID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID
-- 销售出库
insert into 
			#StockTotal(GoodsSKUID,SaleOutQty,SaleOutMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
            and ISNULL(m.BillType,0)=3
            and  ISNULL(m.billnumber,'') like 'XSD%'
		group by 
			D.GoodsSKUID
-- 采购退货
insert into 
			#StockTotal(GoodsSKUID,CGReturnQty,CGReturnMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
			and isnull(BillType,0)=2
		group by 
			D.GoodsSKUID

-- 其他出库
  insert into 
			#StockTotal(GoodsSKUID,OtherOutQty,OtherOutMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
            and ISNULL(m.BillType,0)=3
		group by 
			D.GoodsSKUID

-- 盘点出库
/*盘点的--ck*/
	insert into 
			#StockTotal(GoodsSKUID,PDOutQty,PDOutMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(-D.Amount,0)),
			FMoney	= sum(IsNull(-D.Money,0)) 
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		inner join 
			#Store s on s.StoreID = M.StoreID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and (IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0)) and
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID	
-- 调拨出库
/*调拔的--ck*/
		insert into 
			#StockTotal(GoodsSKUID,DBOutQty,DBOutMoney)
		Select 
			GoodsSKUID	= D.GoodsSKUID,
			FAmount	= sum(IsNull(D.Amount,0)),
			FMoney	= sum(IsNull(D.Money,0)) 
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		inner join 
			#Store s on s.StoreID = M.StoreOutID					
		inner join 
			#Goods g on g.GoodsSKUID = d.GoodsSKUID	
		Where 
			m.CheckFlag <> 3 and 		
			(@ICheck='' or M.CheckFlag =@ICheck) and 	
            Convert(varchar(10),M.MakeDate,121) between Convert(varchar(10),@StartDate,121) 
						and Convert(varchar(10),@EndDate,121)
		group by 
			D.GoodsSKUID

			
/*生成本期数--end*/	
		
/*更新本期发生数*/
		
		select 
			GoodsSKUID,
			FAmount  = sum(IsNull(FAmount,0)) ,
			FMoney   = sum(IsNull(FMoney,0)),
			CGInQty       = sum(IsNull(CGInQty,0)),
			CGInMoney       = sum(IsNull(CGInMoney,0)),
			ReturnQty       = sum(IsNull(ReturnQty,0)),
			ReturnMoney       = sum(IsNull(ReturnMoney,0)),
			OtherInQty       = sum(IsNull(OtherInQty,0)),
			OtherInMoney       = sum(IsNull(OtherInMoney,0)),
			PDInQty       = sum(IsNull(PDInQty,0)),
			PDInMoney       = sum(IsNull(PDInMoney,0)),
			DBInQty       = sum(IsNull(DBInQty,0)),
			DBInMoney       = sum(IsNull(DBInMoney,0)),

			
			SaleOutQty   = sum(IsNull(SaleOutQty,0)),
			SaleOutMoney   = sum(IsNull(SaleOutMoney,0)),
			CGReturnQty   = sum(IsNull(CGReturnQty,0)),
			CGReturnMoney  = sum(IsNull(CGReturnMoney,0)),
			OtherOutQty = sum(IsNull(OtherOutQty,0)),
			OtherOutMoney  = sum(IsNull(OtherOutMoney,0)),
			PDOutQty   = sum(IsNull(PDOutQty,0)),
			PDOutMoney   = sum(IsNull(PDOutMoney,0)),
			DBOutQty   = sum(IsNull(DBOutQty,0)),
			DBOutMoney  = sum(IsNull(DBOutMoney,0))
		into
			#BAccount
		from    
			#StockTotal
		group by 
			GoodsSKUID
		/*余额*/
		/*Update 
			#BAccount 
		Set 
			BAmount	=IsNull(FAmount,0)+IsNull(IAmount,0)-IsNull(OAmount,0),
			BMoney	= IsNull(FMoney,0)+IsNull(IMoney,0)- IsNull(OMoney,0)*/
		
		--如果选择了仓库那么，查询库位，否则库位为空
		
		Select 	
			gs.SKU,
			s.GoodsCode,
			s.GoodsName as '商品名称',
			c.FAmount as  '数量(本月期初)',
			c.FMoney as '金额(本月期初)',  
			c.CGInQty as '数量(采购入库)' ,
			c.CGInMoney as '金额(采购入库)',
			c.ReturnQty as '数量(销售退货)' ,
			c.ReturnMoney as '金额(销售退货)',
			c.OtherInQty-c.ReturnQty as '数量(其他入库)' ,-- 去除销售退货
			c.OtherInMoney-c.ReturnMoney as '金额(其他入库)',-- 去除销售退货
			c.PDInQty as '数量(盘点入库)' ,
			c.PDInMoney as '金额(盘点入库)',
			c.DBInQty as '数量(调拨入库)' ,
			c.DBInMoney as '金额(调拨入库)',
			c.CGInQty+c.OtherInQty+c.PDInQty+c.DBInQty as '数量(本月入库合计)',
			c.CGInMoney+c.OtherInMoney+c.PDInMoney+c.DBInMoney as '金额(本月入库合计)',

			  
			  
			c.SaleOutQty  as '数量(销售出库)',
			c.SaleOutMoney as    '金额(销售出库)',
			c.CGReturnQty as  '数量(采购退货)',
			c.CGReturnMoney as   '金额(采购退货)',
			c.OtherOutQty -c.SaleOutQty as    '数量(其他出库)',-- 去除销售出库
			c.OtherOutMoney -c.SaleOutMoney as   '金额(其他出库)',-- 去除销售出库
			c.PDOutQty  as   '数量(盘点出库)',
			c.PDOutMoney  as   '金额(盘点出库)',
			c.DBOutQty  as    '数量(调拨出库)',
			c.DBOutMoney  as   '金额(调拨出库)',
			c.CGReturnQty+c.OtherOutQty+c.PDOutQty+c.DBOutQty as '数量(出库合计)',
			c.CGReturnMoney+c.OtherOutMoney+c.PDOutMoney+c.DBOutMoney as '金额(出库合计)',
			c.FAmount+c.CGInQty+c.OtherInQty+c.PDInQty+c.DBInQty
			 -(c.CGReturnQty+c.OtherOutQty+c.PDOutQty+c.DBOutQty) as '数量(本期结存)',
			c.FMoney+c.CGInMoney+c.OtherInMoney+c.PDInMoney+c.DBInMoney
			 -(c.CGReturnMoney+c.OtherOutMoney+c.PDOutMoney+c.DBOutMoney) as '金额(本期结存)' 


			 
		From
	 		#BAccount C
		Inner Join 
			B_GoodsSKU gs On gS.NID=C.GoodsSKUID		 	
		Inner Join 
			B_goods s On S.NID=gs.GoodsID
		left join B_GoodsCats gc on gc.NID=s.GoodsCategoryID	
		where isnull(gc.CategoryCode,'') like  @GoodsCatsCode + '%'
		order by 
			S.goodsCode
		Drop Table #Store
		Drop Table #Goods
		Drop Table #StockTotal
		Drop Table #BAccount		 
end

