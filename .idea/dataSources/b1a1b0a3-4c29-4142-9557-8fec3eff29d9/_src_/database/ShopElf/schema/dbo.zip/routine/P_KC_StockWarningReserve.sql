CREATE Proc [P_KC_StockWarningReserve]
	@SKU varchar(100)='',
	@StoreID int=0
as
begin
	select 
		kr.Amount,
		m.MakeDate,
		m.BillNumber,
		gs.SKU,
		BillTypeName='采购退回单'
	from 
		KC_ReserveDetail kr
	inner join 
		B_GoodsSKU gs on gs.NID=kr.GoodsSKUID
	inner join 
		CG_StockInM m on m.NID=kr.BillNID
	where 
		kr.BillType=1 and gs.SKU = @SKU and kr.StoreID=@StoreID
	union all
	select 
		kr.Amount,
		m.MakeDate,
		m.BillNumber,
		gs.SKU,
		BillTypeName=  case when  m.billtype=4  then '返修出库单' else  '其它出库单' end
	from 
		KC_ReserveDetail kr
	inner join 
		B_GoodsSKU gs on gs.NID=kr.GoodsSKUID
	inner join 
		CK_StockOutM m on m.NID=kr.BillNID
	where 
		kr.BillType=2 and gs.SKU = @SKU and kr.StoreID=@StoreID
	union all
	select 
		kr.Amount,
		m.MakeDate,
		m.BillNumber,
		gs.SKU,
		BillTypeName='调拔单'
	from 
		KC_ReserveDetail kr
	inner join 
		B_GoodsSKU gs on gs.NID=kr.GoodsSKUID
	inner join 
		KC_StockChangeM m on m.NID=kr.BillNID
	where 
		kr.BillType=3 and gs.SKU = @SKU and kr.StoreID=@StoreID
	union all
	select 
		kr.Amount,
		m.MakeDate,
		m.BillNumber,
		gs.SKU,
		BillTypeName='盘点单-盘亏'
	from 
		KC_ReserveDetail kr
	inner join 
		B_GoodsSKU gs on gs.NID=kr.GoodsSKUID
	inner join 
		KC_StockCheckM m on m.NID=kr.BillNID
	where 
		kr.BillType=4 and gs.SKU = @SKU and kr.StoreID=@StoreID
	union all
	select 
		kr.Amount,
		 DateAdd(hour,8,m.ordertime) ,
		cast(m.NID as varchar(20)) ,
		gs.SKU,
		BillTypeName='销售订单'
	from 
		KC_ReserveDetail kr
	inner join 
		B_GoodsSKU gs on gs.NID=kr.GoodsSKUID
	inner join 
		P_trade m on m.NID=kr.BillNID		
	where 
		kr.BillType=5 and gs.SKU = @SKU and kr.StoreID=@StoreID		
end
