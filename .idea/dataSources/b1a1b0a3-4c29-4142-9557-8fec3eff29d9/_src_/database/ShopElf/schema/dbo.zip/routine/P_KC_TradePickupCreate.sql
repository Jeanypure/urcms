CREATE proc [P_KC_TradePickupCreate]
	@TradeNIDS varchar(max),
    @BillNumber VarChar(50) OutPut	--返回单据号	
as
begin
	CREATE TABLE #TradeNids
	(
		INO [int] IDENTITY(1,1) NOT NULL,
		TradeNid INT NOT NULL DEFAULT 0
	) 
	
    DECLARE @sSQLCmd varchar(max) = '', 
			@temp varchar(20) = '', 
			@index int = 0
    SET @sSQLCmd = 'insert into #TradeNids(TradeNid) select ';
    set @TradeNids = @TradeNids + ','
    while (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
		SET @sSQLCmd = 'insert into #TradeNids(TradeNid) select '+@temp;
		EXEC(@sSQLCmd)
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
    END 
    if not exists(select top 1 p.NID from P_TradePickup p 
				inner join #TradeNids t on t.TradeNid=p.TradeNID )
	begin
		EXEC  P_S_CodeRuleGet 32000 , @BillNumber OUTPUT
		insert into P_TradePickup(TradeNID, PickupNo, SKU, PosNo, Num, CheckFlag)
		select 
			m.NID,
			@BillNumber,
			isnull(d.SKU,''),
			t.INO,--分拣位
			SUM(d.L_QTY) as num,
			0
		from 
			P_Tradedt d
		inner join 
			P_Trade m on m.NID=d.tradeNID
		inner  join 
			#TradeNids  t on t.tradenid=d.tradenid
		where 
			m.FilterFlag=20 and t.TradeNid not in (select TradeNID from P_TradePickup)
		group by 
			m.NID,
			isnull(d.SKU,''),t.INO
	end
	else
	begin
		set @BillNumber='' --空表示已经存在记录
	end
	--select @Billnumber as billnumber 
end
