
CREATE PROCEDURE [dbo].[P_KC_TradeReturnInStore]
	@StoreID	int,
    @TradeDtIDs varchar(max) ,
    @Recorder VARCHAR(30)                     
AS
BEGIN
  set nocount on;	--使返回的结果中不包含有关受 Transact-SQL 语句影响的行数的信息
begin try 
   BEGIN TRAN crSave
     --查找成本计价方法
  Declare
	@CalcCostFlag int 
  set
	@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
	--增加入库记录
	DECLARE 
		@BillNumber VARCHAR(50) , 
		@MakeDate VARCHAR(30),
		@sSql		VARCHAR(max), 
		@GoodsID INT , 
		@StockInNID INT,
		@OrderNid varchar(max),
		@ErrorMsg varchar(100) 
	-- 返回表记录
	create table #BackSelTable(
	  BackMSg varchar(100) default '')
	--生成明细
	create Table #P_TradeDtUn(
			GoodsSKUID	int,
			l_qty		int,
			CostPrice	money)
	set @sSql = ' insert  into #P_TradeDtUn select GoodsSKUID,sum(l_Qty) as l_Qty,0.0000 as CostPrice '+
					' from P_TradeDtUn where nid in ' +@TradeDtIDs +
					' group by GoodsSKUID '
	exec(@sSql)
	
	create table #p_TradeNid(
	  Nid int
	  )
	set @sSql= ' insert into #p_TradeNid select distinct TradeNid from P_TradeDtUn where nid in ' +@TradeDtIDs
	exec(@sSql)
	
	select @OrderNid = ISNULL(@OrderNid,'') + ',' + ISNULL(convert(varchar(10),Nid),'') from #p_TradeNid
	set @OrderNid = RIGHT(@OrderNid,len(@OrderNid)-1)
    print 0
	if @CalcCostFlag=0
	begin
	  -- 取库存平均价
	  Update 
		 d
		set
			d.CostPrice=isNull(c.Price,0)
		from 
			#P_TradeDtUn d
		left outer join
			KC_CurrentStock c on c.GoodsSKUID=d.GoodsSKUID
	end
	else
	begin
	  -- 取商品信息成本价
	  Update 
		 d
		set
			d.CostPrice= case when isNull(bgs.CostPrice,0)=0 then isNull(bg.CostPrice,0) else isNull(bgs.CostPrice,0) end
		from 
			#P_TradeDtUn d
		left outer join B_GoodsSKU bgs on bgs.NID=d.GoodsSKUID
		left outer join B_Goods bg on bg.NID=bgs.GoodsID
	end
	print 1
	--插入数据	
	insert into #BackSelTable						
	EXEC  P_S_CodeRuleGet 22332 , @BillNumber OUTPUT
	print 2
	SET @MakeDate = CONVERT(VARCHAR(30), GETDATE(), 120) 
	INSERT INTO  
		CG_StockInM (BillType,CheckFlag, InvoiceFlag,BillNumber, MakeDate,SupplierID , 
					SalerID,StoreID,memo,DeptMan,StockMan,Recorder)
	VALUES (3,0,0, @BillNumber, @MakeDate, 0, 0,@StoreID, '退货入库：'+@OrderNid, '', @Recorder,@Recorder) 

	SET @StockInNID = @@identity

	INSERT INTO CG_StockInD(StockInNID,GoodsID, goodsSKUID,Amount, price,TaxPrice,Money,AllMoney)
	select 
		@StockInNID,isNull(GoodsID,0),GoodsSKUID,l_qty,du.costprice,du.costprice,l_qty*du.costprice,l_qty*du.costprice
	from 
		#P_TradeDtUn du
	left outer join 
		B_GoodsSKU gs on gs.nid=du.GoodsSKUID
  print 3
  delete from #BackSelTable
  insert into #BackSelTable	
  EXEC P_KC_CurrentStock 'CK_StockInM', @Recorder, 1, @StockInNID 
  set @ErrorMsg=ISNULL((select BackMSg from #BackSelTable),'')
  -- 成功执行,失败rollback
  if @ErrorMsg='0' 
  begin
    -- 插入日志
    INSERT INTO [P_TradeLogs] ([TradeNID] ,[Operator]  ,[Logs])
    select nid,@Recorder,@Recorder +' '+ CONVERT(VARCHAR(30),GETDATE(),121)+' ' + '已退货入库' from  #p_TradeNid
    print 4
    --退货做标记
    set @sSql=  ' UPDATE P_TradeUn '+
               ' SET RestoreStock =1 '+
               ' WHERE NID IN (select TradeNID from P_TradeDtUn  '+
                        'WHERE NID IN '+@TradeDtIDs+') '+
               ' UPDATE P_TradeDtUn '+
               ' SET L_OPTIONSNAME = ''已退货入库'''+
               ' WHERE NID IN '+@TradeDtIDs;
    exec(@sSql)
    drop table #BackSelTable 
    Commit tran crSave
    select 0 as 'result'  
  end
  else
  begin
    rollback tran crSave
    -- 错误 
    select 1 as 'result'
  end
  End try    
  Begin catch   
	  If (@@TRANCOUNT<>0) 
	  Begin    
		rollback tran crSave
		-- 错误 
		select 1 as 'result'
	  End
  End catch
 END 

