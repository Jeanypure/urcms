Create PROCEDURE [dbo].[P_KC_TradeReturnPackInStore]
	@StoreID	int,
    @TradeNIDs varchar(100) ,
    @REASONCODE varchar(500),
    @Recorder VARCHAR(30),
    @Returntype int  -- 0 驳回待派单重发,1 确认退货入库                    
AS
BEGIN
   set nocount on;	--使返回的结果中不包含有关受 Transact-SQL 语句影响的行数的信息
   DECLARE 
     @FilterFlag int=0
   begin try 
   BEGIN TRAN crSave
   --  仓库id为0,按原仓库id存
   if @StoreID=0
   begin
     set @StoreID=ISNULL((select top 1 StoreID from P_TradeDt where TradeNID=@TradeNIDs),0)
     if @StoreID=0  
       set @StoreID=ISNULL((select top 1 StoreID from P_TradeDt_His where TradeNID=@TradeNIDs),0) 
   end
     --查找成本计价方法
  Declare
	@CalcCostFlag int 
  set
	@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
	
	--增加入库记录
	DECLARE 
		@BillNumber VARCHAR(50) , 
		@MakeDate VARCHAR(30),
		@sSql		VARCHAR(2000), 
		@GoodsID INT , 
		@StockInNID INT,
		@OrderNid varchar(1000),
		@ErrorMsg varchar(100)
	-- 返回表记录
	create table #BackSelTable(
	  BackMSg varchar(100) default '')
	--生成明细
	create Table #P_TradeDt(
			GoodsSKUID	int,
			l_qty		int,
			CostPrice	money)
	set @sSql = ' insert  into #P_TradeDt select GoodsSKUID,sum(l_Qty) as l_Qty,0.0000 as CostPrice '+
					' from P_TradeDt where tradenid=' +@TradeNIDs +
					' group by GoodsSKUID '+
					' union all '+
					' select GoodsSKUID,sum(l_Qty) as l_Qty,0.0000 as CostPrice '+
					' from P_TradeDt_his where tradenid=' +@TradeNIDs +
					' group by GoodsSKUID '
	exec(@sSql)
	create table #p_TradeNid(
	  Nid int
	  )
	set @sSql= ' insert into #p_TradeNid select ' +@TradeNIDs
	exec(@sSql)
	select @OrderNid = ISNULL(@OrderNid,'') + ',' + ISNULL(convert(varchar(10),Nid),'') from #p_TradeNid
	set @OrderNid = RIGHT(@OrderNid,len(@OrderNid)-1)
	
	
	if @CalcCostFlag=0
	begin
	  -- 取库存平均价
	  Update 
		 d
		set
			d.CostPrice=isNull(c.Price,0)
		from 
			#P_TradeDt d
		left outer join
			KC_CurrentStock c on c.GoodsSKUID=d.GoodsSKUID
	end
	else
	begin
	  -- 取商品信息成本价
	  Update 
		 d
		set
			d.CostPrice= case when isNull(bgs.CostPrice,0)=0 then isNull(bg.CostPrice,0) else isNull(bgs.CostPrice,0) end
		from 
			#P_TradeDt d
		left outer join B_GoodsSKU bgs on bgs.NID=d.GoodsSKUID
		left outer join B_Goods bg on bg.NID=bgs.GoodsID
	end
	if @Returntype=1 
	begin
	  -- 1 确认退货入库,此操作把原订单商品形成其它入库记录，需要在其它入库单中审核后增加库存，
	  -- 并且原订单转至待处理订单-->异常订单的退货订单中
	  --插入数据	
		insert into #BackSelTable				
		EXEC  P_S_CodeRuleGet 22332 , @BillNumber OUTPUT
		SET @MakeDate = CONVERT(VARCHAR(30), GETDATE(), 120)
		-- 其他入库单生成一条记录,需手动审核 
		INSERT INTO  
			CG_StockInM (BillType,CheckFlag, InvoiceFlag,BillNumber, MakeDate,SupplierID , 
						SalerID,StoreID,memo,DeptMan,StockMan,Recorder)
		VALUES (3,0,0, @BillNumber, @MakeDate, 0, 0,@StoreID, '退货入库：'+@OrderNid, '', @Recorder,@Recorder) 

		SET @StockInNID = @@identity

		INSERT INTO CG_StockInD(StockInNID,GoodsID, goodsSKUID,Amount, price,TaxPrice,Money,AllMoney)
		select 
			@StockInNID,isNull(GoodsID,0),GoodsSKUID,l_qty,du.costprice,du.costprice,l_qty*du.costprice,l_qty*du.costprice
		from 
			#P_TradeDt du
		left outer join 
			B_GoodsSKU gs on gs.nid=du.GoodsSKUID
		-- 已发货或者归档订单,转至退货订单中
		delete from #BackSelTable
		insert into #BackSelTable
		EXEC  P_S_CodeRuleGet 120 , @BillNumber OUTPUT
		if exists(select 1 from P_Trade where NID=@TradeNIDs)
		begin
		  -- 正常单
		  UPDATE p_trade SET FilterFlag=2,PROTECTIONELIGIBILITYTYPE='退货订单',
				BatchNum=@BillNumber,
				REASONCODE=@REASONCODE,
				RestoreStock=1
				WHERE nid=@TradeNIDs
		  -- 主表
		  INSERT INTO P_TradeUn 
             SELECT * FROM P_Trade WHERE nid=@TradeNIDs
          delete from P_Trade WHERE nid=@TradeNIDs
          -- 细表
          insert into P_TradeDtUn 
			 select * from P_TradeDt where TradeNID=@TradeNIDs 
		  update P_TradeDtUn  set L_OPTIONSNAME = '已退货入库' where TradeNID=@TradeNIDs
		   
		  delete from P_TradeDt WHERE TradeNID=@TradeNIDs
		end
		else
		if exists(select 1 from P_Trade_His where NID=@TradeNIDs)
		begin
		  -- 历史订单
		  UPDATE P_Trade_His SET FilterFlag=2,PROTECTIONELIGIBILITYTYPE='退货订单',
		    BatchNum=@BillNumber,
		    REASONCODE=@REASONCODE,
		    RestoreStock=1
		    WHERE nid=@TradeNIDs 
		  -- 主表
		  INSERT INTO P_TradeUn 
             SELECT * FROM P_Trade_His WHERE nid=@TradeNIDs
          delete from P_Trade_His WHERE nid=@TradeNIDs
          insert into P_TradeDtUn 
			 select * from P_TradeDt_His where TradeNID=@TradeNIDs 
		  update P_TradeDtUn  set L_OPTIONSNAME = '已退货入库' where TradeNID=@TradeNIDs
		  delete from P_TradeDt_His where TradeNID=@TradeNIDs 
		end
	end
	else
	begin
	   --0 驳回待派单重发：此操作把原订单驳回到待派单中，库存还原。
	   -- 先驳回到待派单
		 EXEC OrderReturnBack_pack @TradeNIDs, '1', 'ADMIN',@BillNumber OUTPUT 
		 set @FilterFlag=ISNULL((select FilterFlag from P_Trade where NID=@TradeNIDs),5)
		 -- 判断是否驳回成功
		 if @FilterFlag=5
		 begin
		   UPDATE p_trade 
		     SET REASONCODE=@REASONCODE
				WHERE nid=@TradeNIDs
		   Commit tran crSave
           select 0 as 'result'
           return;
		 end
		 else
		 begin
		    rollback tran crSave
		    select 1 as 'result'
		    return;
		 end 
	end
	Commit tran crSave
    select 0 as 'result'  
  End try    
  Begin catch   
	  If (@@TRANCOUNT<>0) 
	  Begin    
		rollback tran crSave
		-- 错误 
		select 1 as 'result'
	  End
  End catch
 END
