
CREATE proc [P_KC_UpdateReserveStock]
	@flag int=0
as
begin
	--truncate table KC_ReserveDetail_his
	create table #URS
		(
			GoodsSKUID	int default 0,
			Salenum		int default 0,
			StoreID		int default 0
		)
	insert into #URS	
	select goodsskuid,sum(isnull(salenum,0)),StoreID from 
		(
			SELECT isnull(ptd.GoodsSKUID,0) as GoodsSKUID, SUM(ptd.L_QTY) AS Salenum,isnull(ptd.StoreID,0) as StoreID
			FROM P_TradeDt ptd WHERE ptd.TradeNID IN (
			SELECT pt.NID FROM P_Trade pt WHERE pt.FilterFlag >5 AND  pt.FilterFlag < 100) 
			and (isnull(ptd.GoodsSKUID,0) <> 0  and isnull(ptd.StoreID,0)<>0  )
			GROUP BY ptd.GoodsSKUID,ptd.StoreID
			union all
			SELECT isnull(ptd.GoodsSKUID,0) as GoodsSKUID, SUM(ptd.L_QTY) AS Salenum,isnull(ptd.StoreID,0) as StoreID
			FROM P_TradeDtun ptd WHERE ptd.TradeNID IN (
			SELECT pt.NID FROM P_Tradeun pt WHERE pt.FilterFlag = 1 and pt.RestoreStock=-1 ) 
			and (isnull(ptd.GoodsSKUID,0) <> 0  and isnull(ptd.StoreID,0)<>0  )
			GROUP BY ptd.GoodsSKUID,ptd.StoreID	
		) as aa
		group by GoodsSKUID,StoreID
--形成占用
	declare 
		@ErrorCount	 int = 0
	set
		@ErrorCount = 0	
	begin tran ReserveStock	
	   truncate table KC_ReserveDetail	
			--占用数量清零
			UPDATE KC_CurrentStock
			SET
				ReservationNum = 0
			UPDATE kc
			SET
				ReservationNum = t2.Salenum 
			FROM KC_CurrentStock kc 
			inner JOIN #URS t2 ON kc.GoodsSKUID = t2.GoodsSKUID and kc.StoreID=t2.StoreID
			DROP TABLE #URS		
		--判断表，生成记录明细
		 --入库单退回
			--形成新的占用记录	
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				1	,
				m.NID,
				D.GoodsSKUID	,
				m.StoreID,
				abs(d.Amount),
				0,
				'system'	
			from
				CG_StockInD d
			inner join
				CG_StockInM m on m.NID=d.StockInNID
			where
				m.CheckFlag=0 and m.BillType=2
			set 
				@ErrorCount =@ErrorCount +@@ERROR
			--更新库存占用数量
			update 
				k
			set 
				k.ReservationNum = k.ReservationNum+r.amount
			from 
				KC_CurrentStock k 
			inner join 
				( select goodsskuid,storeid,SUM(isnull(amount,0)) as amount from 
					KC_ReserveDetail where Billtype=1 group by  goodsskuid,storeid ) r 
				 on r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
			set 
				@ErrorCount =@ErrorCount +@@ERROR
		--出库单

			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				2	,
				m.NID,
				D.GoodsSKUID	,
				m.StoreID,
				abs(d.Amount),
				0,
				'system'	
			from
			
				CK_StockOutD d
			inner join
				CK_StockOutM m on m.NID=d.StockOutNID
			where
				 m.CheckFlag =0
			set 
				@ErrorCount =@ErrorCount +@@ERROR			 
			--更新库存占用数量
			update 
				k
			set 
				k.ReservationNum = k.ReservationNum+r.amount
			from 
				KC_CurrentStock k 
			inner join 
								( select goodsskuid,storeid,SUM(isnull(amount,0)) as amount from 
					KC_ReserveDetail where Billtype=2 group by  goodsskuid,storeid ) r 
				 on  r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	

													 
			set 
				@ErrorCount =@ErrorCount +@@ERROR
		--调拔单出库

				
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				3	,
				m.NID,
				D.GoodsSKUID	,
				m.StoreOutID ,
				abs(d.Amount),
				0,
				'system'	
			from
				KC_StockChangeD d
			inner join
				KC_StockChangeM m on m.NID=d.StockChangeNID
			where
				m.CheckFlag =0	
			set 
				@ErrorCount =@ErrorCount +@@ERROR							 
			--更新库存占用数量
			update 
				k
			set 
				k.ReservationNum = k.ReservationNum+r.amount
			from 
				KC_CurrentStock k 
			inner join 
								( select goodsskuid,storeid,SUM(isnull(amount,0)) as amount from 
					KC_ReserveDetail where Billtype=3 group by  goodsskuid,storeid ) r 
				 on  r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	
						 
			set 
				@ErrorCount =@ErrorCount +@@ERROR	
		--盘点出库
			
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				4	,
				m.NID,
				D.GoodsSKUID	,
				m.StoreID,
				abs(d.Amount),
				0,
				'system'	
			from
				KC_StockCheckD d
			inner join
				KC_StockCheckM m on m.NID=d.StockCheckNID
			where
				isnull(d.Amount,0)<0 and m.CheckFlag =0
			set 
				@ErrorCount =@ErrorCount +@@ERROR			
			--更新库存占用数量
			update 
				k
			set 
				k.ReservationNum = k.ReservationNum+r.amount
			from 
				KC_CurrentStock k 
			inner join 
								( select goodsskuid,storeid,SUM(isnull(amount,0)) as amount from 
					KC_ReserveDetail where Billtype=4 group by  goodsskuid,storeid ) r 
				 on  r.goodsskuid=k.goodsskuid and r.storeid=k.StoreID	

			set 
				@ErrorCount =@ErrorCount +@@ERROR								 
		--销售订单
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				5	,
				ptd.TradeNID,
				isnull(ptd.GoodsSKUID,0) as GoodsSKUID	,
				isnull(ptd.StoreID,0) as StoreID,
				SUM(ptd.L_QTY) AS Salenum,
				0,
				'system'	
			from 
				 P_TradeDt ptd 
			WHERE ptd.TradeNID IN (
					SELECT pt.NID FROM P_Trade pt WHERE pt.FilterFlag >5 AND  pt.FilterFlag < 100
					) 
				and (isnull(ptd.GoodsSKUID,0) <> 0  and isnull(ptd.StoreID,0)<>0  )
			GROUP BY
				ptd.TradeNID,ptd.GoodsSKUID,ptd.StoreID
		--销售订单缺货设置占用
			insert into 
				KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)
			select
				5	,
				ptd.TradeNID,
				isnull(ptd.GoodsSKUID,0) as GoodsSKUID	,
				isnull(ptd.StoreID,0) as StoreID,
				SUM(ptd.L_QTY) AS Salenum,
				0,
				'system'	
			from 
				 P_TradeDtun ptd 
			WHERE ptd.TradeNID IN (
					SELECT pt.NID FROM P_Tradeun pt WHERE pt.FilterFlag=1 and RestoreStock=-1
					) 
				and (isnull(ptd.GoodsSKUID,0) <> 0  and isnull(ptd.StoreID,0)<>0  )
			GROUP BY
				ptd.TradeNID,ptd.GoodsSKUID,ptd.StoreID				
			set 
				@ErrorCount =@ErrorCount +@@ERROR
		if @ErrorCount=0
		begin
		  commit tran ReserveStock
		  if @flag=0 
		  select '更新占用成功！！！！！'
		end
		else
		begin
		  rollback tran ReserveStock
		   if @flag=0 
		  select '更新占用失败？？？？？？'
		end  	  			
	
end


