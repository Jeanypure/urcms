
CREATE proc [dbo].[P_M_CaseGetStautsCount]
	@BeginDate datetime='2012-01-01',
	@CurrUserID varchar(20)=''
as
begin
	create Table #eBayUserID 
	(
		UserID varchar(100)
	)
	DECLARE @SelDataUser VARCHAR(max), 
		@SqlCmd VARCHAR(max) 
	if LOWER(@CurrUserID)<>'admin'
	begin
		SET @SelDataUser = ISNULL((SELECT SelDataUser  FROM B_Person WHERE NID = @CurrUserID),'')
		IF (ISNULL(@SelDataUser,'') = '') 
		SET @SelDataUser = '''0'''
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1  and '+
				  ' spsi.NoteName IN ('+@SelDataUser+') '
				  	  
		EXECUTE(@SqlCmd) 
    end  
    else
    begin
	
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1   '
		EXECUTE(@SqlCmd)     
    end
        --未处理的
		select 
			'active' as CaseStatus,
			allcount=count(1)	
		from M_eBayCase m
		inner join #eBayUserID e on e.UserID=m.SellerID
		where CreationDate > @BeginDate and IType = 0  
		and  [Status] not in ('CANCELLED','CLOSED','CLOSED_FVFCREDIT','CLOSED_NOFVFCREDIT',
		     'CS_CLOSED','EXPIRED','CASE_CLOSED_CS_RESPONDED','PAID','CLOSED_FVFCREDIT_STRIKE',
		     'CLOSED_FVFCREDIT_NOSTRIKE','CLOSED_NOFVFCREDIT_NOSTRIKE','CLOSED_NOFVFCREDIT_STRIKE',
		     'OTHER_PARTY_RESPONSE_DUE')
		--已回复的      	
		union all
		select 
			'replay' as CaseStatus,
			allcount=count(1)	
		from M_eBayCase m
		inner join #eBayUserID e on e.UserID=m.SellerID
		where CreationDate > @BeginDate and IType = 0  
		and [Status] in ('OTHER_PARTY_RESPONSE_DUE') 
		--关闭的  
		union all
		select 
			'close' as CaseStatus,
			allcount=count(1)	
		from M_eBayCase m
		inner join #eBayUserID e on e.UserID=m.SellerID
		where CreationDate > @BeginDate and IType = 0  
		and [Status] in ('CANCELLED','CLOSED','CLOSED_FVFCREDIT','CLOSED_NOFVFCREDIT',
			'CS_CLOSED','EXPIRED','CASE_CLOSED_CS_RESPONDED','PAID','CLOSED_FVFCREDIT_STRIKE',
			'CLOSED_FVFCREDIT_NOSTRIKE','CLOSED_NOFVFCREDIT_NOSTRIKE','CLOSED_NOFVFCREDIT_STRIKE')
		--未处理return的	
		union all
		select 
			'activereturn' as CaseStatus,
			allcount=count(1)	
		from M_eBayCase m
		inner join #eBayUserID e on e.UserID=m.SellerID
		where CreationDate > @BeginDate and IType = 1  
		and  [Status] not in ('CLOSED','ESCALATED')
		
		--关闭或升级的return的	
		union all
		select 
			'closereturn' as CaseStatus,
			allcount=count(1)	
		from M_eBayCase m
		inner join #eBayUserID e on e.UserID=m.SellerID
		where CreationDate > @BeginDate and IType = 1 
		and  [Status] in ('CLOSED','ESCALATED')
				
		drop table #eBayUserID

end

