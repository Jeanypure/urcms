
--P_M_CaseLinkTrade '5033434050','290932131425','914045361019','2013-07-29 13:33:07.000'
CREATE PROCEDURE [dbo].[P_M_CaseLinkTrade] 
                 @CaseID VARCHAR(50) = ''
                ,@L_NUMBER VARCHAR(50) = ''
                ,@L_EBAYITEMTXNID VARCHAR(50) = ''
                ,@CaseTime	Datetime =''
AS
BEGIN
	if @L_EBAYITEMTXNID='' set @L_EBAYITEMTXNID='0'
	--更新订单号
    declare @SKU varchar(200)=''
			,@tradenid varchar(20)=''
			,@SHIPTOCOUNTRYNAME varchar(200)=''
			,@ORDERTIME varchar(30)=''
			,@CLOSINGDATE varchar(30)=''
			,@Gapdays varchar(10)=''
			,@LogicName varchar(200)=''
			,@LogicENName varchar(200)=''	
			,@TrackNo varchar(20)=''
			,@TransDate datetime=''						
	if Exists(select nid from P_TradeDt where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
		select top 1 
			@tradenid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Gapdays=DATEDIFF(day,m.ORDERTIME,@CaseTime) ,
	        @LogicENName=ISNULL(l.code,''),
	        @LogicName=ISNULL(l.name,''),
	        @TransDate = DATEADD(hh,8, m.ORDERTIME),
	        @TrackNo=m.TrackNo
		from 
			P_TradeDt d
		inner join 
			P_Trade m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else
	if Exists(select nid from P_TradeDt_His where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
		select  top 1 
			@tradenid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Gapdays=DATEDIFF(day,m.ORDERTIME,@CaseTime) ,
	        @LogicENName=ISNULL(l.code,''),
	        @LogicName=ISNULL(l.name,''),
	        @TransDate = DATEADD(hh,8, m.ORDERTIME),
	        @TrackNo=m.TrackNo
		from 
			P_TradeDt_His d
		inner join 
			P_Trade_His m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else	
	if Exists(select nid from P_TradeDtUn where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
		select  top 1 
			@tradenid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Gapdays=DATEDIFF(day,m.ORDERTIME,@CaseTime) ,
	        @LogicENName=ISNULL(l.code,''),
	        @LogicName=ISNULL(l.name,''),
	        @TransDate = DATEADD(hh,8, m.ORDERTIME),
	        @TrackNo=m.TrackNo
		from 
			P_TradeDtUn d
		inner join 
			P_TradeUn m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else	
	if Exists(select nid from P_TradeDtUn_His where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
		select  top 1 
			@tradenid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Gapdays=DATEDIFF(day,m.ORDERTIME,@CaseTime) ,
	        @LogicENName=ISNULL(l.code,''),
	        @LogicName=ISNULL(l.name,''),
	        @TransDate = DATEADD(hh,8, m.ORDERTIME),
	        @TrackNo=m.TrackNo
		from 
			P_TradeDtUn_His d
		inner join 
			P_TradeUn_His m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
			
	update 
		M_eBayCase 
	set 
		SKU=@SKU,
		SendDate=@CLOSINGDATE,
		LogicName =@LogicName,
		LogicEnName=@LogicENName,
		TrackNo=@TrackNo,
		tradenid=@tradenid,
		transactionDate = @TransDate,
		SHIPTOCOUNTRYNAME=@SHIPTOCOUNTRYNAME,
	    GapDays= @Gapdays
	where 
		CaseID = @CaseID
END

