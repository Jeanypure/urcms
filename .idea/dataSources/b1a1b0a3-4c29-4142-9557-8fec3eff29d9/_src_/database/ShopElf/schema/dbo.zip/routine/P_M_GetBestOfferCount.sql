
CREATE proc [dbo].[P_M_GetBestOfferCount]
	@BeginDate Varchar(20)='2012-01-01',
	@CurrUserID varchar(20)=''
as
begin
	create Table #eBayUserID 
	(
		UserID varchar(100)
	)
	DECLARE @SelDataUser VARCHAR(2000), 
		@SqlCmd VARCHAR(3000) 
	if LOWER(@CurrUserID)<>'admin'
	begin
		SET @SelDataUser = ISNULL((SELECT SelDataUser  FROM B_Person WHERE NID = @CurrUserID),'')
		IF (ISNULL(@SelDataUser,'') = '') 
		SET @SelDataUser = '''0'''
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1  and '+
				  ' spsi.NoteName IN ('+@SelDataUser+') '
		print @SqlCmd		  
		  EXECUTE(@SqlCmd) 
    end  
    else
    begin
	
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1   '
		EXECUTE(@SqlCmd)     
    end
		select 
			'active' as BestofferStatus,
			allcount=count(1)	
		from M_BestOffer m
		inner join #eBayUserID e on e.UserID=m.eBayUserID
		where DATEADD(hour,8,ExpirationTime)>GETDATE() and Operstate in 
					('未处理')
		union all
		select 
			'replay' as BestofferStatus,
			allcount=count(1)	
		from M_BestOffer m
		inner join #eBayUserID e on e.UserID=m.eBayUserID		
		where DATEADD(hour,8,ExpirationTime)>GETDATE() and Operstate in 
				('已还价','已接受')
		union all
		select 
			'all' as BestofferStatus,
			allcount=count(1)	
		from M_BestOffer m
		inner join #eBayUserID e on e.UserID=m.eBayUserID		
		where DATEADD(hour,8,ExpirationTime)<GETDATE() or Operstate='已拒绝'
				
		drop table #eBayUserID
	---[status]		
	/*
•	Accepted
•   Active
•   AdminEnded
•   All
•   Countered
•   CustomCode
•   Declined
•   Expired
•   Pending
•   Retracted
	*/
end

