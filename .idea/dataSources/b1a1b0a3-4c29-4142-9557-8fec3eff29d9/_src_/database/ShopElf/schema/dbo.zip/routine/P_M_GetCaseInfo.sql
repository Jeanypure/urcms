create Proc [dbo].[P_M_GetCaseInfo]
    @CaseId     varchar(50)='',           --caseid 如果有caseid 那么@CurrUserID后面的条件都不用
    @CurrUserID varchar(20)='',           --客户端的用户名，用来判断管理的账号的
    @BeginDate  datetime='2012-01-01',    --开始时间
    @StatusType int=0,                    --状态类型 11 未处理case，12 已回复case，13 关闭case，14 未关闭return 15 关闭return
    @SellerID   varchar(50)='',           --卖家ID
    @BuyerID    varchar(50)='',           --买家ID
	@CaseType   varchar(50)=''            --case类型 return暂时不查类型	
as
begin
  --先处理管理的账号
  create Table #eBayUserID 
  (
    UserID varchar(100)
  )
  --组合成查询语句，如果有ADMIN就全部账号，如果不是，就是客户管理的账号
  DECLARE @SelDataUser VARCHAR(max),       --用户管理的账号
		  @SqlCmd VARCHAR(max)             --查询语句
  if LOWER(@CurrUserID)<>'admin'
  begin
	SET @SelDataUser = ISNULL((SELECT SelDataUser FROM B_Person WHERE NID = @CurrUserID),'')
	IF (ISNULL(@SelDataUser,'') = '') 
	SET @SelDataUser = '''0'''
	SET @SqlCmd = ' insert into #eBayUserID(UserId) '
	            + ' SELECT distinct spsi.EbayUserID FROM S_PalSyncInfo ' 
				+ ' spsi WHERE SyncEbayEnable=1 and spsi.NoteName IN ('+@SelDataUser+') '  	  
  end  
  else begin
    SET @SqlCmd = ' insert into #eBayUserID(UserId) '
                + ' SELECT distinct spsi.EbayUserID FROM S_PalSyncInfo spsi ' 
				+ '  WHERE SyncEbayEnable=1 '  
  end
  --执行语句
  EXECUTE(@SqlCmd) 
  
  --组合查询case的语句
  set @SqlCmd = 'select a.NID, a.SellerID, a.CaseID, a.CaseType, '
      + ' a.CaseQuantity, a.CaseAmount, a.CurrencyId, a.CreationDate,'
      + ' a.ItemID, a.ItemTitle, a.TransactionId, a.BuyerID,'
      + ' case when a.RespondByDate=''1900-01-01 00:00:00.000'' then null'
      + ' else a.RespondByDate end  as RespondByDate,'
      + ' a.lastModifiedDate, a.Status, a.DownTime,a.Operater, a.OperateTime,'
      + ' a.globalId, a.transactionDate, a.openReason, a.initialBuyerdescription,'
      + ' a.decision, a.decisionDate, a.decisionReasondescription, a.decisionReasoncontent,'
      + ' a.FVFCredited, a.notCountedInBuyerProtectionCases, a.agreedRefundAmount, '
      + ' a.detailStatusInfodescription, a.detailStatusInfocontent, '
      + ' a.TradeNID, a.LogicName, a.LogicEnName, a.TrackNo, a.SendDate,  '
      + ' a.SKU, a.GapDays, a.SHIPTOCOUNTRYNAME, b.ORDERTIME, a.IType, '
      + ' a.ShipAmt,a.ReturnAddr,a.refundDue'  
      + ' from M_eBayCase a inner join #eBayUserID e on e.UserID=a.SellerID'
      + ' left join P_trade b on a.TradeNID = b.Nid '
      + ' where 1=1 '
  --组合条件  
  if @CaseId <> ''            --如果查询caseid不为空，那么其他条件不用
  begin
    set @SqlCmd = @SqlCmd + ' and a.CaseID = ''' + @CaseId + ''''
  end
  else begin                  --如果查询的caseid为空，那么查询其他条件
    --时间条件
    set @SqlCmd = @SqlCmd + ' and a.CreationDate > ''' + CONVERT(varchar(100),@BeginDate,121) + ''''
    --状态条件
    if @StatusType = 11       --未处理case
    begin
      set @SqlCmd = @SqlCmd + ' and a.IType = 0 and a.[Status] not in '
        + '(''CANCELLED'',''CLOSED'',''CLOSED_FVFCREDIT'',''CLOSED_NOFVFCREDIT'','
		+ '''CS_CLOSED'',''EXPIRED'',''CASE_CLOSED_CS_RESPONDED'',''PAID'',''CLOSED_FVFCREDIT_STRIKE'','
		+ '''CLOSED_FVFCREDIT_NOSTRIKE'',''CLOSED_NOFVFCREDIT_NOSTRIKE'',''CLOSED_NOFVFCREDIT_STRIKE'','
		+ '''OTHER_PARTY_RESPONSE_DUE'')'
    end
    else if @StatusType = 12  --已回复case
    begin
      set @SqlCmd = @SqlCmd + ' and a.IType = 0 and a.[Status] in '
        + '(''OTHER_PARTY_RESPONSE_DUE'')'
    end
    else if @StatusType = 13  --关闭case
    begin
      set @SqlCmd = @SqlCmd + ' and a.IType = 0 and a.[Status] in '
        + '(''CANCELLED'',''CLOSED'',''CLOSED_FVFCREDIT'',''CLOSED_NOFVFCREDIT'','
		+ '''CS_CLOSED'',''EXPIRED'',''CASE_CLOSED_CS_RESPONDED'',''PAID'',''CLOSED_FVFCREDIT_STRIKE'','
		+ '''CLOSED_FVFCREDIT_NOSTRIKE'',''CLOSED_NOFVFCREDIT_NOSTRIKE'',''CLOSED_NOFVFCREDIT_STRIKE'')'
    end
    else if @StatusType = 14  --未关闭return
    begin
      set @SqlCmd = @SqlCmd + ' and a.IType = 1 and a.[Status] not in '
        + '(''CLOSED'',''ESCALATED'')'
    end
    else if @StatusType = 15  --关闭或升级的return
    begin
      set @SqlCmd = @SqlCmd + ' and a.IType = 1 and a.[Status] in '
        + '(''CLOSED'',''ESCALATED'')'		
    end
    --卖家ID 
    if @SellerID <> '' 
    begin
      set @SqlCmd = @SqlCmd + ' and a.SellerID = ''' + @SellerID + ''''
    end
    --买家ID 
    if @BuyerID <> '' 
    begin
      set @SqlCmd = @SqlCmd + ' and a.BuyerID = ''' + @BuyerID + ''''
    end
    --case类型
    if (@CaseType <> '') and (@StatusType in (11,12,13))
    begin
      set @SqlCmd = @SqlCmd + ' and a.CaseType = ''' + @CaseType + ''''
    end         	
  end  
  
  --执行语句
  EXECUTE(@SqlCmd) 
  
  --删除临时表
  Drop Table #eBayUserID 
end
