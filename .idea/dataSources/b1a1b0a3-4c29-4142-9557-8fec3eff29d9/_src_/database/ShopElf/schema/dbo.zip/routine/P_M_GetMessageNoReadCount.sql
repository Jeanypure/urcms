
/*修改message获取未读的存储过程，让其查询表时不再锁定*/
/*修改message获取未读的存储过程，让其查询表时不再锁定*/
CREATE proc [dbo].[P_M_GetMessageNoReadCount]
	@BeginDate Varchar(20)='2012-01-01',
	@CurrUserID varchar(20)=''
as
begin
	create Table #eBayUserID 
	(
		UserID varchar(100)
	)
	DECLARE @SelDataUser VARCHAR(6000), 
		@SqlCmd VARCHAR(8000),
		@personcode VARCHAR(8000) 
	if LOWER(@CurrUserID)<>'admin'
	begin
	    set @personcode=ISNULL((SELECT PersonCode  FROM B_Person WHERE NID = @CurrUserID),'')
		SET @SelDataUser = ISNULL((SELECT SelDataUser  FROM B_Person WHERE NID = @CurrUserID),'')
		IF (ISNULL(@SelDataUser,'') = '') 
		  SET @SelDataUser = '''0'''
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1  and '+
				  ' spsi.NoteName IN ('+@SelDataUser+') '
		print @SqlCmd		  
		  EXECUTE(@SqlCmd) 
    end  
    else
    begin
        set @personcode=''
	    SET @SelDataUser = ''    --这里也赋个空值,下面的查询好用
		SET @SqlCmd = 'insert into #eBayUserID(UserId) SELECT distinct spsi.EbayUserID ' +
					' FROM S_PalSyncInfo spsi WHERE SyncEbayEnable=1   '
		EXECUTE(@SqlCmd)     
    end
    
    --查看是否设置了只显示SKU的权限管理的message
    declare @IsBySKU int = 0 
    if LOWER(@CurrUserID)<>'admin'
    begin
      set @IsBySKU = isnull ((select 1 from s_syspurview 
                       where Two_ID in (select Two_ID  from S_TwoMenus where ProjectName = 'tebaymessagefrm')
                       and USERID = @CurrUserID and PURVIEW not like '%-%'),0)
    end                   
    
    declare @fBeginDate datetime
    set @fBeginDate = DATEADD(hour,-8,@BeginDate)
  
    select x.*,(select count(case when SendStatus=2 then 1 else null end) 
           from M_ebaymessagesR(nolock) where eBayUserID = x.eBayUserID 
           and DeleteFlag = 0 and SendTime > @BeginDate) as  SendLost,
           (select count(case when SendStatus=0 then 1 else null end) 
           from M_ebaymessagesR(nolock) where eBayUserID = x.eBayUserID 
           and DeleteFlag = 0 and SendTime > @BeginDate) as  SendIng,
           (select count(case when SendStatus=1 then 1 else null end) 
           from M_ebaymessagesR(nolock) where eBayUserID = x.eBayUserID 
           and DeleteFlag = 0 and SendTime > @BeginDate) as  SendWin
        from      
		(select 
			m.eBayUserID,
			QuickNoRead=0,
			Helpcount =0,	
			Custcount =0,	
			allcount=sum(case when ReadFlag=0  and FolderID=0 then 1 else 0 end),			
			Membercount =sum(case when ReadFlag=0 and FolderID=0 and  SendToName<>'' then 1 else 0 end),
			eBaycount =sum(case when ReadFlag=0 and FolderID=0 and Sender like 'eBay%' and SendToName='' then 1 else 0 end),
			Highcount =sum(case when ReadFlag=0 and  FolderID=0 and HighPriority=1 then 1 else 0 end),
			sendcount =sum(case when  ReadFlag=0 and  FolderID=0 and  FolderID=1 then 1 else 0 end),		
			trashcount =sum(case when ReadFlag=0  and FolderID=2 then 1 else 0 end),
			archivecount =sum(case when ReadFlag=0  and FolderID=3 then 1 else 0 end)
		from M_eBayMessages(nolock) m
		inner join #eBayUserID e on e.UserID=m.eBayUserID
		where ReceiveDate>@fBeginDate
		and (LOWER(@CurrUserID)='admin' or isnull(m.sku,'') = '' or @IsBySKU = 0
		     or exists (select top 1 1 from b_goodssku(nolock) gs  
		                   inner join b_goods(nolock) g on g.nid = gs.goodsid 
		                   left join B_GoodsSKULinkShop bgsl on bgsl.SKU=gs.SKU
		                   where (g.ViewUser='' or g.ViewUser like '%,''' + @personcode + ''',%')
		                   and (gs.SKU=m.SKU or bgsl.ShopSKU=m.SKU)
		                   ))
		group by m.eBayUserID) x
		union all                  --快速视图
		select 
			'999999999',
			QuickNoRead=sum(case when ReadFlag=0  and FolderID=0 then 1 else 0 end),
			Helpcount =0,
			0,0,0,0,0,0,0,0,0,0,0
		from M_eBayMessages(nolock) m
		inner join #eBayUserID e on e.UserID=m.eBayUserID		
		where ReceiveDate>@fBeginDate	
		and (LOWER(@CurrUserID)='admin' or isnull(m.sku,'') = '' or @IsBySKU = 0
		     or exists (select top 1 1 from b_goodssku(nolock) gs  
		               inner join b_goods(nolock) g on g.nid = gs.goodsid 
		               left join B_GoodsSKULinkShop bgsl on bgsl.SKU=gs.SKU
		               where (g.ViewUser='' or g.ViewUser like '%,''' + @personcode + ''',%')
		               and (gs.SKU=m.SKU or bgsl.ShopSKU=m.SKU)
		                ))
		union all                  --请求帮助
		select 
			'999999999',
			QuickNoRead=0,
			Helpcount =sum(case when  ISNULL(helpmanid,0)<>0 then 1 else 0 end),
			0,0,0,0,0,0,0,0,0,0,0
		from M_eBayMessages(nolock) m
		inner join #eBayUserID e on e.UserID=m.eBayUserID		
		where ReceiveDate>@fBeginDate			
		union all                  --自定义文件夹
		select 
			cast(CustomFolderID+100 as varchar(10)),
			QuickNoRead=0,
			Helpcount =0,	
			Custcount =sum(case when ReadFlag=0  and isnull(CustomFolderID,0)<>0 then 1 else 0 end),
			0,0,0,0,0,0,0,0,0,0		
		from M_eBayMessages(nolock) m
		inner join #eBayUserID e on e.UserID=m.eBayUserID		
		where ReceiveDate>@fBeginDate and isnull(CustomFolderID,0)<>0	
		and (LOWER(@CurrUserID)='admin' or isnull(m.sku,'') = '' or @IsBySKU = 0
		     or exists (select top 1 1 from b_goodssku(nolock) gs  
		                 inner join b_goods(nolock) g on g.nid = gs.goodsid 
		                 left join B_GoodsSKULinkShop bgsl on bgsl.SKU=gs.SKU
		                 where (g.ViewUser='' or g.ViewUser like '%,''' + @personcode + ''',%')
		                 and (gs.SKU=m.SKU or bgsl.ShopSKU=m.SKU)
		                 ))
		group by CustomFolderID
		drop table #eBayUserID
end
