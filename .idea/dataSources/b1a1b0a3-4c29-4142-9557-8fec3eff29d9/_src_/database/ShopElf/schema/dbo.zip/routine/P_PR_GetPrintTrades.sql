CREATE PROCEDURE [dbo].[P_PR_GetPrintTrades] 
  @TradeNIDS VARCHAR(max) = '',
  @TableFlag	INT = 0, 
  @SKUCount1	INT = 0,
  @SortStr		varchar(50),
  @SortFlag		varchar(5)
AS
BEGIN	
	SET NOCOUNT ON;	
	if lower(@SortStr)='nid'
	  set @SortStr = 'm.nid';	
	SET @TradeNIDS = REPLACE(@TradeNIDS,'(','')
	SET @TradeNIDS = REPLACE(@TradeNIDS,')','')
        --如果没有逗号,前后加0和逗号
	if PATINDEX('%,%', @TradeNids) <= 0
	  SET @TradeNIDS = '0,' + @TradeNIDS + ',0'
	
	DECLARE @TradeNids_Bak  VARCHAR(max) = ''
	SET @TradeNids_Bak = @TradeNids
	CREATE TABLE #SelRecordTable
	(
		INO [int] IDENTITY(1,1) NOT NULL,
		TradeNid INT NOT NULL DEFAULT 0,
		FromAddrNID INT NOT NULL DEFAULT 0
	) 
	
    DECLARE @sSQLCmd varchar(max) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable(TradeNid) select ';
    DECLARE @fTradeNids varchar(max);
    set @fTradeNids = @TradeNids
    while (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
		SET @sSQLCmd = 'insert into #SelRecordTable(TradeNid) select '+@temp;
		EXEC(@sSQLCmd)
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 

        --IF (len(@sSQLCmd) > 44)
        --BEGIN         
        -- SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        --END else
        --BEGIN
        --  SET @sSQLCmd = @sSQLCmd + @temp 
        --END         
    
    END 
    --IF (len(@sSQLCmd) > 44)
    --EXEC(@sSQLCmd)
    --SET @sSQLCmd = 'insert into #SelRecordTable(TradeNid) select '+@TradeNids;
    --EXEC(@sSQLCmd)
    DECLARE @FromAddrCount INT = 0,@FromAddrNID INT  = 0
    SET @FromAddrCount = (SELECT ISNULL(COUNT(1),0) FROM B_HabitSet)
    IF (@FromAddrCount = 0)
    BEGIN     
      UPDATE #SelRecordTable
      SET FromAddrNID = 0
    END ELSE 
    IF (@FromAddrCount = 1)
    BEGIN
      SET @FromAddrNID = (SELECT TOP 1 HabitSetID FROM B_HabitSet)	
      UPDATE #SelRecordTable
      SET FromAddrNID = @FromAddrNID
    END ELSE 
    BEGIN    	
      SET @FromAddrNID = (SELECT TOP 1 HabitSetID FROM B_HabitSet)	
      UPDATE #SelRecordTable
      SET FromAddrNID = dbo.F_SE_GetSenderAddressNID(TradeNid,0)
    END
    --查询中国DHL小包的系统参数,挂入每个订单
    DECLARE @DHLUSER_SH varchar(500)         --DHL上海发货账号        
    set @DHLUSER_SH = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-User-SHANGHAI'),'')
    DECLARE @DHLUSER_HK varchar(500)         --DHL深圳香港发货账号
    set @DHLUSER_HK = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-User-XIANGGANG-SHENZHEN'),'')
    DECLARE @DHLPRE_SH varchar(500)          --DHL上海发货前缀 
    set @DHLPRE_SH = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Prefix-SHANGHAI'),'')
    DECLARE @DHLPRE_HK varchar(500)          --DHL深圳香港发货前缀
    set @DHLPRE_HK = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Prefix-XIANGGANG-SHENZHEN'),'')
    DECLARE @DHLSign varchar(500)            --DHL签名
    set @DHLSign = isnull((select top 1 ParaValue from B_SysParams where ParaCode = 'DHLCN-Signature'),'')
       
    --P_Trade表
    IF @TableFlag = 0
    BEGIN
      --没有选择按库位排序
      IF @SKUCount1 = 0 
      BEGIN
      	set @sSQLCmd =' SELECT '+
      		' distinct srt.ino,'+
      		'm.*,dateadd(hour,8,m.ordertime) as OrderTimeCN,  e.name as expressname, '+ 
      		'l.name as logicsWayName, '+ 
           'l.code as logicsWayCode, '+ 
           'l.FileName as printfilename, '+
           'c.CountryZnName, '+
           'l.eub, '+
           'l.ServiceCode, '+
           'l.remark as logicsWayRemark,' + 
           'ZoneCode=case when isnull((select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between  isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''') ),'''')='''' then  '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  ) '+
					'else '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''')  ) '+					
					'end	, '+				
           ' bhs.EmaillEn AS FromEmaillEn '+    
			',bhs.EMaill   AS FromEMaill '+ 
			',bhs.MobileEn AS FromMobileEn '+     
			',bhs.Mobile   AS FromMobile '+ 
			',bhs.PhoneEn  AS FromPhoneEn '+
			',bhs.Phone    AS FromPhone '+  
			',bhs.PostCodeEn AS    FromPostCodeEn '+   
			',bhs.PostCode AS FromPostCode '+     
			',bhs.StreetEn AS FromStreetEn '+     
			',bhs.Street AS  FromStreet  '+
			',bhs.AreasEn AS FromAreasEn '+
			',bhs.AreasCode AS     FromAreasCode '+    
			',bhs.Areas AS   FromAreas '+  
			',bhs.CityEn AS  FromCityEn  '+
			',bhs.CityCode AS FromCityCode  '+    
			',bhs.City AS    FromCity  '+  
			',bhs.ProvinceEn AS    FromProvinceEn '+   
			',bhs.ProvinceCode AS  FromProvinceCode '+ 
			',bhs.Province AS FromProvince '+     
			',bhs.CountryEn AS     FromCountryEn '+    
			',bhs.Country AS FromCountry '+
			',bhs.CompanyEn AS     FromCompanyEn '+    
			',bhs.Company AS FromCompany '+
			',bhs.ContactEn AS     FromContactEn '+    
			',bhs.Contact AS FromContact '+
			',bhs.HabitSetID AS    FromHabitSetID  '+  
			',bhs.EbayUrl AS FromEbayUrl '+
			',bhs.EBayUserID AS    FromEBayUserID  '+  
			',bhs.EMSPickUpType AS FromEMSPickUpType '+  
			',bhs.AddrName AS FromAddrName, '+
			'isnull(c.Area,'''') as Area, '+  
			'''' + @DHLUSER_SH + ''' as DHLUSER_SH, ' +    
			'''' + @DHLUSER_HK + ''' as DHLUSER_HK, ' +    
			'''' + @DHLPRE_SH + ''' as DHLPRE_SH, ' +    
			'''' + @DHLPRE_HK + ''' as DHLPRE_HK, ' +    
			'''' + @DHLSign + ''' as DHLSign, ' +    
			'[StockMemoTotal] ,[StoreMemoTotal] ,[SaleMemoTotal] ,[ServiceMemoTotal] , [PrintMemoTotal] ' +                
		' FROM P_Trade m JOIN #SelRecordTable srt ON m.NID = srt.TradeNid '+    
					   'LEFT JOIN T_express e ON e.nid=m.expressnid  '+  
					   ' LEFT JOIN CG_OutofStock_Total coost on coost.TradeNid= m.nid '+
					  ' LEFT JOIN B_Country c ON c.CountryCode=m.SHIPTOCOUNTRYCODE '+  
					   'LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID '+
					  ' LEFT JOIN B_HabitSet bhs  ON bhs.HabitSetID = srt.FromAddrNID '+
		' Order By srt.ino '-- + @SortStr + ' ' + @SortFlag;			  
		EXEC(@sSQLCmd)					   
      END ELSE 
      BEGIN
      	set @sSQLCmd='SELECT m.*,dateadd(hour,8,m.ordertime) as OrderTimeCN,  '+
      		' e.name as expressname, l.name as logicsWayName '+
			' ,l.code as logicsWayCode, l.FileName as printfilename,c.CountryZnName,l.eub,l.ServiceCode, '+
			'l.remark as logicsWayRemark,' + 
			' ZoneCode=case when isnull((select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between  isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''') ),'''')='''' then '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode) '+
					'else  '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''')  )	'+				
					'end, '+           
            'bhs.EmaillEn AS FromEmaillEn  '+   
			',bhs.EMaill   AS FromEMaill  '+
			',bhs.MobileEn AS FromMobileEn  '+    
			',bhs.Mobile   AS FromMobile '+
			',bhs.PhoneEn  AS FromPhoneEn '+
			',bhs.Phone    AS FromPhone '+ 
			',bhs.PostCodeEn AS    FromPostCodeEn '+   
			',bhs.PostCode AS FromPostCode  '+    
			',bhs.StreetEn AS FromStreetEn '+     
			',bhs.Street AS  FromStreet '+ 
			',bhs.AreasEn AS FromAreasEn '+
			',bhs.AreasCode AS     FromAreasCode '+    
			',bhs.Areas AS   FromAreas '+  
			',bhs.CityEn AS  FromCityEn '+ 
			',bhs.CityCode AS FromCityCode '+     
			',bhs.City AS    FromCity '+   
			',bhs.ProvinceEn AS    FromProvinceEn '+   
			',bhs.ProvinceCode AS  FromProvinceCode '+ 
			',bhs.Province AS FromProvince '+     
			',bhs.CountryEn AS     FromCountryEn '+    
			',bhs.Country AS FromCountry '+
			',bhs.CompanyEn AS     FromCompanyEn '+    
			',bhs.Company AS FromCompany '+
			',bhs.ContactEn AS     FromContactEn '+    
			',bhs.Contact AS FromContact '+
			',bhs.HabitSetID AS    FromHabitSetID '+   
			',bhs.EbayUrl AS FromEbayUrl '+
			',bhs.EBayUserID AS    FromEBayUserID '+   
			',bhs.EMSPickUpType AS FromEMSPickUpType '+  
			',bhs.AddrName AS FromAddrName,lm.LocationName,lm.sku, '+
			'isnull(c.Area,'''') as Area, '+  
			'''' + @DHLUSER_SH + ''' as DHLUSER_SH, ' +    
			'''' + @DHLUSER_HK + ''' as DHLUSER_HK, ' +    
			'''' + @DHLPRE_SH + ''' as DHLPRE_SH, ' +    
			'''' + @DHLPRE_HK + ''' as DHLPRE_HK, ' +    
			'''' + @DHLSign + ''' as DHLSign, ' + 
			'[StockMemoTotal] ,[StoreMemoTotal] ,[SaleMemoTotal] ,[ServiceMemoTotal] , [PrintMemoTotal] ' +            
		'FROM P_Trade m JOIN #SelRecordTable srt ON m.NID = srt.TradeNid '+   
		               'LEFT JOIN '+ 
						'(SELECT d.TradeNID, max(isnull(LocationName,'''')) as LocationName, d.sku  '+
						'FROM P_TradeDt d JOIN #SelRecordTable srt ON d.TradeNID = srt.TradeNid '+
						'LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID '+   
						'LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID '+
						 'AND d.StoreID = bgs.StoreID '+ 
						'LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID  '+
						'GROUP BY d.TradeNID,d.sku '+
						') as lm ON  lm.TradeNid=m.nid '+
					  ' LEFT JOIN T_express e ON e.nid=m.expressnid '+   
					  ' LEFT JOIN CG_OutofStock_Total coost on coost.TradeNid= m.nid '+
					  ' LEFT JOIN B_Country c ON c.CountryCode=m.SHIPTOCOUNTRYCODE '+  
					  ' LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID '+ 
					  ' LEFT JOIN B_HabitSet bhs  ON bhs.HabitSetID = srt.FromAddrNID '+
      	'ORDER BY lm.LocationName,lm.sku ';
      	EXEC(@sSQLCmd);
      END	
    END ELSE --P_TradeUn表
    BEGIN
     --没有选择按库位排序
      IF @SKUCount1 = 0 
      BEGIN
      	set @sSQLCmd='SELECT srt.ino,m.*,dateadd(hour,8,m.ordertime) as OrderTimeCN,  e.name as expressname, l.name as logicsWayName  '+
           ',l.code as logicsWayCode, l.FileName as printfilename,c.CountryZnName,l.eub,l.ServiceCode, '+
           'l.remark as logicsWayRemark,' + 
           'ZoneCode=case when isnull((select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between  isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''') ),'''')='''' then  '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  ) '+
					'else '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							' where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''')  ) '+					
					'end	, '+           
            'bhs.EmaillEn AS FromEmaillEn  '+   
			',bhs.EMaill   AS FromEMaill '+ 
			',bhs.MobileEn AS FromMobileEn  '+    
			',bhs.Mobile   AS FromMobile '+ 
			',bhs.PhoneEn  AS FromPhoneEn '+
			',bhs.Phone    AS FromPhone '+  
			',bhs.PostCodeEn AS    FromPostCodeEn  '+  
			',bhs.PostCode AS FromPostCode '+     
			',bhs.StreetEn AS FromStreetEn '+     
			',bhs.Street AS  FromStreet '+ 
			',bhs.AreasEn AS FromAreasEn '+
			',bhs.AreasCode AS     FromAreasCode '+    
			',bhs.Areas AS   FromAreas  '+ 
			',bhs.CityEn AS  FromCityEn '+ 
			',bhs.CityCode AS FromCityCode '+     
			',bhs.City AS    FromCity '+   
			',bhs.ProvinceEn AS    FromProvinceEn '+   
			',bhs.ProvinceCode AS  FromProvinceCode '+ 
			',bhs.Province AS FromProvince '+     
			',bhs.CountryEn AS     FromCountryEn '+    
			',bhs.Country AS FromCountry '+
			',bhs.CompanyEn AS     FromCompanyEn '+    
			',bhs.Company AS FromCompany '+
			',bhs.ContactEn AS     FromContactEn '+    
			',bhs.Contact AS FromContact '+
			',bhs.HabitSetID AS    FromHabitSetID '+   
			',bhs.EbayUrl AS FromEbayUrl '+
			',bhs.EBayUserID AS    FromEBayUserID  '+  
			',bhs.EMSPickUpType AS FromEMSPickUpType '+  
			',bhs.AddrName AS FromAddrName   , '+
			'isnull(c.Area,'''') as Area, '+  
			'''' + @DHLUSER_SH + ''' as DHLUSER_SH, ' +    
			'''' + @DHLUSER_HK + ''' as DHLUSER_HK, ' +    
			'''' + @DHLPRE_SH + ''' as DHLPRE_SH, ' +    
			'''' + @DHLPRE_HK + ''' as DHLPRE_HK, ' +    
			'''' + @DHLSign + ''' as DHLSign, ' +  
			' [StockMemoTotal] ,[StoreMemoTotal] ,[SaleMemoTotal] ,[ServiceMemoTotal] , [PrintMemoTotal] ' +                         
		'FROM P_TradeUn m JOIN #SelRecordTable srt ON m.NID = srt.TradeNid '+   
					  ' LEFT JOIN T_express e ON e.nid=m.expressnid '+  
					  ' LEFT JOIN CG_OutofStock_Total coost on coost.TradeNid= m.nid '+
					   'LEFT JOIN B_Country c ON c.CountryCode=m.SHIPTOCOUNTRYCODE '+  
					   'LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID '+ 
					   'LEFT JOIN B_HabitSet bhs  ON bhs.HabitSetID = srt.FromAddrNID  '+ 
		'order by srt.ino '-- + @SortStr + ' ' + @SortFlag;	
		EXEC(@sSQLCmd);		   
      END ELSE 
      BEGIN
      	set @sSQLCmd='SELECT m.*,dateadd(hour,8,m.ordertime) as OrderTimeCN,  e.name as expressname, l.name as logicsWayName '+ 
           ',l.code as logicsWayCode, l.FileName as printfilename,c.CountryZnName,l.eub,l.ServiceCode, '+
           'l.remark as logicsWayRemark,' + 
           'ZoneCode=case when isnull((select top 1 isnull(p4.ZoneCode,'') from B_4PXZone p4 '+ 
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode '+ 
									'and m.SHIPTOZIP between  isnull(p4.BeginZipCode,'''') and isnull(p4.EndZipCode,'''') ),'''')='''' then '+ 
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4  '+
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  ) '+
					'else '+
						'(select top 1 isnull(p4.ZoneCode,'''') from B_4PXZone p4 '+ 
							 'where p4.ServiceCode=l.ServiceCode and p4.CountryCode=m.shiptocountrycode  '+
									'and m.SHIPTOZIP between isnull(p4.BeginZipCode,'') and isnull(p4.EndZipCode,'''')  ) '+					
					'end	,'+           
            'bhs.EmaillEn AS FromEmaillEn '+    
			',bhs.EMaill   AS FromEMaill '+ 
			',bhs.MobileEn AS FromMobileEn '+     
			',bhs.Mobile   AS FromMobile '+ 
			',bhs.PhoneEn  AS FromPhoneEn '+
			',bhs.Phone    AS FromPhone '+  
			',bhs.PostCodeEn AS    FromPostCodeEn '+   
			',bhs.PostCode AS FromPostCode '+     
			',bhs.StreetEn AS FromStreetEn '+     
			',bhs.Street AS  FromStreet '+ 
			',bhs.AreasEn AS FromAreasEn '+
			',bhs.AreasCode AS     FromAreasCode '+    
			',bhs.Areas AS   FromAreas '+  
			',bhs.CityEn AS  FromCityEn '+ 
			',bhs.CityCode AS FromCityCode '+     
			',bhs.City AS    FromCity '+   
			',bhs.ProvinceEn AS    FromProvinceEn '+   
			',bhs.ProvinceCode AS  FromProvinceCode '+ 
			',bhs.Province ASFromProvince '+     
			',bhs.CountryEn AS     FromCountryEn '+    
			',bhs.Country AS FromCountry '+
			',bhs.CompanyEn AS     FromCompanyEn '+    
			',bhs.Company AS FromCompany '+
			',bhs.ContactEn AS     FromContactEn '+    
			',bhs.Contact AS FromContact '+
			',bhs.HabitSetID AS    FromHabitSetID '+   
			',bhs.EbayUrl AS FromEbayUrl '+
			',bhs.EBayUserID AS    FromEBayUserID '+   
			',bhs.EMSPickUpType AS FromEMSPickUpType '+  
			',bhs.AddrName AS FromAddrName,lm.LocationName,lm.sku, '+
			'isnull(c.Area,'''') as Area, '+  
			'''' + @DHLUSER_SH + ''' as DHLUSER_SH, ' +    
			'''' + @DHLUSER_HK + ''' as DHLUSER_HK, ' +    
			'''' + @DHLPRE_SH + ''' as DHLPRE_SH, ' +    
			'''' + @DHLPRE_HK + ''' as DHLPRE_HK, ' +    
			'''' + @DHLSign + ''' as DHLSign, ' + 
			'[StockMemoTotal] ,[StoreMemoTotal] ,[SaleMemoTotal] ,[ServiceMemoTotal] , [PrintMemoTotal] ' +                 
		'FROM P_TradeUn m JOIN #SelRecordTable srt ON m.NID = srt.TradeNid  '+   
		                ' LEFT JOIN  '+
						'(SELECT d.TradeNID, max(isnull(LocationName,'''')) as LocationName, d.sku '+ 
						'FROM P_TradeDtUn d JOIN #SelRecordTable srt ON d.TradeNID = srt.TradeNid '+
						'LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID  '+  
						'LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID '+
						' AND d.StoreID = bgs.StoreID '+ 
						'LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID '+ 
						'GROUP BY d.TradeNID,d.sku '+
						') as lm ON  lm.TradeNid=m.nid '+
					   'LEFT JOIN T_express e ON e.nid=m.expressnid  '+  
					   ' LEFT JOIN CG_OutofStock_Total coost on coost.TradeNid= m.nid '+
					   'LEFT JOIN B_Country c ON c.CountryCode=m.SHIPTOCOUNTRYCODE '+  
					   'LEFT JOIN B_LogisticWay l ON l.nid=m.logicsWayNID '+ 
					   'LEFT JOIN B_HabitSet bhs  ON bhs.HabitSetID = srt.FromAddrNID '+
		'ORDER BY lm.LocationName,lm.sku ';
		EXEC(@sSQLCmd);	
      END		
    END
   
END

