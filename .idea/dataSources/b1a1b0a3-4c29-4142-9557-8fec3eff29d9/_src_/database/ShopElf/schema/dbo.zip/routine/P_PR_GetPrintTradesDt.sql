
CREATE PROCEDURE [dbo].[P_PR_GetPrintTradesDt] (@TradeNids VARCHAR(MAX) = '', @TableFlag INT = 0)
AS
BEGIN
	SET NOCOUNT ON 
	CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
	SET @TradeNids = REPLACE(@TradeNids,')','')
	SET @TradeNids = REPLACE(@TradeNids,'(','')
        --如果没有逗号,前后加0和逗号
	if PATINDEX('%,%', @TradeNids) <= 0
	  SET @TradeNIDS = '0,' + @TradeNIDS + ',0'
	
    DECLARE @sSQLCmd varchar(MAx) = '', @temp varchar(20) = '', @index int = 0
    declare @sSql varchar(max) = '', @sortField varchar(300)
    
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    WHILE (PATINDEX('%,%', @TradeNids) > 0)
    BEGIN
      SET @index = PATINDEX('%,%', @TradeNids) - 1
      SET @temp = SubString(@TradeNids,1,@index) 
      SET @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
        IF (len(@sSQLCmd) > 35)
        BEGIN         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        END ELSE
        BEGIN
          SET @sSQLCmd = @sSQLCmd + @temp 
        END               
    END 
    IF (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
    
    set @sortField = IsNull((select paraValue from B_SysParams where ParaCode = 'PrintDtSortField'),'LocationName');
    if @sortField = '' begin
      set @sortField = 'LocationName'
    end
    if UPPER(@sortField) = 'SKU' begin 
        set @sortField = 'd.Sku';
    end
    
    IF (@TableFlag = 0)
    BEGIN
      set @sSql = '
    	SELECT  d.NID, d.TradeNID, d.L_EBAYITEMTXNID, d.L_NAME, d.L_NUMBER, d.L_QTY,d.L_SHIPPINGAMT, d.L_HANDLINGAMT,
		        d.L_CURRENCYCODE, d.L_AMT, d.L_OPTIONSNAME,d.L_OPTIONSVALUE, d.L_TAXAMT, d.SKU, d.CostPrice,
			    d.AliasCnName,d.AliasEnName, d.Weight,d.DeclaredValue, d.OriginCountry, d.OriginCountryCode, 
			    d.BmpFileName, d.GoodsName,d.GoodsSKUID,d.StoreID,d.eBaySku, LocationName,LocationOrder,gs.property1 as Goodscolor,
			    gs.property2, gs.property3,bg.GoodsCategoryID,bg.CategoryCode,bg.GoodsCode,bg.ShopTitle, bg.BarCode,
			    bg.FitCode,bg.MultiStyle,bg.Material,bg.Class,bg.Model,bg.Unit,bg.Style,bg.Brand,bg.Quantity,
			    bg.SalePrice,bg.CostPrice AS OrigCostPrice ,	 bg.[Used],bg.BmpUrl,bg.MaxNum,bg.MinNum,bg.GoodsCount,
			    bg.SupplierID,bg.SellCount,bg.SellDays,bg.Notes,bg.SampleFlag,bg.SampleCount,bg.SampleMemo,bg.CreateDate,
			    bg.GroupFlag,bg.SalerName,ISNULL(kc.Number,0) as kcnum,bg.HSCODE,d.BuyerNote,gs.SKUName,gs.remark,bg.OutNetweight,bg.OutGrossweight,
			    case when bg.IsCharged = 1 then ''是'' else ''否'' end as IsChargedName,
		       case when bg.IsPowder = 1 then ''是'' else ''否'' end as IsPowderName,
		       case when bg.IsLiquid = 1 then ''是'' else ''否'' end as IsLiquidName,
		       bg.Season,bg.PackageCount
		FROM P_TradeDt d JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid
		                 LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID   
						 LEFT JOIN B_Goods bg ON gs.GoodsID = bg.NID 
						 LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID AND d.StoreID = bgs.StoreID 
						 LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID 
						 left outer join KC_CurrentStock kc on kc.StoreID=d.StoreID and kc.GoodsSKUID=d.GoodsSKUID 
						    	and kc.goodsskuid<>0 and kc.storeid<>0 
		ORDER BY d.TradeNID,' +  @sortField
	  EXEC(@sSql)
	  	
    END ELSE 
    IF (@TableFlag = 1)
    BEGIN
      set @sSql = '
    	SELECT  d.NID, d.TradeNID, d.L_EBAYITEMTXNID, d.L_NAME, d.L_NUMBER, d.L_QTY,d.L_SHIPPINGAMT, d.L_HANDLINGAMT,
		        d.L_CURRENCYCODE, d.L_AMT, d.L_OPTIONSNAME,d.L_OPTIONSVALUE, d.L_TAXAMT, d.SKU, d.CostPrice,
			    d.AliasCnName,d.AliasEnName, d.Weight,d.DeclaredValue, d.OriginCountry, d.OriginCountryCode, 
			    d.BmpFileName, d.GoodsName,d.GoodsSKUID,d.StoreID,d.eBaySku, LocationName,LocationOrder,gs.property1 as Goodscolor,
			    gs.property2, gs.property3,bg.GoodsCategoryID,bg.CategoryCode,bg.GoodsCode,bg.ShopTitle, bg.BarCode,
			    bg.FitCode,bg.MultiStyle,bg.Material,bg.Class,bg.Model,bg.Unit,bg.Style,bg.Brand,bg.Quantity,
			    bg.SalePrice,bg.CostPrice AS OrigCostPrice ,	 bg.[Used],bg.BmpUrl,bg.MaxNum,bg.MinNum,bg.GoodsCount,
			    bg.SupplierID,bg.SellCount,bg.SellDays,bg.Notes,bg.SampleFlag,bg.SampleCount,bg.SampleMemo,bg.CreateDate,
			    bg.GroupFlag,bg.SalerName ,ISNULL(kc.Number,0) as kcnum,bg.HSCODE,d.BuyerNote,gs.SKUName,gs.remark,bg.OutNetweight,bg.OutGrossweight,
			    case when bg.IsCharged = 1 then ''是'' else ''否'' end as IsChargedName,
		       case when bg.IsPowder = 1 then ''是'' else ''否'' end as IsPowderName,
		       case when bg.IsLiquid = 1 then ''是'' else ''否'' end as IsLiquidName,
		       bg.Season,bg.PackageCount
		FROM P_TradeDtUn d JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid
		                 LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID   
						 LEFT JOIN B_Goods bg ON gs.GoodsID = bg.NID 
						 LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID AND d.StoreID = bgs.StoreID 
						 LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID 
						 left outer join KC_CurrentStock kc on kc.StoreID=d.StoreID and kc.GoodsSKUID=d.GoodsSKUID 
											and kc.goodsskuid<>0 and kc.storeid<>0 
		ORDER BY d.TradeNID, '  +  @sortField
	  EXEC(@sSql)	
    END ELSE 
    BEGIN
       set @sSql = '
       SELECT  d.NID, d.TradeNID, d.L_EBAYITEMTXNID, d.L_NAME, d.L_NUMBER, d.L_QTY,d.L_SHIPPINGAMT, d.L_HANDLINGAMT, 
			   d.L_CURRENCYCODE, d.L_AMT, d.L_OPTIONSNAME,d.L_OPTIONSVALUE, d.L_TAXAMT, d.SKU, d.CostPrice, 
			   d.AliasCnName,d.AliasEnName, d.Weight,d.DeclaredValue, d.OriginCountry, d.OriginCountryCode, 
			   d.BmpFileName, d.GoodsName,d.GoodsSKUID,d.StoreID,d.eBaySku, LocationName,LocationOrder,gs.property1 as Goodscolor,gs.property2, 
			   gs.property3,bg.GoodsCategoryID,bg.CategoryCode,bg.GoodsCode,bg.ShopTitle, bg.BarCode, bg.FitCode,bg.MultiStyle,
			   bg.Material,bg.Class,bg.Model,bg.Unit,bg.Style,bg.Brand,bg.Quantity,bg.SalePrice,bg.CostPrice AS OrigCostPrice ,
       			bg.[Used],bg.BmpUrl,bg.MaxNum,bg.MinNum,bg.GoodsCount,bg.SupplierID,bg.SellCount,bg.SellDays,bg.Notes,bg.SampleFlag,
       			bg.SampleCount,bg.SampleMemo,bg.CreateDate,bg.GroupFlag,bg.SalerName,
		       ISNULL(kc.Number,0) as kcnum,bg.HSCODE,d.BuyerNote,gs.SKUName,gs.remark,bg.OutNetweight,bg.OutGrossweight,
		       case when bg.IsCharged = 1 then ''是'' else ''否'' end as IsChargedName,
		       case when bg.IsPowder = 1 then ''是'' else ''否'' end as IsPowderName,
		       case when bg.IsLiquid = 1 then ''是'' else ''否'' end as IsLiquidName,
		       bg.Season,bg.PackageCount
       			
       FROM    (      SELECT * FROM P_TradeDt   d JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid 
                UNION SELECT * FROM P_TradeDtUn d JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid
                UNION SELECT * FROM P_TradeDt_His d JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid) d 
                          LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID   
                          LEFT JOIN B_Goods bg ON gs.GoodsID = bg.NID 
                          LEFT JOIN B_GoodsSKULocation bgs ON d.GoodsSKUID = bgs.GoodsSKUID AND d.StoreID = bgs.StoreID 
                          LEFT JOIN B_StoreLocation sl on sl.nid=bgs.LocationID    
                          left outer join KC_CurrentStock kc on kc.StoreID=d.StoreID and kc.GoodsSKUID=d.GoodsSKUID   
											and kc.goodsskuid<>0 and kc.storeid<>0   
       ORDER BY d.TradeNID, ' + @sortField
       EXEC(@sSql)		
    END
END
