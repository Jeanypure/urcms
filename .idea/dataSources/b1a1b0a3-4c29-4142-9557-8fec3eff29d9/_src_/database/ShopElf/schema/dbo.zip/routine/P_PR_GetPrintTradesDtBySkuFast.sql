 
create Proc [dbo].[P_PR_GetPrintTradesDtBySkuFast](@TradeNids VARCHAR(MAX) = '', @TableFlag INT = 0)
AS
BEGIN
	SET NOCOUNT ON 
    	SELECT  d.NID, d.TradeNID, d.L_EBAYITEMTXNID, d.L_NAME, d.L_NUMBER, d.L_QTY,d.L_SHIPPINGAMT, d.L_HANDLINGAMT,
		        d.L_CURRENCYCODE, d.L_AMT, d.L_OPTIONSNAME,d.L_OPTIONSVALUE, d.L_TAXAMT, d.SKU, d.CostPrice,
			    d.AliasCnName,d.AliasEnName, d.Weight,d.DeclaredValue, d.OriginCountry, d.OriginCountryCode, 
			    d.BmpFileName, d.GoodsName,d.GoodsSKUID,d.StoreID,d.eBaySku, 
			    LocationName = (select top 1 LocationName from B_StoreLocation A 
			                inner join B_GoodsSKULocation B on A.NID = B.LocationID and A.StoreID = B.StoreID
			                where A.StoreID = d.storeID and B.GoodsSKUID = d.GoodsSkuID),
			    gs.property1 as Goodscolor,
			    gs.property2, gs.property3,bg.GoodsCategoryID,bg.CategoryCode,bg.GoodsCode,bg.ShopTitle, bg.BarCode,
			    bg.FitCode,bg.MultiStyle,bg.Material,bg.Class,bg.Model,bg.Unit,bg.Style,bg.Brand,bg.Quantity,
			    bg.SalePrice,bg.CostPrice AS OrigCostPrice ,	 bg.[Used],bg.BmpUrl,bg.MaxNum,bg.MinNum,bg.GoodsCount,
			    bg.SupplierID,bg.SellCount,bg.SellDays,bg.Notes,bg.SampleFlag,bg.SampleCount,bg.SampleMemo,bg.CreateDate,
			    bg.GroupFlag,bg.SalerName, 0 as kcnum,bg.HSCODE,d.BuyerNote,gs.SKUName,
			    case when bg.IsCharged = 1 then '是' else '否' end as IsChargedName,
		       case when bg.IsPowder = 1 then '是' else '否' end as IsPowderName,
		       case when bg.IsLiquid = 1 then '是' else '否' end as IsLiquidName,
		       bg.Season,bg.PackageCount
		FROM P_TradeDt d 
		--JOIN #SelRecordTable srt ON  d.TradeNID = srt.TradeNid
		                 LEFT JOIN B_GoodsSKU gs on gs.nid=d.GoodsskuID   
						 LEFT JOIN B_Goods bg ON gs.GoodsID = bg.NID 
		where d.TradeNID=@TradeNids
		ORDER BY d.TradeNID
END
