CREATE PROCEDURE [P_PR_PromotionalAutoNext]
AS
BEGIN
SELECT 
	distinct
	m.[NID]
      ,m.[SellerID]
      ,m.[SaleID]
      ,m.[SaleName]
      ,m.[Status]
      ,m.[DiscountType]
      ,m.[DiscountValue]
      ,NewStartTime = DATEADD(MI,12,m.EndTime)
      ,NewEndTime = DATEADD(MI,DATEDIFF(MI,m.starttime,m.endtime)+12, m.EndTime)
      ,m.[SaleType]
      ,m.[IAuto]
      ,m.[NewPromotionalID]
      ,Daycount=m.EndTime-m.StartTime
      ,ebaytoken=isnull((select top 1  EbayTOKEN from S_PalSyncInfo where EbayUserID=m.SellerID),'')
  FROM [PR_PromotionalsDetail] d 
  inner join PR_Promotionals m on m.SaleID= d.SaleID
  where 
    m.iauto=1 and
	isnull(m.NewPromotionalID,'')='' and 
	(DATEDIFF(dd, m.EndTime,getdate())<8 
	or DATEDIFF(dd, m.EndTime,getdate())>-8 )	
end

