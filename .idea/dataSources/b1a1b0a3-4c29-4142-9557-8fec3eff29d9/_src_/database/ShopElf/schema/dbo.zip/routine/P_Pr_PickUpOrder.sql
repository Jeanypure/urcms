--加停售及SKUName 20161111
CREATE PROCEDURE [dbo].[P_Pr_PickUpOrder] 
	@TradeNids VARCHAR(Max) = '', 
	@TableFlag INT = 0,
	@PickupNo	varchar(50) =''
AS
BEGIN
	set nocount on 
	CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
	SET @TradeNids = REPLACE(@TradeNids,')','')
	SET @TradeNids = REPLACE(@TradeNids,'(','')
    DECLARE @sSQLCmd varchar(MAx) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    while (PATINDEX('%,%', @TradeNids) > 0)
    begin
      set @index = PATINDEX('%,%', @TradeNids) - 1
      set @temp = SubString(@TradeNids,1,@index) 
      set @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
     
      --if (LEN(@sSQLCmd)> 7500)
      --begin
      --  EXEC(@sSQLCmd)
      --  SET @sSQLCmd = 'insert into #SelRecordTable select ';
      --end 
      --else 
      --begin 
        if (len(@sSQLCmd) > 35)
        begin         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        end else
        begin
          SET @sSQLCmd = @sSQLCmd + @temp 
        end         
      --end      
    end 
    if (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
    
    CREATE TABLE #temp
	(
		L_NAME VARCHAR(1000)  DEFAULT '',
		GoodsName VARCHAR(2000)  DEFAULT '',
		SKU VARCHAR(1000)  DEFAULT '',
		AliasCnName VARCHAR(1000) DEFAULT '',
		BmpFileName VARCHAR(1000)  DEFAULT '',
		GoodsSKUID INT  DEFAULT 0,
		StoreID INT  DEFAULT 0,
		L_QTY NUMERIC(10,2)  DEFAULT 0,
	) 
	
    IF ISNULL(@TableFlag,0) = 0
    BEGIN 
		--提取显示数据
		INSERT INTO #temp(L_NAME,GoodsName,SKU,AliasCnName,BmpFileName,GoodsSKUID,StoreID,L_QTY)
		SELECT MAx(L_NAME) as L_NAME ,Max(isnull(GoodsName,'')) as GoodsName,SKU , Max(isnull(AliasCnName,'')) as AliasCnName 
			  ,Max(BmpFileName) AS BmpFileName , isnull(GoodsSKUID,0), isnull(StoreID,0), SUM(L_QTY) AS L_QTY
		FROM P_TradeDt ptd JOIN #SelRecordTable srt ON ptd.TradeNID = srt.TradeNid
		GROUP BY isnull(GoodsSKUID,0),SKU,isnull(StoreID,0)
	END ELSE 
	BEGIN 
		--提取显示数据
		INSERT INTO #temp(L_NAME,GoodsName,SKU,AliasCnName,BmpFileName,GoodsSKUID,StoreID,L_QTY)
		SELECT MAx(L_NAME) as L_NAME ,Max(GoodsName) as GoodsName,SKU , Max(AliasCnName) as AliasCnName 
			  ,Max(BmpFileName) AS BmpFileName , isnull(GoodsSKUID,0), isnull(StoreID,0), SUM(L_QTY) AS L_QTY
		FROM P_TradeDtUn ptd JOIN #SelRecordTable srt ON ptd.TradeNID = srt.TradeNid
		GROUP BY  isnull(GoodsSKUID,0),SKU,isnull(StoreID,0)
	END  
    
    --库位排序规则
    DECLARE @StoreLocationSort varchar(50) = ''
    set @StoreLocationSort = isnull((select ParaValue from B_SysParams where ParaCode = 'Print-StoreLocationSort'),'0')
    
	--数据显示
	set @sSQLCmd = 'SELECT 
			'''+@PickupNo+''' as PickupNo
			,tp.L_NAME
		  ,tp.GoodsName
		  ,tp.SKU
		  ,tp.AliasCnName
		  ,tp.BmpFIleName
		  ,tp.GoodsSKUID
		  ,tp.StoreID
		  ,tp.L_QTY
		  ,bg.CategoryCode
		  ,bg.GoodsCode
		  ,bg.GoodsName
		  ,bg.ShopTitle
		  ,bg.SKU
		  ,bg.BarCode
		  ,bg.FitCode
		  ,bg.MultiStyle
		  ,bg.Material
		  ,bg.Class
		  ,bg.Model
		  ,bg.Unit
		  ,bg.Style
		  ,bg.Brand
		  ,bg.Quantity
		  ,bg.SalePrice
		  ,bg.CostPrice
		  ,bg.[Weight]
		  ,bg.DeclaredValue
		  ,bg.OriginCountry
		  ,bg.OriginCountryCode
		  ,bg.MaxNum
		  ,bg.MinNum
		  ,bg.GoodsCount
		  ,bg.Notes
		  ,bg.SampleFlag
		  ,bg.SampleCount
		  ,bg.SampleMemo
		  ,bg.CreateDate
		  ,bg.GroupFlag
		  ,bg.SalerName
		  ,bg.SellCount
		  ,bg.SellDays
		  ,bg.PackFee
		  ,bg.PackName
		  ,bg.GoodsStatus
		  ,bg.DevDate
		  ,bg.SalerName2
		  ,bg.BatchPrice
		  ,bg.MaxSalePrice
		  ,bg.RetailPrice
		  ,bg.MarketPrice
		  ,bg.PackageCount
		  ,bg.ChangeStatusTime
		  ,bg.StockDays
		  ,bsl.LocationName
		  ,bsl.LocationOrder
		  ,bgs.property1
		  ,bgs.property2	
		  ,bgs.property3
		  ,bgs.skuname
		  ,bg.Used	  
		  ,isnull(s.SupplierName,'''') as 	SupplierName
		  ,ISNULL(ks.Number,0) as kcnumber   
	FROM #temp tp left outer JOIN B_GoodsSKU bgs ON tp.GoodsSKUID= bgs.NID
						   left outer JOIN B_Goods bg ON bg.NID = bgs.GoodsID
						   left outer join B_Supplier s on s.NID=bg.SupplierID
						   LEFT outer JOIN B_GoodsSKULocation bgs2 ON bgs2.GoodsSKUID = tp.GoodsSKUID AND bgs2.StoreID = tp.StoreID
						   LEFT outer JOIN B_StoreLocation bsl ON bsl.NID = bgs2.LocationID
						   LEFT outer JOIN KC_CurrentStock ks ON tp.GoodsSKUID =ks.GoodsSKUID AND ks.StoreID = tp.StoreID'
	if @StoreLocationSort = '1'       --按照拣货顺序-数字排序
	  set @sSQLCmd = @sSQLCmd + ' ORDER BY case when isnumeric(isnull(bsl.LocationOrder,'''')) = 1 then cast(bsl.LocationOrder as float) else 0 end, tp.sku'
	else if @StoreLocationSort = '2'  --按照拣货顺序-文字排序
	  set @sSQLCmd = @sSQLCmd + ' ORDER BY ISNULL(bsl.LocationOrder,''''), tp.sku' 
	else                              --按照库位名称排序
	  set @sSQLCmd = @sSQLCmd + ' ORDER BY  ISNULL(bsl.LocationName,''''), tp.sku' 
	  
	EXEC(@sSQLCmd)     
	DROP TABLE #temp
END
