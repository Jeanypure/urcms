
create Proc [dbo].[P_Pr_PickUpOrderBySkuFast] @TradeNid VARCHAR(100) = '', @TableFlag INT = 0
AS
BEGIN
 
    CREATE TABLE #temp
	(
		L_NAME VARCHAR(1000)  DEFAULT '',
		GoodsName VARCHAR(2000)  DEFAULT '',
		SKU VARCHAR(1000)  DEFAULT '',
		AliasCnName VARCHAR(1000) DEFAULT '',
		BmpFileName VARCHAR(1000)  DEFAULT '',
		GoodsSKUID INT  DEFAULT 0,
		StoreID INT  DEFAULT 0,
		L_QTY NUMERIC(10,2)  DEFAULT 0,
	) 
	
 
		--提取显示数据
		INSERT INTO #temp(L_NAME,GoodsName,SKU,AliasCnName,BmpFileName,GoodsSKUID,StoreID,L_QTY)
		SELECT MAx(L_NAME) as L_NAME ,Max(isnull(GoodsName,'')) as GoodsName,SKU , Max(isnull(AliasCnName,'')) as AliasCnName 
			  ,Max(BmpFileName) AS BmpFileName , isnull(GoodsSKUID,0), isnull(StoreID,0), SUM(L_QTY) AS L_QTY
		FROM P_TradeDt ptd  
		where ptd.TradeNID = @TradeNid
		GROUP BY isnull(GoodsSKUID,0),SKU,isnull(StoreID,0)
	 

	--数据显示
	SELECT tp.L_NAME
		  ,tp.GoodsName
		  ,tp.SKU
		  ,tp.AliasCnName
		  ,tp.BmpFIleName
		  ,tp.GoodsSKUID
		  ,tp.StoreID
		  ,tp.L_QTY
		  ,bg.CategoryCode
		  ,bg.GoodsCode
		  ,bg.GoodsName
		  ,bg.ShopTitle
		  ,bg.SKU
		  ,bg.BarCode
		  ,bg.FitCode
		  ,bg.MultiStyle
		  ,bg.Material
		  ,bg.Class
		  ,bg.Model
		  ,bg.Unit
		  ,bg.Style
		  ,bg.Brand
		  ,bg.Quantity
		  ,bg.SalePrice
		  ,bg.CostPrice
		  ,bg.[Weight]
		  ,bg.DeclaredValue
		  ,bg.OriginCountry
		  ,bg.OriginCountryCode
		  ,bg.MaxNum
		  ,bg.MinNum
		  ,bg.GoodsCount
		  ,bg.Notes
		  ,bg.SampleFlag
		  ,bg.SampleCount
		  ,bg.SampleMemo
		  ,bg.CreateDate
		  ,bg.GroupFlag
		  ,bg.SalerName
		  ,bg.SellCount
		  ,bg.SellDays
		  ,bg.PackFee
		  ,bg.PackName
		  ,bg.GoodsStatus
		  ,bg.DevDate
		  ,bg.SalerName2
		  ,bg.BatchPrice
		  ,bg.MaxSalePrice
		  ,bg.RetailPrice
		  ,bg.MarketPrice
		  ,bg.PackageCount
		  ,bg.ChangeStatusTime
		  ,bg.StockDays
		  ,bsl.LocationName
		  ,bgs.property1
		  ,bgs.property2	
		  ,bgs.property3
		  ,isnull(s.SupplierName,'') as 	SupplierName
		  , 0 as kcnumber
		  -- ,ISNULL(ks.Number,0) as kcnumber 	    
	FROM #temp tp left outer JOIN B_GoodsSKU bgs ON tp.GoodsSKUID= bgs.NID
						   left outer JOIN B_Goods bg ON bg.NID = bgs.GoodsID
						   left outer join B_Supplier s on s.NID=bg.SupplierID
						   LEFT outer JOIN B_GoodsSKULocation bgs2 ON bgs2.GoodsSKUID = tp.GoodsSKUID AND bgs2.StoreID = tp.StoreID
						   LEFT outer JOIN B_StoreLocation bsl ON bsl.NID = bgs2.LocationID
						--   LEFT outer JOIN KC_CurrentStock ks ON tp.GoodsSKUID =ks.GoodsSKUID AND ks.StoreID = bgs2.StoreID
	ORDER BY ISNULL(bsl.LocationName,''), tp.sku
	DROP TABLE #temp
END
