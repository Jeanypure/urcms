
CREATE PROCEDURE [P_PurBillPartSearch] 
                               @PurLevel INT = 0,
                               @chkNoShowPur INT = 0,
                               @SelType INT = 0,  --0:查缺货信息；1:查采购员;2:查供应商
                               @Purchaser VARCHAR(100) = '',
                               @SupplierName VARCHAR(100) = '',
                               @StoreID INT = 0,
                               @GoodsSKUs VARCHAR(MAX) = ''
                               
                                 
AS
BEGIN

	set nocount off	
	CREATE TABLE #SelRecordTable
	(
		GoodsSKUID INT NOT NULL DEFAULT 0,
	) 
    DECLARE @sSQLCmd varchar(max) = '', @temp varchar(20) = '', @index int = 0
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    while (PATINDEX('%,%', @GoodsSKUs) > 0)
    begin
      set @index = PATINDEX('%,%', @GoodsSKUs) - 1
      set @temp = SubString(@GoodsSKUs,1,@index) 
      set @GoodsSKUs = SUBSTRING(@GoodsSKUs,@index+2,LEN(@GoodsSKUs)- @index+2) 
     
      if (LEN(@sSQLCmd)> 7500)
      begin
        exec(@sSQLCmd)
        SET @sSQLCmd = 'insert into #SelRecordTable select ';
      end 
      else 
      begin 
        if (len(@sSQLCmd) > 35)
        begin         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        end else
        begin
          SET @sSQLCmd = @sSQLCmd + @temp 
        end         
      end      
    end 
    if (len(@sSQLCmd) > 35)
    exec(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@GoodsSKUs;
    exec(@sSQLCmd)
    
  /*1.生成商品表结构*/
	CREATE TABLE #SaleTable
	(  GoodsSKUID INT ,
	   SaleNum NUMERIC(18,2),
	   SaleRenum int,--缺货占用
	   StoreID INT)			  
		  				
	/*3.生成所有销售未派单的商品表*/	
	INSERT INTO #SaleTable
	SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum,SUM(SaleRenum) as SaleRenum,StoreID 	
	FROM (  --未派单的销售商品 和  数量(Trade)
		    SELECT ISNULL(gs.NID,0) as GoodsSKUID, SUM(ptd.L_QTY) AS SaleNum,0 as SaleRenum,
					ISNULL(ptd.StoreID,0)AS StoreID
	        FROM P_TradeDt(nolock) ptd 
	        left outer join B_GoodsSKU(nolock) gs on gs.SKU=ptd.SKU	        
	        WHERE ptd.TradeNID IN ( SELECT pt.NID 
	                                FROM P_Trade(nolock) pt               
	                                WHERE pt.FilterFlag <= 5 )
	       GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
	UNION  all --异常单的销售商品 和   数量(TradeUn)
	       SELECT ISNULL(gs.NID,0) as GoodsSKUID, SUM(ptdu.L_QTY) AS SaleNum ,
	       SUM( Case when pt.RestoreStock=-1 then  ptdu.L_QTY else 0 end) as SaleRenum,
	       ISNULL(ptdu.StoreID,0) AS StoreID
	       FROM P_TradeDtUn(nolock) ptdu 
	       inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID 
	       left outer join B_GoodsSKU(nolock) gs on gs.SKU=ptdu.SKU
	       WHERE pt.FilterFlag = 1 /* ptdu.TradeNID IN ( SELECT pt.NID 
	                                 FROM P_Tradeun pt 
	                                 WHERE (pt.FilterFlag = 1) OR (pt.FilterFlag = 0 AND pt.PAYMENTSTATUS IN ('Completed','Pending') )) */
	          
	       GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0) 
	     ) AS C
	GROUP BY GoodsSKUID,StoreID
	
    DELETE FROM #SaleTable WHERE GoodsSKUID NOT IN (SELECT GoodsSKUID FROM #SelRecordTable )	
	--默认发货仓库
	DECLARE @DefStoreID INT = 0 
	SET @DefStoreID = (SELECT TOP 1 NID FROM B_Store
					   WHERE StoreName = (SELECT TOP 1 ParaValue
										  FROM B_SysParams WHERE ParaCode = 'DefaultSendStock'))
										  
	 update CG_StockOrderM set  StoreID = @DefStoreID  where ISNULL(StoreID,0) = 0
										  
	--将没有仓库的更新成默认发货仓库
     UPDATE #SaleTable SET StoreID = @DefStoreID WHERE ISNULL(StoreID,0) = 0	
	
	
	
	CREATE TABLE #CgBillNumber(	GoodsSKUID		int,
									BillNumber	varchar(50),
									cgAmount	Float default 0,									
									InAmount	Float default 0,
	                                StoreID     INT DEFAULT 0)
									
  CREATE TABLE #StockOrderCount(GoodsSKUID VARCHAR(100) DEFAULT '' ,
									cgAmount	Float default 0,									
									InAmount	Float default 0,
                             storeid int default 0 )                             
                            
  
  insert into  #CgBillNumber (GoodsSKUID,billnumber,cgAmount,InAmount,storeid)    
    SELECT csod.GoodsSKUID,csom.billnumber, sum(csod.Amount),sum(csod.InAmount)-isnull((select SUM(isnull(id.amount,0)) from CG_StockInD id 
					  inner join CG_StockInM im on im.NID=id.StockInNID where 
	 id.GoodsSKUID= csod.GoodsSKUID and im.StockOrder=csom.Billnumber and im.CheckFlag=0 ),0), csom.StoreID
    FROM  CG_StockOrderD csod 
    inner join  CG_StockOrderM csom  ON csom.NID = csod.StockOrderNID
    inner join #SelRecordTable st on st.GoodsSKUID=csod.GoodsSKUID
    WHERE csom.CheckFlag = 1 and csom.archive=0	--and csod.InAmount<csod.Amount 
    group by csod.GoodsSKUID,csom.billnumber,csom.StoreID
                        
       
  insert into  #StockOrderCount (GoodsSKUID,cgAmount,InAmount,storeid)    
    SELECT GoodsSKUID, sum(cgAmount),sum(InAmount),StoreID
    FROM  #CgBillNumber 
    group by GoodsSKUID,StoreID
    	
  
  DELETE FROM #StockOrderCount WHERE ISNULL(cgAmount,0) <= ISNULL(InAmount,0) 
  SELECT st.GoodsSKUID, --商品GoodsSKU 
	       st.SaleNum,       --卖出数量
	       (IsNull(kcs.Number,0) - ISNULL(kcs.ReservationNum,0)+ISNULL(st.SaleRenum,0)) AS CurrentNum, --当前仓库可用数量
	       (IsNull(SUM(ISNULL(soc.cgAmount,0) - IsNUll(soc.InAmount,0)),0)) AS NotInStockNum,        --采购未入库数量
	       st.StoreID
  INTO #SaleAndCurrTable
  FROM #SaleTable st LEFT JOIN KC_CurrentStock(nolock) kcs ON  st.GoodsSKUID = kcs.GoodsSKUID AND st.StoreID = kcs.StoreID
                     LEFT JOIN #StockOrderCount soc ON st.GoodsSKUID = soc.GoodsSKUID AND st.StoreID =soc.StoreID
  GROUP BY st.GoodsSKUID, st.SaleNum,ISNULL(st.SaleRenum,0),IsNull(kcs.Number,0),ISNULL(kcs.ReservationNum,0),st.StoreID
  
  	
  --仓库标记缺货的，强硬加进去，并且不做库存判断,后面加入仓库标记缺货
  SELECT SUM(L_QTY) AS SaleNum,ptd.GoodsSKUID,ptd.StoreID
  INTO #WaitPackage
  FROM P_Trade pt JOIN P_TradeDt ptd ON pt.NID = ptd.TradeNID 
  WHERE  pt.FilterFlag = 26 AND ptd.L_SHIPPINGAMT = 1
  GROUP BY ptd.GoodsSKUID,ptd.StoreID
  
  --合并销售数量
  UPDATE st
  SET st.SaleNum = st.SaleNum + wp.SaleNum
  FROM #SaleAndCurrTable st JOIN #WaitPackage wp ON st.GoodsSKUID = wp.GoodsSKUID AND st.StoreID = wp.StoreID
  --插入不存在产品
  INSERT INTO #SaleAndCurrTable(GoodsSKUID,SaleNum,CurrentNum,NotInStockNum,StoreID)
  SELECT GoodsSKUID,SaleNum,0,0,StoreID
  FROM #WaitPackage wp
  WHERE wp.GoodsSKUID NOT IN (SELECT GoodsSKUID FROM #SaleTable) AND wp.StoreID NOT IN (SELECT StoreID FROM #SaleTable)
		
  DROP TABLE #WaitPackage					
  
  SELECT * 
  INTO #PurGoodsTable
  FROM #SaleAndCurrTable 
  WHERE (SaleNum >= (CurrentNum )) AND  (GoodsSKUID <>0)


--8.查询					
	SELECT 
	    0 AS SelFlag,  		gs.SKU,		    gs.property1,		gs.property2,		gs.property3,
		b.BarCode,		    b.goodscode,	b.goodsname,		b.model,		    b.unit,b.goodsstatus,
		b.class,b.Style,b.Material,	     	
		case when ISNULL(d.KcMaxNum,0)>0 then d.KcMaxNum else  gs.maxnum end as maxnum,		
		case when ISNULL(d.KcMinNum,0)>0 then d.KcMinNum else  gs.minnum end as minnum,				   
		 b.SupplierID,		p.CategoryID
       ,p.SupplierCode,p.SupplierName,p.FitCode,p.LinkMan,p.[Address],p.OfficePhone,p.Mobile,p.Recorder
       ,p.InputDate,p.Modifier,p.ModifyDate,p.Email,p.QQ,p.MSN,p.ArrivalDays,p.URL,p.Memo,p.Account,
		s.storeName,		g.StoreID,		d.GoodsID,		   g.GoodsSKUID,		d.Number,
		d.ReservationNum,	g.CurrentNum,	g.SaleNum,	       g.NotInStockNum,
                isnull(b.Used,0) as used,
		(Isnull(g.SaleNum,0) - Isnull(g.CurrentNum,0) - ISNULL(g.NotInStockNum,0)  ) AS LessNum,	                b.BmpFileName,       
		(SELECT TOP 1 bsl.LocationName FROM B_StoreLocation bsl
		   inner join B_GoodsSKULocation bgsl on bsl.NID = bgsl.LocationID
		   WHERE bgsl.GoodsSKUID = g.GoodsSKUID and bgsl.StoreID = g.StoreID) AS LocationName,
		 b.Purchaser,b.LinkUrl,
		 case when ISNULL(d.SellCount1,0)>0 then d.SellCount1 else ISNULL(gs.SellCount1,0) end AS SellCount1,
		 case when ISNULL(d.SellCount2,0)>0 then d.SellCount2 else ISNULL(gs.SellCount2,0) end  AS SellCount2,
		 case when ISNULL(d.SellCount3,0)>0 then d.SellCount3 else ISNULL(gs.SellCount3,0) end AS SellCount3,
		 (Isnull(g.SaleNum,0) - Isnull(g.CurrentNum,0) - ISNULL(g.NotInStockNum,0)  ) AS PurCount,gs.NID,
		 CASE WHEN ISNULL(b.StoreID,0) =0 THEN '' 
		      ELSE  (SELECT bs.StoreName  FROM B_Store bs WHERE bs.NID = b.StoreID)
		 END AS SendStore,
		 case when isnull(gs.CostPrice,0)<>0 then gs.CostPrice else b.CostPrice end as costprice,
		 --add by ylq 2015-04-08 最大延长天数
		 isnull((select max(DATEDIFF(DAY,Dateadd(hour,8,bb.ORDERTIME), GETDATE())) 
		   from P_TradeDtUn aa left join P_TradeUn bb on aa.TradeNID = bb.NID  
		   where bb.FilterFlag = 1 and aa.SKU=gs.SKU),0) as MaxDelayDays,
		 --add by ylq 2015-08-27  
		 gs.SKUName, b.ItemUrl
	INTO #Temp	 
	FROM #PurGoodsTable g  LEFT JOIN KC_CurrentStock(nolock) D ON g.GoodsSKUID = d.GoodsSKUID AND g.StoreID = d.StoreID	
						   LEFT  JOIN B_Store  s         ON s.NID = g.StoreID	                       
	                       LEFT  JOIN B_GoodsSKU(nolock) gs    ON gs.NID = g.GoodsSKUID				
	                       LEFT  JOIN B_Goods b        ON b.NID = gs.GoodsID	
	                       LEFT  JOIN  B_Supplier p     ON p.NID=b.SupplierID
	WHERE  ISNULL(b.GoodsCode,'') <> ''	
	DELETE FROM #Temp WHERE Isnull(SaleNum,0) - Isnull(CurrentNum,0) =0 and ISNULL(NotInStockNum,0)=0	
	IF ISNULL(@chkNoShowPur,0) = 1
    BEGIN
      DELETE FROM #Temp WHERE LessNum <= 0 	
    END
    IF (@SelType = 0)
      SELECT * FROM #Temp
       WHERE ((ISNULL(@Purchaser,'') = '') OR (Purchaser = @Purchaser)) AND ((ISNULL(@SupplierName,'') = '') OR (SupplierName = @SupplierName)) 
        AND ((ISNULL(@StoreID,0) = 0) OR (StoreID = @StoreID))  
      order by sku                          
    ELSE
    IF (@SelType = 1)
      SELECT DISTINCT Purchaser FROM #Temp WHERE    ((ISNULL(@StoreID,0) = 0) OR (StoreID = @StoreID)) 	 
    ELSE
    IF (@SelType = 2)
      SELECT DISTINCT SupplierName FROM #Temp WHERE    ((ISNULL(@StoreID,0) = 0) OR (StoreID = @StoreID))    
      
      
	DROP TABLE #SaleTable
	DROP TABLE #SelRecordTable	
    DROP TABLE #StockOrderCount
    
    DROP TABLE #SaleAndCurrTable
    
	DROP TABLE #PurGoodsTable

	DROP TABLE #Temp
	set nocount on
	
END
