
CREATE proc [P_PurBillSearch]

                               @PurLevel INT = 0,
                               @chkNoShowPur INT = 0,
                               @SelType INT = 0,  --0:查缺货信息；1:查采购员;2:查供应商
                               @Purchaser VARCHAR(100) = '',
                               @SupplierName VARCHAR(100) = '',
                               @SKU VARCHAR(max) = '',
                               @StoreID INT = 0,
                               @ItemInfoKeyWord VARCHAR(100) = '',  --商品信息关键字 模糊查询
                               @IsMoHuSku int = 0
                               
AS
BEGIN
	set nocount off
	
	declare  
      @SqlStr varchar(max),
      @begindate date,
      @enddate date,
      @maxdays int=200
      
       create table #tianshu  --天数表
     (DictionaryName varchar(10),
      nid int
     ) 
     
     set @enddate = GETDATE()
     set @maxdays = (select ParaValue from B_SysParams where ParaCode='PurBillMaxDays')
     set @begindate = dateadd(day,0-@maxdays,getdate())
     
     
 insert into #tianshu(DictionaryName,nid)    
SELECT 

 TOP 3 DictionaryName ,
 ROW_NUMBER() OVER (ORDER BY FitCode) as nid
	FROM B_Dictionary 
	WHERE CategoryID in (SELECT NID FROM B_DictionaryCats 
                          WHERE CategoryName='库存预警销量天数') 
	ORDER BY FitCode
      
  
  
  declare 
  @sellday1 int,
  @sellday2 int,
  @sellday3 int
  
  set @sellday1= (select DictionaryName  from #tianshu where nid=1)
  set @sellday2=(select DictionaryName  from #tianshu where nid=2)
  set @sellday3=(select DictionaryName  from #tianshu where nid=3)
      
  /*1.生成商品表结构*/
	CREATE TABLE #SaleTable
	(  GoodsSKUID INT ,
	   SaleNum NUMERIC(18,2),
	   SaleRenum int,--缺货占用
	   StoreID INT)		
	   
	Create Table #SkuTable
	(
	  Sku varchar(64) 
	)
	
	if @IsMoHuSku = 0
	begin
	  SET @SqlStr = 'insert into #SkuTable(Sku) select ''' + Replace(@SKU, ',', ''' union select ''')
	  set @SqlStr = @SqlStr + ''''
	  EXEC(@SqlStr)
	end 
		  
		  				
	/*3.生成所有销售未派单的商品表*/	
	INSERT INTO #SaleTable
	SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum,SUM(SaleRenum) as SaleRenum, StoreID 	
	FROM (  --未派单的销售商品 和  数量(Trade)
		    SELECT ISNULL(gs.NID,0) as GoodsSKUID, SUM(ptd.L_QTY) AS SaleNum,0 as SaleRenum,ISNULL(ptd.StoreID,0)AS StoreID
	        FROM P_TradeDt(nolock) ptd 
	        left outer join B_GoodsSKU gs on gs.SKU=ptd.SKU	        
	        WHERE ptd.TradeNID IN ( SELECT pt.NID 
	                                FROM P_Trade(nolock) pt               
	                                WHERE pt.FilterFlag <= 5 and convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121))
	              and ((@SKU='' or (ptd.SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0)) or
	                   ((ptd.SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
	              
	       GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
	UNION all  --异常单的销售商品 和   数量(TradeUn)
	       SELECT 
					ISNULL(gs.NID,0) as GoodsSKUID, SUM( ptdu.L_QTY) AS SaleNum ,
					SUM( Case when pt.RestoreStock=-1 then  ptdu.L_QTY else 0 end) as SaleRenum, 
					ISNULL(ptdu.StoreID,0) AS StoreID
	       FROM P_TradeDtUn(nolock) ptdu 
	       inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID and   convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121)
	       left outer join B_GoodsSKU gs on gs.SKU=ptdu.SKU
	       WHERE pt.FilterFlag = 1 /* ptdu.TradeNID IN ( SELECT pt.NID 
	                                 FROM P_Tradeun pt 
	                                 WHERE (pt.FilterFlag = 1) OR (pt.FilterFlag = 0 AND pt.PAYMENTSTATUS IN ('Completed','Pending') )) */
	             --and (@SKU='' or ptdu.SKU=@SKU) 
	             and ((@SKU='' or (ptdu.SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0)) or
	                   ((ptdu.SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
	                                            
	       GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0) 
	     ) AS C
	GROUP BY GoodsSKUID,StoreID	
	--默认发货仓库
	DECLARE @DefStoreID INT = 0 
	SET @DefStoreID = (SELECT TOP 1 NID FROM B_Store
					   WHERE StoreName = (SELECT TOP 1 ParaValue
										  FROM B_SysParams WHERE ParaCode = 'DefaultSendStock'))
										  
	 update CG_StockOrderM set  StoreID = @DefStoreID  where ISNULL(StoreID,0) = 0
										  
	--将没有仓库的更新成默认发货仓库
     UPDATE #SaleTable SET StoreID = @DefStoreID WHERE ISNULL(StoreID,0) = 0	
	
	
	
	CREATE TABLE #CgBillNumber(	GoodsSKUID		int,
									BillNumber	varchar(50),
									cgAmount	Float default 0,								

	
									InAmount	Float default 0,
	                                StoreID     INT DEFAULT 0)
									
  CREATE TABLE #StockOrderCount(GoodsSKUID VARCHAR(100) DEFAULT '' ,
									cgAmount	Float default 0,								

	
									InAmount	Float default 0,
                             storeid int default 0 )                             
                             
  
  insert into  #CgBillNumber (GoodsSKUID,billnumber,cgAmount,InAmount,storeid)    
    SELECT csod.GoodsSKUID,csom.billnumber, sum(csod.Amount),sum(csod.InAmount)-isnull((select SUM(isnull(id.amount,0)) from CG_StockInD id 
					  inner join CG_StockInM im on im.NID=id.StockInNID where 
	 id.GoodsSKUID= csod.GoodsSKUID and im.StockOrder=csom.Billnumber and im.CheckFlag=0 ),0), csom.StoreID
    FROM  CG_StockOrderD csod 
    inner join  CG_StockOrderM csom  ON csom.NID = csod.StockOrderNID
    --inner join  #SaleTable ss on ss.GoodsSKUID=csod.GoodsSKUID and ss.StoreID = csom.StoreID
    WHERE csom.CheckFlag = 1 and csom.archive=0	--and csod.InAmount<csod.Amount 
    group by csod.GoodsSKUID,csom.billnumber,csom.StoreID
                        
  --容错处理，入库数量超过采购数量的，入库数量变成采购数量
  update a set a.InAmount = case when a.cgamount < a.InAmount then a.cgAmount else a.InAmount end  from #CgBillNumber a          

  insert into  #StockOrderCount (GoodsSKUID,cgAmount,InAmount,storeid)    
    SELECT GoodsSKUID, sum(cgAmount),sum(InAmount),StoreID
    FROM  #CgBillNumber 
    group by GoodsSKUID,StoreID
    	
  
  DELETE FROM #StockOrderCount WHERE ISNULL(cgAmount,0) <= ISNULL(InAmount,0)   
  SELECT st.GoodsSKUID, --商品GoodsSKU 
	       st.SaleNum-ISNULL(SaleRenum,0) as SaleNum,       --卖出数量减去缺货占用的
	       (IsNull(kcs.Number,0) - ISNULL(kcs.ReservationNum,0)) AS CurrentNum, --当前仓库可用数量
	       (IsNull(SUM(ISNULL(soc.cgAmount,0) - IsNUll(soc.InAmount,0)),0)) AS NotInStockNum,        --采购未入库数量
	       st.StoreID
  INTO #SaleAndCurrTable
  FROM #SaleTable st LEFT JOIN KC_CurrentStock(nolock) kcs ON  st.GoodsSKUID = kcs.GoodsSKUID AND st.StoreID = kcs.StoreID
                     LEFT JOIN #StockOrderCount soc ON st.GoodsSKUID = soc.GoodsSKUID AND st.StoreID =soc.StoreID
  GROUP BY st.GoodsSKUID, st.SaleNum,ISNULL(SaleRenum,0),IsNull(kcs.Number,0),ISNULL(kcs.ReservationNum,0),st.StoreID
  
  	
  --仓库标记缺货的，强硬加进去，并且不做库存判断,后面加入仓库标记缺货
  SELECT SUM(L_QTY) AS SaleNum,ptd.GoodsSKUID,ptd.StoreID
  INTO #WaitPackage
  FROM P_Trade(nolock) pt JOIN P_TradeDt(nolock) ptd ON pt.NID = ptd.TradeNID 
  WHERE  pt.FilterFlag = 26 AND ptd.L_SHIPPINGAMT = 1
         and convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121)
		--and (@SKU ='' or ptd.SKU=@SKU )
		and ((@SKU='' or (ptd.SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0)) or
	                   ((ptd.SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
	                   
  GROUP BY ptd.GoodsSKUID,ptd.StoreID
  
  --合并销售数量
  UPDATE st
  SET st.SaleNum = st.SaleNum + wp.SaleNum
  FROM #SaleAndCurrTable st JOIN #WaitPackage wp ON st.GoodsSKUID = wp.GoodsSKUID AND st.StoreID = wp.StoreID
  --插入不存在产品
  INSERT INTO #SaleAndCurrTable(GoodsSKUID,SaleNum,CurrentNum,NotInStockNum,StoreID)
  SELECT GoodsSKUID,SaleNum,0,0,StoreID
  FROM #WaitPackage wp
  --WHERE wp.GoodsSKUID NOT IN (SELECT GoodsSKUID FROM #SaleTable) AND wp.StoreID NOT IN (SELECT StoreID FROM #SaleTable)
  WHERE not exists(select 1 FROM #SaleTable where wp.GoodsSKUID=#SaleTable.GoodsSKUID and wp.StoreID=#SaleTable.StoreID)
		
  DROP TABLE #WaitPackage					
  
  SELECT * 
  INTO #PurGoodsTable
  FROM #SaleAndCurrTable 
  WHERE (SaleNum >= (CurrentNum )) AND  (GoodsSKUID <>0)
  
	-- add by ylq 2015-06-05 采购未入库还需重新更新一遍，原因是上面在销售单未必更新的到（可能没数据)
  update #PurGoodsTable set NotInStockNum = IsNull(Soc.NotInStockNum,0)       
	  from #PurGoodsTable A , 
	    (select GoodsSKUID,storeid, 
	        SUM(ISNULL(cgAmount,0) - ISNULL(InAMount,0)) as NotInStockNum from #StockOrderCount group by GoodsSKUID,storeid) soc 
	   where A.GoodsSKUID = soc.GoodsSKUID and A.StoreID = soc.storeid   
	-- end add 
	-- add by ylq 2015-06-08 库存可用数还需要重新更新一遍，原因是上面的销售单未必更的到（可能没数据)
  update #PurGoodsTable set CurrentNum = kcs.CurrentNum
      from #PurGoodsTable A,
        (select GoodsSkuID, storeid, SUM(IsNull(Number,0) - ISNULL(ReservationNum,0)) as CurrentNum 
         from KC_CurrentStock(nolock)  group by GoodsSKUID,storeid
         ) kcs where A.GoodsSKUID = kcs.GoodsSKUID and A.StoreID = kcs.storeid   
	-- end add 
--8.查询					
	SELECT  row_number() OVER(ORDER BY gs.sku ) AS rowid,
	    0 AS SelFlag,  		gs.SKU,		    gs.property1,		gs.property2,		gs.property3,
		b.BarCode,		    b.goodscode,	b.goodsname,		b.model,		    b.unit,
		gs.GoodsSKUStatus as GoodsStatus,    --b.goodsstatus, modify by ylq 2015-04-20 因为状态改到细表了
		b.class,
		case when d.StockDays=0 then  b.StockDays else d.StockDays end as StockDays,	     	
		case when ISNULL(d.KcMaxNum,0)>0 then d.KcMaxNum else  gs.maxnum end as maxnum,		
		case when ISNULL(d.KcMinNum,0)>0 then d.KcMinNum else  gs.minnum end as minnum,	
		b.SupplierID,		p.CategoryID
       ,p.SupplierCode,p.SupplierName,p.FitCode,p.LinkMan,p.[Address],p.OfficePhone,p.Mobile,p.Recorder
       ,p.InputDate,p.Modifier,p.ModifyDate,p.Email,p.QQ,p.MSN,p.ArrivalDays,p.URL,p.Memo,p.Account,
		s.storeName,		g.StoreID,		d.GoodsID,		   g.GoodsSKUID,		d.Number,
		d.ReservationNum,	g.CurrentNum,	g.SaleNum,	       g.NotInStockNum,
                isnull(b.Used,0) as used,
		(Isnull(g.SaleNum,0) - Isnull(g.CurrentNum,0) - ISNULL(g.NotInStockNum,0)  ) AS LessNum,	                b.BmpFileName,       
		(SELECT TOP 1 bsl.LocationName
			FROM B_GoodsSKULocation gsl 
			inner join  B_StoreLocation bsl on gsl.LocationID=bsl.NID 
			WHERE gsl.StoreID=g.StoreID and gsl.GoodsSKUID=g.GoodsSKUID
		) AS LocationName,
		 b.Purchaser,b.LinkUrl,b.LinkUrl2,b.LinkUrl3,b.LinkUrl4, b.LinkUrl5, b.LinkUrl6,
		 case when ISNULL(d.SellCount1,0)>0 then d.SellCount1 else ISNULL(gs.SellCount1,0) end AS SellCount1,
		 case when ISNULL(d.SellCount2,0)>0 then d.SellCount2 else ISNULL(gs.SellCount2,0) end  AS SellCount2,
		 case when ISNULL(d.SellCount3,0)>0 then d.SellCount3 else ISNULL(gs.SellCount3,0) end AS SellCount3,
		  (case when isnull(@sellday1,0)=0 or isnull(@sellday2,0)=0 or isnull(@sellday3,0)=0 then '0' else
		 ((case when ISNULL(d.SellCount1,0)>0 then d.SellCount1 else ISNULL(gs.SellCount1,0) end)/@sellday1+
		  (case when ISNULL(d.SellCount2,0)>0 then d.SellCount2 else ISNULL(gs.SellCount2,0) end)/@sellday2+
		  (case when ISNULL(d.SellCount3,0)>0 then d.SellCount3 else ISNULL(gs.SellCount3,0) end)/@sellday3 )/3 end )  as everydaysell,  --算日平均销量
		 (Isnull(g.SaleNum,0) - Isnull(g.CurrentNum,0) - ISNULL(g.NotInStockNum,0)  ) AS PurCount,gs.NID,
		 CASE WHEN ISNULL(b.StoreID,0) =0 THEN '' 
		      ELSE  (SELECT bs.StoreName  FROM B_Store bs WHERE bs.NID = b.StoreID)
		 END AS SendStore,
		 --这段是查询最大延迟时间
		 case when isnull(gs.CostPrice,0)<>0 then gs.CostPrice else b.CostPrice end as costprice,
		 isnull((select max(DATEDIFF(DAY,Dateadd(hour,8,bb.ORDERTIME), GETDATE())) 
		   from P_TradeDtUn(nolock) aa left join P_TradeUn(nolock) bb on aa.TradeNID = bb.NID  
		   where bb.FilterFlag = 1 and aa.SKU=gs.SKU),0) as MaxDelayDays,
		 -- add by ylq 2015-04-21  增加商品Url
		 b.ItemUrl,gs.SKUName ,cCount.c,b.salername,gc.CategoryName 
		     
	INTO #Temp	 
	FROM #PurGoodsTable g  LEFT outer JOIN KC_CurrentStock(nolock) D ON g.GoodsSKUID = d.GoodsSKUID AND g.StoreID = d.StoreID	
						   LEFT  outer JOIN B_Store  s         ON s.NID = g.StoreID	                       
	                       LEFT  outer JOIN B_GoodsSKU(nolock) gs    ON gs.NID = g.GoodsSKUID				
	                       LEFT  outer JOIN B_Goods(nolock) b     ON b.NID = gs.GoodsID	
	                       LEFT  outer JOIN  B_Supplier p     ON p.NID=b.SupplierID
	                       left  outer join B_GoodsCats gc on gc.nid=b.GoodsCategoryID
	                       LEFT  outer join 
	                            (select StoreID , GoodsSKUID,COUNT(*) as c from (
	                               SELECT ptd.StoreID ,ptd.GoodsSKUID , DATEDIFF(Day,pt.ORDERTIME,GETDATE()) as DiffDays, 

ptd.TradeNID,ptd.L_QTY,bg.GoodsName,gs.SKU,gs.property1,gs.property2,gs.property3,pt.SUFFIX,pt.TRANSACTIONTYPE,
                                   pt.AMT, ls.name as logicsWayName,pt.Memo,gs.SKUName 
                                   FROM P_TradeDt(nolock) ptd LEFT JOIN B_GoodsSKU(nolock) gs on gs.SKU=ptd.SKU
                                   LEFT JOIN B_Goods(nolock) bg ON bg.NID = gs.GoodsID	 
                                   LEFT JOIN P_Trade(nolock) pt ON pt.NID = ptd.TradeNID and convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121)    
                                   left join B_LogisticWay ls on ls.NID = pt.logicsWayNID   
                                    where  TradeNID IN ( SELECT pt.NID  FROM P_Trade(nolock) pt 
    	                               WHERE ( (pt.FilterFlag <= 5) OR (pt.FilterFlag = 26)) and convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121) )    
	                                union SELECT ptdu.StoreID ,ptdu.GoodsSKUID , DATEDIFF(Day,ptu.ORDERTIME,GETDATE()) as DiffDays, 

ptdu.TradeNID,ptdu.L_QTY,bg.GoodsName,gs.SKU,gs.property1,gs.property2,gs.property3,ptu.SUFFIX,ptu.TRANSACTIONTYPE,
                                    ptu.AMT, ls.name as logicsWayName,ptu.Memo ,gs.SKUName 
                                    FROM P_TradeDtUn(nolock) ptdu  
	                                   LEFT JOIN B_GoodsSKU(nolock) gs on gs.SKU=ptdu.SKU
                                    LEFT JOIN B_Goods(nolock) bg ON bg.NID = gs.GoodsID	 
                                    LEFT JOIN P_TradeUn(nolock) ptu ON ptu.NID = ptdu.TradeNID and convert(varchar(10),ptu.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121)	
                                    left join B_LogisticWay ls on ls.NID = ptu.logicsWayNID  
   	                                   WHERE    ptdu.TradeNID IN ( SELECT pt.NID FROM P_Tradeun(nolock) pt 
   	                               WHERE pt.FilterFlag =1 and convert(varchar(10),pt.ordertime,121) between convert(varchar(10),@BeginDate,121) and convert(varchar(10),@enddate,121) )   )aa group by StoreID , GoodsSKUID)cCount 
   	                          on g.StoreID=cCount.StoreID and g.GoodsSKUID=cCount.GoodsSKUID 	
	WHERE  ISNULL(b.GoodsCode,'') <> ''	and (@ItemInfoKeyWord = '' 
	   or b.aliasCnName like '%' + @ItemInfoKeyWord  + '%'
	   or b.aliasEnName like '%' + @ItemInfoKeyWord  + '%'
	   or b.GoodsName like '%' + @ItemInfoKeyWord  + '%'
	   or b.SKU like '%' + @ItemInfoKeyWord  + '%'
	   or gs.SKU like '%' + @ItemInfoKeyWord  + '%')
	   

		     
	DELETE FROM #Temp WHERE Isnull(SaleNum,0) - Isnull(CurrentNum,0) =0 and ISNULL(NotInStockNum,0)=0	
	
	IF ISNULL(@chkNoShowPur,0) = 1
    BEGIN
      DELETE FROM #Temp WHERE LessNum <= 0 	
    END
    IF (@SelType = 0)         --缺货信息
    begin
      SELECT *,LessSumPrice=LessNum*Costprice,
      OtherStockEnabledNumber=ISNULL((select SUM(Number-ReservationNum) from KC_CurrentStock 
                                               where StoreID <> t.StoreID and GoodsSKUID=t.GoodsSKUID),0) 
      FROM #Temp t
      WHERE ((ISNULL(@Purchaser,'') = '') OR (t.Purchaser = @Purchaser)) 
      AND ((ISNULL(@SupplierName,'') = '') OR (t.SupplierName = @SupplierName)) 
      AND ((ISNULL(@StoreID,0) = 0) OR (t.StoreID = @StoreID)) 
     -- AND ((ISNULL(@SKU,'') = '') OR (t.SKU = @SKU)) 
      and ((@SKU='' or ( SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0))  or
	                   ((t.SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
      
      
      order by t.sku    
    end                        
    ELSE IF (@SelType = 1)    --采购员
    begin
      SELECT DISTINCT Purchaser FROM #Temp WHERE    ((ISNULL(@StoreID,0) = 0) OR (StoreID = @StoreID)) 
       -- AND ((ISNULL(@SKU,'') = '') OR (SKU = @SKU)) 	
       and ((@SKU='' or ( SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0)) or
	                   ((SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1))) 
    end
    ELSE IF (@SelType = 2)    --供应商
    begin
      SELECT DISTINCT SupplierName FROM #Temp WHERE    ((ISNULL(@StoreID,0) = 0) OR (StoreID = @StoreID)) 
        --AND ((ISNULL(@SKU,'') = '') OR (SKU = @SKU)) 
        and ((@SKU='' or (SKU in (select SKU from #SkuTable)) and (@IsMoHuSku=0)) or
	                   ((SKU like '%' + @SKU + '%') and (@IsMoHuSku = 1)))
        	     
    end  
      
	DROP TABLE #SaleTable
	
    DROP TABLE #StockOrderCount
    
    DROP TABLE #SaleAndCurrTable
    
	DROP TABLE #PurGoodsTable

	DROP TABLE #Temp
	set nocount on
	
END
