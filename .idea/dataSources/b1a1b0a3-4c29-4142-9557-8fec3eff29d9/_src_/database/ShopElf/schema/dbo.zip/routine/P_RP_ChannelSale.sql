
CREATE proc [dbo].[P_RP_ChannelSale]
	@BeginDate  datetime = '',
	@EndDate	DateTime= '',
	@Channel    varchar(50) = ''
as
begin
  --查找成本计价方法
  Declare
	@CalcCostFlag int 
  set
	@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
  
  --查找信息放入临时表
  select
    pt.TradeNID,                                  --nid
	p.TRANSACTIONTYPE,                            --渠道名称
	p.AMT * ISNULL(bcc.ExchangeRate,1) as AMT,    --销售价转人民币
	case when @CalcCostFlag =0 then sum(pt.CostPrice) 
	     else sum(pt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                        else isnull(bg.CostPrice,0) end )) end as CostPrice    --成本价
  into #Temp
  from P_TradeDt pt 
  left join P_Trade p on pt.TradeNID = p.NID
  left join B_CurrencyCode bcc on bcc.CURRENCYCODE = p.CURRENCYCODE
  left join b_goodssku bgs on bgs.sku = pt.sku
  left join b_goods bg on bg.nid = bgs.goodsid
  where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate)) 
  and ((@EndDate = '') or (p.ORDERTIME < @EndDate))
  and ((@Channel = '') or (p.TRANSACTIONTYPE = @Channel))
  group by pt.TradeNID,p.TRANSACTIONTYPE,p.AMT,ISNULL(bcc.ExchangeRate,1)
  union all 
  select
    pt.TradeNID,                                  --nid
	p.TRANSACTIONTYPE,                            --渠道名称
	p.AMT * ISNULL(bcc.ExchangeRate,1) as AMT,    --销售价转人民币
	case when @CalcCostFlag =0 then sum(pt.CostPrice) 
	     else sum(pt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                        else isnull(bg.CostPrice,0) end )) end as CostPrice    --成本价
  from P_TradeDt_His pt 
  left join P_Trade_His p on pt.TradeNID = p.NID
  left join B_CurrencyCode bcc on bcc.CURRENCYCODE = p.CURRENCYCODE
  left join b_goodssku bgs on bgs.sku = pt.sku
  left join b_goods bg on bg.nid = bgs.goodsid
  where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate)) 
  and ((@EndDate = '') or (p.ORDERTIME < @EndDate))
  and ((@Channel = '') or (p.TRANSACTIONTYPE = @Channel))
  group by pt.TradeNID,p.TRANSACTIONTYPE,p.AMT,ISNULL(bcc.ExchangeRate,1)
	
  select 
	t.TRANSACTIONTYPE,
	SUM(AMT) as AMT,
	SUM(CostPrice) as CostPrice
  into #last
  from #Temp t
  group by t.TRANSACTIONTYPE
	
  select 
	l.TRANSACTIONTYPE,
	l.AMT,
	l.CostPrice,
	(ISNULL(l.AMT,0) - ISNULL(l.CostPrice,0)) as Salepri,
	case when ISNULL(l.AMT,0) = 0 then 0 
	     else (ISNULL(l.AMT,0) - ISNULL(l.CostPrice,0))*100/AMT end as SaleRate
  from #last l
end
