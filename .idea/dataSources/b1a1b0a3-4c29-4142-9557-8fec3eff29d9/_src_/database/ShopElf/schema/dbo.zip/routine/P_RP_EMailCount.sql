
CREATE Proc [dbo].[P_RP_EMailCount]
	@BeginDate	datetime=null,
	@EndDate	datetime=null,
	@ebayuserid	varchar(100)=''
	
as
begin
	select 
		ebayuserid,
		CONVERT(varchar(10),DateAdd(hour,8,ReceiveDate),121) as ReceiveDate,
		sum(case when Sender<>eBayUserID then 1 else 0 end) as AllEmailCount,
		sum(case when Sender ='eBay' OR Sender ='eBay 客戶服務支援' then 1 else 0 end) AS eBayEmailCount,	
		sum(case when MessageSubject like '%您的 eBay 物品已賣出！%' then 1 else 0 end) AS SaleEmailCount,
		sum(case when MessageSubject like '%您的刊登已確認%' then 1 else 0 end) AS ListEmailCount,
		sum(case when SendToName=eBayUserID  then 1 else 0 end) AS BuyerEmailCount,
		
		sum(case when FolderID=1 then 1 else 0 end) AS BuyerRepliedEmailCount
	from 
		M_eBayMessages
	where
		DateAdd(hour,8,ReceiveDate)
			between @BeginDate and @EndDate
		and (@ebayuserid='' or ebayuserid =@ebayuserid)
					 
	group by 
		ebayuserid,
		CONVERT(varchar(10),DateAdd(hour,8,ReceiveDate),121)
	order by 
		CONVERT(varchar(10),DateAdd(hour,8,ReceiveDate),121)
end		


