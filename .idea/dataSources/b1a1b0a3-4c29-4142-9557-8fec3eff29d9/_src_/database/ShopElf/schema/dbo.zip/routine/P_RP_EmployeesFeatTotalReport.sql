create PROCEDURE [dbo].[P_RP_EmployeesFeatTotalReport]
	@BeginDate	varchar(10) = '',
	@EndDate	Varchar(10)= '',
	@Sku		Varchar(100)= '',	
	@SalerName VARCHAR(50) ='',
	@SalerName2 VARCHAR(50)='',
	@SalerAliasName VARCHAR(50)=''
AS
BEGIN
	DECLARE @DateFlag INT = 1,@Flag	INT=0
	CREATE TABLE #FinancialProfit
	(
			nid int,
			OrderDay varchar(20),	
			SKU varchar(4000),
			Suffix varchar(100),
			TrackNo varchar(50),
			CurrencyCode varchar(10),
     		wlWay	Varchar(200),
			SHIPTOCOUNTRYNAME varchar(100),
			ExchangeRate	money  default 0,	     			
			SaleMoney money default 0,
			SHIPPINGAMT  money default 0,
			eBayFee  money default 0,
			eBayFeeZn  money default 0,	
			ppFee  money default 0,
			ppFeeZn  money default 0,	
			ppMoney  money default 0,
			sdMoney  money default 0,
			sdMoneyUs  money default 0,			
			sdMoneyZn  money default 0,	
			CostMoney  money default 0,
			ExpressFare  money default 0,
			packageMoney  money default 0,
			InpackageMoney  money default 0,		
			OutpackageMoney  money default 0,					
			lrMoney  money default 0,
			TotalWeight  money default 0,
			SaleItemsCount NUMERIC(10,0) DEFAULT 0,
			SaleSKUCount NUMERIC(10,0) DEFAULT 0
	)
	CREATE TABLE #FinancialProfit1
	(
			nid int,
			OrderDay varchar(20),	
			SKU varchar(4000),
			Suffix varchar(100),			
			TrackNo varchar(50),
			CurrencyCode varchar(10),
     		wlWay	Varchar(200),
			SHIPTOCOUNTRYNAME varchar(100),
			ExchangeRate	money  default 0,	     			
			SaleMoney money default 0,
			SHIPPINGAMT  money default 0,
			eBayFee  money default 0,
			eBayFeeZn  money default 0,	
			ppFee  money default 0,
			ppFeeZn  money default 0,	
			ppMoney  money default 0,
			sdMoney  money default 0,
			sdMoneyUs  money default 0,			
			sdMoneyZn  money default 0,	
			CostMoney  money default 0,
			ExpressFare  money default 0,
			packageMoney  money default 0,
			InpackageMoney  money default 0,		
			OutpackageMoney  money default 0,				
			lrMoney  money default 0,
			TotalWeight  money default 0,
			SaleItemsCount  NUMERIC(10,0) DEFAULT 0,
			SaleSKUCount NUMERIC(10,0) DEFAULT 0
		)
	--查找USD的汇率
	DECLARE
		@ExchangeRate FLOAT 
	SET
		@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 	if @ExchangeRate=0
 	  set 	@ExchangeRate=1	
	--查找成本计价方法
	DECLARE
		@CalcCostFlag INT 
	SET
		@CalcCostFlag =ISNULL((SELECT ParaValue FROM B_SysParams WHERE ParaCode ='CalCostFlag'),0)	
 	  
	if @Flag=0 
	begin
		INSERT INTO  #FinancialProfit
		select
			m.nid,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			dbo.Ex_GetOrderSkusBySalerName(m.nid,@SalerName,@SalerName2) as sku ,
			m.Suffix,			
			m.TrackNo,	
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			max(bc.CountryZnName) +'('+(m.SHIPTOCOUNTRYNAME)+')',
			0 as ExchangeRate,				
			sum(d.L_AMT) *max(c.ExchangeRate) as SaleMoney,
			0 as SHIPPINGAMT,
			0 as eBayFee,
			0 as eBayFeeZn,	
			0 as ppFee ,
			0 as ppFeeZn ,	
			0  as ppMoney,
			0 as sdMoney,
			0 as sdMoneyUs,			
			0 as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*bg.CostPrice) end as CostMoney,
			max(m.SHIPPINGAMT) *max(c.ExchangeRate) as ExpressFare ,
			0 as packageMoney,
			0 as inpackageMoney,
			0 as outpackageMoney,						
			0 as lrMoney,
			0 as TotalWeight,
			COUNT(d.sku) AS SaleItemsCount,
			sum(d.L_QTY) AS SaleSKUCount
			
		from 
			P_TradeDt d
		left outer join 
			P_Trade m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID		
		left  JOIN B_Country bc ON bc.CountryCode = m.COUNTRYCODE
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		where 
			((@DateFlag=1 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate) )
			AND d.SKU like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX = @SalerAliasName)
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName) 
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
		group by 
			m.NID,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name,
			m.SHIPTOCOUNTRYNAME			
		union all	
		select
			m.NID,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			dbo.Ex_GetOrderSkusBySalerName(m.nid,@SalerName,@SalerName2) as sku ,
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			max(bc.CountryZnName) +'(' +(m.SHIPTOCOUNTRYNAME)+')',
			0 as ExchangeRate,				
			sum(d.L_AMT) *max(c.ExchangeRate) as SaleMoney,
			0 as SHIPPINGAMT,
			0 as eBayFee,
			0 as eBayFeeZn,	
			0 as ppFee ,
			0 as ppFeeZn ,	
			0  as ppMoney,
			0 as sdMoney,
			0 as sdMoneyUs,			
			0 as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*bg.CostPrice) end as CostMoney,
			max(m.SHIPPINGAMT) *max(c.ExchangeRate) as ExpressFare ,
			0 as packageMoney,
			0 as inpackageMoney,
			0 as outpackageMoney,						
			0 as lrMoney,
			sum(d.[Weight]) as TotalWeight,
			COUNT(d.sku) AS SaleItemsCount,
			sum(d.L_QTY) AS SaleSKUCount
			
		from 
			P_TradeDt_His d
		left outer join 
			P_Trade_His m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID		
		left  JOIN B_Country bc ON bc.CountryCode = m.COUNTRYCODE				
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		where 
			((@DateFlag=1 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate) )
			AND d.SKU like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX = @SalerAliasName)
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
		group by 
			m.NID,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name	,
			m.SHIPTOCOUNTRYNAME							
	END
	select 
			nid,
			OrderDay,	
			SKU,
			Suffix,			
		    CONVERT(VARCHAR(20), sum(SaleMoney)) as SaleMoney ,
			sum(CostMoney) as CostMoney  ,
			sum(TotalWeight) as TotalWeight,
			sum(SaleItemsCount) AS SaleItemsCount,
			sum(SaleSKUCount) AS SaleSKUCount,
			SHIPTOCOUNTRYNAME ,	
			wlWay	,	
			TrackNo,
			@SalerName AS SalerName ,
	        @SalerName2 AS SalerName2,
	        SUM(ExpressFare) AS ExpressFare
	from #FinancialProfit
	group by 
			nid,
			OrderDay,	
			SKU ,
			Suffix,
			TrackNo,
			CurrencyCode,
			wlWay,
			SHIPTOCOUNTRYNAME				
	drop table 	#FinancialProfit	
	drop table 	#FinancialProfit1
end	


