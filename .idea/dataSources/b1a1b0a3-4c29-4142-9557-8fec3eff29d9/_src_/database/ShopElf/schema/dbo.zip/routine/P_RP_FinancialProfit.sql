
--索引名称去掉 cf 1123
--cuifeng edit 增加发货时间查询时FilterFlag=100
CREATE proc [P_RP_FinancialProfit]
	@DateFlag int,                         --时间标记 0 交易时间 1 发货时间
	@BeginDate	varchar(20),               --开始时间
	@EndDate	Varchar(20),               --结束时间
	@Sku		Varchar(100),              --SKU
	@Flag		INT,                       --按天还是按月查询 0 天 2 月
	@SalerName VARCHAR(50),                --业绩归属人1
	@SalerName2 VARCHAR(50),               --业绩归属人2
	@chanel VARCHAR(50),                   --销售渠道
	@SaleType VARCHAR(50),	               --销售类型
	@SalerAliasName VARCHAR(max) = '',     --卖家简称 可以用逗号分隔
	@eBayUserID VARCHAR(100)='',           --卖家ID
	@fNo	VARCHAR(100)='',               --订单编号 或 店铺单号
	@DevDate varchar(20),                  --商品开发时间--开始时间
	@DevDateEnd varchar(20),               --商品开发时间--结束时间
	@Purchaser  VARCHAR(50),
	@RateFlag  int                         --是否使用订单保存的汇率 1 使用 0 使用汇率表里的汇率
	
AS
begin
 -- 存放订单副表信息
   create table #tempskucostprice(
  PackFee money default 0,
  goodcostprice money default 0,
  costprice money default 0,
  tradenid int default 0,
  StoreName varchar(200) default '')
  -- 创建临时表用来存储信息
  create Table #TempTradeInfo
  (
    nid int,                                 --nid
	OrderDay varchar(20),                    --时间显示到日(yyyy-mm-dd) 0 交易 1 发货  	
	OrderMonth varchar(20),                  --时间显示到月(yyyy-mm) 0 交易 1 发货  
	Suffix varchar(100),                     --卖家简称			
	ExchangeRate float default 0,            --销售汇率 包括(销售价,PP手续费,买家付运费) 根据系统参数取 系统汇率还是订单里面的汇率     			
	SaleMoney float default 0,               --销售价 AMT
	SHIPPINGAMT  float default 0,            --买家付运费
	ppFee  float default 0,                  --PP手续费
	ebayExchangeRate float,                  --平台手续费汇率 ebay paypal的取美元  否则 根据系统参数取 系统汇率还是订单里面的汇率
	eBayFee  float default 0,                --平台手续费
	CostMoney  float default 0,              --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价）
	ExpressFare  float default 0,            --快递费￥
	InpackageMoney  float default 0,         --内包装金额￥		
	OutpackageMoney  float default 0,        --外包装金额￥					
	TotalWeight  float default 0,            --总重量 G
	DevDate dateTime null,                   --最大商品开发时间
	ItemCostPrice float default 0,           --商品信息的成本价（商品成本加一起）
	ACK VARCHAR(50),                         --店铺单号
	[User] VARCHAR(100),                     --卖家id
	PaiDanMen VARCHAR(50),                   --派单人
	SKU varchar(8000),                       --sku明细
	TrackNo varchar(200),                    --跟踪号
	CurrencyCode varchar(10),                --币种
	wlWay Varchar(200),                      --物流方式名称
	SHIPTOCOUNTRYNAME varchar(100),          --收货人国家
	TRANSACTIONID varchar(50),               --PP交易ID
	BuyerID nvarchar(120),                   --买家ID	
	SaleItemsCount NUMERIC(10,0) DEFAULT 0,  --销售总数量
	SaleSKUCount NUMERIC(10,0) DEFAULT 0,    --SKU数量
	SHIPTOCOUNTRYCODE varchar(100),          --收件人国家代码
	CountryZnName  varchar(100),              --收件人国家中文名
	StoreName varchar(200) -- 仓库名称
  )
  --临时的NID	
  create Table #TempTradeInfo_TempNID
  (
    nid int,                                 --nid
    primary key(nid)
  )	
  --最终的NID
  create Table #TempTradeInfo_NID
  (
    nid int primary key(nid)
  )	
	
  --分解卖家简称放到表格里	
  CREATE TABLE #tbSalerAliasName( SalerAliasName VARCHAR(100) )
  IF LTRIM(RTRIM(@SalerAliasName)) <> ''
  BEGIN
	DECLARE @sSQLCmd VARCHAR(max) = ''
	SET @SalerAliasName = REPLACE(@SalerAliasName,',','''))UNION SELECT ltrim(rtrim(''') 
    SET @sSQLCmd = 'INSERT INTO #tbSalerAliasName(SalerAliasName) SELECT ltrim(rtrim('+ @SalerAliasName+'))'
	EXEC(@sSQLCmd )
  END
  
  --查找USD的汇率
  Declare
	@ExchangeRate float 
  set
	@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
  if @ExchangeRate=0
    set @ExchangeRate=1	
    
  --查找成本计价方法
  Declare
	@CalcCostFlag int 
  set
	@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
	
  if @Sku = '%%' 
    set @Sku = ''	

  --数据插入临时表 --正常表
  --先查询主表条件里面的订单编号
  insert into #TempTradeInfo_TempNID
  select 
    m.NID 
  from P_Trade(nolock) m
  where		
    ((@DateFlag=1 and m.FilterFlag=100 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
	 or (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate))
	AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName))    --卖家简称	
	AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 	                                       --卖家ID		
	AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)                                --销售渠道
	AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 			                       --销售类型
	AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)                                     --订单号或店铺单号
	
  --再查询最终的明细的订单编号	 
  insert into #TempTradeInfo_NID
  select 
    D.TradeNid 
  from (select TradeNid,SKU from P_TradeDt(nolock) where TradeNid in (select NID from #TempTradeInfo_TempNID)) d
  left join B_GoodsSKU(nolock) bgs on bgs.SKU = d.SKU 
  left join b_goods(nolock) bg on bg.NID = bgs.GoodsID 
  where 
    (isnull(@Sku,'') = '' or isnull(d.SKU,'') like '%'+@Sku+'%')                             --SKU                           	
    AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)                            --业绩归属人1
    AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)                         --业绩归属人2	
    AND (ISNULL(@DevDate,'') ='' or convert(varchar(10),bg.DevDate,121) >= @DevDate)         --商品开发开始时间
    AND (ISNULL(@DevDateEnd,'') ='' or convert(varchar(10),bg.DevDate,121) <= @DevDateEnd)   --商品开发结束时间 
    AND (ISNULL(@Purchaser,'') = '' OR bg.Purchaser = @Purchaser)
  group by  
    D.TradeNid 
      -- 正常表 sku数据
    insert into #tempskucostprice(tradenid,goodcostprice,costprice,PackFee,StoreName)
    select
    dt.TradeNID,
    sum(dt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                                      else bg.CostPrice end)),
	SUM(dt.CostPrice),
	sum(dt.L_QTY*(ISNULL(bg.PackFee,0))),
	MAX(bs.StoreName)
	                                  
    from P_TradeDt dt with(nolock) 
    inner join B_GoodsSKU bgs with(nolock)  on bgs.SKU = dt.SKU 
	inner join b_goods bg with(nolock)  on bg.NID = bgs.GoodsID
	left join B_Store bs on bs.NID=dt.StoreID
    where dt.tradenid in (select NID from #TempTradeInfo_NID)
    group by dt.TradeNID 
  print 1
  --再根据查询的NID插入详细信息
  insert into #TempTradeInfo
  select                             
	m.nid,                                                                                --nid  
	case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	                  --时间显示到日(yyyy-mm-dd) 0 交易 1 发货 
	case when @DateFlag=0  then convert(varchar(7),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(7),m.CLOSINGDATE,121) end as OrderMonth,                    --时间显示到月(yyyy-mm) 0 交易 1 发货   	   
	m.Suffix,	                                                                          --卖家简称	
	case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	     else isnull(c.ExchangeRate,1) end as ExchangeRate,                               --销售汇率 包括(销售价,pp手续费,买家付运费)
	m.AMT as SaleMoney,			                                                          --销售价 AMT
	m.SHIPPINGAMT as SHIPPINGAMT,		                                                  --买家付运费
	m.FEEAMT as ppFee ,                                                                   --PP手续费  
	case when m.ADDRESSOWNER = 'ebay' or m.ADDRESSOWNER = 'paypal' then @ExchangeRate 
		 else case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
		           else isnull(c.ExchangeRate,1) end end as ebayExchangeRate,             --平台手续费汇率  
	m.SHIPDISCOUNT as eBayFee,		                                                      --平台手续费  
	isnull( (case when @CalcCostFlag =0 then ts.costprice else ts.goodcostprice end),0) as CostMoney,                                    --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价） 
	m.ExpressFare,                                                                        --快递费￥      
	isnull(ts.PackFee,0) as InpackageMoney,                               --内包装金额￥
	m.INSURANCEAMOUNT as outpackageMoney,	                                              --外包装金额￥
	m.TotalWeight*1000 as TotalWeight,                                                    --总重量 G
	'' as DevDate,                                              --最大商品开发时间
	isnull(ts.goodcostprice,0) as ItemCostPrice,                                --商品信息的成本价（商品成本加一起） 
	m.ACK,                                                                                --店铺单号
	m.[User],	                                                                          --卖家id
	m.PaiDanMen,	                                                                      --派单人	
	m.AllGoodsDetail as sku,	                                                          --sku明细
	m.TrackNo,                                                                            --跟踪号
	m.CURRENCYCODE as CurrencyCode,                                                       --币种
	l.name as wlWay,                                                                      --物流方式名称
	m.SHIPTOCOUNTRYNAME,                                                                  --收货人国家
	m.TRANSACTIONID,		                                                              --PP交易ID
	m.BuyerID,                                                                            --买家ID	
	m.MULTIITEM AS SaleItemsCount,			                                              --销售总数量
	m.SALESTAX AS SaleSKUCount,                                                           --SKU数量
	m.SHIPTOCOUNTRYCODE,		                                                          --收件人国家代码	
	bc.CountryZnName,	                                                                  --国家中文名
	ts.StoreName                                                                          -- 仓库名称
  from 
	P_Trade(nolock) m		
	left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID		
	left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
	left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE
	left join #tempskucostprice ts with(nolock) on ts.tradenid=m.NID		
  where 
	m.NID in (select NID from #TempTradeInfo_NID) 
	
  --清除不用的数据
  Truncate Table #TempTradeInfo_TempNID
  Truncate Table #TempTradeInfo_NID	
  truncate table #tempskucostprice
				  
  --数据插入临时表 --历史表		
  --先查询主表条件里面的订单编号
  insert into #TempTradeInfo_TempNID
  select 
    m.NID 
  from P_Trade_his(nolock) m
  where		
    ((@DateFlag=1 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
	 or (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate))
	AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName))    --卖家简称	
	AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 	                                       --卖家ID		
	AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)                                --销售渠道
	AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 			                       --销售类型
	AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)                                     --订单号或店铺单号
	
  --再查询最终的明细的订单编号	 
  insert into #TempTradeInfo_NID
  select 
    D.TradeNid 
  from (select TradeNid,SKU from P_TradeDt_his(nolock) where TradeNid in (select NID from #TempTradeInfo_TempNID)) d
  left join B_GoodsSKU(nolock) bgs on bgs.SKU = d.SKU 
  left join b_goods(nolock) bg on bg.NID = bgs.GoodsID 
  where 
    (isnull(@Sku,'') = '' or isnull(d.SKU,'') like '%'+@Sku+'%')                             --SKU                           	
    AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)                            --业绩归属人1
    AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)                         --业绩归属人2	
    AND (ISNULL(@DevDate,'') ='' or convert(varchar(10),bg.DevDate,121) >= @DevDate)         --商品开发开始时间
    AND (ISNULL(@DevDateEnd,'') ='' or convert(varchar(10),bg.DevDate,121) <= @DevDateEnd)   --商品开发结束时间
    AND (ISNULL(@Purchaser,'') = '' OR bg.Purchaser = @Purchaser) 
  group by  
    D.TradeNid 
     -- 历史表sku数据
    insert into #tempskucostprice(tradenid,goodcostprice,costprice,PackFee,StoreName)
    select
    dt.TradeNID,
    sum(dt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                                      else bg.CostPrice end)),
	SUM(dt.CostPrice),
	sum(dt.L_QTY*(ISNULL(bg.PackFee,0))),
	MAX(bs.StoreName)
    from P_TradeDt_His dt with(nolock) 
    inner join B_GoodsSKU bgs with(nolock)  on bgs.SKU = dt.SKU 
	inner join b_goods bg with(nolock)  on bg.NID = bgs.GoodsID
	left join B_Store bs on bs.NID=dt.StoreID
    where dt.tradenid in (select NID from #TempTradeInfo_NID) 
    group by dt.TradeNID
  
  --再根据查询的NID插入详细信息	  
  insert into #TempTradeInfo
  select                             
	m.nid,                                                                                --nid  
	case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	                  --时间显示到日(yyyy-mm-dd) 0 交易 1 发货 
	case when @DateFlag=0  then convert(varchar(7),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(7),m.CLOSINGDATE,121) end as OrderMonth,                    --时间显示到月(yyyy-mm) 0 交易 1 发货   	   
	m.Suffix,	                                                                          --卖家简称	
	case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	     else isnull(c.ExchangeRate,1) end as ExchangeRate,                               --销售汇率 包括(销售价,pp手续费,买家付运费)
    m.AMT as SaleMoney,			                                                          --销售价 AMT
	m.SHIPPINGAMT as SHIPPINGAMT,		                                                  --买家付运费
	m.FEEAMT as ppFee ,                                                                   --PP手续费  
	case when m.ADDRESSOWNER = 'ebay' or m.ADDRESSOWNER = 'paypal' then @ExchangeRate 
	     else case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	               else isnull(c.ExchangeRate,1) end end as ebayExchangeRate,             --平台手续费汇率  
	m.SHIPDISCOUNT as eBayFee,		                                                      --平台手续费  
	isnull((case when @CalcCostFlag =0 then ts.costprice 
	               else ts.goodcostprice end),0) as CostMoney,        --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价） 
	m.ExpressFare,                                                                        --快递费￥      
	isnull(ts.PackFee,0) as InpackageMoney,   --内包装金额￥
	m.INSURANCEAMOUNT as outpackageMoney,	                                              --外包装金额￥
	m.TotalWeight*1000 as TotalWeight,                                                    --总重量 G
	'' as DevDate,                   --最大商品开发时间
	isnull(ts.goodcostprice,0) as ItemCostPrice,    --商品信息的成本价（商品成本加一起） 
	m.ACK,                                                                                --店铺单号
	m.[User],	                                                                          --卖家id
	m.PaiDanMen,	                                                                      --派单人	
	m.AllGoodsDetail as sku,	                                                          --sku明细
	m.TrackNo,                                                                            --跟踪号
	m.CURRENCYCODE as CurrencyCode,                                                       --币种
	l.name as wlWay,                                                                      --物流方式名称
	m.SHIPTOCOUNTRYNAME,                                                                  --收货人国家
	m.TRANSACTIONID,		                                                              --PP交易ID
	m.BuyerID,                                                                            --买家ID	
	m.MULTIITEM AS SaleItemsCount,			                                              --销售总数量
	m.SALESTAX AS SaleSKUCount,                                                           --SKU数量
	m.SHIPTOCOUNTRYCODE,		                                                          --收件人国家代码	
	bc.CountryZnName,	                                                                  --国家中文名	
	ts.StoreName                                                                          -- 仓库名称
  from 
	P_Trade_his(nolock) m		
	left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID			
	left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
	left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE
	left join #tempskucostprice ts with(nolock) on ts.tradenid=m.NID	
  where 
	m.NID in (select NID from #TempTradeInfo_NID)  				    

  --0日期 2月份
  if @Flag=0 
  begin
	--统计信息 	
	--扣除PP手续费 = 销售价 - pp手续费 	
	--实得金额 = 销售价 - pp手续费 - 平台手续费
	--包装成本 = 内包装 + 外包装
	--利润 =  销售价 - pp手续费 - 平台手续费 - 商品成本价 - 内包装 - 外包装 - 快递费
	--利润率 = 利润 / 销售价
	select 
	  nid,                                     --nid
	  ACK,                                     --店铺单号
	  [User],                                  --卖家ID
	  PaiDanMen,                               --派单员
	  OrderDay,	                               --时间-日
	  SKU,                                     --商品明细
	  Suffix,                                  --卖家简称
	  TrackNo,                                 --跟踪号
	  CurrencyCode,                            --币种
	  wlWay,	                               --物流方式
	  SHIPTOCOUNTRYNAME ,                      --收件人国家名称
	  TRANSACTIONID,		                   --PP交易ID
	  BuyerID,                                 --买家ID				
	  ExchangeRate,                            --平台汇率				
	  SaleMoney,                                                        --销售价
	  round(SaleMoney * ExchangeRate / @ExchangeRate,3) as SaleMoneyUS,          --销售价$
	  round(SaleMoney * ExchangeRate,2) as SaleMoneyzn,                          --销售价￥
	  SHIPPINGAMT,                                                      --买家付运费
	  round(SHIPPINGAMT * ExchangeRate / @ExchangeRate,3) as SHIPPINGAMTUS,      --买家付运费$
	  round(SHIPPINGAMT * ExchangeRate,2) as SHIPPINGAMTzn,                      --买家付运费￥
	  eBayFee as eBayFeeYs,                                             --平台交易费
	  round(eBayFee * ebayExchangeRate / @ExchangeRate,3) as eBayFee,            --平台交易费$
	  round(eBayFee * ebayExchangeRate,2) as eBayFeezn,                          --平台交易费￥
	  ppFee,                                                            --pp手续费
	  round(ppFee * ExchangeRate / @ExchangeRate,3) as ppFeeUS,                  --pp手续费$
	  round(ppFee * ExchangeRate,2) as ppFeezn,                                  --pp手续费￥
	  SaleMoney - ppFee as sdMoney  ,                                   --扣除PP手续费
	  round((SaleMoney - ppFee) * ExchangeRate / @ExchangeRate,3) as ppMoney,    --扣除PP手续费$
	  round((SaleMoney - ppFee) * ExchangeRate,2) as ppMoneyzn,                  --扣除PP手续费￥
	  round(SaleMoney * ExchangeRate / @ExchangeRate  
	  - eBayFee * ebayExchangeRate / @ExchangeRate
	  - ppFee * ExchangeRate / @ExchangeRate,3) as sdMoneyUs,              --实得金额$
	  round(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate 
	  - ppFee * ExchangeRate,2)  as sdMoneyZn,                             --实得金额￥
	  CostMoney,                                                        --商品成本价￥		
	  ExpressFare,                                                      --快递费￥	
	  inpackageMoney + outpackageMoney as packageMoney,                 --包装成本￥
	  inpackageMoney  ,                                                 --内包装成本￥
	  outpackageMoney  ,                                                --外包装成本￥	
	  round(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare,2) as lrMoney,                                         --利润￥
	  TotalWeight,                                                      --总重量                                    
	  SaleItemsCount,                                                   --销售总数量
	  SaleSKUCount,                                                     --销售SKU数量
	  case when SaleMoney * ExchangeRate = 0 then 0
	  else round((SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare) / (SaleMoney * ExchangeRate) * 100,2) end as lrl,  --利润率	
	  SHIPTOCOUNTRYCODE,                                                --国家代码
	  CountryZnName,                                                    --国家中文
	  DevDate,                                                          --商品开发日期
	  ItemCostPrice,                                                     --商品信息成本价
	  StoreName
	  from #TempTradeInfo 			
  end
  else if @Flag=2
  BEGIN
	--统计信息 	
	--扣除PP手续费 = 销售价 - pp手续费 	
	--实得金额 = 销售价 - pp手续费 - 平台手续费
	--包装成本 = 内包装 + 外包装
	--利润 =  销售价 - pp手续费 - 平台手续费 - 商品成本价 - 内包装 - 外包装 - 快递费
	--利润率 = 利润 / 销售价	
	select 
	  OrderMonth as OrderDay,	                                             --时间-月
	  Suffix,                                                                --卖家简称	
	  round(sum(SaleMoney),2) as SaleMoneyYs,                                         --销售价
	  round(sum(SaleMoney * ExchangeRate / @ExchangeRate),3) as SaleMoney,            --销售价$
	  round(sum(SaleMoney * ExchangeRate),2) as SaleMoneyzn,                          --销售价￥
	  round(sum(SHIPPINGAMT),2) as SHIPPINGAMT,                                       --买家付运费
	  round(sum(SHIPPINGAMT * ExchangeRate / @ExchangeRate),3) as SHIPPINGAMTUS,      --买家付运费$
	  round(sum(SHIPPINGAMT * ExchangeRate),2) as SHIPPINGAMTzn,                      --买家付运费￥
	  round(sum(eBayFee),2) as eBayFeeYs,                                             --平台交易费
	  round(sum(eBayFee * ebayExchangeRate / @ExchangeRate),3) as eBayFee,            --平台交易费$
	  round(sum(eBayFee * ebayExchangeRate),2) as eBayFeezn,                          --平台交易费￥
	  round(sum(ppFee),2) as ppFeeYs,                                                 --pp手续费
	  round(sum(ppFee * ExchangeRate / @ExchangeRate),3) as ppFee,                    --pp手续费$
	  round(sum(ppFee * ExchangeRate),2) as ppFeezn,                                  --pp手续费￥
	  round(sum(SaleMoney - ppFee),2) as sdMoney  ,                                   --扣除PP手续费
	  round(sum((SaleMoney - ppFee) * ExchangeRate / @ExchangeRate),3) as ppMoney,    --扣除PP手续费$
	  round(sum((SaleMoney - ppFee) * ExchangeRate),2) as ppMoneyzn,                  --扣除PP手续费￥
	  round(sum(SaleMoney * ExchangeRate / @ExchangeRate  
	  - eBayFee * ebayExchangeRate / @ExchangeRate
	  - ppFee * ExchangeRate / @ExchangeRate),3) as sdMoneyUs,                  --实得金额$
	  round(sum(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate 
	  - ppFee * ExchangeRate),2)  as sdMoneyZn,                                 --实得金额￥
	  round(sum(CostMoney),2) as CostMoney,                                           --商品成本价￥		
	  round(sum(ExpressFare),2) as ExpressFare,                                       --快递费￥	
	  round(sum(inpackageMoney + outpackageMoney),2) as packageMoney,                 --包装成本￥
	  round(sum(inpackageMoney),2) as inpackageMoney ,                                --内包装成本￥
	  round(sum(outpackageMoney),2) as  outpackageMoney,                              --外包装成本￥	
	  round(sum(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare),2) as lrMoney,                                             --利润￥
	  sum(TotalWeight) as TotalWeight,                                       --总重量                                    
	  sum(SaleItemsCount) as SaleItemsCount,                                 --销售总数量
	  case when sum(SaleMoney * ExchangeRate) = 0 then 0
	  else round(sum(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare) / sum(SaleMoney * ExchangeRate) * 100,2) end as lrl,    --利润率	
	  SUM(ItemCostPrice) as ItemCostPrice ,                                  --商品信息成本价
	  Count(Nid) as TradeCount                                               --订单数量
	  from #TempTradeInfo f 
	  group by
	    OrderMonth,Suffix
  end
		
  drop table #TempTradeInfo
  drop table #tbSalerAliasName	
  drop table #TempTradeInfo_NID
  drop table #TempTradeInfo_TempNID
  drop table #tempskucostprice
end								
