CREATE proc [dbo].[P_RP_FinancialProfit_632581735_bb_rjf]                         
	@BeginDate	varchar(20),               --开始时间
	@EndDate	Varchar(20),               --结束时间
	@sku	Varchar(20),                   --SKU编码
	@Purchaser		Varchar(100),          --采购员  
	@SupplierName VARCHAR(50),             --供应商
	@SalerName VARCHAR(50),                --业绩归属人1
	@SalerName2 VARCHAR(50),               --业绩归属人2
	@caigounid VARCHAR(50),                --采购订单号
	@Goodstatus VARCHAR(max),              --商品状态 
	                 
    @UserIDtemp int=0
	
As
begin
set @BeginDate=SUBSTRING(@BeginDate,1,10)
set @EndDate=SUBSTRING(@EndDate,1,10)
set @EndDate=CONVERT(varchar(10),DATEADD(DD,1,@EndDate),121)
 declare 
    @TodayDate varchar(10),
    @Today30 varchar(10)
    
    set @Today30=CONVERT(varchar(10),DATEADD(mm,-1,DATEADD(DD,-day(@BeginDate)+1 ,@BeginDate)),121) --上个月第一天
    set @TodayDate=CONVERT(varchar(10),DATEADD(DD,-day(@BeginDate)+1 ,@BeginDate),121)  --本月第一天
-- 商品状态
 DECLARE @SqlCmd VARCHAR(Max)
  CREATE TABLE #tbGoodstatus( Goodstatus VARCHAR(200) ) 
  IF LTRIM(RTRIM(@Goodstatus)) <> ''
  BEGIN
    set @Goodstatus=''''+@Goodstatus+''''
    SET @Goodstatus = REPLACE(@Goodstatus,',','''))UNION SELECT ltrim(rtrim(''') 
    print @Goodstatus
    SET @SqlCmd = 'INSERT INTO #tbGoodstatus(Goodstatus) SELECT ltrim(rtrim('+ @Goodstatus+'))'
    
    print @SqlCmd
    
    EXEC(@SqlCmd )
  END 
  
 
  
  
  --采购订单
   create table #CG_SkuTable30(
  GoodsSKUID int ,
  Qty int,
  AllMoney money default 0)
    -- 30天销量
  insert into #CG_SkuTable30
  select
  ind.GoodsSKUID,
  sum(ISNULL(ind.Amount,0)), --30天入库数量
  SUM(ISNULL(ind.Amount,0)*ISNULL(ind.TaxPrice,0)) --入库订单的含税单价*入库数量
  from CG_StockInm(nolock) inm
  inner join CG_StockInD(nolock) ind on ind.StockInNID=inm.NID 
  left join b_goodssku bgs on bgs.NID=ind.GoodsSKUID
  left join  CG_StockOrderM cgm on cgm.BillNumber=inm.StockOrder
  where cgm.MakeDate>=@Today30 and cgm.MakeDate<@TodayDate and inm.CheckFlag=1
  group by ind.GoodsSKUID
  
  -------------------------------------------------------------------------------------------------------- 
   create table #inm_SkuTable(
  GoodsSKUID int ,
  BillNumber varchar(50) ,
  Qty int,
  inmdate datetime )
  insert into #inm_SkuTable
  select
  ind.GoodsSKUID,
  cgm.BillNumber,
  SUM( ISNULL(ind.Amount,0)),--没期限的入库数量
  inm.MakeDate
  from CG_StockInm(nolock) inm
  inner join CG_StockInD(nolock) ind on ind.StockInNID=inm.NID 
  left join b_goodssku bgs on bgs.NID=ind.GoodsSKUID
  left join CG_StockOrderM cgm on inm.StockOrder=cgm.BillNumber
  group by ind.GoodsSKUID,cgm.BillNumber,inm.MakeDate
  -------------------------------------------------------------------------------------------
  --采购订单数量汇总
  create table #cgd_huizong(
  goodsskuid int ,
  BillNumber varchar(20),
  Amount int ,    --采购数量
  TaxPrice varchar(50) )  --税收单价
  
  insert into #cgd_huizong
  select
  cgd.GoodsSKUID,
  cgm.BillNumber,
  SUM(cgd.Amount),
  isnull(cgd.TaxPrice,0)
  
  from CG_StockOrderM(nolock) cgm
   inner join CG_StockOrderd(nolock) cgd on cgd.StockOrderNID=cgm.NID
   left join b_goodssku bgs on bgs.NID=cgd.GoodsSKUID
   group by cgd.GoodsSKUID,cgm.BillNumber,cgd.TaxPrice
  


select                                                                      
Cgm.BillNumber as '采购订单号',  
Cgm.MakeDate as '采购日期',  
bgs.SKU as '产品SKU',  
bg.GoodsName as '商品名称', 
convert( varchar(20),bg.GoodsCode ) as '商品编码',
ISNULL(bgs.GoodsSKUStatus,'')  as '产品状态', 
hui.Amount as  '采购数量',      --cgd里的  
cast(convert(decimal(8,4),hui.TaxPrice)as varchar) as '含税单价',    
bo.PersonName as '采购员', 
d.Dictionaryname as '付款方式',  
b.suppliercode as '供应商编号',  
inm.MakeDate as '入库日期',             
ll.Qty as '入库数量',                                       
cast(convert(decimal(8,4),case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end) as varchar) as '上月采购均价',      
case when  cast(convert(decimal(8,4),case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end) as varchar)='0.0000'
then '0' else  cast(convert(decimal(8,4),case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end)-hui.TaxPrice as varchar) end as '采购单价差额',
case when  cast(convert(decimal(8,4),case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end) as varchar)='0.0000'
then '0' else (convert(decimal(8,4),case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end)-hui.TaxPrice)*ind.amount end as '采购差额' 
               
 from CG_StockInM inm inner join CG_StockInD ind on inm.NID=ind.StockInNID
                      left join B_GoodsSKU bgs on bgs.NID=ind.GoodsSKUID
                      left join B_Goods bg on bg.NID=bgs.GoodsID
                      left join CG_StockOrderM cgm on cgm.BillNumber=inm.StockOrder
                      Left  join B_Supplier b on b.NID=Cgm.SupplierID	
    	              Left  join B_Dictionary d on d.NID=Cgm.BalanceID	
    	              Left  join B_Person BO on  BO.NID=Cgm.SalerID 
                      left join #CG_SkuTable30 cg30 on cg30.GoodsSKUID=bgs.NID
    	              left join #inm_SkuTable ll on ll.GoodsSKUID=bgs.NID and ll.BillNumber=cgm.BillNumber and ll.inmdate=inm.MakeDate
    	              left join #cgd_huizong hui on hui.goodsskuid=bgs.NID and  hui.BillNumber=inm.StockOrder 
 
  where
  
    (@Sku = '' or  (bgs.SKU like '%'+@Sku+'%'))  
 and Cgm.MakeDate>=(ISNULL(@BeginDate,'')) and   Cgm.MakeDate<(ISNULL(@EndDate,''))
 AND ((ISNULL(@SalerName,'') = '0') OR (isnull(bg.SalerName,'') in (select Personname from B_Person where NID=@SalerName))) 
 AND ((ISNULL(@SalerName2,'') = '0') OR (isnull(bg.SalerName2,'') in (select Personname from B_Person where NID=@SalerName2)))

  AND ((ISNULL(@SupplierName,'') = '0') OR (isnull(b.SupplierName,'0') in (select SupplierName from B_Supplier where NID=@SupplierName)))	
 and ((ISNULL(@Purchaser,'') = '0') OR (isnull(bo.PersonName,'') in (select Personname from B_Person where NID=@Purchaser)))
 and (@caigounid = '' or  (Cgm.BillNumber like '%'+@caigounid+'%'))
 AND ((ISNULL(@Goodstatus,'') = '' OR bgs.GoodsSKUStatus IN (SELECT Goodstatus FROM #tbGoodstatus)))
 and Cgm.CheckFlag=1 and inm.CheckFlag=1
 
  
 end
