create procedure [dbo].[P_RP_FinancialProfit_customrjf_getperson]
  @UserID varchar(100)='',
  @usertype int=0
 as 
 begin
   DECLARE @Username VARCHAR(200)
   -- 现在@UserID=0 就是admin
   if @UserID=0
   begin
     set @Username='admin'
   end
   else
   begin
     set @Username=isnull((select top 1 USERID from S_SystemUser where NID=@UserID),'')
   end
   if LOWER(@Username)='admin'
   begin
     if  @usertype=0
     begin
       SELECT 1,spsi.NoteName FROM S_PalSyncInfo spsi 
       union SELECT 1,DictionaryName FROM  B_Dictionary  
       WHERE  CategoryID = 12
     end
     else
     begin
        select 0,'' union all 
         SELECT SyncInfoID,spsi.EbayUserID 
        FROM S_PalSyncInfo spsi 
     end
     
   end
   else
   begin
     DECLARE @SelDataUser VARCHAR(Max), @SqlCmd VARCHAR(Max) 
      SET @SelDataUser = ISNULL((SELECT SelDataUser 
      FROM B_Person WHERE NID = @UserID),'')
      IF (ISNULL(@SelDataUser,'') = '') SET @SelDataUser = '''' 
      if @usertype=0
      begin
         SET @SqlCmd = ' 
     SELECT 1,spsi.NoteName 
      FROM S_PalSyncInfo spsi WHERE spsi.NoteName IN ('+@SelDataUser+')' 
      +' UNION SELECT 1,DictionaryName FROM  B_Dictionary WHERE (CategoryID = 12)'
      +'  AND DictionaryName IN ('+@SelDataUser+')'
        
      end
      else 
      begin
        SET @SqlCmd = ' select 0,'''' union all 
         SELECT SyncInfoID,spsi.EbayUserID 
        FROM S_PalSyncInfo spsi WHERE spsi.NoteName IN ('+@SelDataUser+')' ;
      end
    
        EXECUTE(@SqlCmd)
   end
 end
