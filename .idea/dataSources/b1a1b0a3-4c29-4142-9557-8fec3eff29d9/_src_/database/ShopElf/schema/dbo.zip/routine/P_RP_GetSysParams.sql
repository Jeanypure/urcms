Create PROCEDURE [dbo].[P_RP_GetSysParams]                  
AS
begin
  select NID,ParaCode,ParaValue from B_SysParams(nolock) 
  where ParaCode not in ('Guid','TerminalProcess','OldVersion','RegisterCode')
end
