CREATE  proc [dbo].[P_RP_GoodsSaleTotal]
	@BeginDate  datetime =null,
	@EndDate	DateTime=null,
	@SKU		Varchar(100)='',
	@WeightPrice Float=0,
	@FeeRate	float=0
	
as
begin
	Create Table #fGoods 
	( 
		  sku varchar(100), 
		  ebaysku varchar(100), 
		  l_qty int, 
		  l_AMT money, 
		  costmoney money, 
		  Interest money 
	) 
	insert into #fGoods  
	SELECT  
		IsNull(d.SKU,'') as SKU,  
		IsNull(d.ebaySKU,'') as ebaySKU,  
		 sum(d.l_qty) as l_qty,
		 sum(isnull(d.l_amt*isnull(b.ExchangeRate,1),0)) as l_AMT, 
		 sum(d.costprice) AS costmoney, 
		 sum(d.l_amt*isnull(b.ExchangeRate,1) - d.costprice) AS Interest 
	FROM 
		p_tradedt d  
	left outer  join 
		p_trade m on m.nid=d.tradenid 
	left outer join 
		B_CurrencyCode b on b.currencycode=m.currencycode  
	where
		CONVERT(varchar(10), DateAdd(hour,8,m.ordertime),121) 
			between CONVERT(varchar(10),@BeginDate,121) and CONVERT(varchar(10),@EndDate,121)		
		and (@SKU='' or d.SKU like '%'+@SKU + '%')
	group by   
		IsNull(d.SKU,''), 
		IsNull(d.ebaySKU,'')  
	union all  
	SELECT  
		 IsNull(d.SKU,'') as SKU, 
		IsNull(d.ebaySKU,'') as ebaySKU,  
		 sum(d.l_qty) as l_qty, 
		sum(isnull(d.l_amt*isnull(b.ExchangeRate,1),0)) as l_AMT, 
		 sum(d.costprice) AS costmoney,  
		 sum(d.l_amt*isnull(b.ExchangeRate,1) - d.costprice) AS Interest 
	FROM  
		P_TradeDt_His d  
	left outer  join 
		P_Trade_His m on m.nid=d.tradenid 
	left outer join 
		B_CurrencyCode b on b.currencycode=m.currencycode  
	where
		CONVERT(varchar(10), DateAdd(hour,8,m.ordertime),121) 
			between CONVERT(varchar(10),@BeginDate,121) and CONVERT(varchar(10),@EndDate,121)		
		and (@SKU='' or d.SKU like '%'+@SKU + '%')
	group by    
		IsNull(d.SKU,''),IsNull(d.ebaySKU,'')  

	SELECT  
		g.GoodsCode,g.GoodsName,
		g.Class,g.Model,d.SKU,d.ebaysku,
		sum(d.l_qty) as l_qty, 
		ROUND(sum(d.l_amt),2) as l_AMT, 
		ROUND(sum(d.costmoney),2) AS costmoney, 
		SUM(isnull(g.[weight],0)*d.l_qty) as allweight,
		ROUND(SUM(isnull(g.[weight],0)*d.l_qty)*@WeightPrice,2) as weightMoeny,
		MAX(isnull(g.[weight],0))*@WeightPrice as WeightPrice,
		ROUND(sum(d.Interest)-SUM(isnull(g.[weight],0)*d.l_qty)*@WeightPrice-sum(d.l_amt)*@FeeRate,2) AS Interest ,
		ROUND(sum(d.l_amt)*@FeeRate,2)  AS OtherFee ,		
		ROUND(case when sum(d.l_qty)=0 then 0 else
				(sum(d.Interest)-SUM(isnull(g.[weight],0)*d.l_qty)*@WeightPrice-sum(d.l_amt)*@FeeRate)/sum(d.l_qty) end,2) AS oneInterest 		
	FROM   
		#fGoods d  
	left outer join 
		B_GoodsSKU gs on isnull(gs.SKU,'')=isnull(d.SKU,'') 
	left outer join 
		B_Goods g on g.NID=gs.GoodsID 
	group by   
		g.GoodsCode,g.GoodsName,g.Class,g.Model,d.SKU,d.ebaysku

	drop table #fGoods 
end
