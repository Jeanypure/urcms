CREATE proc [dbo].P_RP_LogisticWayRule_xy
@LogisticWayRulenid int   --物流规则选中的nid

AS
begin
declare @LogisticWayRulesetnid int
declare @maxset int
declare @nid int
--新建游标
declare youbiao cursor        
for 
select nid
from B_LogisticWaySet where LogisticWayRuleID=@LogisticWayRulenid and IType=1  --传进来老的物流规则nid变量

set @LogisticWayRulesetnid=(select MAX(NID) as NID from B_LogisticWayRuleSet)

--打开游标
open youbiao
--从游标里取出数据给 变量 赋值
fetch next from youbiao into @nid

while @@fetch_status = 0
begin
--print @nid
insert into B_LogisticWaySet
select 0 as LogisticWayNID,IType,CountryCode,ConditionValue,ConditionValue2,ShopLogisticWay,StoreNid,@LogisticWayRulesetnid as LogisticWayRuleID
from B_LogisticWaySet where  IType=1 and NID=@nid    --逐行插入
 
set @maxset=(select max(nid) from B_LogisticWaySet)

 
insert into B_LogisticWayRulePostCode
select postcodeS,postcodeE,@maxset,postName from  B_LogisticWayRulePostCode where LogisticWaySetID=@nid
--print @maxset


fetch next from youbiao into @nid

end


--关闭游标
close youbiao
--撤销游标
deallocate youbiao


end
