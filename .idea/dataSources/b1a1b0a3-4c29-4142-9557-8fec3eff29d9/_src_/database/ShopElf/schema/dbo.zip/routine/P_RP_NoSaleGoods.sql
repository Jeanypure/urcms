
CREATE proc [dbo].[P_RP_NoSaleGoods]
	@BeginDate  datetime =null,
	@EndDate	DateTime=null,
	@GoodsCode  Varchar(100)='',
	@GoodsName  Varchar(100)='',
	@SalerName  varchar(50) = '',
	@SalerName2  varchar(50) = '',
	@SKU		Varchar(100)='',
	@SupplierName varchar(100) = ''
	
as
begin
	select 
	  b.GoodsCode,
	  b.GoodsName,
	  a.SKU,
	  b.SalerName,
	  b.SalerName2,
	  bs.SupplierName
	from B_GoodsSKU a 
	left join B_Goods b on a.GoodsID = b.NID
	left join B_Supplier bs on b.SupplierID = bs.NID
	where (a.NID not in 
		(select pt.GoodsSKUID from P_TradeDt pt left join P_Trade p on pt.TradeNID = p.NID
		 where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate))
		   and ((@EndDate = '') or (p.ORDERTIME <= @EndDate))))
	  and (a.NID not in
		 (select pt.GoodsSKUID from P_TradeDt_His pt left join P_Trade_His p on pt.TradeNID = p.NID
			 where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate))
			   and ((@EndDate = '') or (p.ORDERTIME <= @EndDate))))
	  and (a.NID not in
		 (select pt.GoodsSKUID from P_TradeDtUn pt left join P_TradeUn p on pt.TradeNID = p.NID
			 where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate))
			   and ((@EndDate = '') or (p.ORDERTIME <= @EndDate))))
	  and ((@SKU = '') or (a.SKU like '%'+ @SKU +'%'))
	  and ((@GoodsName = '') or (b.GoodsName like '%'+ @GoodsName +'%'))
	  and ((@GoodsCode = '') or (b.GoodsCode like '%'+ @GoodsCode +'%'))
	  and ((@SalerName = '') or (b.SalerName = @SalerName))
	  and ((@SalerName2 = '') or (b.SalerName2 = @SalerName2))
	  and ((@SupplierName = '') or (bs.SupplierName like '%'+ @SupplierName +'%'))
end
