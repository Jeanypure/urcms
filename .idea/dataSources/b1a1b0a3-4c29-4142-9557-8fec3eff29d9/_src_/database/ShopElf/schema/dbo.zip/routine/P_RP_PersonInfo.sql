
CREATE proc [P_RP_PersonInfo]
    @BeginDate  datetime = '',
    @EndDate    datetime = '',
    @PackageMan    varchar(50) = ''
as
begin
   --主表
   create table #Trade(NID int,PaidanDate datetime,packingMan varchar(50),
                       PackageMan varchar(50),CheckMan varchar(50),
                       WeightMan varchar(50),SKUNum int,logicsWayNID int)
   insert into #Trade
   select 
      NID,
      PaidanDate,
      PackingMen,
      PackageMen,
      ScanningMen,
      WeighingMen,
      (select COUNT(1) from P_TradeDt pd where pd.TradeNID = p.NID),
      p.logicsWayNID
   from P_Trade p
   where (p.PackageMen <> '')
      and (@BeginDate = '' or p.PaidanDate >= @BeginDate)
      and (@EndDate = '' or p.PaidanDate <= @EndDate)
      and (@PackageMan = '' or p.PackageMen = @PackageMan)
   union 
   select 
      p.NID,
      PaidanDate,
      PackingMen,
      PackageMen,
      ScanningMen,
      WeighingMen,
      (select COUNT(1) from P_TradeDt pd where pd.TradeNID = p.NID),
      p.logicsWayNID
   from P_Trade_His p
   where (p.PackageMen <> '')
      and (@BeginDate = '' or p.PaidanDate >= @BeginDate)
      and (@EndDate = '' or p.PaidanDate <= @EndDate)
      and (@PackageMan = '' or p.PackageMen = @PackageMan)   
  
   --员工情况表
   create table #EmpInfo(PersonName varchar(50),
                        PackingNum int ,--拣货数量
                        PackageNum int,--包装数量
                        CheckNum int,--核单数量
                        WeightNum int,--称重数量
                        logicsWayNID int)--快递方式
    --包装统计
    insert into #EmpInfo(PersonName,PackageNum,logicsWayNID)
    select
       p.PackageMan,
       COUNT(p.NID),
       isnull(p.logicsWayNID,0)
    from #Trade p 
    group by p.PackageMan,logicsWayNID
    --拣货统计
    insert into #EmpInfo(PersonName,PackingNum,logicsWayNID)
    select
       p.packingMan,
       SUM(p.SKUNum),
       isnull(p.logicsWayNID,0)
    from #Trade p 
    group by p.packingMan ,logicsWayNID
    --核单统计
    insert into #EmpInfo(PersonName,CheckNum,logicsWayNID)
    select
       p.CheckMan,
       SUM(p.SKUNum),
       isnull(p.logicsWayNID,0)
    from #Trade p 
    group by p.CheckMan ,logicsWayNID
    --称重统计
    insert into #EmpInfo(PersonName,WeightNum,logicsWayNID)
    select
       p.WeightMan,
       COUNT(p.NID),
       isnull(p.logicsWayNID,0)
    from #Trade p 
    group by p.WeightMan,logicsWayNID
    
    select 
       o.PersonName,
       SUM(o.PackingNum) as PackingNum,
       SUM(o.PackageNum) as PackageNum,
       SUM(o.CheckNum)   as CheckNum,
       SUM(o.WeightNum) as WeightNum,
       b.name as logicsWay
    from #EmpInfo o
    left join B_LogisticWay b on o.logicsWayNID = b.NID
    group by PersonName,b.Name
END
