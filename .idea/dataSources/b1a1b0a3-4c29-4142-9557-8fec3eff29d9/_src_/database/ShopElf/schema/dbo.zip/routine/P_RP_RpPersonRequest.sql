CREATE proc [P_RP_RpPersonRequest]
	@BeginDate  varchar(10),
	@EndDate	varchar(10),
	@TrackNo	VARCHAR(100),
	@OrderNID	VARCHAR(100),
	@StoreName	VARCHAR(100),
	@Express	VARCHAR(100),
	@LogicsWay	VARCHAR(100),
	@ACK        Varchar(100),
	@Suffixs	varchar(Max),
	@ImportStartDate varchar(19),
	@ImportEndDate varchar(19),
	@CheckFlag int = 0   --0 全部订单  1未归档订单  2已归档订单
as
begin

    CREATE TABLE #tbSuffixs( SuffixsName VARCHAR(100) )
	IF LTRIM(RTRIM(@Suffixs)) <> ''
	BEGIN
		DECLARE @sSQLCmd VARCHAR(max) = ''
		SET @Suffixs = REPLACE(@Suffixs,',','''))UNION SELECT ltrim(rtrim(''') 
        SET @sSQLCmd = 'INSERT INTO #tbSuffixs(SuffixsName) SELECT ltrim(rtrim('+ @Suffixs+'))'
        PRINT @sSQLCmd
		EXEC(@sSQLCmd )
	END
	 
	if (@ImportEndDate='')
	begin
	  set @ImportEndDate = '2099-12-30 23:59:59';
	end
	create table #temporder(
	ack varchar(100) default '',
	SUFFIX varchar(100) default '',
	NID int not null,
	ClosingDate varchar(30) default '',
	TrackNo varchar(100) default '',
	TotalWeight money default 0,
	Expressfare money default 0,
	TotalWeight_import money default 0,
	Expressfare_import money default 0,
	TotalWeight_compare money default 0,
	Expressfare_compare money default 0,
	importTime datetime null,
	StockOut varchar(100) default '',

	LogisticWay varchar(100) default '',
	LogisticCompany varchar(100) default '',
	SHIPTOCOUNTRYNAME varchar(100) default '',
	CountryZnName varchar(100) default '',
	WeighingMen varchar(100) default ''
	)
	--update B_GoodsComparation set TrackNo = B.TrackNo 
	--from B_GoodsComparation A, p_Trade B 
	--   where IsNull(A.OrderNo,'')= convert(varchar(32),B.Nid) 
	--   and  IsNull(A.TrackNo,'') = ''

	--1.订单跟踪号关联的数据
	if @CheckFlag = 0 
	begin  
	insert into #temporder
	select  m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
		m.totalweight as TotalWeight,m.expressfare as Expressfare,
		bgc.TOTALWEIGHT as TotalWeight_import,
		bgc.EXPRESSFARE as Expressfare_import,
		isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
		isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
		bgc.IMPORTTIME as importTime, b.storename as StockOut,
		l.name as LogisticWay, e.name as LogisticCompany,
		SHIPTOCOUNTRYNAME ,bc.CountryZnName  -- add by ylq 2015-12-12  增加收货人国家名称 
		,m.WeighingMen
	From p_trade(nolock) m 
		LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
		LEFT JOIN T_express e on e.nid=m.expressnid 
		left join p_tradedt(nolock) d on d.tradenid=m.nid 
		left join b_goodssku(nolock) gs on gs.sku=d.sku 
		left join b_goods(nolock) bg on bg.nid=gs.goodsid 
		left join B_store b on b.nid=d.StoreID 
		left join B_GoodsComparation(nolock) bgc on  
		((bgc.TRACKNO = m.TrackNo and m.TrackNo<>'' )) 
		left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
	where  m.FilterFlag=100 and (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
		and (isnull(m.trackno,'') like '%'+@TrackNo+'%')
		and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
		and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
		and (isnull(e.name,'') Like '%'+@Express+'%')
		and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
		and (ISNULL(m.ack,'') like '%' + @ACK + '%')
		and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
		and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
		and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)
	union 
	select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
		m.totalweight as TotalWeight,m.expressfare as Expressfare,
		bgc.TOTALWEIGHT as TotalWeight_import,
		bgc.EXPRESSFARE as Expressfare_import,
		isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
		isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
		bgc.IMPORTTIME as importTime, b.storename as StockOut,
		l.name as LogisticWay, e.name as LogisticCompany,
		SHIPTOCOUNTRYNAME ,bc.CountryZnName  -- add by ylq 2015-12-12  增加收货人国家名称 
		,m.WeighingMen
	From p_trade(nolock) m 
		LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
		LEFT JOIN T_express e on e.nid=m.expressnid 
		left join p_tradedt(nolock) d on d.tradenid=m.nid 
		left join b_goodssku(nolock) gs on gs.sku=d.sku 
		left join b_goods(nolock) bg on bg.nid=gs.goodsid 
		left join B_store b on b.nid=d.StoreID 
		left join B_GoodsComparation(nolock) bgc on  
		( (bgc.OrderNo=cast(m.NID as varchar(50)))) 
		left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
	where  m.FilterFlag=100 and (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
		and (isnull(bgc.trackno,'') = '')
		and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
		and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
		and (isnull(e.name,'') Like '%'+@Express+'%')
		and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
		and (ISNULL(m.ack,'') like '%' + @ACK + '%')
		and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
		and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
		and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)	
    union 
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME,
			bc.CountryZnName    
			,m.WeighingMen
		From p_trade_his(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt_his(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  
			((bgc.TRACKNO = m.TrackNo and m.TrackNo<>'' )) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
			and (isnull(m.trackno,'') like '%'+@TrackNo+'%')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)	
		union
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME,
			bc.CountryZnName    
			,m.WeighingMen
		From p_trade_his(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt_his(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  
			((bgc.OrderNo=cast(m.NID as varchar(50)))) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
		and (isnull(bgc.trackno,'') = '')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)			
    end
    else if @CheckFlag = 1 
    begin 
        insert into #temporder
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME ,bc.CountryZnName  -- add by ylq 2015-12-12  增加收货人国家名称 
			,m.WeighingMen
		From p_trade(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  ((bgc.TRACKNO = m.TrackNo and m.TrackNo<>'' )) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  m.FilterFlag=100 and (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
			and (isnull(m.trackno,'') like '%'+@TrackNo+'%')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)    
		union 
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME ,bc.CountryZnName  -- add by ylq 2015-12-12  增加收货人国家名称 
			,m.WeighingMen
		From p_trade(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  ( (bgc.OrderNo=cast(m.NID as varchar(50)))) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  m.FilterFlag=100 and (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
			and (isnull(bgc.trackno,'') = '')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)    
		
    end
    else if @CheckFlag = 2 
    begin
      	insert into #temporder
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME,bc.CountryZnName  
			,m.WeighingMen
		From p_trade_his(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt_his(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  ((bgc.TRACKNO = m.TrackNo and m.TrackNo<>'' ) ) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
			and (isnull(m.trackno,'') like '%'+@TrackNo+'%')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)	    
		union 
		select m.ack, m.SUFFIX,  m.nid as NID,m.ClosingDate as ClosingDate,m.trackno as TrackNo,
			m.totalweight as TotalWeight,m.expressfare as Expressfare,
			bgc.TOTALWEIGHT as TotalWeight_import,
			bgc.EXPRESSFARE as Expressfare_import,
			isnull(m.totalweight,0) - IsNull(bgc.TOTALWEIGHT,0) as TotalWeight_compare,
			isnull(m.expressfare,0) - ISNULL(bgc.EXPRESSFARE,0) as Expressfare_compare,
			bgc.IMPORTTIME as importTime, b.storename as StockOut,
			l.name as LogisticWay, e.name as LogisticCompany,
			SHIPTOCOUNTRYNAME,bc.CountryZnName    
			,m.WeighingMen
		From p_trade_his(nolock) m 
			LEFT JOIN B_LogisticWay l on l.NID = m.logicsWayNID 
			LEFT JOIN T_express e on e.nid=m.expressnid 
			left join p_tradedt_his(nolock) d on d.tradenid=m.nid 
			left join b_goodssku(nolock) gs on gs.sku=d.sku 
			left join b_goods(nolock) bg on bg.nid=gs.goodsid 
			left join B_store b on b.nid=d.StoreID 
			left join B_GoodsComparation(nolock) bgc on  ((bgc.OrderNo=cast(m.NID as varchar(50)))) 
			left join B_Country bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE	
		where  (convert(varchar(10),m.closingdate,121) between @BeginDate and @EndDate)
			and (isnull(bgc.trackno,'') ='')
			and (isnull(@OrderNID,'')='' or  m.NID=@OrderNID)
			and (isnull(b.StoreName,'') Like '%'+@StoreName+'%')
			and (isnull(e.name,'') Like '%'+@Express+'%')
			and (isnull(l.Name,'') Like '%'+@LogicsWay+'%')
			and (ISNULL(m.ack,'') like '%' + @ACK + '%')
			and (m.SUFFIX in ( select SuffixsName from #tbSuffixs)  or @Suffixs = '')
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') >= @ImportStartDate)
			and (ISNULL(CONVERT(varchar(19),bgc.importTime,120),'') <= @ImportEndDate)	    
		
        end
         select
        * from (
        select
			m.ClosingDate as ClosingDate,
			m.CountryZnName as CountryZnName,
			m.Expressfare as Expressfare,
			m.Expressfare_compare as Expressfare_compare,
			m.Expressfare_import as Expressfare_import,
			m.LogisticCompany as LogisticCompany,
			m.LogisticWay as LogisticWay,
			m.NID,
			m.SHIPTOCOUNTRYNAME as SHIPTOCOUNTRYNAME,
			m.SUFFIX as SUFFIX,
			m.StockOut as StockOut,
			m.TotalWeight as TotalWeight,
			m.TotalWeight_compare as TotalWeight_compare,
			m.TotalWeight_import as TotalWeight_import,
			m.TrackNo as TrackNo,
			m.ack as ack,
			m.importTime as importTime,
			m.WeighingMen,
			row_number() over(partition by m.NID order by m.Expressfare_import desc) rn 
        from #temporder m ) a
        where a.rn<=1
        drop table #temporder
			 
end
