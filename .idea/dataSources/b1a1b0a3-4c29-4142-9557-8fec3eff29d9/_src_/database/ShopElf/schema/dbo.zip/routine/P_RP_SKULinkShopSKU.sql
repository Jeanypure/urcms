
create proc P_RP_SKULinkShopSKU 
	@SKU varchar(50)='',
	@ShopSKU varchar(100)=''
as
begin
	select 
		bs.SKU,
		bss.ShopSKU,
		g.goodsname,
		g.goodscode 
	from 
		B_GoodsSKULinkShop bss
	inner join 
		B_GoodsSKU bs on bs.SKU=bss.SKU
	inner join 
		B_Goods g on g.NID=bs.GoodsID
	where 
		(@sku='' or bs.sku=@sku)
		and  (@ShopSKU='' or bss.ShopSKU=@ShopSKU) 
end