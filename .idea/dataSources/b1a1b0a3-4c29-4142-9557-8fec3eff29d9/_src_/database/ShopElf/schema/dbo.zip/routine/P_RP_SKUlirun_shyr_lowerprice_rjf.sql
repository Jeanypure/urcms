CREATE proc [dbo].[P_RP_SKUlirun_shyr_lowerprice_rjf]
    @Purchaser VARCHAR(50),                --采购员
    @Sku		Varchar(100),              --SKU
    @Goodstatus VARCHAR(max),                --商品状态	
	@SalerName VARCHAR(50),                --业绩归属人1
	@SalerName2 VARCHAR(50),               --业绩归属人2
	@SupplierName VARCHAR(50),                --供应商
    @UserIDtemp int=0
AS
begin
  
  declare 
    @TodayDate varchar(10),
    @Today15 varchar(10),
    @Today30 varchar(10)
    -- 客户说今天不算在内 所以要向前推算一天
    set @TodayDate=CONVERT(varchar(10),DATEADD(DD,-1,GETDATE()),121)
    set @Today15=CONVERT(varchar(10),DATEADD(DD,-16,GETDATE()),121)
    set @Today30=CONVERT(varchar(10),DATEADD(DD,-31,GETDATE()),121)
  -- 商品状态
  DECLARE @SqlCmd VARCHAR(Max)
  CREATE TABLE #tbGoodstatus( Goodstatus VARCHAR(200) ) 
  IF LTRIM(RTRIM(@Goodstatus)) <> ''
  BEGIN
    set @Goodstatus=''''+@Goodstatus+''''
    SET @Goodstatus = REPLACE(@Goodstatus,',','''))UNION SELECT ltrim(rtrim(''') 
    SET @SqlCmd = 'INSERT INTO #tbGoodstatus(Goodstatus) SELECT ltrim(rtrim('+ @Goodstatus+'))'
    EXEC(@SqlCmd )
  END 
  -- 销售订单sku  
  create table #SkuTable15(
  SKU varchar(200) ,
  Qty int)
  create table #SkuTable30(
  SKU varchar(200) ,
  Qty int)
  -- 采购订单sku
  create table #CG_SkuTable15(
  GoodsSKUID int ,
  Qty int,
  AllMoney money default 0)
  create table #CG_SkuTable30(
  GoodsSKUID int ,
  Qty int,
  AllMoney money default 0)
  --销售订单
  -- 15天销量
  insert into #SkuTable15
  select 
    m.SKU,
    sum(m.L_QTY)
  from
  (select
  isnull(dt.SKU,'') as SKU,
  ISNULL(dt.L_QTY,0) as L_QTY
  from P_Trade(nolock) m
  inner join P_TradeDt(nolock) dt on dt.TradeNID=m.NID 
  where (m.ORDERTIME between @Today15 and @TodayDate)
  union all
  select
  isnull(dt.SKU,''),
  ISNULL(dt.L_QTY,0)
  from P_Trade_His(nolock) m
  inner join P_TradeDt_his(nolock) dt on dt.TradeNID=m.NID 
  where (m.ORDERTIME between @Today15 and @TodayDate)) m
  group by m.SKU
  -- 16-45天销量
  insert into #SkuTable30
  select 
    m.SKU,
    sum(m.L_QTY)
  from
  (select
  isnull(dt.SKU,'') as SKU,
  ISNULL(dt.L_QTY,0) as L_QTY
  from P_Trade(nolock) m
  inner join P_TradeDt(nolock) dt on dt.TradeNID=m.NID 
  where (m.ORDERTIME between @Today30  and @Today15)
  union all
  select
  isnull(dt.SKU,''),
  ISNULL(dt.L_QTY,0)
  from P_Trade_His(nolock) m
  inner join P_TradeDt_his(nolock) dt on dt.TradeNID=m.NID 
  where (m.ORDERTIME between @Today30  and @Today15)) m
  group by m.SKU
  -- 采购订单
  -- 15天采购订单
  insert into #CG_SkuTable15
  select
  dt.GoodsSKUID,
  sum(ISNULL(dt.Amount,0)),
  SUM(ISNULL(dt.Amount,0)*ISNULL(dt.TaxPrice,0))
  from CG_StockOrderM(nolock) m
  inner join CG_StockOrderD(nolock) dt on dt.StockOrderNID=m.NID 
  where (m.MakeDate between @Today15 and @TodayDate)
  group by dt.GoodsSKUID
  -- 16-45天销量
  insert into #CG_SkuTable30
  select
  dt.GoodsSKUID,
  sum(ISNULL(dt.Amount,0)),
  SUM(ISNULL(dt.Amount,0)*ISNULL(dt.TaxPrice,0))
  from CG_StockOrderM(nolock) m
  inner join CG_StockOrderD(nolock) dt on dt.StockOrderNID=m.NID 
  where (m.MakeDate between @Today30  and @Today15)
  group by dt.GoodsSKUID
  
  -- 
  select
  bgs.SKU as '产品SKU',
  bg.GoodsCode as '商品编码',
  bg.GoodsName as '商品名称',
  bgs.GoodsSKUStatus as '商品SKU状态',
  isnull(bsp.SupplierName,'') as '供应商名称',
  bg.SalerName as '业绩归属1',
  bg.SalerName2 as '业绩归属2',
  bg.Purchaser as '采购员',
  isnull(m15.Qty,0)*2 as '(SKU近15天销量)*2',
  isnull(m30.Qty,0)*2 as '(SKU前15-30天销量)*2',
 isnull( m15.Qty,0)*2-isnull(m30.Qty,0)*2 as '销量变化(30天)',
  ROUND(case when isnull(cg15.Qty,0)=0 then 0 else cg15.AllMoney/cg15.Qty end,2) as 'SKU近15天平均采购单价',
  ROUND(case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end,2) as 'SKU前15-30天平均采购单价',
  ROUND((case when isnull(cg15.Qty,0)=0 then 0 else cg15.AllMoney/cg15.Qty end)
  -  (case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end),2) '采购价变化',
  convert(numeric(12,3), case when (case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end)=0 then 0
  else ((case when isnull(cg15.Qty,0)=0 then 0 else cg15.AllMoney/cg15.Qty end)
  -  (case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end))/
    (case when isnull(cg30.Qty,0)=0 then 0 else cg30.AllMoney/cg30.Qty end)
  end ) as '采购价变化率'
  from B_Goods bg
  inner join B_GoodsSKU bgs on bgs.GoodsID=bg.NID
  left join #SkuTable15 m15 on m15.SKU=bgs.SKU
  left join #SkuTable30 m30 on m30.SKU=m15.SKU
  left join B_Supplier bsp on bsp.NID=bg.SupplierID
  left join #CG_SkuTable15 cg15 on cg15.GoodsSKUID=bgs.NID
  left join #CG_SkuTable30 cg30 on cg30.GoodsSKUID=bgs.NID
  where ((ISNULL(@Purchaser,'') = '0') OR (isnull(bg.Purchaser,'') in (select Personname from B_Person where NID=@Purchaser)))
  AND (@Sku = '' or  (bgs.SKU like '%'+@Sku+'%')) 
  AND (ISNULL(@Goodstatus,'') = '' OR bgs.GoodsSKUStatus IN (SELECT Goodstatus FROM #tbGoodstatus))	   --卖家简称
  AND ((ISNULL(@SalerName,'') = '0') OR (isnull(bg.SalerName,'') in (select Personname from B_Person where NID=@SalerName))) 
  AND ((ISNULL(@SalerName2,'') = '0') OR (isnull(bg.SalerName2,'') in (select Personname from B_Person where NID=@SalerName2)))	
  and (@SupplierName='' or (isnull(bg.SupplierID,0) in (select NID from B_Supplier where SupplierName=@SupplierName)))
end	