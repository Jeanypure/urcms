Create procedure [dbo].[P_RP_SKUlirun_shyr_spztduoxuan_rjf]
as
begin
    
    select nid,DictionaryName  
    from B_Dictionary 
    where CategoryID in ( select NID from B_DictionaryCats where CategoryName='商品状态')

end
