
CREATE Proc [P_RP_SaleAfterTotal]
	@SellerID	varchar(50)='',
	@BillType	varchar(50)='',
	@SaleAfterType	varchar(200)='',
	@BeginDate	Varchar(30)=null,
	@EndDate	Varchar(30)=null
as
begin
  
  create table #TabTrade(
    SaleAfterNid   int Null,
    sku   varchar(48) Null,
    OrderAmount   float Null,
    OrderMoney    float Null 
  )
  
  create table #TabMain(
    SaleAfterNid   int Null,
    AddressOwner  varchar(48) Null,
    ScanningMen   varchar(48) Null,
    Suffix  varchar(50) Null,
    logicsWayName varchar(68) Null
  )
 
   insert into #TabTrade (SaleAfterNid,Sku, OrderAmount, OrderMoney)
   select M.Nid, gs.SKu,  SUM(L_Qty), SUM(L_Amt)  
      from p_trade A
      inner join P_TradeDt B on A.NID = B.TradeNID 
      inner join XS_SaleAfterM M on cast(M.OrderNumber as varchar(20)) = cast(A.NID as varchar(20))  
      inner join b_GoodsSku gs on gs.Nid = B.GoodsSkuId 
      where convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)
    group by M.Nid,gs.SKu 
    
   insert into #TabTrade (SaleAfterNid,Sku, OrderAmount, OrderMoney)
   select M.Nid, gs.SKu,  SUM(L_Qty), SUM(L_Amt)  
      from p_trade_His A
      inner join P_TradeDt_His B on A.NID = B.TradeNID 
      inner join XS_SaleAfterM M on cast(M.OrderNumber as varchar(20)) = cast(A.NID as varchar(20))  
      inner join b_GoodsSku gs on gs.Nid = B.GoodsSkuId 
      where convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)
    group by M.Nid,gs.SKu
    
    insert into #TabMain(SaleAfterNid,AddressOwner,ScanningMen,Suffix,logicsWayName)
    select M.Nid, A.ADDRESSOWNER, A.ScanningMen, A.SUFFIX, l.name 
      from p_trade A
      inner join XS_SaleAfterM M on cast(M.OrderNumber as varchar(20)) = cast(A.NID as varchar(20))  
      left join B_LogisticWay l on l.NID = A.logicsWayNID 
      where convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)
 
    insert into #TabMain(SaleAfterNid,AddressOwner,ScanningMen,Suffix,logicsWayName)
    select distinct M.Nid, A.ADDRESSOWNER, A.ScanningMen, A.SUFFIX, l.name 
      from p_trade_His A
      inner join XS_SaleAfterM M on cast(M.OrderNumber as varchar(20)) = cast(A.NID as varchar(20))  
      left join B_LogisticWay l on l.NID = A.logicsWayNID 
      where convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)  
		
    insert into #TabMain(SaleAfterNid,AddressOwner,ScanningMen,Suffix,logicsWayName)
    select distinct M.Nid, A.ADDRESSOWNER, A.ScanningMen, A.SUFFIX, l.name 
      from p_tradeUn A
      inner join XS_SaleAfterM M on cast(M.OrderNumber as varchar(20)) = cast(A.NID as varchar(20))  
      left join B_LogisticWay l on l.NID = A.logicsWayNID 
      where convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)   
    
	select 
		CONVERT(varchar(10),m.MakeDate,121) as MakeDate,
		m.UserName as sellername,
		m.SaleType as CategoryName,
		m.SaleTag as SaleType,
		m.CurrencyCode,
		m.SellerEMail,
		m.ShipToCountry as Country,
		gs.SKU,
		m.Recorder,
		case when m.SaleType='重寄' then d.[Money] else 0 end as [Money],
		case when isnull(d.Reason,'')='' then '未指定原因' else isnull(d.Reason,'') end  as Reason,
		count(1) as Aftercount,		
		sum(d.ReMoney) as ReturnMoney,
		sum(m.SaleMoney) as SaleMoney,
		case when m.SaleType='重寄' then sum(d.[Money]) else sum(d.remoney) end as SendMoney,
		sum(m.amt) as OriginalMoney,
		SUM(d.ReMoney * ISNULL(bc.ExchangeRate,1)) as ReturnMoneyRMB,
		SUM(m.amt * ISNULL(bc.ExchangeRate,1)) as OriginalMoneyRMB,
		tmp2.AddressOwner, tmp2.ScanningMen, tmp2.logicsWayName, 
		Sum(tmp1.OrderAmount) as OrderAmount, Sum(tmp1.OrderMoney) as OrderMoney,
		bb.CountryZnName, g.SalerName, g.Purchaser,g.possessMan1, g.possessMan2,tmp2.Suffix,
		DateDiff(Day, dateadd(hour,8,M.ordertime),M.MakeDate) as DayTime
	from 
		XS_SaleAfterD D
	inner join 
		XS_SaleAfterM M on m.NID=d.SaleAfterNID
	inner join 
		B_GoodsSKU gs on gs.NID=d.GoodsSKUID
	inner join b_Goods g on g.NID = gs.GoodsID 
	left join #TabTrade tmp1 on tmp1.SaleAfterNid = M.Nid and tmp1.sku = gs.SKU 
	left join #TabMain tmp2 on tmp2.SaleAfterNid = M.NID 
    left join 
        B_CurrencyCode bc on bc.CURRENCYCODE = m.CURRENCYCODE	
    left join B_Country bb on bb.CountryCode = m.ShipToCountryCode 
	where 
		convert(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate
		and (@SellerID='' or m.UserName=@SellerID)
		and (@billtype='' or m.saleType=@billtype)		
		and (@SaleAfterType='' or m.Saletag=@SaleAfterType)
	group by 
		CONVERT(varchar(10),m.MakeDate,121),
		m.UserName,
		m.SaleType,
		m.SaleTag,
		m.CurrencyCode,
		m.SellerEMail,
		m.ShipToCountry,
		gs.SKU,
		m.Recorder,
		[Money],
		isnull(d.Reason,''),
		tmp2.AddressOwner, tmp2.ScanningMen, tmp2.logicsWayName,tmp2.Suffix, 
		bb.CountryZnName, g.SalerName, g.Purchaser,g.possessMan1, g.possessMan2,
		m.ORDERTIME, M.MakeDate 
		 
end
