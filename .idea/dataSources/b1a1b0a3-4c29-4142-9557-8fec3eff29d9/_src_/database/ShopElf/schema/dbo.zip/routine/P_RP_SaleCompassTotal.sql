
CREATE PROCEDURE [dbo].[P_RP_SaleCompassTotal]
AS
BEGIN 
   CREATE TABLE #TodaySendTrade
   (
   	 OrderCount INT DEFAULT 0,
   	 amt NUMERIC(18,4) DEFAULT 0
   	)
   INSERT INTO  #TodaySendTrade
   SELECT   isnull(cast(count(p.nid)  AS integer),0) AS ordercount,
   isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE     filterflag = 100  AND CONVERT(VARCHAR(10),p.CLOSINGDATE,121) = CONVERT(VARCHAR(10), GETDATE(),121)
   
   
   INSERT INTO  #TodaySendTrade
   SELECT   isnull(cast(count(p.nid)  AS integer),0) AS ordercount,
   isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
  
   FROM   p_trade_His  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE  CONVERT(VARCHAR(10),p.CLOSINGDATE,121) = CONVERT(VARCHAR(10), GETDATE(),121)
   
   SELECT 
      cast(1  AS integer) AS ino 
      ,'未付款订单' AS orderstatus 
      ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
      ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt  
   FROM   p_tradeUn  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE p.FilterFlag = 0 and DATEPART(YYYY,p.ORDERTIME)>2010 
UNION 
  SELECT 
      cast(2  AS integer) AS ino 
      ,'缺货订单' AS orderstatus 
      ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
      ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt  
   FROM   p_tradeUn  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE p.FilterFlag = 1   and DATEPART(YYYY,p.ORDERTIME)>2010 
 --UNION 
 -- SELECT 
 --     cast(3  AS integer) AS ino 
 --     ,'退货订单[待处理]' AS orderstatus 
 --     ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
 --     ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt  
 --  FROM   p_tradeUn  p 
 --  left join B_CurrencyCode b on b.currencycode=p.currencycode 
 --  WHERE p.FilterFlag = 2 
 --UNION 
 -- SELECT 
 --     cast(4  AS integer) AS ino 
 --     ,'取消订单[待处理]' AS orderstatus 
 --     ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
 --     ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt  
 --  FROM   p_tradeUn  p 
 --  left join B_CurrencyCode b on b.currencycode=p.currencycode 
 --  WHERE p.FilterFlag = 3 
   
 -- UNION 
 -- SELECT 
 --     cast(5  AS integer) AS ino 
 --     ,'其它异常单[待处理]' AS orderstatus 
 --     ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
 --     ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt  
 --  FROM   p_tradeUn  p 
 --  left join B_CurrencyCode b on b.currencycode=p.currencycode 
 --  WHERE p.FilterFlag = 4 
     
UNION  
  SELECT  cast(3  AS integer) AS ino 
          ,'待派单' AS orderstatus 
          ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
          ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE   isnull(filterflag,0) = 5  and DATEPART(YYYY,p.ORDERTIME)>2010 
  UNION  
  SELECT cast(4  AS integer) AS ino 
         ,'已派未转仓库' AS orderstatus 
         ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
         ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE     filterflag = 6 and DATEPART(YYYY,p.ORDERTIME)>2010 
  UNION  
  SELECT cast(5  AS integer) AS ino 
         ,'未拣货' AS orderstatus 
         ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
         ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE  filterflag = 20 and DATEPART(YYYY,p.ORDERTIME)>2010  
    UNION  
  SELECT cast(6  AS integer) AS ino 
         ,'未核单' AS orderstatus 
         ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
         ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE     filterflag = 22
	and DATEPART(YYYY,p.ORDERTIME)>2010  
UNION  
  SELECT cast(7  AS integer) AS ino 
         ,'未包装' AS orderstatus 
         ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
         ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
   WHERE     filterflag = 24   and DATEPART(YYYY,p.ORDERTIME)>2010  
UNION  
  SELECT cast(8  AS integer) AS ino 
         ,'待发货订单' AS orderstatus 
         ,isnull(cast(count(p.nid)  AS integer),0) AS ordercount
         ,isnull(sum(amt*isnull(b.ExchangeRate,1)),0) as amt   
   FROM   p_trade  p 
   left join B_CurrencyCode b on b.currencycode=p.currencycode 
  WHERE FilterFlag=40 and DATEPART(YYYY,p.ORDERTIME)>2010  
UNION  
   SELECT   cast(9  AS integer) AS ino ,'已发货(今日)' AS orderstatus ,sum(p.ordercount) AS ordercount,
   SUM(p.amt) as amt   
   FROM   #TodaySendTrade  p 
   
  ORDER BY   ino  
  DROP TABLE #TodaySendTrade 
END

