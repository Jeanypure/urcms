
CREATE proc [dbo].[P_RP_SaleTypeList]
	@BeginDate  datetime = '',
	@EndDate	DateTime= '',
	@TypeName    varchar(50) = ''
as
begin
	select
	  pt.TradeNID,
	  p.SALUTATION,
	  p.AMT,
	  SUM(pt.CostPrice) as CostPrice
	into #Temp
	from P_TradeDt pt 
	left join P_Trade p on pt.TradeNID = p.NID
	where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate))
	  and ((@EndDate = '') or (p.ORDERTIME <= @EndDate))
	  and ((@TypeName = '') or (p.SALUTATION = @TypeName))
	 group by pt.TradeNID,p.SALUTATION,p.AMT
    union all 
    select
	  pt.TradeNID,
	  p.SALUTATION,
	  p.AMT,
	  SUM(pt.CostPrice) as CostPrice
	from P_TradeDt_His pt 
	left join P_Trade_His p on pt.TradeNID = p.NID
	where ((@BeginDate = '') or (p.ORDERTIME >= @BeginDate))
	  and ((@EndDate = '') or (p.ORDERTIME <= @EndDate)) 
	  and ((@TypeName = '') or (p.SALUTATION = @TypeName))
	group by pt.TradeNID,p.SALUTATION,p.AMT   
	
	select 
	  t.SALUTATION,
	  SUM(AMT) as AMT,
	  SUM(CostPrice) as CostPrice
	into #last
	from #Temp t
	group by t.SALUTATION
	
	select 
	  l.SALUTATION,
	  l.AMT,
	  l.CostPrice,
	  (ISNULL(l.AMT,0) - ISNULL(l.CostPrice,0)) as Salepri,
	  (ISNULL(l.AMT,0) - ISNULL(l.CostPrice,0))*100/AMT as SaleRate
	from #last l
	
end
