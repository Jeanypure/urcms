
CREATE proc [dbo].[P_RP_SkuSaleTotal2]
	@BeginDate  datetime =null,
	@EndDate	DateTime=null,
	@SKU		Varchar(100)=''
	
as
BEGIN
	
	CREATE TABLE #SendTrade
	(
		TradeNID INT DEFAULT 0 
	)
	
	CREATE TABLE #SendTradeDt
	(
		GoodsSKUNID INT DEFAULT 0,
		StoreID INT DEFAULT 0 , 
		Qty NUMERIC(18,4) DEFAULT 0 
	)
	
	CREATE TABLE #SendTradeDtTotal
	(
		GoodsSKUNID INT DEFAULT 0,
		StoreID INT DEFAULT 0 , 
		Qty NUMERIC(18,4) DEFAULT 0 
	)
	
	DECLARE @GoodsSKUID INT = 0
	IF ISNULL(@SKU,'') <> ''
	SET @GoodsSKUID = ISNULL((SELECT NID FROM B_GoodsSKU WHERE SKU = @SKU),0)
	
	
	INSERT INTO #SendTrade	
	SELECT pt.NID FROM P_trade pt WHERE pt.FilterFlag = 10 AND (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)
		
	INSERT INTO #SendTrade	
	SELECT pt.NID FROM P_trade_His pt WHERE (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)	
	
	INSERT INTO #SendTradeDt	
	SELECT pt.GoodsSKUID, pt.StoreID, pt.L_QTY
	FROM P_tradeDt pt JOIN #SendTrade st ON pt.TradeNID = st.TradeNID	
	WHERE (ISNULL(@GoodsSKUID,0) = 0 OR pt.GoodsSKUID = @GoodsSKUID)
	
	
	INSERT INTO #SendTradeDt	
	SELECT pt.GoodsSKUID, pt.StoreID, pt.L_QTY
	FROM P_TradeDt_His pt JOIN #SendTrade st ON pt.TradeNID = st.TradeNID
	WHERE (ISNULL(@GoodsSKUID,0) = 0 OR pt.GoodsSKUID = @GoodsSKUID)
	
	
	INSERT INTO #SendTradeDtTotal	
	SELECT GoodsSKUNID , StoreID, SUM(Qty) 
	FROM #SendTradeDt
	GROUP BY GoodsSKUNID , StoreID	
	
	
	select 
	  b.GoodsCode,
	  b.GoodsName,
	  a.SKU,
	  b.Class,
	  b.Model,
	  a.property1,
	  a.property2,
	  a.property3,
	  bss.StoreName,
	  st.Qty
	from B_GoodsSKU a JOIN #SendTradeDtTotal st ON a.NID = st.GoodsSKUNID
                      LEFT JOIN B_Store bss ON bss.NID = st.StoreID
	                  LEFT JOIN B_Goods b on a.GoodsID = b.NID
	
	ORDER BY a.SKU
   DROP TABLE #SendTrade	
   
   DROP TABLE #SendTradeDt
   
   DROP TABLE #SendTradeDtTotal
end
