create proc [dbo].[P_RP_StockInDetail]
	@BeginDate varchar(10)='',
	@EndDate	varchar(10)='',
	@Sku		varchar(10)=''
as
begin	
	
	select 
		'入库类别'=case when m.BillType  =1 then '采购入库单' 
				        when m.BillType =2 then '采购退回单' 
				        when m.BillType =3 then '其它入库单'
				        when m.BillType =3 then '返修入库单'
				        else '无类别' end, 
		'单据状态'= case m.checkflag    when 1 then '审核'   when 3 then '作废' else '未审核' end,
		'仓库'	= ISNULL(t.storename,''),
		'经办人'= ISNULL(p.personname,''),
		'制单人'= m.recorder, 
		'审核人'= m.audier,
		'审核时间'=m.audieDate,
		'财务审核人'=m.financialMan,
		'财务审核时间'=m.financialTime,
		'商品编码'=ISNULL(g.GoodsCode,''),
		'商品名称'=ISNULL(g.GoodsName,''),
		'商品SKU'=ISNULL(gs.SKU,''),
		'供应商名称'=ISNULL(s.SupplierName,''),
		'单位'=ISNULL(g.Unit,''),
		'规格尺寸'=ISNULL(g.Model,''),
		'入库日期'=m.MakeDate,
		'入库单号'=m.BillNumber,
		'入库数量'=d.Amount,
		'入库单价'=d.TaxPrice,
		'入库金额'=d.AllMoney,
		'备注'=d.Remark
	from 
		cg_stockind d
	inner join 
		CG_StockInM m on m.nid=d.stockinnid
	left outer join 
		b_store t on t.nid=m.storeid
	left outer join 
		B_Person p on p.nid=m.salerid		
	left outer join 
		B_Supplier s on s.NID=m.SupplierID
	left outer join 
		B_goodssku gs on gs.nid=d.goodsskuid
	left outer join 
		b_goods g on g.nid=gs.goodsid
	where
		CONVERT(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate 
		and (@sku='' or gs.SKU like '%'+@sku+'%')
end
