
Create proc P_RP_StockInTaxprice
@BDate varchar(20),
@EDate varchar(20),
@sku varchar(50),
@salerid integer,
@possessman varchar(50)            
as

	create Table #StockInSKUPrice(		
		GoodsskuID		int,        
        Taxprice1	numeric(18,2),
		Taxprice2	numeric(18,2),
        Taxprice3	numeric(18,2),
		Taxprice4	numeric(18,2),
        Taxprice5	numeric(18,2),
		Taxprice6	numeric(18,2),
        Taxprice7	numeric(18,2),
		Taxprice8	numeric(18,2),
        Taxprice9	numeric(18,2),
		Taxprice10	numeric(18,2),
        Taxprice11	numeric(18,2),
		Taxprice12	numeric(18,2),
        Taxprice13	numeric(18,2),
		Taxprice14	numeric(18,2),
        Taxprice15	numeric(18,2),
		Taxprice16	numeric(18,2),
        Taxprice17	numeric(18,2),
		Taxprice18	numeric(18,2),
        Taxprice19	numeric(18,2),
		Taxprice20	numeric(18,2),
        Taxprice21	numeric(18,2),
		Taxprice22	numeric(18,2),
        Taxprice23	numeric(18,2),
		Taxprice24	numeric(18,2),
        Taxprice25	numeric(18,2),
		Taxprice26	numeric(18,2),
        Taxprice27	numeric(18,2),
		Taxprice28	numeric(18,2),
        Taxprice29	numeric(18,2),
		Taxprice30	numeric(18,2)		
	)



DECLARE MyCursor CURSOR FOR 
select distinct goodsskuid from cg_StockInd d 
inner join cg_StockInm m on m.nid=d.StockInnid 
inner join b_goodssku bgs on bgs.nid=d.goodsskuid 
inner join b_goods bg on bg.nid=bgs.goodsid 
where m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1  
and (@sku='' or bgs.sku like '%' + @sku + '%')
and (@salerid=0 or m.salerid = @salerid)
and (@possessman='' or  bg.possessman1 =  @possessman )

 

--打开游标    
OPEN MyCursor

--循环游标
DECLARE @goodsskuid int
FETCH NEXT FROM  MyCursor INTO @goodsskuid
WHILE @@FETCH_STATUS =0
BEGIN
--
insert into #StockInSKUPrice  
select t.goodsskuid,t.taxprice as t1taxprice, t2.taxprice as t2price,
t3.taxprice as t3price,t4.taxprice as t4price,t5.taxprice as t5price,t6.taxprice as t6price,
t7.taxprice as t7price,t8.taxprice as t8price,t9.taxprice as t9price,t10.taxprice as t10price,
t11.taxprice as t11price,t12.taxprice as t12price,t13.taxprice as t13price,t14.taxprice as t14price,
t15.taxprice as t15price,t16.taxprice as t16price,t17.taxprice as t17price,t18.taxprice as t18price,
t19.taxprice as t19price,t20.taxprice as t20price,t21.taxprice as t21price,t22.taxprice as t22price,
t23.taxprice as t23price,t24.taxprice as t24price,t25.taxprice as t25price,t26.taxprice as t26price,
t27.taxprice as t27price,t28.taxprice as t28price,t29.taxprice as t29price,t30.taxprice as t30price

from 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid  and (@salerid=0 or m.salerid = @salerid)
) t 
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t2 on t2.goodsskuid=t.goodsskuid and t2.rn=2
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t3 on t3.goodsskuid=t.goodsskuid and t3.rn=3
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t4 on t4.goodsskuid=t.goodsskuid and t4.rn=4
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t5 on t5.goodsskuid=t.goodsskuid and t5.rn=5
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t6 on t6.goodsskuid=t.goodsskuid and t6.rn=6
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t7 on t7.goodsskuid=t.goodsskuid and t7.rn=7
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t8 on t8.goodsskuid=t.goodsskuid and t8.rn=8
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t9 on t9.goodsskuid=t.goodsskuid and t9.rn=9
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t10 on t10.goodsskuid=t.goodsskuid and t10.rn=10
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t11 on t11.goodsskuid=t.goodsskuid and t11.rn=11
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t12 on t12.goodsskuid=t.goodsskuid and t12.rn=12
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t13 on t13.goodsskuid=t.goodsskuid and t13.rn=13
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t14 on t14.goodsskuid=t.goodsskuid and t14.rn=14
left join
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t15 on t15.goodsskuid=t.goodsskuid and t15.rn=15
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t16 on t16.goodsskuid=t.goodsskuid and t16.rn=16
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t17 on t17.goodsskuid=t.goodsskuid and t17.rn=17
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t18 on t18.goodsskuid=t.goodsskuid and t18.rn=18
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t19 on t19.goodsskuid=t.goodsskuid and t19.rn=19
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t20 on t20.goodsskuid=t.goodsskuid and t20.rn=20
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t21 on t21.goodsskuid=t.goodsskuid and t21.rn=21
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t22 on t22.goodsskuid=t.goodsskuid and t22.rn=22
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t23 on t23.goodsskuid=t.goodsskuid and t23.rn=23
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t24 on t24.goodsskuid=t.goodsskuid and t24.rn=24
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t25 on t25.goodsskuid=t.goodsskuid and t25.rn=25
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t26 on t26.goodsskuid=t.goodsskuid and t26.rn=26
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t27 on t27.goodsskuid=t.goodsskuid and t27.rn=27
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t28 on t28.goodsskuid=t.goodsskuid and t28.rn=28
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t29 on t29.goodsskuid=t.goodsskuid and t29.rn=29
left join 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid and (@salerid=0 or m.salerid = @salerid)) t30 on t30.goodsskuid=t.goodsskuid and t30.rn=30
where t.rn=1

       
FETCH NEXT FROM  MyCursor INTO @goodsskuid
END    

--关闭游标
CLOSE MyCursor
--释放资源
DEALLOCATE MyCursor


select t.*,bgs.sku,bgs.skuname,bg.goodscode,bg.class,bg.model,bg.linkurl,bg.linkurl2,bg.linkurl3,bg.linkurl4,bg.linkurl5,bg.linkurl6 
from #StockInSKUPrice t
inner join B_GoodsSKU bgs on bgs.nid=t.goodsskuid
inner join B_Goods bg on bg.nid=bgs.goodsid

Drop table #StockInSKUPrice

