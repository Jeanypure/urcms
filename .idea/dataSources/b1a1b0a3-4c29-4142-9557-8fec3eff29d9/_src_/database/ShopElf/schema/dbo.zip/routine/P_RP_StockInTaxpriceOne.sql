
Create proc P_RP_StockInTaxpriceOne
@BDate varchar(20),
@EDate varchar(20),
@sku varchar(50),
@salerid integer,
@possessman varchar(50)            
as

	create Table #StockInSKUPrice(		
		GoodsskuID		int,        
		Taxprice	numeric(18,2)		
	)


DECLARE @goodsskuid int, @i int
set @goodsskuid=(
select distinct goodsskuid from cg_StockInd d 
inner join cg_StockInm m on m.nid=d.StockInnid 
inner join b_goodssku bgs on bgs.nid=d.goodsskuid 
inner join b_goods bg on bg.nid=bgs.goodsid 
where m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1  
and (@sku='' or bgs.sku = @sku )
and (@salerid=0 or m.salerid = @salerid)
and (@possessman='' or  bg.possessman1 = @possessman )) 

set @i = 1
while @i <10
begin
insert into #StockInSKUPrice  
select t.goodsskuid,t.taxprice 
from 
(select d.goodsskuid,d.taxprice ,row_number() over(order by m.makedate,m.nid) as rn 
from CG_StockInD d
inner join cg_StockInm m on m.nid=d.StockInnid and m.makedate >= @BDate  and m.makedate <= @EDate and m.checkflag<>3 and m.billtype=1 
where goodsskuid=@goodsskuid  and (@salerid=0 or m.salerid = @salerid)
) t 
where t.rn=@i
set @i=@i+1
end

       



select t.*,bgs.sku,bgs.skuname,bg.goodscode,bg.class,bg.model,bg.linkurl,bg.linkurl2,bg.linkurl3,bg.linkurl4,bg.linkurl5,bg.linkurl6 
from #StockInSKUPrice t
inner join B_GoodsSKU bgs on bgs.nid=t.goodsskuid
inner join B_Goods bg on bg.nid=bgs.goodsid

Drop table #StockInSKUPrice

