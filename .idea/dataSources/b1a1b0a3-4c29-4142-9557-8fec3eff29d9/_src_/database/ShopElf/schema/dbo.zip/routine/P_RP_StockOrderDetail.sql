
CREATE proc [dbo].[P_RP_StockOrderDetail]
	@BillNumber varchar(30)='',
	@BeginDate varchar(20)='',
	@EndDate varchar(20)=''
as
begin
	select 
		m.MakeDate,
		s.SupplierCode,
		m.BillNumber,
		g.Model,
		g.GoodsCode,
		g.GoodsName,
		g.Unit,
		gs.SKU,
		d.TaxPrice,
		d.Amount,	
		'物流公司'='',
		'包裹跟踪号'='',	
		'包裹签收人'='',	
		'到货日期'	='',
		'实际到货数量'='',	
		'实际可入库数量'='',
		'次品数量'='',	
		'备注'=''		

	from 
		CG_StockOrderD d
	inner join 
		CG_StockOrderM m on m.NID=d.StockOrderNID
	inner join 
		B_Goods g on g.NID=d.GoodsID
	inner join 
		B_GoodsSKU gs on gs.NID=d.GoodsSKUID	
	inner join
		B_Supplier s on s.NID=m.SupplierID	
	where 
		(@BillNumber='' or m.BillNumber = @Billnumber )	
		and (@BeginDate = '' or  convert(varchar(10),m.MakeDate,121) >=  convert(varchar(10),@BeginDate,121))
		and (@EndDate = '' or  convert(varchar(10),m.MakeDate,121) <=  convert(varchar(10),@EndDate,121))
end	
	

