

CREATE proc [dbo].[P_RP_StockOurOtherDetail]
	@BeginDate varchar(10)='',
	@EndDate	varchar(10)='',
	@cklb		varchar(20)='',
	@Sku		varchar(10)=''
as
begin	
	select 
	'出库类别'=ISNULL(dc.DictionaryName,''),
	'商品编码'=ISNULL(g.GoodsCode,''),
	'商品名称'=ISNULL(g.GoodsName,''),
	'商品SKU'=ISNULL(gs.SKU,''),
	'出库仓库'=ISNULL(s.StoreName,''),
	'单位'=ISNULL(g.Unit,''),
	'规格尺寸'=ISNULL(g.Model,''),
	'出库日期'=m.MakeDate,
	'出库单号'=m.BillNumber,
	'出库数量'=d.Amount,
	'出库单价'=d.Price,
	'出库金额'=d.[money],
	'备注'=d.Remark
	from 
		CK_StockOutD d
	inner join 
		CK_StockOutM m on m.nid=d.StockOutNID
	left outer join 
		B_store s on s.NID=m.StoreID
	left outer join 
		B_goodssku gs on gs.nid=d.goodsskuid
	left outer join 
		b_goods g on g.nid=gs.goodsid
	left outer join 
		B_Dictionary dc on dc.nid=m.SupplierID		
	where
		CONVERT(varchar(10),m.MakeDate,121) between @BeginDate and @EndDate 
		and (@sku='' or gs.SKU like '%'+@sku+'%')
		and (@cklb='' or dc.DictionaryName like '%'+@cklb+'%')
end
