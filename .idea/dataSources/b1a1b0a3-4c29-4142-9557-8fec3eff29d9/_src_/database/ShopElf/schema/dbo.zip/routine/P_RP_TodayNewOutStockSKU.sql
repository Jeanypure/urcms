CREATE PROCEDURE [dbo].[P_RP_TodayNewOutStockSKU]
AS
BEGIN 
	DECLARE @Begin VARCHAR(25) = '', @End VARCHAR(25) = ''
	SET @Begin = CONVERT(VARCHAR(10),GETDATE(),121) + ' 00:00:00'
	--SET @Begin = '2010-09-01 00:00:00'
	SET @End = CONVERT(VARCHAR(10),GETDATE(),121) + ' 23:59:59' 
	EXEC P_CG_OutOfStockQuery  0,@Begin, @End,0,'','','',-1,'','','-1;0;1;2;3'	
END 
