
CREATE PROCEDURE [dbo].[P_RP_TodaySendTradeExpressStatus]
AS
BEGIN 
	SELECT NAME,SUM(rCount) AS ordercount, SUM(c.TotalWeight) AS TotalWeight,SUM(ExpressFare) AS ExpressFare
	FROM (	SELECT blw.NAME, COUNT(p.nid) AS rCount, SUM(p.TotalWeight) AS TotalWeight,SUM(p.ExpressFare) AS ExpressFare
			FROM P_trade p LEFT JOIN B_LogisticWay blw ON p.logicsWayNID = blw.nid  
			WHERE FilterFlag = 100 AND CONVERT(VARCHAR(10), CLOSINGDATE,121) = CONVERT(VARCHAR(10),GETDATE(),121)
			GROUP BY blw.name
			UNION 
			SELECT blw.NAME, COUNT(p.nid) AS rCount, SUM(p.TotalWeight) AS TotalWeight,SUM(p.ExpressFare) AS ExpressFare
			FROM P_trade_his p LEFT JOIN B_LogisticWay blw ON p.logicsWayNID = blw.nid  
			WHERE CONVERT(VARCHAR(10), CLOSINGDATE,121) = CONVERT(VARCHAR(10),GETDATE(),121)
			GROUP BY blw.name) c
	GROUP BY c.NAME
END
