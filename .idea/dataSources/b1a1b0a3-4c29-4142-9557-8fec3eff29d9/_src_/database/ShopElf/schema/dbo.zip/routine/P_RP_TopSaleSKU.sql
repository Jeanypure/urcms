CREATE Procedure [dbo].[P_RP_TopSaleSKU] 	
	@SDate	datetime='',
	@EDate	datetime='',
	@sku	varchar(100)=''
as
begin
	declare @con	varchar(200);
	set @con = '';
	if @sku <> '' 
	begin
		set @con = '%' + @sku +'%';	
	end;
	if @SDate is null or @SDate = ''
		set @SDate = '2012-06-01';
	if @EDate is null or @EDate = ''
		set @EDate = CONVERT(varchar(10),GETDATE()+1,120);
		
	select top 1000 a.sku,sum(l_qty) qty,b.SalerName2,b.GoodsStatus,b.GoodsName,b.Class,bgs.property1,bgs.property2
	from
	(select SKU,L_QTY from P_TradeDt a inner join P_trade b on a.TradeNID = b.NID where b.ordertime between @SDate and @EDate + 1 and (a.SKU like @con or @con ='')
		union all
		select SKU,L_QTY from P_TradeDt_His a inner join P_Trade_His b on a.TradeNID = b.NID where b.ordertime between @SDate and @EDate + 1 and (a.SKU like @con or @con ='')
		union all
		select SKU,L_QTY from P_TradeDtUn a inner join P_TradeUn b on a.TradeNID = b.NID where  b.ordertime between @SDate and @EDate + 1 and b.FilterFlag = 1 and (a.SKU like @con or @con ='')) a
	left JOIN B_GoodsSKU bgs on bgs.SKU = a.SKU	
		
	left join B_Goods b on b.nid = bgs.GoodsID

	group by a.SKU,b.SalerName2,b.GoodsStatus,b.GoodsName,b.Class,bgs.property1,bgs.property2
	order by SUM(L_QTY) desc

end
