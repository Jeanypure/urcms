CREATE proc [dbo].[P_RP_yr_CG_bb_rjf]
	@BeginDate	varchar(20),               --采购开始时间
	@EndDate	Varchar(20),               --采购结束时间
	@StockInBeginDate	varchar(20),       --入库开始时间
	@StockInEndDate	Varchar(20),           --入库结束时间
	@StoreName varchar(10),                -- 仓库
	@cgBillNumber varchar(50),
	@rkBillNumber varchar(50),
	@Recorder varchar(50),                --制单人
	@BalanceName varchar(50),             --付款方式
    @UserIDtemp int=0
AS
begin
  set @BeginDate=SUBSTRING(@BeginDate,1,10)
  set @EndDate = SUBSTRING(@EndDate,1,10) + ' 23:59:59'
  set @StockInBeginDate=SUBSTRING(@StockInBeginDate,1,10)
  set @StockInEndDate = SUBSTRING(@StockInEndDate,1,10) + ' 23:59:59'
  Create table #TmpCGOrder
  (   cgBillNumber varchar(100),--采购单号
      rkBillNumber varchar(1000),--入库单号
      SupplierName varchar(100),--供应商名称
      BargainID varchar(100),--合同号
      Noallamt money null,--总金额(已审核未完全入库)
      Noallnoinamt money null,--未入库金额(已审核未完全入库)
      noallinamt money null,--已入库金额(已审核未完全入库)
      hisamt money null,--总金额(归档)
      hisnoinamt money null,--未入库金额(归档)
      hisinamt money null,--已入库金额(归档)
      rkshamt money null,--入库已审核金额
      rknoshamt money null,--入库未审核金额
      rkhisamt money null,--入库归档金额
      cgreturnamt  money null,--采购退回 全部都算
      cgamt money null,--本期采购金额
      alibabamoney  money null,  --1688实付款
      AllMoney money null,     --差额
      Recorder varchar(100),
      BalanceName varchar(100)
  )
    --未完全入库的采购单NID插入到临时表中
 create table #NoInTable
 (  StockNid int,
    InAmount int default 0,
    InMoney money default 0
 )
  insert into #NoInTable(StockNid)
  select distinct A.Nid from CG_StockOrderM A
    left join (
      select a3.billNumber as StockOrder,  a4.GoodsSKUID,
        Sum(case when a2.InStatus = 1 and a1.CheckFlag<>3 then 1 else 0 end) as InStatus  
    from CG_StockOrderM a3 
      inner join CG_StockOrderD a4 on a3.Nid = a4.StockOrderNID 
      left join CG_StockInM a1 on a1.StockOrder = a3.BillNumber 
      left join CG_StockInD a2 on a1.NID = a2.StockInNID and a2.GoodsSKUID = a4.GoodsSKUID 
    where  a3.CheckFlag = 1  and a3.Archive = 0    -- and IsNull(a1.CheckFlag,0) <> 3(不需要了）  
    group by  a3.billNumber, a4.GoodsSKUID 
    having MIN(a4.Amount) - SUM(case a1.CheckFlag when 3 then 0 else   Isnull(a2.Amount,0) end ) > 0 
    ) C on A.BillNumber = C.StockOrder  
    where  C.InStatus = 0 
    
  -- 已审核未完全入库
  insert into #TmpCGOrder
  select
	  m.BillNumber,--采购单号
	  '',--入库单号
	  bs.SupplierName,--供应商名称
	  m.alibabaorderid,--合同号
	  0,--总金额(已审核未完全入库)
	  d.AllMoney -isnull((select SUM(isnull(id.AllMoney,0)) from CG_StockInD id  
   inner join CG_StockInM im on im.NID=id.StockInNID where   
   id.GoodsSKUID= d.GoodsSKUID and im.StockOrder=m.Billnumber ),0) as Noinmoney ,--未入库金额(已审核未完全入库)
   (select SUM(isnull(id.AllMoney,0)) from CG_StockInD id  inner join CG_StockInM im on im.NID=id.StockInNID 
   where  
    id.GoodsSKUID= d.GoodsSKUID and im.StockOrder=m.Billnumber ) as inmoney,--已入库金额(已审核未完全入库) 只要采购订单审核 采购入库可以不审核
	   0,--总金额(归档)
	  0,--未入库金额(归档)
	  0,--已入库金额(归档)
	  0,--入库已审核金额
	  0,--入库未审核金额
	  0,--入库归档金额
	  0,--采购退回 全部都算
	  0,--本期采购金额
	  m.alibabamoney,
	 (select SUM(d.AllMoney)  from  CG_StockOrderD(nolock) D where m.Nid = D.StockOrderNid),
	 m.Recorder,
	 bd.DictionaryName
  from CG_StockOrderM m
  left join CG_StockOrderD d on d.StockOrderNID=m.NID
  left join B_Supplier bs on bs.NID=m.SupplierID
  Left  join B_Dictionary bd on bd.NID=m.BalanceID
  where (m.MakeDate >= convert(DateTime,@BeginDate))
  and (m.MakeDate <= convert(DateTime,@EndDate))
  and (m.Archive=0 and m.checkflag=1) 
  and m.NID in (select StockNid from #NoInTable)
  AND ((ISNULL(@StoreName,'') = '0') OR (m.StoreID=@StoreName))
  and (isnull(@cgBillNumber,'')='' or (m.BillNumber=@cgBillNumber))
  and (isnull(@Recorder,'')='' or (m.Recorder=@Recorder))
  and (isnull(@BalanceName,'')='' or (bd.DictionaryName=@BalanceName)) 

  -- 归档
  insert into #TmpCGOrder
  select
	  m.BillNumber,--采购单号
	  '',--入库单号
	  bs.SupplierName,--供应商名称
	  m.alibabaorderid,--合同号
	  0,--总金额(已审核未完全入库)
	 0 ,--未入库金额(已审核未完全入库)
	 0,--已入库金额(已审核未完全入库)
	 case when m.checkflag=1 then d.AllMoney else 0 end,--总金额(归档)
	 0,--未入库金额(归档)
	 (select SUM(isnull(id.AllMoney,0)) from CG_StockInD id  inner join CG_StockInM im on im.NID=id.StockInNID where im.checkflag = 1 and 
    id.GoodsSKUID= d.GoodsSKUID and im.StockOrder=m.Billnumber and im.BillType=1) as inmoney,--已入库金额(归档)
	  0,--入库已审核金额
	  0,--入库未审核金额
	  0,--入库归档金额
	   0,--采购退回 全部都算
	  0,--本期采购金额
	  m.alibabamoney,
	  (select SUM(d.AllMoney)  from  CG_StockOrderD(nolock) D where m.Nid = D.StockOrderNid),
	  m.Recorder,
	  bd.DictionaryName
  from CG_StockOrderM m
  left join CG_StockOrderD d on d.StockOrderNID=m.NID
  left join B_Supplier bs on bs.NID=m.SupplierID
  Left  join B_Dictionary bd on bd.NID=m.BalanceID
  where (m.MakeDate >= convert(DateTime,@BeginDate))
  and (m.MakeDate <= convert(DateTime,@EndDate))
  and m.Archive=1 
  AND ((ISNULL(@StoreName,'') = '0') OR (m.StoreID=@StoreName))
  and (isnull(@cgBillNumber,'')='' or (m.BillNumber=@cgBillNumber)) 
  and (isnull(@Recorder,'')='' or (m.Recorder=@Recorder))
  and (isnull(@BalanceName,'')='' or (bd.DictionaryName=@BalanceName)) 

  -- 入库订单
  insert into #TmpCGOrder
  select
	  m.BillNumber,--采购单号
	  '',--入库单号
	  bs.SupplierName,--供应商名称
	  m.alibabaorderid,--合同号
	  0,--总金额(已审核未完全入库)
	  0 ,--未入库金额(已审核未完全入库)
	  0,--已入库金额(已审核未完全入库)
	  0,--总金额(归档)
	  0,--未入库金额(归档)
	  0,--已入库金额(归档)
	  (case when (ISNULL(im.checkflag,0)=1 and im.BillType=1 and ISNULL(im.Archive,0)=0) then id.AllMoney else 0 end),--入库已审核金额
	  (case when (ISNULL(im.checkflag,0)=0 and im.BillType=1 and ISNULL(im.Archive,0)=0) then id.AllMoney else 0 end),--入库未审核金额
	  (case when ISNULL(im.Archive,0)=1 and im.BillType=1 then id.AllMoney else 0 end),--入库归档金额
	   0,--采购退回 全部都算
	  0,--本期采购金额
	  m.alibabamoney,
	  (select SUM(d.AllMoney)  from  CG_StockOrderD(nolock) D where m.Nid = D.StockOrderNid),
	  m.Recorder,
	  bd.DictionaryName
  from CG_StockOrderM m
  inner join CG_StockInM im on im.StockOrder=m.BillNumber
  inner join CG_StockInD id on id.StockInNID=im.NID
  left join B_Supplier bs on bs.NID=m.SupplierID
  Left  join B_Dictionary bd on bd.NID=m.BalanceID
  where (im.MakeDate >= convert(DateTime,@StockInBeginDate))
  and (im.MakeDate <= convert(DateTime,@StockInEndDate))
  AND ((ISNULL(@StoreName,'') = '0') OR (m.StoreID=@StoreName))
  and (isnull(@cgBillNumber,'')='' or (m.BillNumber=@cgBillNumber)) 
  and (isnull(@rkBillNumber,'')='' or (im.BillNumber=@rkBillNumber))
  and (isnull(@Recorder,'')='' or (m.Recorder=@Recorder))
  and (isnull(@BalanceName,'')='' or (bd.DictionaryName=@BalanceName)) 

  
  -- 采购退回
   insert into #TmpCGOrder
  select
	  m.BillNumber,--采购单号
	  '',--入库单号
	  bs.SupplierName,--供应商名称
	  m.alibabaorderid,--合同号
	  0,--总金额(已审核未完全入库)
	  0 ,--未入库金额(已审核未完全入库)
	  0,--已入库金额(已审核未完全入库)
	  0,--总金额(归档)
	  0,--未入库金额(归档)
	  0,--已入库金额(归档)
	  0,--入库已审核金额
	  0,--入库未审核金额
	   0,--入库归档金额
	   idth.AllMoney,--采购退回 全部都算
	  0,--本期采购金额
	  m.alibabamoney,
	  (select SUM(d.AllMoney)  from  CG_StockOrderD(nolock) D where m.Nid = D.StockOrderNid),
	  m.Recorder,
	  bd.DictionaryName
  from CG_StockOrderM m
  inner join CG_StockInM imcg on imcg.StockOrder=m.BillNumber
  inner join CG_StockInM imth on imth.StockOrder=imcg.BillNumber
  inner join CG_StockInD idth on idth.StockInNID=imth.NID
  left join B_Supplier bs on bs.NID=m.SupplierID
  Left  join B_Dictionary bd on bd.NID=m.BalanceID
  where (imth.MakeDate >= convert(DateTime,@StockInBeginDate))
  and (imth.MakeDate <= convert(DateTime,@StockInEndDate))
  AND ((ISNULL(@StoreName,'') = '0') OR (m.StoreID=@StoreName))
  and (isnull(@cgBillNumber,'')='' or (m.BillNumber=@cgBillNumber)) 
  and (isnull(@rkBillNumber,'')='' or (imcg.BillNumber=@rkBillNumber))
  and imth.BillType=2
  and (isnull(@Recorder,'')='' or (m.Recorder=@Recorder))
  and (isnull(@BalanceName,'')='' or (bd.DictionaryName=@BalanceName)) 

  
  select 
      m.cgBillNumber as 采购单号,
      max(dbo.Ex_GetCGDetail_yr_bl_rjf(m.cgBillNumber)) as 入库单号,
      max(m.SupplierName) as 供应商名称,
      max(m.BargainID) as '1688订单号',
      max(m.alibabamoney) as '1688实付款',
      MAX(m.alibabamoney-m.AllMoney) as '付款差额',
      ROUND(sum(isnull(m.noallinamt,0)+isnull(m.Noallnoinamt,0)),2) as '总金额(已审核未完全入库)',
      ROUND(sum(isnull(m.Noallnoinamt,0)),2) as '未入库金额(已审核未完全入库)',
      ROUND(sum(isnull(m.noallinamt,0)),2) as '已入库金额(已审核未完全入库)',
      ROUND(sum(isnull( m.hisamt,0)),2) as '总金额(归档)',
      ROUND(sum(isnull(m.hisamt,0)-isnull(m.hisinamt,0)),2) as '未入库金额(归档)',
      ROUND(sum(isnull(m.hisinamt,0)),2) as '已入库金额(归档)',
      
      ROUND(sum(isnull(m.rkshamt,0)),2) as '入库已审核金额',
      ROUND(sum(isnull(m.rknoshamt,0)),2) as '入库未审核金额',
      ROUND(sum(isnull(m.rkhisamt,0)),2) as '入库归档金额',
      ROUND(sum(isnull(m.cgreturnamt,0)),2) as '采购退回',--采购退回 全部都算
      ROUND(sum(isnull(m.Noallnoinamt,0)
            +isnull(m.hisnoinamt,0)
            +isnull(m.rkshamt,0)
            +isnull(m.rknoshamt,0)
            +isnull(m.rkhisamt,0)
            -isnull(m.cgreturnamt,0)
      ),2) as '本期采购金额',
      max(m.Recorder) as '制单人',
      max(m.BalanceName) as '付款方式'
  from #TmpCGOrder m
  group by m.cgBillNumber
  
  
  
end	