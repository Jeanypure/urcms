CREATE proc [dbo].[P_Rp_Demo1]
	@Sku		varchar(20) = '',
	@BeginDate	varchar(30)='',
	@EndDate	varchar(30)=''
as
begin
	select * from B_GoodsSKU where SKU like @Sku+'%'
end
