
CREATE PROCEDURE [dbo].[P_Rp_SKUNumByUser]
   @BeginDate  datetime = '',
   @EndDate    datetime = '',
   @GoodsSKU   varchar(100) = '',
   @User       varchar(100) = ''
AS
BEGIN
    select 
	  pt.[User],
	  pd.SKU,
	  pd.GoodsName,
	  sum(pd.L_QTY) as L_QTY
	into #Last
	from P_TradeDt pd
	left join P_Trade pt on pd.TradeNID = pt.NID 
	where ((@BeginDate = '') or (pt.ORDERTIME >= @BeginDate))
	  and ((@EndDate = '') or (pt.ORDERTIME <= @EndDate))
	  and ((@GoodsSKU = '') or (pd.SKU = @GoodsSKU))
	  and ((@User = '') or (pt.[USER] = @User))
	group by pt.[User],pd.SKU,pd.GoodsName
	union
	select 
	  pt.[User],
	  pd.SKU,
	  pd.GoodsName,
	  sum(pd.L_QTY) as L_QTY
	from P_TradeDt_His pd
	left join P_Trade_His pt on pd.TradeNID = pt.NID 
	where ((@BeginDate = '') or (pt.ORDERTIME >= @BeginDate))
	  and ((@EndDate = '') or (pt.ORDERTIME <= @EndDate))
	  and ((@GoodsSKU = '') or (pd.SKU = @GoodsSKU))
	  and ((@User = '') or (pt.[USER] = @User))
	group by pt.[User],pd.SKU,pd.GoodsName
    
    select 
       [USER],
       SKU,
       GoodsName,
       sum(L_QTY) as L_Qty
     from #Last
     group by [user],sku,goodsname
END
