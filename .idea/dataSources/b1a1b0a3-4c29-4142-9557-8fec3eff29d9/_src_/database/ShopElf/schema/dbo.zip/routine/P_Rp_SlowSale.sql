
CREATE proc [dbo].[P_Rp_SlowSale]
	@BeginDate  datetime =null,
	@EndDate	DateTime=null,
	@SlowCount	int=0,  --滞销数量
	@CatoryClassName varchar(50)='' 
	
as
begin

	--创建销售表
	Create Table #SlowSale
		(
			GoodsSKUID	int,
			SaleCount	int,
		)
	insert into #SlowSale
	select 
		goodsskuid,
		SUM(l_qty)  as salecount
	from 
		P_TradeDt d
	inner join 
		P_Trade m on m.NID =d.TradeNID
	where 
		DateAdd(hour,8,ordertime) > @BeginDate and DateAdd(hour,8,ordertime)< @EndDate
	group by 
		GoodsSKUID	
			
				
	insert into #SlowSale
	select 
		goodsskuid,
		SUM(l_qty)  as salecount
	from 
		P_TradeDt_His d
	inner join 
		P_Trade_His m on m.NID =d.TradeNID
	where 
		DateAdd(hour,8,ordertime) > @BeginDate and DateAdd(hour,8,ordertime)< @EndDate	
	group by 
		GoodsSKUID	
	--取默认发货仓库
	declare 
		@StoreID int =0
	set
		@StoreID = (select top 1 isnull(nid,0) from B_Store where StoreName=
						(
						select top 1 isnull(ParaValue,'') from B_SysParams where ParaCode='DefaultSendStock'
						) 
				)	
			
	select 
		CONVERT(varchar(10),@BeginDate,121)+'--' +CONVERT(varchar(10),@endDate,121) as DateBand,
		gs.sku,
		c.GoodsSKUID,
		c.Number- c.ReservationNum as ReservationNum,
		c.Price,
		c.Money as kcmoney,
		g.SalerName,
		g.GoodsName,
		g.SupplierID,
		s.SupplierName,
		isnull(ss.salecount,0) as salecount,
		g.SellCount  --滞销下限
	from 
		KC_CurrentStock c
	left outer join 
		B_GoodsSKU gs on gs.NID = c.GoodsSKUID
	inner join 
		B_Goods g on g.NID=c.GoodsID
	left outer join 
		B_Supplier s on s.NID=g.SupplierID
	left outer join 
		(select goodsskuid,SUM(SaleCount) as salecount 
			from #SlowSale group by GoodsSKUID)	 ss on ss.GoodsSKUID=c.GoodsSKUID
	where 
		c.StoreID=@StoreID and 
		(@CatoryClassName like '' or g.GoodsName like '%'+ @CatoryClassName+'%') and
		isnull(ss.salecount,0) <= @SlowCount		

end
