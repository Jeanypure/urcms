CREATE PROCEDURE P_SE_EmployeesMsg
AS
BEGIN	
	SELECT DISTINCT Purchaser  AS PersonName
	FROM B_Goods
	WHERE ISNULL(Purchaser,'') <> ''
END
