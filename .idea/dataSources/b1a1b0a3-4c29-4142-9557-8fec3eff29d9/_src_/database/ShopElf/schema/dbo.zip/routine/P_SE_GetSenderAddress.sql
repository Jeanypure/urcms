
CREATE PROCEDURE [P_SE_GetSenderAddress] @TradeNID VARCHAR(10) = '0', @IsReturnAddr INT = 0
AS
BEGIN
    DECLARE @LogcalWayNid varchar(10) = '0'
    IF EXISTS(SELECT 1 FROM P_TRADE WHERE NID = @TradeNID)
      SET @LogcalWayNid = (SELECT logicsWayNID FROM P_TRADE WHERE NID = @TradeNID) 
    ELSE 
      SET @LogcalWayNid = (SELECT logicsWayNID FROM P_TRADEUN WHERE NID = @TradeNID)
    --揽收地址       
    IF @IsReturnAddr = 0 
    BEGIN      
		IF ISNULL(@LogcalWayNid,'0') = '0'
		BEGIN
			SELECT TOP 1 EMaill     ,EmaillEn   ,MobileEn  
				  ,Mobile     ,PhoneEn    ,Phone      ,PostCodeEn
				  ,PostCode   ,StreetEn   ,Street     ,AreasEn   
				  ,AreasCode  ,CityEn     ,CityCode   ,ProvinceEn
				  ,ProvinceCode   ,CountryEn  ,Country    ,CompanyEn 
				  ,Company    ,ContactEn  ,Contact ,City,Province  
				  ,HabitSetID, EMSPickUpType  
			FROM B_HabitSet
			WHERE IsDefault = 1
		END ELSE
		BEGIN
		  IF EXISTS(SELECT 1 
					FROM B_HabitSet WHERE LogcalWayNids LIKE '%;'+@LogcalWayNid+';%' )
		  BEGIN 
			 SELECT TOP 1 EMaill     ,EmaillEn   ,MobileEn  
						,Mobile     ,PhoneEn    ,Phone      ,PostCodeEn
						,PostCode   ,StreetEn   ,Street     ,AreasEn   
						,AreasCode  ,CityEn     ,CityCode   ,ProvinceEn
						,ProvinceCode   ,CountryEn  ,Country    ,CompanyEn 
						,Company    ,ContactEn  ,Contact  ,City,Province 
						,HabitSetID, EMSPickUpType  
			 FROM B_HabitSet
			 WHERE LogcalWayNids LIKE '%;'+@LogcalWayNid+';%'
		  END ELSE
		  BEGIN
	  		SELECT TOP 1 EMaill     ,EmaillEn   ,MobileEn  
				  ,Mobile     ,PhoneEn    ,Phone      ,PostCodeEn
				  ,PostCode   ,StreetEn   ,Street     ,AreasEn   
				  ,AreasCode  ,CityEn     ,CityCode   ,ProvinceEn
				  ,ProvinceCode   ,CountryEn  ,Country    ,CompanyEn 
				  ,Company    ,ContactEn  ,Contact ,City,Province  
				  ,HabitSetID, EMSPickUpType  
			FROM B_HabitSet
			WHERE IsDefault = 1
		  END
		END
	END ELSE --退货地址
	BEGIN
		IF ISNULL(@LogcalWayNid,'0') = '0'
		BEGIN
			SELECT TOP 1 * 
			FROM B_Address
			WHERE IsDefault = 1
		END ELSE
		BEGIN
		  IF EXISTS(SELECT 1 
					FROM B_Address WHERE LogcalWayNids LIKE '%;'+@LogcalWayNid+';%' )
		  BEGIN 
			 SELECT TOP 1 * 
			 FROM B_Address
			 WHERE LogcalWayNids LIKE '%;'+@LogcalWayNid+';%'
		  END ELSE
		  BEGIN
	  		SELECT TOP 1 * 
			FROM B_Address
			WHERE IsDefault = 1
		  END
		END
	END 
END

