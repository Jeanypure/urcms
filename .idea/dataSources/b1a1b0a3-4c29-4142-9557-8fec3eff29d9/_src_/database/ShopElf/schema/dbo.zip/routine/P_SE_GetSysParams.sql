CREATE PROCEDURE P_SE_GetSysParams @ParaCode VARCHAR(200) = ''
AS
BEGIN
    SELECT ParaValue FROM B_SysParams WHERE ParaCode = @ParaCode
END
