CREATE PROCEDURE [dbo].[P_SE_GoodsGroup] @SelectStr VARCHAR(100) = ''
AS
BEGIN
	DECLARE @RecordCount INT = 0, @GroupFlag INT = 0 , @GoodsID INT = 0
	
	SELECT @RecordCount = COUNT(*)
	FROM B_Goods bg JOIN B_GoodsSKU bgs ON Bg.NID = bgs.GoodsID
	WHERE bgs.SKU = ISNULL(@SelectStr,'')
	
	IF (@RecordCount = 1) 
	BEGIN 
		SELECT TOP 1 @GroupFlag = bg.GroupFlag, @GoodsID = bg.NID
		          FROM B_Goods bg JOIN B_GoodsSKU bgs ON Bg.NID = bgs.GoodsID
		          WHERE bgs.SKU = ISNULL(@SelectStr,'')
		          
		IF (ISNULL(@GroupFlag,0) = 1 )
		BEGIN
			SELECT bgs.SKU, bgg.Amount
			FROM B_GoodsGroup bgg JOIN B_GoodsSKU bgs ON bgg.GoodsSKUID = bgs.NID WHERE bgg.GoodsID =  @GoodsID
		END ELSE
	    BEGIN
	    	SELECT bgs.SKU, bgg.Amount
			FROM B_GoodsGroup bgg JOIN B_GoodsSKU bgs ON bgg.GoodsSKUID = bgs.NID WHERE 1=2
	    END 
	END ELSE 
    BEGIN
    	SELECT bgs.SKU, bgg.Amount
		FROM B_GoodsGroup bgg JOIN B_GoodsSKU bgs ON bgg.GoodsSKUID = bgs.NID WHERE 1=2
    END 
	
END
