
CREATE PROCEDURE [dbo].[P_SE_IsAllowCancelCheck] @ModuleName VARCHAR(100) = '',@BillNumber VARCHAR(100) = ''
AS
BEGIN	
	DECLARE @ResFlag INT = 0,@Msg VARCHAR(2000) = ''
	
	IF @ModuleName = 'TStockCheckEditFrm' --盘点单
	BEGIN
		IF EXISTS(SELECT 1 FROM KC_StockCheckM WHERE MakeDate >(SELECT MakeDate  
		                                                        FROM KC_StockCheckM 
		                                                        WHERE BillNumber = @BillNumber and CheckFlag<>3 ))
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '在此盘点单之后已有新单据,不能反审核!'
		END		
	END ELSE 
	IF @ModuleName = 'TStockOutOtherEditFrm' --其它出库
	BEGIN		
		IF EXISTS(SELECT 1 FROM CK_StockOutM WHERE MakeDate >(SELECT MakeDate  
		                                                        FROM CK_StockOutM 
		                                                        WHERE BillNumber = @BillNumber and CheckFlag<>3 ))
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '在此出库单之后已有新单据,不能反审核!'
		END		
	END ELSE 	
	IF @ModuleName = 'TStockInOtherEditFrm' --其它入库
	BEGIN		
		IF EXISTS(SELECT 1 FROM CG_StockInM WHERE MakeDate >(SELECT MakeDate  
		                                                        FROM CG_StockInM 
		                                                        WHERE BillNumber = @BillNumber and CheckFlag<>3 ))
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '在此入库单之后已有新单据,不能反审核!'
		END		
	END	ELSE 	
	IF @ModuleName = 'TStockRepairOutEditFrm' --返修出库
	BEGIN
		IF EXISTS(SELECT 1 FROM CK_StockOutM WHERE MakeDate >(SELECT MakeDate  
		                                                        FROM CK_StockOutM 
		                                                        WHERE BillNumber = @BillNumber and CheckFlag<>3 ))
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '在此出库单之后已有新单据,不能反审核!'
		END		
	END	ELSE 	
	IF @ModuleName = 'TStockRepairInEditFrm' --返修入库   
	BEGIN
		IF EXISTS(SELECT 1 FROM CG_StockInM WHERE MakeDate >(SELECT MakeDate  
		                                                        FROM CG_StockInM  
	                                                       WHERE BillNumber = @BillNumber and CheckFlag<>3 ))
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '在此入库单之后已有新单据,不能反审核!'
		END		
	END	ELSE 	
	IF @ModuleName = 'TStockOrderlEditFrm' --采购订单
	BEGIN
		IF EXISTS(SELECT 1 FROM CG_StockInM WHERE StockOrder = @BillNumber and CheckFlag<>3 )
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '此采购订单已有入库单据,不能反审核!'
		END		
	END	ELSE
	IF @ModuleName = 'TStockOrderMulitiEditFrm' --采购订单(多供应商)
	BEGIN
		IF EXISTS(SELECT 1 FROM CG_StockInM WHERE StockOrder = @BillNumber and CheckFlag<>3 )
		BEGIN
		   SET @ResFlag = 1
		   SET @Msg = '此采购订单已有入库单据,不能反审核!'
		END		
	END	ELSE  	
	IF @ModuleName = 'TStockInEditFrm' --采购入库单
	BEGIN
		--一直不让
		   SET @ResFlag = 1	
		   SET @Msg = '审核后不能反审核!'
	END	ELSE 
	IF @ModuleName = 'TStockChangeEditFrm' --调拨单
	BEGIN
		--一直不让
		   SET @ResFlag = 1	
		    SET @Msg = '审核后不能反审核!'
	END ELSE 
	BEGIN 
    	SET @ResFlag = 1	
	   SET @Msg = '不能反审核!'
	END 
	
	SELECT @ResFlag AS Result , @Msg AS Msg
END 
