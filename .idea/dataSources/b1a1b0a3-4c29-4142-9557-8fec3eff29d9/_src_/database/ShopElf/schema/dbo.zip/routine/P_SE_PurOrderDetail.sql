
CREATE PROCEDURE [dbo].[P_SE_PurOrderDetail] 
	@GoodsSKUID INT = 0,
	@StoreID int=0
AS
BEGIN
 DECLARE @GoodsCatsCode VARCHAR(50)
 SET @GoodsCatsCode = ''
    --4.计算商品的采购订单数量
  CREATE TABLE #CgBillNumber(	GoodsSKUID		int,
									BillNumber	varchar(50),
									cgAmount	Float default 0,									
									InAmount	Float default 0,
	                                StoreID     INT DEFAULT 0)
  CREATE TABLE #StockOrderCount(GoodsSKUID VARCHAR(100) DEFAULT '' ,
								BillNumber	varchar(50),
									cgAmount	Float default 0,									
									InAmount	Float default 0,
                             storeid int default 0 )   									
										
  insert into  #CgBillNumber (GoodsSKUID,billnumber,cgAmount,InAmount,storeid)    
    SELECT csod.GoodsSKUID,csom.billnumber, sum(csod.Amount),sum(csod.InAmount)-isnull((select SUM(isnull(id.amount,0)) from CG_StockInD id 
					  inner join CG_StockInM im on im.NID=id.StockInNID where 
	 id.GoodsSKUID= csod.GoodsSKUID and im.StockOrder=csom.Billnumber and im.CheckFlag=0 ),0), csom.StoreID
    FROM  CG_StockOrderD csod inner join  CG_StockOrderM csom  ON csom.NID = csod.StockOrderNID
    WHERE csod.GoodsSKUID=@GoodsSKUID and (@storeid=0 or csom.StoreID=@StoreID) 
				and  csom.CheckFlag = 1 and csom.archive=0	--and csod.InAmount<csod.Amount 
    group by csod.GoodsSKUID,csom.billnumber,csom.StoreID
                        
       
  insert into  #StockOrderCount (GoodsSKUID,BillNumber,cgAmount,InAmount,storeid)    
    SELECT GoodsSKUID, BillNumber,sum(cgAmount),sum(InAmount),StoreID
    FROM  #CgBillNumber 
    group by GoodsSKUID,BillNumber,StoreID
    	
  
  DELETE FROM #StockOrderCount WHERE ISNULL(cgAmount,0) <= ISNULL(InAmount,0)                         
                            

	SELECT bgs.SKU,bg.GoodsName,bgs.property1,bgs.property2,bgs.property3,  
			cgAmount-inamount as NotInStockNum, bg.StockDays, 
			BillNumber as StockOrder
	FROM #StockOrderCount pgt LEFT JOIN B_GoodsSKU bgs ON pgt.GoodsSKUID = bgs.NID
	                        LEFT JOIN B_goods bg ON bg.NID = bgs.GoodsID 

	
    DROP TABLE #CgBillNumber
    DROP TABLE #StockOrderCount
                             
END
