
CREATE proc [dbo].[P_SE_PurTradeDetail] 
	@GoodsSKUID INT = 0,
	@StoreID INT = 0
AS
BEGIN
    --未派单的销售商品 和  数量(Trade)
    SELECT DATEDIFF(Day,pt.ORDERTIME,GETDATE()) as DiffDays, ptd.TradeNID,ptd.L_QTY,bg.GoodsName,gs.SKU,gs.property1,gs.property2,gs.property3,pt.SUFFIX,pt.TRANSACTIONTYPE,
        pt.AMT,pt.ack,dateadd(hour,8,pt.ordertime) as OrderTimeCN, ls.name as logicsWayName,pt.Memo,gs.SKUName -- add by ylq 2015-05-18  增加了后面三个字段
    FROM P_TradeDt ptd 
    LEFT JOIN B_GoodsSKU gs on gs.SKU=ptd.SKU
    LEFT JOIN B_Goods bg ON bg.NID = gs.GoodsID	 
    LEFT JOIN P_Trade pt ON pt.NID = ptd.TradeNID    
    left join B_LogisticWay ls on ls.NID = pt.logicsWayNID   
    WHERE ((ISNULL(ptd.StoreID,0) = 0) OR (@StoreID = 0) OR (ISNULL(ptd.StoreID,0) =@StoreID)) AND  ptd.GoodsSKUID =@GoodsSKUID AND  ptd.TradeNID IN ( SELECT pt.NID 
                            FROM P_Trade pt                --仓库标记缺货
                            WHERE (pt.FilterFlag <= 5) OR (pt.FilterFlag = 26) )
UNION  --异常单的销售商品 和   数量(TradeUn)
   SELECT DATEDIFF(Day,ptu.ORDERTIME,GETDATE()) as DiffDays, ptdu.TradeNID,ptdu.L_QTY,bg.GoodsName,gs.SKU,gs.property1,gs.property2,gs.property3,ptu.SUFFIX,ptu.TRANSACTIONTYPE,
       ptu.AMT, ptu.ack,dateadd(hour,8,ptu.ordertime) as OrderTimeCN,ls.name as logicsWayName,ptu.Memo ,gs.SKUName  -- add by ylq 2015-05-18  增加了后面三个字段
   FROM P_TradeDtUn ptdu 
   LEFT JOIN B_GoodsSKU gs on gs.SKU=ptdu.SKU
   LEFT JOIN B_Goods bg ON bg.NID = gs.GoodsID	 
   LEFT JOIN P_TradeUn ptu ON ptu.NID = ptdu.TradeNID	
   left join B_LogisticWay ls on ls.NID = ptu.logicsWayNID  
   WHERE((ISNULL(ptdu.StoreID,0) = 0) OR (@StoreID = 0) OR (ISNULL(ptdu.StoreID,0) =@StoreID)) AND  ptdu.GoodsSKUID =@GoodsSKUID AND  ptdu.TradeNID IN ( SELECT pt.NID 
                             FROM P_Tradeun pt 
                             WHERE pt.FilterFlag =1 )
                             
END

