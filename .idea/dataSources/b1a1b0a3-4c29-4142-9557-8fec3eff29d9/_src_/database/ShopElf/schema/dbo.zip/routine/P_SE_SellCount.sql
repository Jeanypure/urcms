CREATE PROCEDURE P_SE_SellCount
AS
BEGIN
	SELECT TOP 3 DictionaryName 
	FROM B_Dictionary 
	WHERE CategoryID in (SELECT NID FROM B_DictionaryCats 
                          WHERE CategoryName='库存预警销量天数') 
	ORDER BY FitCode
END

