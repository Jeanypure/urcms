
CREATE PROCEDURE [dbo].[P_SP_EditGoodsSupplierMsg] @GoodsID INT = 0, @SupplierID INT = 0, 
    @Price NUMERIC(10,2) = 0, @Remark VARCHAR(8000) = '',@Url varchar(128)='',@SupIndex int =0,
    @IsDev int = 0
AS
BEGIN	
  if @IsDev = 1 begin 	
	IF NOT EXISTS(SELECT 1 
	              FROM B_GoodsSupplier_Dev  
	              WHERE GoodsID = @GoodsID AND SupplierName = @SupplierID)
	BEGIN 	
		INSERT INTO B_GoodsSupplier_Dev
		(
			GoodsID, SupplierName,Price,Remark,Url,SupIndex
		)
		VALUES
		(
		  @GoodsID,@SupplierID,@Price,@Remark,@Url,@SupIndex
		)
	END
  end
  else begin
	IF NOT EXISTS(SELECT 1 
	              FROM B_GoodsSupplier 
	              WHERE GoodsID = @GoodsID AND SupplierName = @SupplierID)
	BEGIN 	
		INSERT INTO B_GoodsSupplier
		(
			GoodsID, SupplierName,Price,Remark,Url,SupIndex
		)
		VALUES
		(
		  @GoodsID,@SupplierID,@Price,@Remark,@Url,@SupIndex
		)
	END  
  end
  
end	

