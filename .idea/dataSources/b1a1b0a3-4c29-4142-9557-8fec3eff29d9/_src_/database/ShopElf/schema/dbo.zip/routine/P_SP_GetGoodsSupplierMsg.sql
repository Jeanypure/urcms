
CREATE  PROCEDURE [dbo].[P_SP_GetGoodsSupplierMsg] @GoodsID INT = 0,
  @IsDev int = 0 
AS
BEGIN	
  if @IsDev = 1 begin
	SELECT bgs.NID, bgs.GoodsID, bgs.Price, bgs.Remark, bs.SupplierName, bs.LinkMan, bs.Mobile AS Phone,
	    bgs.Url,bgs.SupIndex 
    FROM B_GoodsSupplier_Dev bgs 
    LEFT JOIN  B_Supplier bs ON bgs.SupplierName =cast( bs.NID as varchar(10))
	WHERE bgs.GoodsID = @GoodsID
	order by bgs.SupIndex  
  
  end
  else begin
	SELECT bgs.NID, bgs.GoodsID, bgs.Price, bgs.Remark, bs.SupplierName, bs.LinkMan, bs.Mobile AS Phone,
	    bgs.Url,bgs.SupIndex 
    FROM B_GoodsSupplier bgs 
    LEFT JOIN  B_Supplier bs ON bgs.SupplierName =cast( bs.NID as varchar(10))
	WHERE bgs.GoodsID = @GoodsID
	order by bgs.SupIndex
  end
END

