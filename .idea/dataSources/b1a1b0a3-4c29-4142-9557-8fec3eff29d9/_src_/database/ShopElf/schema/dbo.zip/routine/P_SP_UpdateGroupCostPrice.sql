-- 更新组合品成本价
create PROCEDURE [P_SP_UpdateGroupCostPrice] 
  @GoodsID INT = 0 -- 主商品sku
AS
BEGIN	
  -- 组合品商品id
  create table #GroupTemp(
  nid int
  )
  -- 组合品商品需要更新的数据
  create table #GroupSumTemp(
  nid int ,
  costprice money default 0,
  saleprice money default 0,
  Weight money default 0,
  DeclaredValue money default 0,
  )
  -- 根据sku明细 id 获取组合品id
  insert into #GroupTemp
  select
  distinct
  GoodsID
  from B_GoodsGroup 
  where GoodsSKUID in (select nid from B_GoodsSKU where GoodsID=@GoodsID)
  
  -- 根据组合品id求和
  insert into #GroupSumTemp
  select
  bgp.GoodsID,
  SUM((case when isnull(bgs.costprice,0)<>0 then isnull(bgs.costprice,0) else isnull(bg.costprice,0) end)*ISNULL(bgp.Amount,0)),
  SUM(ISNULL(bg.saleprice,0)),
  SUM((case when isnull(bgs.Weight,0)<>0 then isnull(bgs.Weight,0) else isnull(bg.Weight,0) end)*ISNULL(bgp.Amount,0)),
  SUM(ISNULL(bg.DeclaredValue,0)*ISNULL(bgp.Amount,0))
  from B_GoodsGroup bgp
  inner join B_GoodsSKU bgs on bgs.NID=bgp.GoodsSKUID
  inner join B_Goods bg on bg.NID=bgs.GoodsID
  where bgp.GoodsID in (select NID from #GroupTemp)
  group by bgp.GoodsID

  -- 更新商品成本什么的 根据组合品id
  -- 主表
  update bg 
    set bg.CostPrice=bgtmp.costprice,
        bg.SalePrice=bgtmp.saleprice,
        bg.Weight=bgtmp.Weight,
        bg.DeclaredValue=bgtmp.DeclaredValue
    from B_Goods bg
    inner join #GroupSumTemp bgtmp on bgtmp.nid=bg.NID
  -- sku表
  update bgs 
    set bgs.CostPrice=bgtmp.costprice,
        bgs.Weight=bgtmp.Weight
    from B_GoodsSKU bgs
    inner join #GroupSumTemp bgtmp on bgtmp.nid=bgs.GoodsID  
  drop table #GroupSumTemp
  drop table #GroupTemp
  
end	
