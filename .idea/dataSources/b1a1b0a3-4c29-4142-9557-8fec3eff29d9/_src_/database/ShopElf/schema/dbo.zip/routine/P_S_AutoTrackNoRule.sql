CREATE proc [P_S_AutoTrackNoRule]
	@LogicWayNID int
AS
BEGIN
    begin tran TrackNoRule
		Declare @TrackNoRule Varchar(50)
		Declare @TrackNo VarChar(50)
		Declare @fTrackNoRule varchar(50)
		Declare @IntTrack bigint
		set @TrackNoRule=isnull((select top 1 AutoTrackNoRule from B_LogisticWay where NID=@LogicWayNID),'')
		SET @TrackNo = ''
		set @IntTrack=0
		--分析跟踪号中的规则两位字母+流水号+字母的方式，如 RF{123467891}CN
		IF (PATINDEX('%{%', @TrackNoRule) > 0)
		BEGIN 
			set @TrackNo=substring(@TrackNoRule,CHARINDEX('{',@TrackNoRule)+1,CHARINDEX('}',@TrackNoRule)-CHARINDEX('{',@TrackNoRule)-1)
			if isnumeric(@TrackNo)=1 
			  set @IntTrack=CAST(@TrackNo as bigint)+1
			else
			  set @IntTrack =0
			set @fTrackNoRule  = REPLACE(@TrackNoRule,'{'+@TrackNo+'}','{'+CAST(@IntTrack as varchar)+'}') 
			set @TrackNo = REPLACE(@TrackNoRule,'{'+@TrackNo+'}',CAST(@IntTrack as varchar))  
			update B_LogisticWay set AutoTrackNoRule= @fTrackNoRule where NID=@LogicWayNID
		END ELSE 
		IF @TrackNoRule = '中邮跟踪号'
		BEGIN 
			set @TrackNo=(select top 1 ISNULL(TrackNo,'') from B_ChinaPostTrackNo  WITH (UPDLOCK) 
					where IsUsed=0 and  LogisticWayNID=@LogicWayNID)
			if ISNULL(@TrackNo,'')=''
			set @TrackNo='无可以用跟踪号' 
			update B_ChinaPostTrackNo set IsUsed= 1 where TrackNo=@TrackNo
			SET @IntTrack = 1		
		END ELSE 		
		BEGIN
			SET @TrackNo = @TrackNoRule
			SET @IntTrack = 1
		END
		
	if 	@IntTrack=0
	  rollback tran TrackNoRule
	else
	  commit tran TrackNoRule  
		select trackno= @TrackNo
END
