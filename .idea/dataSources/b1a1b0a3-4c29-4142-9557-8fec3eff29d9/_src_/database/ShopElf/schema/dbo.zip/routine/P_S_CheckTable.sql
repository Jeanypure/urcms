
create  proc P_S_CheckTable
as
begin

	/********************************/
	/*     检测表记录类型--start    */
	/********************************/
	declare 
		@TableId int=0,
		@shiptoNameFieldType varchar(5)='',
		@shiptoStreet1FieldType varchar(5)='',
		@shiptoStreet2FieldType varchar(5)=''
	set
		@TableID=isnull((select id from sysobjects where name = 'P_trade'),0)
	set	
		@shiptoNameFieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTONAME' ),'')
	set	
		@shiptoStreet1FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET' ),'')
	set	
		@shiptoStreet2FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET2' ),'')
	if 	@shiptoNameFieldType='0' and @shiptoStreet1FieldType='0' and @shiptoStreet2FieldType='0' 
	begin
	  select 'p_trade字段类型检测正常!!!!!'
	  print 'p_trade字段类型检测正常!!!!!'
	end		
	else
	begin
	  select '***********p_trade字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************'; 
	  print '***********p_trade字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************';
	  exec('''***********p_trade字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************''')
	end	
	--P_Trade_His
	set
		@TableID=isnull((select id from sysobjects where name = 'P_Trade_His'),0)
	set	
		@shiptoNameFieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTONAME' ),'')
	set	
		@shiptoStreet1FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET' ),'')
	set	
		@shiptoStreet2FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET2' ),'')
	if 	@shiptoNameFieldType='0' and @shiptoStreet1FieldType='0' and @shiptoStreet2FieldType='0' 
	begin
	  select 'P_Trade_His字段类型检测正常!!!!!'
	  print 'P_Trade_His字段类型检测正常!!!!!'
	end		
	else
	begin
	  select '***********P_Trade_His字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************'; 
	  print '***********P_Trade_His字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************';
	  exec('''***********P_Trade_His字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************''')
	end	

	--P_TradeUn

	set
		@TableID=isnull((select id from sysobjects where name = 'P_TradeUn'),0)
	set	
		@shiptoNameFieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTONAME' ),'')
	set	
		@shiptoStreet1FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET' ),'')
	set	
		@shiptoStreet2FieldType = isnull(
			(select usertype from syscolumns where id =@TableID	 and name = 'SHIPTOSTREET2' ),'')
	if 	@shiptoNameFieldType='0' and @shiptoStreet1FieldType='0' and @shiptoStreet2FieldType='0' 
	begin
	  select 'P_TradeUn字段类型检测正常!!!!!'
	  print 'P_TradeUn字段类型检测正常!!!!!'
	end		
	else
	begin
	  select '***********P_TradeUn字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************'; 
	  print '***********P_TradeUn字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************';
	  exec('''***********P_TradeUn字段类型检测失败！！！！！ 请确认P_trade表结构！！！！************''')
	end	

	/********************************/
	/*     检测表记录类型--end      */
	/********************************/


end
