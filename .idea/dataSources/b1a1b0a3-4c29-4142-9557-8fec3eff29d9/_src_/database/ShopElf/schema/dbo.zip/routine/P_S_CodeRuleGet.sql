CREATE PROCEDURE [dbo].[P_S_CodeRuleGet]		--获得编码单号
	@FuncID int = 0,			--功能模块菜单ID
	@RMaxBillCode VarChar(50) OutPut	--返回单据号	
AS
begin 
	begin tran CodeRuleGet
  	DECLARE @NID int			--编码规则编号
  	DECLARE @BillShort VarChar(4)	--单据简称
  	DECLARE @Seq TInyint			--日期类型
  	DECLARE @SpaceMark VarChar(2)	--分隔符
  	DECLARE @StartMark VarChar(8)	--起始号
  	DECLARE @BillCode VarChar(50)	--单据号
  	DECLARE @MaxBillCode VarChar(50)	--最大单据号  	
  	DECLARE @StartMarkTmp VarChar(8)--临时起始号
  	DECLARE @BillCodeTmp VarChar(50)--临时单据号
  	DECLARE @OldBillCode VarChar(50)--保留上一次的单据号
  	--获得编码规则
  	SELECT
  		@NID = bcr.NID,
  		@BillShort = BillShort,
  		@Seq = DateTypeID,
  		@SpaceMark = SpaceMark,
  		@StartMark = StartMark,
  		@BillCode = BillCode
  	FROM
  		S_CodeRule  bcr 
  	WHERE
  		BillMenuID = @FuncID
  	
  	Set @OldBillCode = 	isnull(@BillCode,'')  --保留上一次的单据号	
  		
  	DECLARE @DateStr VarChar(10)
  	--生产编码规则	
  	SET @BillCodeTmp = @BillShort + @SpaceMark
  	--日期类型处理
  	IF @Seq = 0
  	BEGIN
  		SET @BillCodeTmp = @BillCodeTmp + @SpaceMark
  	END
  	ELSE IF @Seq = 1
  	BEGIN
  		SET @BillCodeTmp = @BillCodeTmp + CONVERT(VarChar(4),YEAR(getdate())) + @SpaceMark
  	END
  	ELSE IF @Seq = 2
  	BEGIN
  		SET @BillCodeTmp = @BillCodeTmp + CONVERT(VarChar(4),YEAR(getdate())) + @SpaceMark
  		SET @DateStr = CONVERT(VarChar(2),MONTH(getdate()))
  		IF len(@DateStr) = 1
  		BEGIN
  			SET @DateStr = '0' + @DateStr
  		END
  		SET @BillCodeTmp = @BillCodeTmp + @DateStr + @SpaceMark
  	END
  	ELSE
  	BEGIN
  		SET @BillCodeTmp = @BillCodeTmp + CONVERT(VarChar(4),YEAR(getdate())) + @SpaceMark
  		SET @DateStr = CONVERT(VarChar(2),MONTH(getdate()))
  		IF len(@DateStr) = 1
  		BEGIN
  			SET @DateStr = '0' + @DateStr
  		END
  		SET @BillCodeTmp = @BillCodeTmp + @DateStr + @SpaceMark
  		SET @DateStr = CONVERT(VarChar(2),DAY(getdate()))
  		IF len(@DateStr) = 1
  		BEGIN
  			SET @DateStr = '0' + @DateStr
  		END
  		SET @BillCodeTmp = @BillCodeTmp + @DateStr + @SpaceMark
  	END
  	--判断跟原来的最大单据单号是否符合
  	SET @StartMarkTmp = SubString(@BillCode, Len(@BillCodeTmp) + 1, Len(@BillCode) - Len(@BillCodeTmp))
  	SET @BillCode = SubString(@BillCode, 1, Len(@BillCodeTmp))
  	--符合格式自动加一
  	IF (@BillCodeTmp = @BillCode) AND (Len(@StartMark) = Len(@StartMarkTmp))
  	BEGIN
  		SET @StartMark = CONVERT(VarChar(10),(CONVERT(Int, @StartMarkTmp) + 1))
  		
  		--如果加1后的数值超过了长度,那么表示单号用完,返回''
  		if Len(@StartMarkTmp) >= Len(@StartMark)
  		  SET @MaxBillCode = @BillCode + SubString(@StartMarkTmp, 1, Len(@StartMarkTmp) - Len(@StartMark)) + @StartMark
  		else 
  		  SET @MaxBillCode = ''  
  	END
  	--不符合生产编号
  	ELSE
  	BEGIN
  		SET @MaxBillCode = @BillCodeTmp + @StartMark
  	END
  	IF IsNull(@MaxBillCode, '') = ''
  	BEGIN
  		SET @MaxBillCode = ''
  	END
  	--修改当前最大单据编号,如果最大的是空，那么保留上一次的单据号，否则保留最大单据号
  	if @MaxBillCode = '' 
  	begin
  	  UPDATE S_CodeRule SET BillCode = @OldBillCode WHERE NID = @NID 
  	end
  	else begin
  	  UPDATE S_CodeRule SET BillCode = @MaxBillCode WHERE NID = @NID 
  	end;
  		
	commit tran CodeRuleGet
  	SET @RMaxBillCode =@MaxBillCode
	select MaxBillCode = @MaxBillCode
END 
