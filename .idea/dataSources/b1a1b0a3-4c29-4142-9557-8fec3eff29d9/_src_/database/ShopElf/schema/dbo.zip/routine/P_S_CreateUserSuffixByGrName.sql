create proc [P_S_CreateUserSuffixByGrName]
	@GroupName varchar(50)
as
begin
	declare @userID varchar(20)='0',
	        @suffixs varchar(max)='',
			@suffix varchar(500)='',
		    @sSQLCmd VARCHAR(max) = ''
	Declare 
			AmountCur Cursor For Select cast(NID as varchar(20)) ,seldatauser  From B_Person where GroupName=@GroupName 
		Open AmountCur
		Fetch Next From AmountCur Into @userid,@suffixs
		While (@@Fetch_Status=0)
		begin
            EXEC('delete s_usersuffix where userid='+@userid )
            set @sSQLCmd='';
            if @suffixs<>''
				set @suffixs=@suffixs+','
            while PATINDEX('%,%',@suffixs)>0
            begin
              set @suffix=SUBSTRING(@suffixs,1,PATINDEX('%,%',@suffixs)-1);
              set @suffixs=SUBSTRING(@suffixs,PATINDEX('%,%',@suffixs)+1,LEN(@suffixs));
              set @sSQLCmd=@sSQLCmd+' select '+@userid+','+@suffix+' union ';
            end;
            if @sSQLCmd<>''
            begin
				set @sSQLCmd=SUBSTRING(@sSQLCmd,1,LEN(@sSQLCmd)-6);
				set @sSQLCmd='INSERT INTO s_usersuffix(userid,Suffix) '+@sSQLCmd;
				exec(@sSQLCmd);
            end			
		  Fetch Next From AmountCur Into @userid,@suffixs
		end
		Close AmountCur
		Deallocate AmountCur
end
