
--P_S_GetErrorOrderByNID  1850223
CREATE proc [dbo].[P_S_GetErrorOrderByNID]
	@TradeNID integer
 as
 begin
	select 
		top 500  
		d.tradenid,
		d.nid,
		d.L_Number,
		d.l_name, 
		d.L_EBAYITEMTXNID,
		m.ORDERTIME,
		m.[User] as eBayUserID,
		m.RECEIVERBUSINESS,  
		m.TRANSACTIONID,
		m.buyerid as buyerid,
		m.SALESTAX, 
		DATEADD(HH,-240,ORDERTIME) as ModTimeFrom,   
		DATEADD(HH,0,getdate()) as   ModTimeTo  
	from P_TradeDt(nolock) d  
	inner join P_Trade(nolock) m on m.nid=d.tradeNid  
	where  
		m.NID=@TradeNID
		and (Isnull(d.sku,'') =''  )   
		and  d.L_EBAYITEMTXNID = '0'  
 end
