
create PROCEDURE [dbo].[P_Sku_CheckIsAllowDel] @Sku varchar(64) = ''
AS
BEGIN
  DECLARE @Return Varchar(1000) = ''
  declare @BillNumber varchar(100)
  
    set @Return = '0';
    --采购订单..................................
    select @BillNumber = ISNULL(so.BillNumber,'') from CG_StockOrderD sod 
               inner join CG_StockOrderM so on sod.StockOrderNID = so.NID 
               inner join  B_GoodsSKU bgs ON sod.GoodsSKUID = bgs.NID 
            WHERE bgs.Sku = @Sku 
    if (@BillNumber <> '') begin
      set @Return = '采购订单:' + @BillNumber + '使用商品sku为:' + @Sku 
      select @Return as Ret
      return
    end
    --库存单................................... 
    select @BillNumber = ISNULL(convert(varchar(32),sod.GoodsID),'') from KC_CurrentStock sod 
              JOIN B_GoodsSKU bgs ON sod.GoodsSKUID = bgs.NID 
              WHERE bgs.Sku = @Sku 
    if (@BillNumber <> '') begin
      set @Return = '库存单存在商品sku为:' + @Sku 
      select @Return as Ret
      return
    end
    --待处理单.........................
    select @BillNumber = ISNULL(convert(varchar(32),so.Nid),'') from P_tradedt sod 
               inner join P_Trade so on sod.TradeNID  = so.NID 
               inner join  B_GoodsSKU bgs ON sod.GoodsSKUID = bgs.NID 
            WHERE bgs.Sku = @Sku 
    if (@BillNumber <> '') begin
      set @Return = '待处理订单:' + @BillNumber + '使用商品sku为:' + @Sku 
      select @Return as Ret
      return
    end
    select @BillNumber = ISNULL(convert(varchar(32),so.Nid),'') from P_TradeDt_His sod 
               inner join P_Trade_His so on sod.TradeNID  = so.NID 
               inner join  B_GoodsSKU bgs ON sod.GoodsSKUID = bgs.NID 
            WHERE bgs.Sku = @Sku 
    if (@BillNumber <> '') begin
      set @Return = '已归档订单:' + @BillNumber + '使用商品sku为:' + @Sku 
      select @Return as Ret
      return
    end
    select @BillNumber = ISNULL(convert(varchar(32),so.Nid),'') from P_TradeDtUn  sod 
               inner join P_TradeUn so on sod.TradeNID  = so.NID 
               inner join  B_GoodsSKU bgs ON sod.GoodsSKUID = bgs.NID 
            WHERE bgs.Sku = @Sku 
    if (@BillNumber <> '') begin
      set @Return = '异常订单:' + @BillNumber + '使用商品sku为:' + @Sku 
      select @Return as Ret
      return
    end
    --其他入库单，出库单...等先忽略
  select @Return as Ret
END

