
CREATE PROCEDURE [dbo].[P_TR_AutoLinkPackName] @TradeNIDs VARCHAR(MAX) = '' , 
                                       @PackName VARCHAR(100) = '',
                                       @ForceAssign Int = 0
AS
BEGIN
  --创建临时订单号表
  CREATE TABLE #SelRecordTable
  (
	TradeNID INT NOT NULL DEFAULT 0,
  ) 
  
  --把传入的订单号分解后插入临时表
  DECLARE @sSQLCmd varchar(max) = '', @temp varchar(20) = '', @index int = 0
  SET @sSQLCmd = 'insert into #SelRecordTable select ';
  while (PATINDEX('%,%', @TradeNIDs) > 0)
  begin
    set @index = PATINDEX('%,%', @TradeNIDs) - 1
    set @temp = SubString(@TradeNIDs,1,@index) 
    set @TradeNIDs = SUBSTRING(@TradeNIDs,@index+2,LEN(@TradeNIDs)- @index+2) 
     
    if (LEN(@sSQLCmd)> 7500)
    begin
      exec(@sSQLCmd)
      SET @sSQLCmd = 'insert into #SelRecordTable select ';
    end 
    else begin 
      if (len(@sSQLCmd) > 35)
      begin         
        SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
      end 
      else begin
        SET @sSQLCmd = @sSQLCmd + @temp 
      end         
    end      
  end 
  if (len(@sSQLCmd) > 35)
    exec(@sSQLCmd)
  SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNIDs;
  exec(@sSQLCmd)
 	
  --先把包装规格都清空了	
  update P_Trade set PROTECTIONELIGIBILITY='',INSURANCEAMOUNT = 0
  where NID in (SELECT TradeNID FROM #SelRecordTable) 
 
  --根据标志分别操作 强制的话，就直接更新，如果不强制那么判断一单一货的商品有包装规格的，按默认，其他按设置
  --获取选择包装的成本价
  DECLARE @CostPrice money = 0
  set @CostPrice = (select top 1 CostPrice from B_PackInfo where PackName = @PackName)
  set @CostPrice = ISNULL(@CostPrice,0) 
  if @ForceAssign = 1      --直接设置
  begin
    update P_Trade set INSURANCEAMOUNT = @CostPrice,PROTECTIONELIGIBILITY = @PackName
    where NID in (SELECT TradeNID FROM #SelRecordTable) 	
  end
  else begin               --先匹配一单一货有默认包装规格的
    --先匹配一单一货
    update p
    set p.PROTECTIONELIGIBILITY = isnull(bp.PackName,''),
        p.INSURANCEAMOUNT = ISNULL(bp.CostPrice,0)    
    from P_Trade p  
    inner join P_tradedt d on d.tradenid=p.nid  
    inner join B_GoodsSKU gs on gs.nid=d.goodsskuid  
    inner join B_Goods g on g.nid=gs.goodsid
    inner join B_PackInfo bp on bp.PackName = g.PackName
    inner join 
    (select TradeNID,count(sku) as MyCount,sum(L_QTY) as MySum 
    from P_Tradedt   
    where tradenid in (SELECT TradeNID FROM #SelRecordTable) 
    group by TradeNID) pd on pd.TradeNID = p.NID
    where pd.MyCount = 1 and pd.MySum = 1 
    
    --再匹配剩下的包装规格是空的
    update P_Trade set INSURANCEAMOUNT = @CostPrice,PROTECTIONELIGIBILITY = @PackName
    where NID in (SELECT TradeNID FROM #SelRecordTable) and PROTECTIONELIGIBILITY = ''	
  end
  
  --最后删除临时表
  drop table #SelRecordTable
END
