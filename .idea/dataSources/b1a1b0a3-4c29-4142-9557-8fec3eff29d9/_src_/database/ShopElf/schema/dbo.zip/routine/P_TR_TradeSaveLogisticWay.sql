
/*修改订单保存物流方式的存储过程，加了个跟踪号有改变些日志*/
CREATE PROCEDURE [P_TR_TradeSaveLogisticWay] @TradeNid INT = 0,                   
                                           @EubFlag  INT = 0, --是否e邮宝订单。0：不是;1:是；
                                           @OrigFilterFlag INT = 0,
                                           @ExpressNID INT = 0,
                                           @LogicWayNID INT = 0,                                           
                                           @TrackNo VARCHAR(100) = '',
                                           @StoreNID INT = 0,
                                           @BatchNum VARCHAR(50) = '',
                                           @Operater VARCHAR(50) = '',
                                           @IsAutoPaiDan int = 0,       --是否自动派单 0 手动派单 1 自动派单
                                           @IsCNPL int = 0              --是否中邮跟踪号，0 否 1 是 （如果是中邮跟踪号，并且系统参数里设置了缺货订单不保存跟踪号，那么跟踪号再返还到中邮跟踪号列表）  
AS
BEGIN
	--2013-06-17 做了逻辑处理调整,SKU,库存检查通过的,才能派单 陈卫
  DECLARE  @FilterFlag INT = 0, @temp VARCHAR(20) = '', @SelResult INT = 0, @SelResultMsg VARCHAR(200) = ''  
  DECLARE @Logs VARCHAR(8000) = '',@piPeiHaveGoods int, @NewStoreID int, @LineCount int
 	--check storeid
	if not  exists(select top 1 nid from B_Store(nolock) where NID=@StoreNID)
	begin
		if (select count(nid) from b_store(nolock) where used=0)=1
		begin
			set @StoreNID=(select top 1 nid from b_store(nolock))
		end else
		begin
			set @temp=CONVERT(VARCHAR(20),@TradeNid);
			set @SelResultMsg='订单 ' +@temp + ' 仓库不存在，请手动选择仓库后派单';	
	  		SELECT 1 AS result, @SelResultMsg AS Msg
	  		EXEC S_WriteTradeLogs @temp,@SelResultMsg ,@Operater 
	  		Return
		end
	end
	  
  set @piPeiHaveGoods = (select CONVERT(int, IsNull(paraValue,0)) from B_SysParams where ParaCode = 'PiPeiHaveGoodsStore')
 
  IF EXISTS(SELECT 1 FROM P_Trade WHERE NID = @TradeNid  ) --AND FilterFlag=ISNULL(@OrigFilterFlag,0)	--增加 ISNULL(ExpressStatus,0) <> 1
  BEGIN   
    SET @temp = CONVERT(VARCHAR(20),@TradeNid)
    SET @FilterFlag = 6
    --IF ISNULL(@EubFlag,0) = 1
    -- SET @FilterFlag = 7    	
  	
  	declare @oldtrackno	varchar(500);   --记录老跟踪号
  	declare @newtrackno	varchar(500);   --记录新跟踪号
  	declare @oldlogicID	integer;   --原单物流Id
  	declare @oldFilterFlag	integer;   --原单FilterFlag 
  	declare @oldStoreID		integer;   --原单StoreID   	
	DECLARE @RestoreStock integer;   --原单缺货占用标记  		
  	declare @fstr	varchar(500);		--临时
  	set	@oldlogicID=0
   	set	@oldFilterFlag=0
  	set	@oldStoreID=0   	 		
  	--查询老跟踪号及其它值
  	select top 1 
  		@oldtrackno		=isnull(trackno,''),
  		@oldFilterFlag	=FilterFlag,
  		@oldlogicID		=logicsWayNID,
  		@RestoreStock	=RestoreStock
  	from p_trade 
  	where nid = @TradeNid;  
  	--判断原单值如果是6，为已派单的再派单动作，检测仓库是否变化

  	if @oldFilterFlag=5 and @RestoreStock=-1
  	begin
  		select top 1 
  			@oldStoreID		=storeid
  		from p_tradedt 
  		where tradenid = @TradeNid;  
  		 		
  		--如果仓库和原单不等，取消占用
  		if isnull(@oldStoreID,0)<> @StoreNID 
  		begin
  			exec P_KC_FreeReservationNum @TradeNid
  			set @fstr = '派单时仓库ID改变:'+CAST(@oldStoreID as varchar(20))+'->'+ CAST(@StoreNID as varchar(20))
  			EXEC S_WriteTradeLogs @temp,@fstr,@Operater   	  			
  		end 	
  	end	
 	
  	--记录跟踪号
  	--if exists (select top 1 nid from p_trade where nid = @TradeNid and logicsWayNID<>@LogicWayNID  and isnull(trackno,'')<>'' )
  	--begin
  	--	set @fstr = '派单时物流改变,原跟踪号['+ isnull(@oldtrackno,'')+']清空!'
  	--	EXEC S_WriteTradeLogs @temp,@fstr,@Operater   		
  	--end;
  	/***--cf修改成下面****/
  	if @oldlogicID<>@LogicWayNID  and @oldtrackno<>'' 
  	begin
  		set @fstr = '派单时物流改变,原跟踪号['+ isnull(@oldtrackno,'')+']清空!'
  		EXEC S_WriteTradeLogs @temp,@fstr,@Operater   		
  	end;  	
 
  	--filterflag待库存检测通过后，再更新，其它信息可立即更新　2013.06.19　陈卫
  	if @oldlogicID=@LogicWayNID  and @oldtrackno<>'' 
  	begin
  		set @newtrackno = @oldtrackno
  	end	
  	else
  		set @newtrackno = @TrackNo
  		
  	UPDATE P_Trade 
  			SET 
  			    PaidanDate=GetDate(),
  			    PaidanMen=@Operater,  	
  			    expressNID=@ExpressNID,
  				logicsWayNID=@LogicWayNID,		    
  			    trackno=@newtrackno,--case when logicsWayNID=@LogicWayNID and isnull(trackno,'')<>'' then trackno else @TrackNo end , --已派时前后物流方式一样的，保留原跟踪号,否则清空
  			    BatchNum= CASE WHEN ISNULL(@BatchNum,'')<>'' THEN @BatchNum ELSE BatchNum END  
  			    
  			WHERE NID=@TradeNid
  	
  	--更新数据后查询新跟踪号
  	--cf set @newtrackno = (select top 1 isnull(trackno,'') from p_trade where nid = @TradeNid);	
  	--如果跟踪号有变化，那么记录日志
  	if @newtrackno <> @oldtrackno 
  	begin
      set @fstr = '跟踪号由['+ isnull(@oldtrackno,'')+']变为[' + isnull(@newtrackno,'') + ']'
  	  EXEC S_WriteTradeLogs @temp,@fstr,@Operater    
  	end;
  	--6时，只更新物流和快递公司后，直接退出
  	if @oldFilterFlag>5 
  	begin
		SELECT 0 AS result, '更新物流方式成功' AS Msg
	  	DECLARE @E1 VARCHAR(100)='', @L1 VARCHAR(100)=''
	  	  SET @E1  = (SELECT TOP 1 NAME FROM T_Express WHERE NID = @ExpressNID)
	  	  SET @L1 = (SELECT TOP 1 NAME FROM B_LogisticWay WHERE NID = @LogicWayNID)
     	  SET @Logs = '改变物流:['+@E1+']['+@L1+']'
	  	  EXEC S_WriteTradeLogs @temp, @Logs,@Operater      	  		
		return;   
  	end	  	
  	--IF EXISTS(SELECT 1 													--这个判断没有加上订单号,感觉有点不妥...未派单应该不涉及库存占用/还原的问题.... 陈卫
  	--          FROM P_Trade WHERE   (RestoreStock NOT IN (-1,1)) )		-- 把 ISNULL(ExpressStatus,0) <> 1 发货标记,放在前面判断
  	--BEGIN   	
  		--0802 默认匹配订单
  		UPDATE P_TradeDt 
  		SET StoreID =@StoreNID
  		--SET StoreID =case when isnull(StoreID,0)=0 then @StoreNID else StoreID end
  		WHERE TradeNID =@TradeNid
	  	
	  	CREATE TABLE #CheckResut (result INT , Msg VARCHAR(5000))
	  	-------------------------------------------------------------------------------   
		--add by by ylq 2016-08-12 如果仓库缺货，是转到有货的仓库去
		/*select top 1  @oldStoreID = storeid from p_tradedt  where tradenid = @TradeNid; --取没更新时的仓库ID
		set @NewStoreID = @oldStoreID
			if (@piPeiHaveGoods = 1) begin
			  select @LineCount = COUNT(1) from P_TradeDt 
			     where TradeNID = @TradeNid group by GoodsSkuID
		 
			  select B.StoreID, Sum(1) as LineCount into #TabStore
				   from 
				   ( select   GoodsSkuID,SUM(L_Qty) as L_Qty from P_TradeDt A
					 where TradeNID = @TradeNid 
					 group By  GoodsSkuID
				   ) A
				   inner join KC_CurrentStock B on A.GoodsSKUID = B.GoodsSKUID
				   where (B.Number - B.ReservationNum) > A.L_QTY 
				   group by B.StoreID 
			       
			   if not EXISTS (select 1 from #TabStore where StoreID = @oldStoreID 
			             having COUNT(1) >= @LineCount)
			   begin 
			       if EXISTS (select 1 from #TabStore where LineCount >= @LineCount)
			       begin 
				      update P_TradeDt set StoreID = (select top 1 StoreID from #TabStore where LineCount >= @LineCount)
				      where TradeNID = @TradeNid 
				   end     
			   end    
			   drop table #TabStore   
			 end
			 */
        -----------------------------------------------------------------------
        
        INSERT INTO #CheckResut
		EXEC P_KC_CheckReservationNum @TradeNid 	--检查库存
 
	  	IF EXISTS(SELECT TOP 1 * FROM #CheckResut WHERE result = 1 )
	  	BEGIN 
	  	   ----查找派单时缺货中邮跟踪号是否保留
		   Declare
			   @SendOrderStockOutIsReturnTrackNo int = 0
		   set
			   @SendOrderStockOutIsReturnTrackNo =ISNULL((select top 1 ParaValue from B_SysParams 
											where ParaCode ='SendOrder-StockOutIsReturnTrackNo'),0)	
	  	 							
		   BEGIN TRAN quehuo  
		   DECLARE @Errorcount INT = 0    
	 
	       --缺货的时候，如果系统参数有设置缺货不保留中邮跟踪号的，是中邮跟踪号，并且有跟踪号，那么跟踪号退回跟踪号列表
	       if (@IsCNPL = 1) and (@TrackNo <> '') and (@SendOrderStockOutIsReturnTrackNo=1)
	       begin
		       UPDATE P_Trade 
			   SET FilterFlag = 1,
			       TrackNo = '',             --如果是中邮跟踪号，缺货的时候清掉跟踪号，因为该要返回跟踪号列表
  				   expressNID=@ExpressNID,
  				   logicsWayNID=@LogicWayNID,			   
				   AdditionalCharge = 0,
				   InsuranceFee = 0,
				   BatchNum= @BatchNum,
				   PROTECTIONELIGIBILITYTYPE='缺货订单' 
			   WHERE NID = @TradeNid 
			   SET  @Errorcount=@@ERROR
		   end
		   else begin
		       UPDATE P_Trade 
		       SET FilterFlag = 1,
  				   expressNID=@ExpressNID,
  				   logicsWayNID=@LogicWayNID,			   
				   AdditionalCharge = 0,
				   InsuranceFee = 0,
				   BatchNum= @BatchNum,
				   PROTECTIONELIGIBILITYTYPE='缺货订单' 
			   WHERE NID = @TradeNid 
			   SET  @Errorcount=@@ERROR
		   end
		       
		   INSERT INTO P_TradeUn 
		   SELECT * 
		   FROM P_Trade 
		   WHERE NID = @TradeNid 
		   SET  @Errorcount=@@ERROR + @Errorcount   
		   
		   INSERT INTO P_TradeDtUn 
		   SELECT * 
		   FROM P_TradeDt 
		   WHERE TradeNID = @TradeNid 
		   SET  @Errorcount=@@ERROR + @Errorcount     
		   
		   DELETE FROM P_Trade WHERE NID = @TradeNid 
		   SET  @ErrorCount=@@ERROR + @ErrorCount     
		   
		   DELETE FROM P_TradeDt WHERE TradeNID = @TradeNid 
		   SET  @Errorcount=@@ERROR + @Errorcount  
		   --转缺货也计算成本及利润
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedtun where tradenid=pt.nid),0),
				pt.ExpressFare= isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0) 
			FROM P_Tradeun pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNID
				    
			UPDATE pt
			SET 
				pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-pt.GoodsCosts-
				ExpressFare),0)
			FROM P_Tradeun pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNID	
				   
		   if (@IsCNPL = 1) and (@TrackNo <> '') and (@SendOrderStockOutIsReturnTrackNo=1)  --如果是中邮跟踪号，并且有跟踪号，那么跟踪号退回跟踪号列表
		   begin
		     update B_ChinaPostTrackNo 
		         set IsUsed = 0
		     where LogisticWayNID = @LogicWayNID
		       and TrackNo = @TrackNo  
		     SET  @Errorcount=@@ERROR + @Errorcount      
		   end
		   
		   IF @Errorcount=0  
		   BEGIN     
   			COMMIT TRAN quehuo 
			----查找派单时缺货是否写入缺货表0 不写入  1 写入
			Declare
				@SaveLogicWayIsOutOfStock int 
			set
				@SaveLogicWayIsOutOfStock =ISNULL((select top 1 ParaValue from B_SysParams 
											where ParaCode ='SaveLogicWayIsOutOfStock'),0)
  
			  if @SaveLogicWayIsOutOfStock=1 
			  begin
				exec P_CG_OutOfStock @temp;	--转缺货订单成功后,加入到缺货管理中 
			  end   			  
   			 
   			--if @IsAutoPaiDan = 1 
	  	  --    SET @Logs = '自动:库存不足,转至缺货订单!'
	  	  --  else 
	  	  --    SET @Logs = '手动:库存不足,转至缺货订单!'
   			
   			--EXEC S_WriteTradeLogs @temp, @Logs,@Operater 
		   END ELSE 
		   BEGIN     
   			ROLLBACK TRAN quehuo   
   			
   			if @IsAutoPaiDan = 1 
	  	      SET @Logs = '自动:库存不足,转至缺货订单出错!'
	  	    else 
	  	      SET @Logs = '手动:库存不足,转至缺货订单出错!'
   			
   			EXEC S_WriteTradeLogs @temp, @Logs,@Operater 
		   END
		   IF (ISNULL(@Errorcount,0) = 0)
		   BEGIN
		     if @IsAutoPaiDan = 1 
	  	       SET @Logs = '自动:库存不足,转至缺货订单,sid:'+ CAST(@StoreNID as varchar(20)) 
	  	     else 
	  	       SET @Logs = '手动:库存不足,转至缺货订单,sid:'++ CAST(@StoreNID as varchar(20))
		   	 EXEC S_WriteTradeLogs @temp, @Logs,@Operater 
		   	 SET @SelResult = 1
		   	 SET @SelResultMsg = '订单 ' +@temp + ' 库存不足,转至缺货订单';					--增加缺货订单提示
		   END ELSE 
		   BEGIN
		   	 SET @SelResult = 1
		   	 SET @SelResultMsg = '在订单转至"异常订单"环节时出错!'
		   END	   
	  	END ELSE 
	  	IF EXISTS(SELECT TOP 1 * FROM #CheckResut WHERE result = 2 )
	  	BEGIN
	  	  SET @SelResultMsg = (SELECT TOP 1 Msg FROM #CheckResut WHERE result = 2)  
	  	  SET @SelResult = 1
		  SET @SelResultMsg = '订单"' + @temp  + '"商品SKU没有与库存进行对应,请检查!'+ Char(13)+Char(10)+ @SelResultMsg
	  	END ELSE  
		IF EXISTS(SELECT TOP 1 * FROM #CheckResut WHERE result = 3 )
	  	BEGIN
	  	  SET @SelResultMsg = (SELECT TOP 1 Msg FROM #CheckResut WHERE result = 3)  
	  	  SET @SelResult = 1
		  SET @SelResultMsg = '订单"' + @temp + '"中的商品在对应仓库未找到关于此商品的任何信息,请检查!'+ Char(13)+Char(10)+ @SelResultMsg
	  	END ELSE 
	  	IF EXISTS(SELECT TOP 1 * FROM #CheckResut WHERE result = -1 )
	  	BEGIN
	  	  SET @SelResultMsg = (SELECT TOP 1 Msg FROM #CheckResut WHERE result = -1)  
	  	  SET @SelResult = 1
		  SET @SelResultMsg = '订单"' + @temp + '"执行SQL语句出错，请确认!'+ Char(13)+Char(10)+ @SelResultMsg
		  EXEC S_WriteTradeLogs @temp, '执行SQL语句出错，请确认!',@Operater 
	  	END ELSE 
	  	IF EXISTS(SELECT TOP 1 * FROM #CheckResut WHERE result = 0 )
	  	BEGIN
	  		--订单SKU,库存等检查通过,可以派单  陈卫2013.06.17
	  		UPDATE P_Trade 
  				SET FilterFlag = @FilterFlag,--CASE WHEN ISNULL(ExpressStatus,0) <> 1 THEN  @FilterFlag ELSE FilterFlag END  	      			    
  					expressNID=@ExpressNID,
  					logicsWayNID=@LogicWayNID
  			WHERE NID=@TradeNid
	  		
	  	  DECLARE @ExpressName VARCHAR(100)='', @LogicWayName VARCHAR(100)='', 
	  		@StoreName VARCHAR(100)='',@StoreCount varchar(300)='0'
	  	  SET @ExpressName  = (SELECT TOP 1 NAME FROM T_Express WHERE NID = @ExpressNID)
	  	  SET @LogicWayName = (SELECT TOP 1 NAME FROM B_LogisticWay WHERE NID = @LogicWayNID)
	  	  --SET @StoreName    = (SELECT TOP 1 StoreName FROM B_Store  WHERE  NID = @StoreNID)
	  	  set @StoreCount=(SELECT TOP 1 msg FROM #CheckResut WHERE result = 0)	 
 	 
	  	  -- add by ylq 2015-04-02 区分自动派单和手动派单
	  	  if @IsAutoPaiDan = 1 begin 
	  	    SET @Logs         = '自动:['+@ExpressName+']['+@LogicWayName+'];' + @StoreCount + ',并占用'
	  	  end
	  	  else begin
	  	    SET @Logs         = '手动:['+@ExpressName+']['+@LogicWayName+'];' + @StoreCount + ',并占用'
	  	  end
	  	  
	  	  EXEC P_KC_Reservation @TradeNID
	  	 
	  	  EXEC S_WriteTradeLogs @temp, @Logs,@Operater 
	  
	  
	  	END 	   
		DROP TABLE #CheckResut
	 END 
	BEGIN TRY
		--EXEC P_XS_CheckTradeDiffAddr @TradeNID	
		UPDATE pt
		SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.nid),0),
			pt.ExpressFare= isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0) 
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
			    
		UPDATE pt
		SET 
			pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-pt.GoodsCosts-
			ExpressFare),0)
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
	END TRY
	BEGIN CATCH
	END CATCH	
	--把订单购买总数量\SKU个数求求和  TransMail 多仓
	UPDATE pt
	SET pt.MULTIITEM  = ISNULL((SELECT SUM(ptd.L_QTY) 
							  FROM P_TradeDt ptd 
							  WHERE TradeNID = pt.NID),0),
	    --add by ylq 2015-11-13 主表SKU个数取数改变
	    pt.SALESTAX  =  isnull((select sum(1) from (select sku from P_TradeDt 
					where TradeNID=pt.NID group by sku ) as aa),0)														  
	FROM P_Trade pt
	WHERE pt.NID = @TradeNID 
	--库位号	 
	BEGIN TRY
		UPDATE pt
		SET pt.GoodItemIDs=dbo.Ex_GetOrderLocationNames(@TradeNID)
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID
			    
	END TRY
	BEGIN CATCH
	END CATCH	
  --END
	--spliteramt	 del
	--BEGIN TRY
	--	EXEC P_XS_TradedtZHSpliteAmt @TradeNID
	--END TRY
	--BEGIN CATCH
	--END CATCH	
  --END  

  if @IsAutoPaiDan = 1 
  begin
    set @SelResultMsg = '自动:' +  @SelResultMsg 
  end
  else begin 
    set @SelResultMsg = '手动:' +  @SelResultMsg
  end 
  SELECT @SelResult AS result, @SelResultMsg AS Msg
END
