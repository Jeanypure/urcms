CREATE PROCEDURE [dbo].[P_TR_UpdateGoodsNames] @TradeID INT = 0
AS
BEGIN
  --获取配货信息是否用SKUNAME 0 不使用 1 使用
  declare
	@OrdersGoodsNameIsSKUName int=0 
  set 
	@OrdersGoodsNameIsSKUName = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='OrdersGoodsNameIsSKUName')	
   
  --最后更新数据 如果ID在订单表就在更新订单表，否则在订单异常表更新	
  if exists(select nid from p_Trade where nid=@TradeID)
  begin
    UPDATE 
	  D
    SET d.GoodsName = CASE WHEN ISNULL(g.MultiStyle,0) = 0  THEN  g.GoodsName 
	  		   ELSE 
	  		     case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
			     else 
			      ltrim(rtrim(ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
				  ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,''))) 
			     end                           
			   END, 	
	d.CostPrice=(case when isnull(gs.CostPrice,0)<>0 then gs.CostPrice 
		          else isnull(g.CostPrice ,0) end)*d.L_QTY
    FROM P_TradeDt D		
	 inner join B_GoodsSKU gs on gs.SKU=d.SKU			
	 inner join B_Goods g on g.NID=gs.GoodsID				
    WHERE d.TradeNID = @TradeID
  end
  else begin
    UPDATE 
	  D
    SET d.GoodsName = CASE WHEN ISNULL(g.MultiStyle,0) = 0  THEN  g.GoodsName 
	  		   ELSE 
	  		     case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
			     else ltrim(rtrim(ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
			          ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,''))) 
			     end                           
			   END, 	
	d.CostPrice=(case when isnull(gs.CostPrice,0)<>0 then gs.CostPrice 
	                  else isnull(g.CostPrice ,0) end)*d.L_QTY
    FROM P_TradeDtUn D		
	 inner join B_GoodsSKU gs on gs.SKU=d.SKU			
	 inner join B_Goods g on g.NID=gs.GoodsID				
    WHERE d.TradeNID = @TradeID
  end
END 
