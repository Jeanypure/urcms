
CREATE PROCEDURE [dbo].[P_TR_WaitPackageToDone] @TradeNid INT = 0, 
                                        @BatchNum VARCHAR(50) = '',
                                        @SendFlage INT = 0 , --0:到待发货；1:到已发货
                                        @Operater VARCHAR(50) = ''
AS
BEGIN
  DECLARE @strFlag varchar(32)
  
  IF EXISTS(SELECT 1 FROM P_Trade WHERE NID = @TradeNid AND FilterFlag in (24,28) )	
  BEGIN
  	DECLARE @stTradeDtNID INT , 
  			@stGoodsSKUID INT , 
  			@stStoreID INT ,
  			@L_QTY NUMERIC(18,2),
  			@L_AMT NUMERIC(18,2),
  			@ErrCount int
	DECLARE @temp VARCHAR(20)
	SET @temp = CONVERT(VARCHAR(20),@TradeNid)
	set @ErrCount =0 
	begin tran TR_WaitPackageToDone
  	IF ISNULL(@SendFlage,0) = 0
  	BEGIN
		UPDATE P_Trade 
        SET 
            FilterFlag=40,
            WeighingMen= (case when ISNULL(WeighingMen,'')='' then @Operater else WeighingMen end ),
            BatchNum=@BatchNum
        WHERE NID =@TradeNid	
        set @ErrCount =@ErrCount +@@ERROR  
        EXEC S_WriteTradeLogs @temp, '手工将订单从待包装转至待发货.',@Operater
        set @ErrCount =@ErrCount +@@ERROR 
  	END ELSE 
  	IF ISNULL(@SendFlage,0) = 1
  	BEGIN     
  		UPDATE P_Trade 
		SET SHIPPINGMETHOD = (case when SHIPPINGMETHOD='1'  then '1' else '0' end), 
			ExpressStatus=1, 
			FilterFlag=100, 
			CLOSINGDATE=CONVERT(varchar(16),GETDATE(),121), 
			WeighingMen= (case when ISNULL(WeighingMen,'')='' then @Operater else WeighingMen end ),
			BatchNum= @BatchNum
		WHERE NID = @TradeNid ; 
		set @ErrCount =@ErrCount +@@ERROR 
		EXEC S_WriteTradeLogs @temp, '手工将订单从待包装转至已发货.',@Operater
		set @ErrCount =@ErrCount +@@ERROR 	  	 							
		DECLARE CurSaleTable CURSOR
		FOR SELECT  Max(ptd.nid) as nid, isnull(ptd.StoreID,0) as StoreID, isnull(ptd.GoodsSKUID,0) as GoodsSKUID, 
				sum(isnull(ptd.L_QTY,0)) as l_qty, sum(isnull(ptd.L_AMT,0))  as l_amt
			FROM P_TradeDt ptd 
			WHERE ptd.TradeNID = @TradeNid and isnull(ptd.GoodsSKUID,0)<>0
        group by 
			ptd.StoreID, ptd.GoodsSKUID			
		OPEN CurSaleTable
		FETCH NEXT FROM CurSaleTable INTO @stTradeDtNID, @stStoreID, @stGoodsSKUID, @L_QTY, @L_AMT
		WHILE (@@FETCH_STATUS = 0)
		BEGIN  
		  SET @TradeNid = ISNULL(@TradeNid,0);
		  SET @stTradeDtNID = ISNULL(@stTradeDtNID,0);
		  SET @stStoreID = ISNULL(@stStoreID,0);
		  SET @stGoodsSKUID = ISNULL(@stGoodsSKUID,0);
		  SET @L_QTY = ISNULL(@L_QTY,0);
		  SET @L_AMT = ISNULL(@L_AMT,0);
		  SET @Operater = ISNULL(@Operater,'');
		  		
		  EXEC P_KC_Insert_CK_StockOut
								@TradeNid,
								@stGoodsSKUID,--用SKUID判断 @stTradeDtNID,
								@stStoreID,
								@stGoodsSKUID,
								@L_QTY,
								@L_AMT,
								@Operater;
		  set @ErrCount =@ErrCount +@@ERROR 
		  FETCH NEXT FROM CurSaleTable INTO  @stTradeDtNID, @stStoreID, @stGoodsSKUID, @L_QTY, @L_AMT
		END
		CLOSE CurSaleTable
		DEALLOCATE CurSaleTable
    END   
    
    select @strFlag = IsNull(ParaValue,0) from B_SysParams where ParaCode = 'PackFin_SetPackMan'
    if @strFlag = 1 begin
      update P_Trade set PackageMen = @Operater where NID =@TradeNid and ISNULL(packageMen,'') = ''
      update P_Trade set PackingMen = @Operater where NID =@TradeNid and ISNULL(PackingMen,'') = ''
    end
     
    if @ErrCount =0
      commit tran TR_WaitPackageToDone
    else
      rollback tran TR_WaitPackageToDone  
  END
END

