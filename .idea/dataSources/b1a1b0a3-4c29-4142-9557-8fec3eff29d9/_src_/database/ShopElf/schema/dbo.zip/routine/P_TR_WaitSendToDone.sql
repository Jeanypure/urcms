
CREATE PROCEDURE [dbo].[P_TR_WaitSendToDone] @TradeNid INT = 0, 
                                     @BatchNum VARCHAR(50) = '',
                                     @Operater VARCHAR(50) = ''
AS
BEGIN
	
  IF EXISTS(SELECT 1 FROM P_Trade WHERE NID = @TradeNid AND FilterFlag=40)	
  BEGIN
  	DECLARE		@stTradeDtNID INT , 
  				@stGoodsSKUID INT , 
  				@stStoreID INT ,
  				@L_QTY NUMERIC(18,2),
  				@L_AMT NUMERIC(18,2),
  				@ErrCount int
  	set @ErrCount=0			 	
  	begin tran TR_WaitSendToDone
  	UPDATE P_Trade 
    SET SHIPPINGMETHOD = (case when SHIPPINGMETHOD='1'  then '1' else '0' end), 
        ExpressStatus=1, 
        FilterFlag=100, 
        CLOSINGDATE=CONVERT(varchar(16),GETDATE(),121), 
        BatchNum= @BatchNum
    WHERE NID = @TradeNid ;  
    set @ErrCount=@ErrCount+@@ERROR
    DECLARE @temp VARCHAR(20)
    SET @temp = CONVERT(VARCHAR(20),@TradeNid)
    
    EXEC S_WriteTradeLogs @temp, '待发货订单转至已发货.',@Operater
    set @ErrCount=@ErrCount+@@ERROR
  	--cf 修改一个SKUID一条记录 							
	DECLARE CurSaleTable CURSOR
	FOR SELECT  Max(ptd.nid) as nid, isnull(ptd.StoreID,0) as StoreID, isnull(ptd.GoodsSKUID,0) as GoodsSKUID,  
			sum(isnull(ptd.L_QTY,0)) as l_qty, sum(isnull(ptd.L_AMT,0))  as l_amt
		FROM P_TradeDt ptd 
		WHERE ptd.TradeNID = @TradeNid and isnull(ptd.GoodsSKUID,0) <>0 
    group by 
		ptd.StoreID, ptd.GoodsSKUID
	OPEN CurSaleTable
	FETCH NEXT FROM CurSaleTable INTO @stTradeDtNID, @stStoreID, @stGoodsSKUID, @L_QTY, @L_AMT
	WHILE (@@FETCH_STATUS = 0)
	BEGIN  
	  SET @TradeNid = ISNULL(@TradeNid,0);
	  SET @stTradeDtNID = ISNULL(@stTradeDtNID,0);
	  SET @stStoreID = ISNULL(@stStoreID,0);
	  SET @stGoodsSKUID = ISNULL(@stGoodsSKUID,0);
	  SET @L_QTY = ISNULL(@L_QTY,0);
	  SET @L_AMT = ISNULL(@L_AMT,0);
	  SET @Operater = ISNULL(@Operater,'');
	  		
	   EXEC P_KC_Insert_CK_StockOut
							@TradeNid,
							@stGoodsSKUID,--用SKUID判断 @stTradeDtNID,
							@stStoreID,
							@stGoodsSKUID,
							@L_QTY,
							@L_AMT,
							@Operater;
		set @ErrCount=@ErrCount+@@ERROR					
	  FETCH NEXT FROM CurSaleTable INTO  @stTradeDtNID, @stStoreID, @stGoodsSKUID, @L_QTY, @L_AMT
	END
	CLOSE CurSaleTable
	DEALLOCATE CurSaleTable
  	if @ErrCount=0 
  	  Commit tran TR_WaitSendToDone
  	else
  	  RollBack tran   TR_WaitSendToDone
    
  END
END

