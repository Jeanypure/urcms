
CREATE proc [dbo].[P_XS_AliToPrade]
	@TRANSACTIONID varchar(30)
as
begin
	declare 
		@TradeNID_A int
	declare 
		@SmtLastCloseTime varchar(10), @UpTradeOn varchar(3) 
		
	set @UpTradeOn = IsNull((select top 1 IsNull(ParaValue,'0') from B_SysParams where ParaCode = 'LoadToTradeUn'),0)
	
	set 
	  @SmtLastCloseTime='0'
	set
		@TradeNID_A = 0
	set @TradeNID_A=isnull((select top 1 nid from P_Trade_A 
						where TRANSACTIONID=@TRANSACTIONID and ISNULL(SHIPTONAME,'')=''),0)
	set 
	  @SmtLastCloseTime=isnull((select top 1 ParaValue from B_SysParams where ParaCode='SmtLastClosingDate'),'0')
  if (not exists(select nid from P_Trade where TRANSACTIONID=@TRANSACTIONID))
		and (@TradeNID_A=0)
  begin	
	set @TradeNID_A=isnull((select top 1 nid from P_Trade_A 
						where TRANSACTIONID=@TRANSACTIONID ),0)  
		BEGIN TRAN crSave_A 
		DECLARE @ins_error INT 
		DECLARE @TradeNID INT 
		UPDATE 
			T 
		SET 
			T.ALLGOODSDETAIL=DBO.EX_GETORDERSKUS_A(@TRADENID_A)
		FROM P_TRADE_A T
		WHERE NID = @TRADENID_A 		
		--有附表再转
		if @SmtLastCloseTime='1'
		begin
		  -- 存最后发货时间
		  INSERT INTO P_Trade(CLOSINGDATE,FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 ORDERTIME,[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],[subject],[memo],[Note],[INVNUM],[VERSION]) 
            SELECT CLOSINGDATE,FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 dateadd(hh,7,ORDERTIME),[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],[subject],[memo],[Note],[INVNUM],[VERSION]
            FROM P_Trade_A
            WHERE nid =@TradeNID_A     
		end
		else
		begin
		  INSERT INTO P_Trade(FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 ORDERTIME,[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],[subject],[memo],[Note],[INVNUM],[VERSION]) 
            SELECT FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 dateadd(hh,7,ORDERTIME),[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],[subject],[memo],[Note],[INVNUM],[VERSION]
            FROM P_Trade_A
            WHERE nid =@TradeNID_A  
		end
		
            SET NOCOUNT ON SELECT @TradeNid =SCOPE_IDENTITY() 
            SELECT @ins_error=@@Error 
            INSERT INTO P_TradeDt(
					TradeNID,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU,
					costprice,AliasCnName,AliasEnName,[Weight],DeclaredValue,
					OriginCountry,goodsname,OriginCountryCode,GoodsSKUID,StoreID,
					L_OPTIONSNAME,L_ShipFee,BuyerNote,BmpFileName) 
				
            SELECT 
				@TradeNid,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU ,
				isnull(costprice,0),AliasCnName,AliasEnName,isnull([Weight],0),isnull(DeclaredValue,0),
				OriginCountry,goodsname,OriginCountryCode,isnull(GoodsSKUID,0),isnull(StoreID,0),
				L_OPTIONSNAME,L_ShipFee,BuyerNote,BmpFileName				
            FROM 
				P_Trade_ADt
            WHERE 
				TradeNID = @TradeNID_A 
            SELECT @ins_error=@ins_error+@@Error   
            exec P_XS_TradeDtSKU @TradeNID 
            SELECT @ins_error= @ins_error + @@Error 
            DELETE FROM P_Trade_ADt WHERE TradeNID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
             DELETE FROM P_Trade_A   WHERE NID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
             
             -- add by ylq 2016-03-24 子不语他们要求直接转到缺货单
             if @UpTradeOn = '1' 
             begin
               exec P_XS_TradeToTradeUn @TradeNID,1,'缺货订单'
               SELECT @ins_error= @ins_error + @@Error 
             end
             -- end add 
 
            IF @ins_error=0 
            begin
              COMMIT TRAN crSave_A 
              exec S_WriteTradeLogs @TradeNID ,'自动下载','Server-Ali'
            end
            ELSE 
             ROLLBACK TRAN crSave_A 
  end          
  else
  begin
	delete from  P_trade_A where nid=@TradeNID_A 
	delete from  P_Trade_ADt where tradenid=@TradeNID_A 	
  end 
end          

