create Proc [P_XS_AmazonGetDownRpt]
	@sellerid	varchar(50),
	@marketid	VARCHAR(50)
AS
begin

	select s.reportid,s.reporttype
	from S_AmazonReportIDS s
	inner join 
		(	select reporttype,MAX(AvailableDate) as maxdate 
			from S_AmazonReportIDS 
			where sellerid = @sellerid
				and  MarketplaceId =@marketid
				and downFlag = 0
			group by reporttype
		) as ss on ss.ReportType=s.ReportType and ss.maxdate=s.AvailableDate
	where s.sellerid = @sellerid
				and  s.MarketplaceId =@marketid
end