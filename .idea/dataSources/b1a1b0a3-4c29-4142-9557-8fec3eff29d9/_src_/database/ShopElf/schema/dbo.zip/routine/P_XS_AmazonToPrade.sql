
CREATE proc [P_XS_AmazonToPrade]
	@TradeNID_A int=0
as
begin
  if (not exists(select nid from P_Trade where 
	[guid]=(select top 1 [Guid] from p_trade_A where NID=@TradeNID_A)
	and [User]=(select top 1 [User] from p_trade_A where NID=@TradeNID_A)))	
		and (exists(select nid from P_Trade_ADT where tradenid=@TradeNID_A))
  begin
		BEGIN TRAN crSave_A 
		DECLARE @ins_error INT 
		DECLARE @TradeNID INT, @UpTradeOn varchar(3) 
		
		set @UpTradeOn = IsNull((select top 1 IsNull(ParaValue,'0') from B_SysParams where ParaCode = 'LoadToTradeUn'),0)
	 
		--有附表再转
		INSERT INTO P_Trade(FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 ORDERTIME,[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],INVNUM,memo,PAYERSTATUS) 
            SELECT FilterFlag,EMAIL,COUNTRYCODE,SALUTATION,
					 SUFFIX,case when CHARINDEX('AFN',CUSTOM)>0 then '1' else SHIPPINGMETHOD end,ExpressStatus,
					 SHIPTONAME, 
					 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
					 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
					 TRANSACTIONTYPE,ADDRESSOWNER,PAYMENTTYPE,
					 ORDERTIME,[TIMESTAMP],AMT,CURRENCYCODE,SHIPDISCOUNT,
					 PAYMENTSTATUS,BUYERID, 
					 ACK,SHIPPINGAMT,[Guid], 
					 CUSTOM,[User],INVNUM,memo,''
				 
            FROM P_Trade_A
            WHERE NID =@TradeNID_A  
            SET NOCOUNT ON SELECT @TradeNid =SCOPE_IDENTITY() 
            SELECT @ins_error=@@Error 
            INSERT INTO P_TradeDt(
					TradeNID,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU,
					costprice,AliasCnName,AliasEnName,[Weight],DeclaredValue,OriginCountry,goodsname,
					OriginCountryCode,GoodsSKUID,StoreID,L_TransFee,L_ShipFee) 
				
            SELECT 
				@TradeNid,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU ,
				isnull(costprice,0),AliasCnName,AliasEnName,isnull([Weight],0),isnull(DeclaredValue,0),
				OriginCountry,goodsname,OriginCountryCode,isnull(GoodsSKUID,0),isnull(StoreID,0),
				L_TransFee,L_ShipFee				
            FROM 
				P_Trade_ADt
            WHERE 
				TradeNID = @TradeNID_A and L_QTY>0
            SELECT @ins_error=@ins_error+@@Error   
            UPDATE 
				t 
            SET 
				t.AllGoodsDetail=dbo.Ex_GetOrderSKUS(@TradeNID),
				t.AMT= case when CHARINDEX('AFN',CUSTOM)>0 then
						 ISNULL((select sum(l_amt) from p_tradedt where tradenid=t.nid),0) 
						 else amt end ,
				t.SHIPPINGAMT=  case when CHARINDEX('AFN',CUSTOM)>0 then 0 else t.SHIPPINGAMT end 			
            FROM P_Trade t
            WHERE nid = @TradeNid 
            SELECT @ins_error=@ins_error+@@Error 
            exec P_XS_TradeDtSKU @TradeNID 
            SELECT @ins_error= @ins_error + @@Error 
            DELETE FROM P_Trade_ADt WHERE TradeNID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
             DELETE FROM P_Trade_A   WHERE NID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
             
             -- add by ylq 2016-03-24 子不语他们要求直接转到缺货单
             if @UpTradeOn = '1' 
             begin
               exec P_XS_TradeToTradeUn @TradeNID,1,'缺货订单'
               SELECT @ins_error= @ins_error + @@Error 
             end
             -- end add 
             
            IF @ins_error=0 
            begin
              COMMIT TRAN crSave_A 
              exec S_WriteTradeLogs @TradeNID ,'自动下载','Server-Amazon'
            end
            ELSE 
             ROLLBACK TRAN crSave_A 
  end          
  else
  begin
	delete from  P_trade_A where nid=@TradeNID_A 
        delete from  P_Trade_ADt where tradenid=@TradeNID_A
  end 
end  
