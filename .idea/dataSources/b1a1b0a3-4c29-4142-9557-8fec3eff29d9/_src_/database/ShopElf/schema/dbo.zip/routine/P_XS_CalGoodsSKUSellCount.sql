
/*修改计算销量的存储过程，屏蔽掉异常单里的取消订单*/
CREATE Proc [P_XS_CalGoodsSKUSellCount]
as
begin

    Declare @SellDay1 int=5
    declare @SellDay2 int=15
    declare @SellDay3 int=30  
	select  @SellDay1= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='1' and ISNUMERIC(DictionaryName)=1
	select  @SellDay2= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='2' and ISNUMERIC(DictionaryName)=1
	select  @SellDay3= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
	where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
			and FitCode='3' and ISNUMERIC(DictionaryName)=1			    
    if @SellDay1=0
      set @SellDay1=5
    if @SellDay2=0
      set @SellDay2=15
    if @SellDay3=0
      set @SellDay3=30           
	select
		sku,
		StoreId,
		SUM(SellCount) as SellCount,
		SUM(SellCount1) as SellCount1,
		SUM(SellCount2) as SellCount2,
		SUM(SellCount3) as SellCount3		
		Into #GoodsSKUSellCount
	from (
		select 
			pd.sku,
			isnull(pd.StoreID,0) as storeID,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3	
		from 
			P_TradeDt(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_Trade(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			DATEADD(Day,-(@SellDay3+1),GETDATE())<pm.ORDERTIME and ISNULL(pd.SKU,'') <> '' 
		group by 
			pd.sku,isnull(pd.StoreID,0)
		union all				
		select 
			pd.sku,
			isnull(pd.StoreID,0) as storeID,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3	
		from 
			P_TradeDtUn(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_TradeUn(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			DATEADD(Day,-(@SellDay3+1),GETDATE())<pm.ORDERTIME and pm.FilterFlag in (0,1,2,4) and ISNULL(pd.SKU,'') <> '' 
		group by 
			pd.sku,isnull(pd.StoreID,0)
		
		union all
		select 
			pd.sku,
			isnull(pd.StoreID,0) as storeID,
			sum(case  when DATEADD(Day,ISNULL(-b.SellDays,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay1,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount1 ,
			sum(case  when DATEADD(Day,ISNULL(-@SellDay2,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount2,	
			sum(case  when DATEADD(Day,ISNULL(-@SellDay3,0),GETDATE())<DATEADD(HOUR,8,pm.ORDERTIME) 
					then pd.L_QTY else 0  end) as SellCount3															

		from 
			P_TradeDt_his(nolock) pd
		inner join 
			B_goodsSKU(nolock) bs on bs.sku=pd.sku
		inner join 
			P_Trade_his(nolock) pm on pm.NID=pd.TradeNID
		left outer join 
			B_goods b on b.nid=bs.goodsid	
		where 
			DATEADD(Day,-(@SellDay3+1),GETDATE())<pm.ORDERTIME and ISNULL(pd.SKU,'') <> '' 
		group by 
			pd.sku,isnull(pd.StoreID,0) ) 
	as ftable
	group by SKU,storeID	
	--更新kc_Currentstock sellcount	
	Update 
		kc_Currentstock 
	set
		SellCount1=0,
		sellcount2=0,
		sellcount3=0,
		SellCount=0	
			
	Update 
		g
	set
		g.SellCount1=gsc.SellCount1,
		g.sellcount2=gsc.SellCount2,
		g.sellcount3=gsc.SellCount3,
		g.SellCount = gsc.SellCount				
	from 
		kc_Currentstock g 
	inner join 
		B_Goodssku gs on gs.nid=g.goodsskuid
	inner join 
		#GoodsSKUSellCount gsc on gs.sku=gsc.sku and g.storeid=gsc.storeid
			
	--更新B_boogssku对应sellcount
	
	Update 
		B_GoodsSKU 
	set
		sellcount=0,
		SellCount1=0,
		sellcount2=0,
		sellcount3=0	
	--SKU汇总
	select 
		sku,
		sum(SellCount) as SellCount,
		sum(SellCount1) as SellCount1,
		sum(SellCount2) as SellCount2,
		sum(SellCount3) as SellCount3
		into #GoodsSKUSellCount1
	from 
		#GoodsSKUSellCount 
	group by 
		sku		
	Update 
		g
	set
		g.sellcount=gs.SellCount,
		g.SellCount1=gs.SellCount1,
		g.sellcount2=gs.SellCount2,
		g.sellcount3=gs.SellCount3					
	from 
		B_GoodsSKU g ,#GoodsSKUSellCount1 gs
	where 
		isnull(g.sku,'')=gs.sku -- and isnull(gs.SellCount,0) <>0	
	drop table #GoodsSKUSellCount
	drop table #GoodsSKUSellCount1
end
