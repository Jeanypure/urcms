CREATE PROCEDURE [dbo].[P_XS_CheckTradeDiffAddr] @TradeNID VARCHAR(20) = '0'
AS
BEGIN
	DECLARE @eBayEnable INT = 0, @AddressDifferentFlag INT = 0, @SUFFIX VARCHAR(100)= '',@DataSourcesFlag INT = 0
	SET NOCOUNT ON;
	
	UPDATE P_Trade SET SHIPTOSTATE = ''  WHERE UPPER(SHIPTOSTATE) = 'NOTPROVIDED' and NID = @TradeNID
	UPDATE P_Trade SET SHIPTOSTATE = ''  WHERE  NID = @TradeNID and ISNULL(SHIPTOSTATE,'')=''
	
	IF EXISTS(SELECT 1 
	          FROM P_trade WHERE NID = @TradeNID)
	BEGIN 
	  SET @SUFFIX =  ISNULL((SELECT SUFFIX FROM P_trade WHERE NID = @TradeNID),'') 
	END ELSE 
	BEGIN 
	  SET @SUFFIX =  ISNULL((SELECT SUFFIX FROM P_tradeUn WHERE NID = @TradeNID),'')
	END
	--是否开启ebay同步
	SELECT TOP 1 @eBayEnable = SyncEbayEnable
	FROM S_PalSyncInfo 
	WHERE SyncModuleName = 'trades' AND NoteName = @SUFFIX  
   --是否开启不同地址检测   
   SELECT TOP 1 @AddressDifferentFlag = Paravalue FROM B_SysParams WHERE ParaCode ='AddressDifferentHint'
   
   SELECT TOP 1 @DataSourcesFlag = Paravalue FROM B_SysParams WHERE ParaCode ='DataSourcesFlag'

   IF (@eBayEnable = 1) AND (@AddressDifferentFlag = 1) AND (@DataSourcesFlag = 0)
   BEGIN
   	DECLARE 
   			@eBayAddr VARCHAR(8000) = '', 
   			@PPAddr VARCHAR(8000) = '',
   			@eBayAddrNull VARCHAR(8000) = ''
   	SELECT TOP 1 @eBayAddr=ISNULL(e.Name,'')+ISNULL(e.CountryName,'')+ISNULL(e.StateOrProvince,'')+
   	                       ISNULL(e.CityName,'')+ISNULL(e.Street1,'')+ISNULL(e.Street2,'')+ ISNULL(e.PostalCode,'') ,
   	             @eBayAddrNull = ISNULL(e.Name,'') + ISNULL(e.Street1,'')           
   	FROM E_ShippingAddress e  INNER JOIN P_tradedt p on p.L_EBAYITEMTXNID=e.TransID and  p.L_NUMBER=e.ItemID 
   	WHERE p.TradeNID = @TradeNID
   	SET @eBayAddr = LOWER(REPLACE(@eBayAddr,' ',''));
    	

		IF EXISTS(SELECT 1 
				  FROM P_trade WHERE NID = @TradeNID) 	
		BEGIN
		  SELECT TOP 1 @PPAddr=ISNULL(p.SHIPTONAME,'')+ISNULL(p.SHIPTOCOUNTRYNAME,'')+ISNULL(p.SHIPTOSTATE,'')+
   							   ISNULL(p.SHIPTOCITY,'')+ISNULL(p.SHIPTOSTREET,'')+ISNULL(p.SHIPTOSTREET2,'')+ ISNULL(p.SHIPTOZIP,'')  
   		  FROM P_trade p
   		  WHERE p.NID = @TradeNID
		END ELSE 
		BEGIN
		  SELECT TOP 1 @PPAddr=ISNULL(p.SHIPTONAME,'')+ISNULL(p.SHIPTOCOUNTRYNAME,'')+ISNULL(p.SHIPTOSTATE,'')+
   							   ISNULL(p.SHIPTOCITY,'')+ISNULL(p.SHIPTOSTREET,'')+ISNULL(p.SHIPTOSTREET2,'')+ ISNULL(p.SHIPTOZIP,'')  
   		  FROM P_trade p
   		  WHERE p.NID = @TradeNID
		END
	    
		SET @PPAddr = LOWER(REPLACE(@PPAddr,' ',''));
   		IF EXISTS(SELECT 1 
				  FROM P_trade WHERE NID = @TradeNID)
		BEGIN 
		  IF (@eBayAddr <> @PPAddr) 
   			UPDATE  P_Trade SET  BUSINESS = 1 WHERE nid= @TradeNID
   		  ELSE 
   	  		UPDATE  P_Trade SET  BUSINESS = 0 WHERE nid= @TradeNID 
		END ELSE 
		BEGIN
		 IF (@eBayAddr <> @PPAddr) 
   			UPDATE  P_TradeUn SET  BUSINESS = 1 WHERE nid= @TradeNID
   		 ELSE 
   	  		UPDATE  P_TradeUn SET  BUSINESS = 0 WHERE nid= @TradeNID 	
		ENd
    --判断地址是否是 空,eBay无地址
    if @eBayAddrNull=''  
    begin
   	  	UPDATE  P_Trade SET  BUSINESS = '2' WHERE (ADDRESSOWNER not  in ('aliexpress','amazon11')) and  nid= @TradeNID     
    end		
  ENd 	
END

