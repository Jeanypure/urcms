create proc [dbo].[P_XS_DaysSendPackageAndSKUTotal]
	@BeginDate	varchar(10) = '',
	@EndDate	Varchar(10)= '',	
	@SalerAliasName VARCHAR(50)=''
AS
BEGIN
	CREATE TABLE #SendHistory
	( SendDay varchar(10), 
	  SendPackageCount INT, 
	  SendCount NUMERIC(10,2),
	  SendSKUCount NUMERIC(10,2),
	  eBayShipped INT DEFAULT 0,
	  eBayUnShipped INT DEFAULT 0,
	)
	
	
	INSERT INTO #SendHistory
	SELECT CONVERT(varchar(10),pt.CLOSINGDATE,121), 1,ISNULL(pt.MULTIITEM,0), ISNULL(pt.SALESTAX,0), ISNULL(pt.SHIPPINGMETHOD,0),0
	FROM P_Trade pt 
	WHERE  (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)			
			AND (ISNULL(@SalerAliasName,'') = '' OR pt.SUFFIX = @SalerAliasName)
			and pt.FilterFlag = 100
	
	INSERT INTO #SendHistory
	SELECT CONVERT(varchar(10),pt.CLOSINGDATE,121), 1,ISNULL(pt.MULTIITEM,0), ISNULL(pt.SALESTAX,0), ISNULL(pt.SHIPPINGMETHOD,0),0
	FROM P_Trade_His pt 
	WHERE  (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)			
			AND (ISNULL(@SalerAliasName,'') = '' OR pt.SUFFIX = @SalerAliasName)    

    SELECT SendDay, COUNT(eBayShipped) AS eBayShipped
    INTO #eBayShipped
    FROM #SendHistory
    WHERE eBayShipped = 1
    GROUP BY SendDay 

    SELECT SendDay, COUNT(eBayShipped) AS eBayUnShipped
    INTO #eBayUnShipped
    FROM #SendHistory
    WHERE eBayShipped = 0
    GROUP BY SendDay 
   
   
	SELECT pt.SendDay AS '发货日期'
	       ,sum(pt.SendPackageCount)  AS '发货包裹数量'
	       ,Sum(pt.SendCount) AS '商品发货总数' 
	       ,sum(pt.SendSKUCount) AS '发货SKU个数'
	       ,MAX(es.eBayShipped) AS '标记eBay成功包裹数'
	       ,max(isnull(eus.eBayUnShipped,0)) AS '标记eBay失败包裹数'
	INTO #temp 
	FROM #SendHistory pt left outer JOIN #eBayShipped  es ON pt.SendDay = es.SendDay
	                     left outer JOIN #eBayUnShipped  eus ON pt.SendDay = eus.SendDay 
	GROUP BY pt.SendDay
	ORDER BY pt.SendDay
	SELECT * FROM #temp 
	
	DROP TABLE #eBayShipped
	DROP TABLE #eBayUnShipped
	DROP TABLE #temp
	DROP TABLE #SendHistory
END
