CREATE PROCEDURE [dbo].[P_XS_DaysSendPackageBySellerAccount]
	@BeginDate	varchar(10) = '',
	@EndDate	Varchar(10)= ''
AS
BEGIN
	CREATE TABLE #SendHistory
	( SendDay DATETIME, 
	  SendPackageCount INT, 
	  SendPackageMoney NUMERIC(18,4),
	  SUFFIX VARCHAR(100),
	)
	
	
	INSERT INTO #SendHistory
	SELECT CONVERT(varchar(10),pt.CLOSINGDATE,121), 1,ISNULL(pt.AMT,0),pt.SUFFIX
	FROM P_Trade pt 
	WHERE  (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)			
			

	INSERT INTO #SendHistory
	SELECT CONVERT(varchar(10),pt.CLOSINGDATE,121), 1,ISNULL(pt.AMT,0),pt.SUFFIX
	FROM P_Trade_His pt 
	WHERE  (CONVERT(varchar(10),pt.CLOSINGDATE,121) BETWEEN @BeginDate and @endDate)	   
   
	SELECT pt.SendDay AS '发货日期'
	       ,sum(pt.SendPackageCount)  AS '数量'
	       ,SUM(pt.SendPackageMoney) AS '金额'
	       ,pt.SUFFIX AS '卖家简称'
	INTO #temp 
	FROM #SendHistory pt 
	GROUP BY pt.SendDay,pt.SUFFIX
	ORDER BY pt.SendDay,sum(pt.SendPackageCount) DESC ,pt.SUFFIX
	SELECT * FROM #temp 
	
	DROP TABLE #temp
	DROP TABLE #SendHistory
END
