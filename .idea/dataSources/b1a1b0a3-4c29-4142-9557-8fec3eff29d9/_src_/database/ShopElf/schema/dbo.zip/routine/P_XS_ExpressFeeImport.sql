
CREATE PROCEDURE [P_XS_ExpressFeeImport] @NID VARCHAR(100) = '',
                                       @ExpressFee NUMERIC(10,4) = 0, 
                                       @Ack VARCHAR(100) = ''
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE 
	   @ReturnStr VARCHAR(500) = '',
	   @TempNid varchar(100) = ''
	   
	set @TempNid = @NID 
	if (LEN(@NID) >= 9) begin
	  set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade where TrackNo = @NID),'0')
	  if @TempNid = '0' begin
	    set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade_His where TrackNo = @NID),'0')
	  end
	end
	if ((@TempNid = '') or (@TempNid = '0')) and (@Ack<>'') begin
	  set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade where Ack = @Ack),'0')
	  if @TempNid = '0' begin
	    set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade_His where Ack = @Ack),'0')
	  end
	end
 
 
	  IF EXISTS(SELECT 1 FROM P_Trade WHERE NID = @TempNid) 
			or EXISTS(SELECT 1 FROM P_Trade_His WHERE NID = @TempNid)      
		  BEGIN
	  		UPDATE P_Trade	SET ExpressFare = @ExpressFee  	WHERE NID = @TempNid
	  		UPDATE P_Trade_His	SET ExpressFare = @ExpressFee  	WHERE NID = @TempNid	  
	  		SET @ReturnStr = '订单编号:"'+@TempNid +'"的运费导入成功!'		
		  END ELSE
		  BEGIN
	  		SET @ReturnStr = '订单编号或跟踪号:"'+@NID +'"未找到，导入失败!'	
		  END	
 
 
	
	SELECT @ReturnStr AS ReturnStr, @TempNid as Nid
END

