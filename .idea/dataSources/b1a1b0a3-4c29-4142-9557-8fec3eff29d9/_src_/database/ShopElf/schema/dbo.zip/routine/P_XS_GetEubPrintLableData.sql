
CREATE PROCEDURE [dbo].[P_XS_GetEubPrintLableData] @CK1loWay VARCHAR(1000) = '', @4PXloWay VARCHAR(1000) = ''
AS
BEGIN
	DECLARE @MinTradeNID INT, @sSQLCmd VARCHAR(8000) = ''
	
	CREATE TABLE #CK1(loNID INT NOT NULL DEFAULT 0) 
	CREATE TABLE #4PX(loNID INT NOT NULL DEFAULT 0) 
	
    IF ISNULL(@CK1loWay,'') <> ''
    BEGIN
      SET @sSQLCmd = ' insert into #CK1 '+' select ' + REPLACE(@CK1loWay,';',' union all select ')
      EXEC(@sSQLCmd)
    END 
    IF ISNULL(@4PXloWay,'') <> ''
    BEGIN
	  SET @sSQLCmd = ' insert into #4PX '+' select ' + REPLACE(@4PXloWay,';',' union all select ')
      EXEC(@sSQLCmd)
    END 
        
	SET @MinTradeNID = (SELECT min(pt.NID) 
						FROM P_Trade pt INNER JOIN B_LogisticWay blw ON pt.logicsWayNID = blw.NID
						WHERE pt.FilterFlag >5 AND pt.FilterFlag < 100 AND ISNULL(pt.TrackNo,'') <> '')
	--E邮宝      
	SELECT pt.NID AS TradeNid, pt.TrackNo, isnull(pt.[User],pt.SUFFIX) AS eBayUserID , 1 AS loType 
	FROM P_Trade pt INNER JOIN B_LogisticWay blw ON pt.logicsWayNID = blw.NID
	WHERE ISNULL(blw.EUB,0) =1 AND  pt.FilterFlag >5 AND pt.FilterFlag < 100 AND ISNULL(pt.TrackNo,'') <> '' AND 
	      pt.NID NOT IN ( SELECT TradeNID 
	                      FROM P_AutoGetEubPrintLable 
	                      WHERE TradeNID >= @MinTradeNID AND ((ISNULL(IsSuccess,0) = 1) or (ISNULL(SyncCount,0) > 3)))
    UNION 
    --出口易
    SELECT pt.NID AS TradeNid, pt.TrackNo, pt.[User] AS eBayUserID , 2 AS loType 
	FROM P_Trade pt join #CK1 ck1 on ISNULL(pt.logicsWayNID,0) = ck1.loNID
	WHERE --ISNULL(pt.logicsWayNID,0) IN (SELECT loNID FROM #CK1) AND  
	         pt.FilterFlag >=20 AND pt.FilterFlag < 100 AND ISNULL(pt.TrackNo,'') <> '' AND 
	      pt.NID NOT IN ( SELECT TradeNID 
	                      FROM P_AutoGetEubPrintLable 
	                      WHERE TradeNID >= @MinTradeNID AND ((ISNULL(IsSuccess,0) = 1) or (ISNULL(SyncCount,0) > 3)))
	--UNION 
 --   --4PX
 --   SELECT pt.NID AS TradeNid, pt.TrackNo, pt.[User] AS eBayUserID , 3 AS loType 
	--FROM P_Trade pt
	--WHERE ISNULL(pt.logicsWayNID,0) IN (SELECT loNID FROM #4PX) AND  pt.FilterFlag >5 AND pt.FilterFlag < 100 AND ISNULL(pt.TrackNo,'') <> '' AND 
	--      pt.NID NOT IN ( SELECT TradeNID 
	--                      FROM P_AutoGetEubPrintLable 
	--                      WHERE TradeNID >= @MinTradeNID AND ((ISNULL(IsSuccess,0) = 1) or (ISNULL(SyncCount,0) > 3)))
    DROP TABLE #CK1
    DROP TABLE #4PX	
END

