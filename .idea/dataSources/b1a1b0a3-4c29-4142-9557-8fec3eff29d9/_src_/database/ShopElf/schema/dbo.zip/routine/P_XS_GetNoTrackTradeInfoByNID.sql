
CREATE proc [dbo].[P_XS_GetNoTrackTradeInfoByNID]
	@TradeNId int=0,
	@EubFlag  int=0/*0是E邮宝*/
as
begin
	if @EubFlag=0  /*E邮宝*/
	begin
		SELECt  
			m.NID,m.ADDRESSOWNER,m.logicsWayNID,m.EMAIL,
			m.suffix,l.servicecode,m.[User],
			m.SHIPTONAME,m.SHIPTOSTREET,
			m.SHIPTOSTREET2,m.SHIPTOCITY,m.SHIPTOSTATE,m.SHIPTOZIP,m.SHIPTOCOUNTRYCODE,
			m.SHIPTOCOUNTRYNAME,m.SHIPTOPHONENUM,m.BUYERID as  PAYERID,m.ORDERTIME,m.ACK,
			l.code as logicsWayCode,m.TotalWeight,
			m.trackno,
			(select top 1 EbayTOKEN from S_PalSyncInfo where EbayUserID=m.[user] and SyncModuleName = 'trades') as token,
			(select top 1 SyncEubEnable from S_PalSyncInfo where EbayUserID=m.[user] and SyncModuleName = 'trades') as SyncEUBFlag,
			(select top 1 lr.CarrierEN from B_LogisticWayReg lr where lr.LogisticWayNID=m.logicsWayNID and lr.[Platform]='trades') as carrier
		FROM P_Trade(nolock) m 
		LEFT outer JOIN B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB=1
		where
			m.NID=@TradeNID and 
			m.FilterFlag = 6 and 
			isnull(m.TrackNo,'')=''
	end
	else
	begin
		SELECt  
			m.NID,m.ADDRESSOWNER,m.logicsWayNID,m.EMAIL,
			m.suffix,l.servicecode,m.[User],
			m.SHIPTONAME,m.SHIPTOSTREET,
			m.SHIPTOSTREET2,m.SHIPTOCITY,m.SHIPTOSTATE,m.SHIPTOZIP,m.SHIPTOCOUNTRYCODE,
			m.SHIPTOCOUNTRYNAME,m.SHIPTOPHONENUM,m.BUYERID as  PAYERID,m.ORDERTIME,m.ACK,
			l.code as logicsWayCode,m.TotalWeight,
			isnull(l.eub,0) as eub,
			m.trackno,m.CURRENCYCODE,DoorPlate,BUYERID,
			
			(select top 1 lr.CarrierEN from B_LogisticWayReg lr where lr.LogisticWayNID=m.logicsWayNID and lr.[Platform]='trades') as carrier
		FROM P_Trade(nolock) m 
		LEFT outer JOIN B_LogisticWay l on l.nid=m.logicsWayNID
		where
			m.NID=@TradeNID and 
			m.FilterFlag = 6 and 
			isnull(m.TrackNo,'')=''
	end
end


