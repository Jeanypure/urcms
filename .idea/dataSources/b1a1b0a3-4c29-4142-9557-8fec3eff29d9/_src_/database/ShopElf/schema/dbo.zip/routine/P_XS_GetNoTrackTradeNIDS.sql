 --exec P_XS_GetNoTrackTradeNIDS '300,269,259,182,0'
CREATE proc [P_XS_GetNoTrackTradeNIDS]
	@LogicNIDS varchar(8000)
as
begin
	declare @sql varchar(8000)
	set @sql = 'select 	m.NID,	m.logicsWayNID '+
	'from  '+
		'p_trade(nolock) m  '+
	'where  '+
		'm.FilterFlag = 6 and m.logicsWayNID in ( '+@LogicNIDS+' ) and '+
		'isnull(TrackNo,'''')='''' and  '+
		'isnull(ADDRESSOWNER,'''')<>''''  '
	exec (@sql)
	
end

