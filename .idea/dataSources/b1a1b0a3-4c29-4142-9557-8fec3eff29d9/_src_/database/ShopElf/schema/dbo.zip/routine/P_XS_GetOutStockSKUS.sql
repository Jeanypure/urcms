--待派单缺货生成采购显示一条记录问题，物流费分摊前单价不显示问题
CREATE proc [dbo].[P_XS_GetOutStockSKUS] @TradeNids VARCHAR(Max) = '' , @MyType smallint = 0,@StoreID varchar(100)=''
AS
BEGIN
    --@MyType 0：表示查询待派单的缺货订单 1：表示查询带包装的缺货订单
	set nocount on 
	CREATE TABLE #SelRecordTable
	(
		TradeNid INT NOT NULL DEFAULT 0,
	) 
	SET @TradeNids = REPLACE(@TradeNids,')','')
	SET @TradeNids = REPLACE(@TradeNids,'(','')
    DECLARE @sSQLCmd varchar(MAx) = '', @temp varchar(20) = '', @index int = 0, @NumFlag varchar(10)
    SET @sSQLCmd = 'insert into #SelRecordTable select ';
    while (PATINDEX('%,%', @TradeNids) > 0)
    begin
      set @index = PATINDEX('%,%', @TradeNids) - 1
      set @temp = SubString(@TradeNids,1,@index) 
      set @TradeNids = SUBSTRING(@TradeNids,@index+2,LEN(@TradeNids)- @index+2) 
     
      --if (LEN(@sSQLCmd)> 7500)
      --begin
      --  EXEC(@sSQLCmd)
      --  SET @sSQLCmd = 'insert into #SelRecordTable select ';
      --end 
      --else 
      --begin 
        if (len(@sSQLCmd) > 35)
        begin         
         SET @sSQLCmd = @sSQLCmd + ' union select ' + @temp 
        end else
        begin
          SET @sSQLCmd = @sSQLCmd + @temp 
        end         
      --end      
    end 
    if (len(@sSQLCmd) > 35)
    EXEC(@sSQLCmd)
    SET @sSQLCmd = 'insert into #SelRecordTable select '+@TradeNids;
    EXEC(@sSQLCmd)
    
    
    CREATE TABLE #GetPurBillData
	(
		SKU VARCHAR(1000)  DEFAULT '',
		GoodsSKUID INT  DEFAULT 0,
		L_QTY NUMERIC(10,2)  DEFAULT 0,
	) 
	
		--提取显示数据 0 查询带派单的缺货信息 1 查询带包装的缺货信息
		if (@MyType = 0) 
		begin
		  INSERT INTO #GetPurBillData(SKU,GoodsSKUID,L_QTY)
		  SELECT SKU , isnull(GoodsSKUID,0), SUM(L_QTY) AS L_QTY
		  FROM P_TradeDtUn ptd JOIN #SelRecordTable srt ON ptd.TradeNID = srt.TradeNid
		  GROUP BY  isnull(GoodsSKUID,0),SKU
		end
		else begin
		  INSERT INTO #GetPurBillData(SKU,GoodsSKUID,L_QTY)
		  SELECT SKU , isnull(GoodsSKUID,0),  SUM(L_QTY) AS L_QTY
		  FROM P_TradeDt ptd JOIN #SelRecordTable srt ON ptd.TradeNID = srt.TradeNid
		  join P_Trade pt on pt.NID = ptd.TradeNID and pt.FilterFlag = 26
		  GROUP BY  isnull(GoodsSKUID,0),SKU
		end
		
	
		CREATE TABLE #CgBillNumber(	GoodsSKUID		int,
										BillNumber	varchar(50),
										cgAmount	Float default 0,									
										InAmount	Float default 0)
										
	   CREATE TABLE #StockOrderCount(GoodsSKUID VARCHAR(100) DEFAULT '' ,
										cgAmount	Float default 0,									
										InAmount	Float default 0 )       
   insert into  #CgBillNumber (GoodsSKUID,billnumber,cgAmount,InAmount)    
    SELECT csod.GoodsSKUID,csom.billnumber, sum(csod.Amount),sum(csod.InAmount)-isnull((select SUM(isnull(id.amount,0)) from CG_StockInD id 
					  inner join CG_StockInM im on im.NID=id.StockInNID where 
	 id.GoodsSKUID= csod.GoodsSKUID and im.StockOrder=csom.Billnumber and im.CheckFlag=0 ),0)
    FROM  CG_StockOrderD csod 
    inner join  CG_StockOrderM csom  ON csom.NID = csod.StockOrderNID
    inner join  #GetPurBillData g on g.GoodsSKUID=csod.GoodsSKUID 
    WHERE csom.CheckFlag = 1 and csom.archive=0	--and csod.InAmount<csod.Amount 
    group by csod.GoodsSKUID,csom.billnumber,csom.StoreID
     
  insert into  #StockOrderCount (GoodsSKUID,cgAmount,InAmount)    
    SELECT GoodsSKUID, sum(cgAmount),sum(InAmount)
    FROM  #CgBillNumber 
    group by GoodsSKUID  
       
  DELETE FROM #StockOrderCount WHERE ISNULL(cgAmount,0) <= ISNULL(InAmount,0)   
  
  set @NumFlag = '0'
  select @NumFlag = IsNull(ParaValue,'0') from B_SysParams where ParaCode = 'TradeUnToCGStockWishNum'
                           
	--8.查询					
	SELECT distinct 
	    0 AS SelFlag,  		gs.SKU,		    gs.property1,		gs.property2,		gs.property3,
		b.BarCode,		    b.goodscode,	b.goodsname,		b.model,		    b.unit,
		b.class,	     	b.maxnum,		b.minnum,		    b.SupplierID,		p.SupplierName,
		s.storeName,		d.StoreID,		d.GoodsID,		   g.GoodsSKUID,		d.Number,
		d.ReservationNum,	CurrentNum=0,	SaleNum=g.L_QTY,   
		 NotInStockNum=isnull(sc.cgAmount,0)-isnull(sc.InAmount,0),	
		case when gs.CostPrice<>0 then gs.CostPrice else b.CostPrice end as price,
		case when isnull(gs.maxnum,0)=0 then g.L_QTY else isnull(gs.maxnum,0)-(isnull(d.Number,0)-isnull(d.ReservationNum,0))-(isnull(sc.cgAmount,0)-isnull(sc.InAmount,0)) end AS Amount_Tmp, 
		--modify by ylq 2015-06-17   --以订单数量为准 
		g.L_QTY as Amount,  
		--end modify 
		b.MinPrice, 
		p.[Address],
		p.OfficePhone,
		p.Mobile,
		b.BmpFileName, 
		isnull(b.PackageCount,0) PackageCount,
		b.GoodsStatus,      
		'' AS LocationName,
		gs.Weight, b.StockMinAmount,
		gs.SKUName ,
		gs.sellcount1,gs.SellCount2,gs.sellcount3
	INTO #Temp	 
	FROM #GetPurBillData g 				
	                       left outer JOIN KC_CurrentStock D ON g.GoodsSKUID = d.GoodsSKUID	
	                       left outer join #StockOrderCount sc on sc.GoodsSKUID=g.GoodsSKUID 
							left  outer JOIN B_Store s         ON s.NID = d.StoreID	                       
	                       LEFT   outer JOIN B_GoodsSKU gs    ON gs.NID = g.GoodsSKUID				
	                       LEFT   outer JOIN B_Goods b        ON b.NID = gs.GoodsID	
	                       LEFT   outer JOIN  B_Supplier p     ON p.NID=b.SupplierID
	WHERE /*ISNULL(b.used,0) = 0 AND*/
	   ISNULL(b.GoodsCode,'') <> '' and (D.StoreID is Null or D.StoreID= @StoreID)
	   -- modify by ylq 2015-06-16  过滤掉，订单是多少就是多少
       --modify by ylq 2015-09-28  小俞的客户要求了， 还是要按缺货数量来统计，已经好几次了，那就再改回来，以后就以这为准 
       --modify by ylq 2015-10-22  根据参数配置来了，想按订单按订单，按库存按库存	
     	and ((@NumFlag = 1) or ((d.Number-d.ReservationNum)+(isnull(sc.cgAmount,0)-isnull(sc.InAmount,0))-g.L_QTY <=0))  
    
    SELECT * FROM #Temp


	DROP TABLE #Temp
END
