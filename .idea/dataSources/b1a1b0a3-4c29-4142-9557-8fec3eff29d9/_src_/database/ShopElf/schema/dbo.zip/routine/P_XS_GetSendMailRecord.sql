/****************************************/
/*获取ebay标记发货成功，未发送发货通知的记录*/
/******************cuifeng***************/
/****************************************/
CREATE proc [dbo].[P_XS_GetSendMailRecord]
AS
BEGIN
	DECLARE @SyncShippedType INT, @IsSyncOutStockOrder INT ,@SyncFaildCount INT, @InMonth INT,@BeginDate DATETIME
	SELECT 
		TOP 1 @SyncShippedType = ISNULL(SyncShippedType,1)
           ,@IsSyncOutStockOrder =  ISNULL(IsSyncOutStockOrder,0) 
           ,@SyncFaildCount = ISNULL(SyncFaildCount,0) 
           ,@InMonth = ISNULL(InMonth,0)    
    FROM P_AutoSyncShppedBaseSet
    
    --SET @BeginDate = DATEADD(MONTH,-@InMonth,GETDATE())
    SET @BeginDate = DATEADD(DAY,-2,GETDATE())
	select top 2000               --正常表
		a.OrderID,
		p.[user] as SellerID,
		p.EMAIL,
		l.code as logicCode,
		l.SendNote,
		l.URL,
		l.emailTemplate,
		l.emailSubject,
		p.firstname + ' ' + p.LASTNAME AS Customername,
		p.trackno,
		p.AllGoodsDetail,
		p.SHIPTONAME,
		p.SHIPTOSTREET,
		p.SHIPTOSTREET2,
		p.SHIPTOCITY,
		p.SHIPTOSTATE,
		p.SHIPTOZIP,
		p.SHIPTOCOUNTRYNAME,
		p.TRANSACTIONID,
		p.BUYERID,
		p.ack			
	from 
		P_AutoSyncShipped(nolock) a
	inner join
		P_Trade(nolock) p on p.NID=a.OrderID
	left outer join 
		B_LogisticWay l on l.NID=p.logicsWayNID
	where 
		SyncLastDate > @BeginDate
		and SyncLastDate < GETDATE()
		and IsSuccess=1 and SendMailSuccess=0
		and SendMailCount<@SyncFaildCount
    union
    select top 2000           --异常表
		a.OrderID,
		p.[user] as SellerID,
		p.EMAIL,
		l.code as logicCode,
		l.SendNote,
		l.URL,
		l.emailTemplate,
		l.emailSubject,
		p.firstname + ' ' + p.LASTNAME AS Customername,
		p.trackno,
		p.AllGoodsDetail,
		p.SHIPTONAME,
		p.SHIPTOSTREET,
		p.SHIPTOSTREET2,
		p.SHIPTOCITY,
		p.SHIPTOSTATE,
		p.SHIPTOZIP,
		p.SHIPTOCOUNTRYNAME,
		p.TRANSACTIONID,
		p.BUYERID,
		p.ack			
	from 
		P_AutoSyncShipped(nolock) a
	inner join
		P_Tradeun(nolock) p on p.NID=a.OrderID
	left outer join 
		B_LogisticWay l on l.NID=p.logicsWayNID
	where 
		SyncLastDate > @BeginDate
		and SyncLastDate < GETDATE()
		and IsSuccess=1 and SendMailSuccess=0
		and SendMailCount<@SyncFaildCount	
	    union
    select top 2000          --历史表
		a.OrderID,
		p.[user] as SellerID,
		p.EMAIL,
		l.code as logicCode,
		l.SendNote,
		l.URL,
		l.emailTemplate,
		l.emailSubject,
		p.firstname + ' ' + p.LASTNAME AS Customername,
		p.trackno,
		p.AllGoodsDetail,
		p.SHIPTONAME,
		p.SHIPTOSTREET,
		p.SHIPTOSTREET2,
		p.SHIPTOCITY,
		p.SHIPTOSTATE,
		p.SHIPTOZIP,
		p.SHIPTOCOUNTRYNAME,
		p.TRANSACTIONID,
		p.BUYERID,
		p.ack			
	from 
		P_AutoSyncShipped(nolock) a
	inner join
		P_Trade_his(nolock) p on p.NID=a.OrderID
	left outer join 
		B_LogisticWay l on l.NID=p.logicsWayNID
	where 
		SyncLastDate > @BeginDate
		and SyncLastDate < GETDATE()
		and IsSuccess=1 and SendMailSuccess=0
		and SendMailCount<@SyncFaildCount		
    		
		
END

