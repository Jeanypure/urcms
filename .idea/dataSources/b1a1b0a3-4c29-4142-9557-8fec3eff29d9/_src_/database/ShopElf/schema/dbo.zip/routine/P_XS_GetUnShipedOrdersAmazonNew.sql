create   Proc [P_XS_GetUnShipedOrdersAmazonNew]
	@qhFlag varchar(2)='0',
	@pdFlag varchar(2)='0',
	@bzFlag varchar(2)='0',
	@wfhFlag varchar(2)='0',
	@yfhFlag varchar(2)='0',
	@sellerID varchar(50),
	@iSendHour integer=0,
	@iSendHourTrackNo integer=0,
	@MarketId  varchar(50)=''
as
begin
	declare @fHour integer
	if @iSendHour > @iSendHourTrackNo 
		set @fHour= @iSendHour
	else
		set @fHour= @iSendHourTrackNo
    --条件判断的时间设置		
	set @fHour=@fHour+8
	--有跟踪号或无跟踪号的调节时间如果小于等于0，那么变成1，防止标记发货的时间等于发货时间
	if @iSendHourTrackNo <= 0 
	  set @iSendHourTrackNo = 1
	if @iSendHour <= 0
	  set @iSendHour = 1  
	--最后都加上时差8小时   
    set @iSendHourTrackNo=@iSendHourTrackNo+8
	set @iSendHour = @iSendHour +8 
	declare 
		@fSql  varchar(Max);
	set @fSql='';
	if @qhFlag='1' --缺货 
	begin		
		set @fSql = 
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			
		' from p_tradeUn(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user] and s.AliasName=t.SUFFIX '    +
		'  where t.FilterFlag=1 and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+				
				' and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
				' and CHARINDEX(''AFN '',t.custom)=0 '+
				--' and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo , '+
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +
		' from p_tradeUn(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.FilterFlag=1 and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=1 ' +
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
			'  and t.AdditionalCharge <4 ' ;			
	end			
	if @pdFlag='1' --派单后 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE'+
		' from p_trade(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  '    +
		'  where ( t.FilterFlag =6)  '+	 
				' and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
				'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
				' and CHARINDEX(''AFN '',t.custom)=0 '+			
				--'  and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+				
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  '+
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			 
		' from p_trade(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=1 ' +
				' and ( t.FilterFlag =6)  '+		
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+			
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' ;			
	end			
	if @bzFlag='1' --包装 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE'+
		' from p_trade(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  '    +
		'  where ( t.FilterFlag >= 20 and t.FilterFlag < 40)  '+	 
				' and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
				'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
				' and CHARINDEX(''AFN '',t.custom)=0 '+			
				--'  and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+				
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  '+
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			 
		' from p_trade(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=1 ' +
				' and (t.FilterFlag >= 20 and t.FilterFlag < 40)  '+		
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+			
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' ;		

	end
	if @wfhFlag='1' -- 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE'+
		' from p_trade(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  '    +
		'  where (t.FilterFlag=40)  '+	 
				' and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
				'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
				' and CHARINDEX(''AFN '',t.custom)=0 '+			
				--'  and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+				
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo , '+
		' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			 
		' from p_trade(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=1 ' +
				' and ( t.FilterFlag=40)  '+		
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+			
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' ;	

	end
	if @yfhFlag='1' --已发货及归档 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE'+
		' from p_trade(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  '    +
		'  where t.FilterFlag=100  '+	 
				' and t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
				'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
				--'  and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+				
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo , '+
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			 
		' from p_trade(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeFlag,0)=1 ' +
				' and t.FilterFlag=100  '+		
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+			
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+
		' select ' +
			' distinct top 2000 hNID=0, t.nid,t.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  ' +
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE'+
		' from p_trade_his(nolock) t  ' +
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID  '+
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  '    +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeBillID,0)=0  '+
				--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
				' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+
				'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
				' and CHARINDEX(''AFN '',t.custom)=0 '+			
				--'  and isnull(l.code,'''')<>'''' ' +
				'  and LEN(t.trackno)=datalength(t.trackno) ' + -- 取消汉字
				'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
				'  and  t.[User]=' +''''+ @sellerID +'''' + 
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
				'  and t.AdditionalCharge <4 ' +
		' union '+				
		' select distinct top 2000 hNID=t.nid,b.nid,b.TRANSACTIONID,t.logicsWayNID,l.ServiceCode,l.code,l.name,t.TrackNo,  '+
			' case when t.TrackNo<>'''' then DATEadd(hh,' + cast(@iSendHourTrackNo as varchar(10))+',t.ORDERTIME) else  DATEadd(hh,' + cast(@iSendHour as varchar(10))+',t.ORDERTIME) end as sendtime ' + 
			',t.AdditionalCharge as SyncCount,t.CLOSINGDATE' +			 
		' from p_trade_his(nolock) t   ' +
		' inner join P_Trade_b(nolock) b on b.MergeBillID=t.NID '+
		' left outer join B_LogisticWay l on l.NID=t.logicsWayNID   ' +
		'  left outer join S_AmazonSyncInfo s on s.SellerId=t.[user]  and s.AliasName=t.SUFFIX  ' +
		'  where t.ADDRESSOWNER=''amazon11''  and isnull(t.MergeBillID,0)=1 ' +	
			--'  and DATEadd(hh,' + cast(@fHour as varchar(10)) + ',t.ORDERTIME)<GETDATE() ' +
			' and DATEDIFF(dd,t.ORDERTIME,getdate())<15 '+			
			'  and isnull(t.SHIPPINGMETHOD,'''')=''0'' ' +
			' and CHARINDEX(''AFN '',t.custom)=0 '+			
			--'  and isnull(l.code,'''')<>'''' ' +
			'  and LEN(t.trackno)=datalength(t.trackno) ' + 
			'  and (isnull(t.TIMESTAMP,'''')<>'''' ) ' + 
			'  and  t.[User]=' + ''''+ @sellerID +'''' +
				'  and s.MarketplaceId='+''''+ @MarketId +'''' +
			'  and t.AdditionalCharge <4 ' ;
	end
	if @fSql<>''
	begin
	    exec(@fSql)	;	
	end
	else
	begin
	  select '1 as Msg';
	end
end
