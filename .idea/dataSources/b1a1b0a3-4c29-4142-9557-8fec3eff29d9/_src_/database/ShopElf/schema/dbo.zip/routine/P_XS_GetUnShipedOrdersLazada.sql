--P_XS_GetUnShipedOrdersLazada '1','1','1','1','1'
create Proc [dbo].[P_XS_GetUnShipedOrdersLazada]
	@qhFlag varchar(2)='0',
	@pdFlag varchar(2)='0',
	@bzFlag varchar(2)='0',
	@wfhFlag varchar(2)='0',
	@yfhFlag varchar(2)='0'
as
begin
	declare 
		@fSql  varchar(max);
	set @fSql='';
	if @qhFlag='1' --缺货 
	begin
	  set @fSql = 
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+			
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+			
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+						
		'from  P_TradeUn(nolock) p   '+	
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+				
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=0  '+
				'and p.FilterFlag=1   '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0''  '+
		' union '+	
		' select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+		
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+			
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+						
		'from  P_TradeUn(nolock) p   '+	
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+	
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+				
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=1  '+
				'and p.FilterFlag=1   '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0''  ';				
	end
	if @pdFlag='1' --派单后 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p  '+
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=0  '+
				'and ( p.FilterFlag = 6)  '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0'' ' +
		' union ' +
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+	
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p  '+
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+			
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=1  '+
				'and ( p.FilterFlag = 6)  '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0'' ';				
	end
	if @bzFlag='1' --包装 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p  '+
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=0  '+
				'and (p.FilterFlag >= 20 and p.FilterFlag < 40)  '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				'  and p.SHIPPINGMETHOD=''0'' '+
		' union '+
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+	
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p  '+
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+			
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=1  '+
				'and (p.FilterFlag >= 20 and p.FilterFlag < 40) '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				'  and p.SHIPPINGMETHOD=''0'' ';				
	end
	if @wfhFlag='1' -- 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select distinct top 5000 '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p '+
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=0  '+
				'and p.FilterFlag=40 '+
				'  and p.ADDRESSOWNER=''lazada''  '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0''  '+
		' union ' +
		'select distinct top 5000 '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+	
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p '+
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+			
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=1  '+
				'and p.FilterFlag=40 '+
				'  and p.ADDRESSOWNER=''lazada''  '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0''  ';		
	end
	if @yfhFlag='1' --已发货及归档 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select distinct top 5000 '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p   '+
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=0  '+
				'and p.FilterFlag=100  '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				'  and p.SHIPPINGMETHOD=''0''  '+
		'union ' +		
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeBillID,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			' 0 as NIDb,'+
			'p.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade_His(nolock) p '+
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeBillID,0)=0 '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0'' '+
		' union ' +
		'select distinct top 5000 '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+	
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade(nolock) p   '+
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+			
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeFlag,0)=1  '+
				'and p.FilterFlag=100  '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				'  and p.SHIPPINGMETHOD=''0''  '+
		'union ' +		
		'select distinct top 5000 '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeBillID,0) as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'b.nid as NIDb,'+	
			'b.ack, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.URL,'''') as URL, '+				
			'isnull(l.SendNote,'''') as SendNote, '+
			'isnull(s.WebSite,'''') as WebSite, '+				
			'isnull(s.APIKey,'''') as APIKey, '+
			'isnull(s.UserID,'''') as UserID '+	
		'from P_Trade_His(nolock) p '+
		'inner join   P_Trade_b b on  b.MergeBillID=p.NID   '+			
		'inner join S_LazadaSyncInfo s on s.UserID=p.[user]  and s.AliasName =p.SUFFIX  '+			
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<15  and isnull(p.MergeBillID,0)=1 '+
				' and p.ADDRESSOWNER=''lazada'' '+
				' and isnull(p.trackno,'''')<>'''' '+					
				' and p.SHIPPINGMETHOD=''0'' ';					
	end
	if @fSql<>''
	begin
		set @fSql = @fSql + ' order by p.OrderTime desc '
	    exec(@fSql)	;	
	end
	else
	begin
	  select '1 as Msg';
	end
end
