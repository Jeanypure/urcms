
CREATE Proc [dbo].[P_XS_GetUnShipedOrdersLazadaDt]
	@MergeFlag int,
	@TradeNid int
as
begin
	--if @MergeFlag=0 
	--	begin
		select 
			L_NUMBER
		from 
			P_TradeDt 
		where 
			TradeNID=@TradeNid and isnull(L_NUMBER,'') <> '' 
		union
		select 
			L_NUMBER
		from 
			P_TradeDt_His
		where 
			TradeNID=@TradeNid	and isnull(L_NUMBER,'') <> ''
		union
		select 
			L_NUMBER
		from 
			P_TradeDtUn 
		where 
			TradeNID=@TradeNid	and isnull(L_NUMBER,'') <> ''	
	--end	
	--else
	--begin
	--	select 
	--		L_NUMBER
	--	from 
	--		P_Trade_bdt
	--	where 
	--		TradeNID=@TradeNid	and isnull(L_NUMBER,'') <> ''
	
	--end
end
