--P_XS_GetUnShipedOrdersMagento '1','1','1','1','1'
create Proc [dbo].[P_XS_GetUnShipedOrdersMagento]
	@qhFlag varchar(2)='0',
	@pdFlag varchar(2)='0',
	@bzFlag varchar(2)='0',
	@wfhFlag varchar(2)='0',
	@yfhFlag varchar(2)='0'
as
begin
	declare 
		@fSql  varchar(max);
	set @fSql='';
	if @qhFlag='1' --缺货 
	begin
	  set @fSql = 
		'select '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_TradeUn(nolock) p  '+
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30  '+
				'and p.FilterFlag=1   '+
				' and p.ADDRESSOWNER=''magento'' '+
				' and   p.SHIPPINGMETHOD=''0''  ';
	end
	if @pdFlag='1' --派单后 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_Trade(nolock) p  '+
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30  '+
				'and ( p.FilterFlag = 6)  '+
				' and p.ADDRESSOWNER=''magento'' '+
				' and p.SHIPPINGMETHOD=''0'' ';
	end
	if @bzFlag='1' --包装 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeFlag,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_Trade(nolock) p  '+
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30  '+
				'and (p.FilterFlag >= 20 and p.FilterFlag < 40) '+
				' and p.ADDRESSOWNER=''magento'' '+
				'  and p.SHIPPINGMETHOD=''0'' ';
	end
	if @wfhFlag='1' -- 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_Trade(nolock) p  '+
		'left outer join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30  '+
				'and p.FilterFlag=40 '+
				'  and p.ADDRESSOWNER=''magento''  '+
				' and p.SHIPPINGMETHOD=''0''  ';
	end
	if @yfhFlag='1' --已发货及归档 
	begin
	  if @fSql<> ''
	    set @fSql = @fSql + ' union ';
	  set @fSql = @fSql +
		'select '+
			'p.ordertime,'+
			'p.TrackNo, '+
			'isnull(p.MergeFlag,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_Trade(nolock) p  '+
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30  '+
				'and p.FilterFlag=100  '+
				' and p.ADDRESSOWNER=''magento'' '+
				'  and p.SHIPPINGMETHOD=''0''  '+
		'union ' +		
		'select '+
			'p.ordertime,'+		
			'p.TrackNo, '+
			'isnull(p.MergeBillID,''0'') as MergeFlag, '+
			'p.SUFFIX, '+
			'p.logicsWayNID,'+			
			'p.NID, '+
			'p.ACK, '+
			'isnull(p.AdditionalCharge,0) as syncCount,'+			
			'isnull(l.ServiceCode,'''') as ServiceCode, '+
			'isnull(l.code,'''') as logicsWayCode, '+
			'isnull(l.SendNote,'''') as SendNote '+
		'from P_Trade_his(nolock) p  '+
		'left outer  join B_LogisticWay l on l.NID=p.logicsWayNID '+
		'where DATEDIFF(dd,p.ORDERTIME,getdate())<30 '+
				' and p.ADDRESSOWNER=''magento'' '+
				' and p.SHIPPINGMETHOD=''0'' ';		
	end
	if @fSql<>''
	begin
		set @fSql = @fSql + ' order by p.OrderTime desc '
	    exec(@fSql)	;	
	end
	else
	begin
	  select '1 as Msg';
	end
end

