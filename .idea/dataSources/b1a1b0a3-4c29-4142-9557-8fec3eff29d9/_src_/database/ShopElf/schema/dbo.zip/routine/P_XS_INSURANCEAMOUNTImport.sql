create PROCEDURE [dbo].[P_XS_INSURANCEAMOUNTImport] @NID VARCHAR(100) = '',
                                       @INSURANCEAMOUNT VARCHAR(100) = ''	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ReturnStr VARCHAR(500) = ''
	
	
	IF (LEN(@NID) < 9)
	BEGIN
	  if ISNUMERIC(@Nid) = 0 begin
	    SET @ReturnStr = '导入的订单号"' + @Nid + '"不是数字型,无法导入';	
	  end
	  else begin 
		  IF EXISTS(SELECT 1  FROM P_Trade WHERE NID = @NID  union 
			 SELECT 1  FROM P_Trade_His WHERE TrackNo = @NID 
			 )
		  BEGIN
	  		UPDATE P_Trade	SET INSURANCEAMOUNT = @INSURANCEAMOUNT  	WHERE NID = @NID	  
	  		UPDATE P_Trade_His	SET INSURANCEAMOUNT = @INSURANCEAMOUNT  	WHERE NID = @NID	  
		  	
	  		SET @ReturnStr = '订单"'+@NID +'"的包装费导入成功!'		
		  END ELSE
		  BEGIN
	  		SET @ReturnStr = '订单"'+@NID +'"未找到，导入失败!'	
		  END
	  end 
	END ELSE
	BEGIN
	  IF EXISTS(SELECT 1  FROM P_Trade WHERE TrackNo = @NID  union 
	       SELECT 1  FROM P_Trade_His WHERE TrackNo = @NID 
	     )
	  BEGIN
	  	UPDATE P_Trade	SET INSURANCEAMOUNT = @INSURANCEAMOUNT  	WHERE TrackNo = @NID	  
    	UPDATE P_Trade_His	SET INSURANCEAMOUNT = @INSURANCEAMOUNT  	WHERE TrackNo = @NID	  

	  	SET @ReturnStr = '订单"'+@NID +'"的包装费导入成功!'		
	  END ELSE
	  BEGIN
	  	SET @ReturnStr = '订单"'+@NID +'"未找到，导入失败!'	
	  END	
	END
	SELECT @ReturnStr AS ReturnStr
END
