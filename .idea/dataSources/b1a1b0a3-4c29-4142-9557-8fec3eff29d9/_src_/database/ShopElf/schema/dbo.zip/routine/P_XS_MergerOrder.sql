CREATE proc [P_XS_MergerOrder]
	@TradeNIDS	varchar(Max),
	@CurUserName	varchar(50)
as
begin
	DECLARE @TradeNids_Bak  VARCHAR(max) = ''
	DECLARE @InStore  VARCHAR(32) = ''
	
	SET @TradeNids_Bak = @TradeNids
	set @TradeNIDS = '0,'+@TradeNIDS+',0'
	CREATE TABLE #MergeTradeNIDS
	(
		TradeNid INT NOT NULL DEFAULT 0
	) 
	create Table #t
	(
		Maxbillcode varchar(100)
	)	
    --简化一下订单号的插入代码 陈卫
    DECLARE @sSQLCmd varchar(max) = '';
	select @sSQLCmd =  'insert into #MergeTradeNIDS(TradeNid) select ' +	REPLACE(@TradeNIDS,',',' union select ');
	--select @sSQLCmd;
	
    EXEC(@sSQLCmd);
    
    ----判断记录是否存在，如果不存在，退出   更改为:
    --检查待合并的订单数量,订单不存在,或者只传入1个存在的订单号则不能合并  陈卫
	if (select COUNT(nid) from P_Trade where NID in ( select tradenid from #MergeTradeNIDS)) <= 1
	begin
		select ReturnMsg='订单不存在,或者待合并的订单个数必须大于1个！',TradeNID=0;
		return;     
	end;
	
	 -- add by ylq 2015-06-26  检查仓库是否一致
	select @InStore = ISNULL(ParaValue,'0') from B_SysParams where ParaCode = 'MergerInStore'
	if @InStore = '1' begin 
		if (select count(*) from (select StoreID from P_TradeDt
			 where TradeNID in ( select tradenid from #MergeTradeNIDS)
			 group by StoreID ) A )> 1
		begin
		  select ReturnMsg='待合并订单的细表仓库数量有多个，不允许合并!',TradeNID=0;
		  return;   
		end
	end 
    -- end add 
     
    	
	--检查是否合并过  陈卫
	if exists (select nid from P_Trade where NID in ( select tradenid from #MergeTradeNIDS) and isnull(MergeFlag,0) = 1)
	begin
		select ReturnMsg='已合并过的订单,先拆分后再进行合并！',TradeNID=0;
		return;     
	end;
	
	--检查是否符合 合并规则,防止随意传入订单导致合并混乱 陈卫
	declare 
		@MergeOrder  int=0
	set
		@MergeOrder=isnull((select paravalue from B_SysParams where ParaCode='MergeOrder'),0)
	if 	@MergeOrder=0 
	begin
		if (select count(*) from  (SELECT  isnull(BUYERID,'') as BUYERID,SHIPTOCOUNTRYCODE,isnull(SHIPTOSTATE,'') as SHIPTOSTATE ,isnull(SHIPTOCITY,'') as SHIPTOCITY,SHIPTOSTREET,SHIPTONAME ,[User],isnull(ADDRESSOWNER,'') as addressowner
				FROM P_Trade WHERE  FilterFlag=5  and NID in  ( select tradenid from #MergeTradeNIDS)
					GROUP BY isnull(BUYERID,''),SHIPTOCOUNTRYCODE,isnull(SHIPTOSTATE,''),isnull(SHIPTOCITY,''),SHIPTOSTREET,SHIPTONAME ,[User],isnull(ADDRESSOWNER,'')) as a) <> 1
		begin
			select ReturnMsg='买家id或收货人地址信息不一致或不同的eBay账号订单，不能进行合并!',TradeNID=0;
			return;     	
		end;	
	end
	else
	begin
		if (select count(*) from  (SELECT  isnull(BUYERID,'') as BUYERID,SHIPTOCOUNTRYCODE,isnull(SHIPTOSTATE,'') as SHIPTOSTATE ,isnull(SHIPTOCITY,'') as SHIPTOCITY,SHIPTOSTREET,SHIPTONAME ,isnull(ADDRESSOWNER,'') as addressowner
				FROM P_Trade WHERE  FilterFlag=5  and NID in  ( select tradenid from #MergeTradeNIDS)
					GROUP BY isnull(BUYERID,''),SHIPTOCOUNTRYCODE,isnull(SHIPTOSTATE,''),isnull(SHIPTOCITY,''),SHIPTOSTREET,SHIPTONAME ,isnull(ADDRESSOWNER,'')) as a) <> 1
		begin
			select ReturnMsg='买家id或收货人地址信息不一致,不能进行合并!',TradeNID=0;
			return;     	
		end;	
	end
	   
	--检查最大合并重量的判断
	declare 
		@MergerMaxWeight  float
	set
		@MergerMaxWeight=isnull((select paravalue from B_SysParams where ParaCode='MergerMaxWeight'),0)
	if @MergerMaxWeight > 0 
	begin
	  if (select SUM(d.weight) from p_tradedt d inner join p_trade m on m.nid = d.tradenid
	     where m.FilterFlag=5  and m.NID in  (select tradenid from #MergeTradeNIDS)) > @MergerMaxWeight
	  begin
	    select ReturnMsg='合并后的重量超过 ' + CAST(@MergerMaxWeight as varchar(50)) + ' 公斤，不能进行合并!',TradeNID=0;
		return;  
	  end   
	end
	   
    --生成唯一ID
    Declare 
		@TradeGuid varchar(50)='' ,
		@TradeNId integer =0
	set
		@TradeGuid = isnull((select NEWID()),'')
	if len(@TradeGuid)>10
	  set @TradeGuid = '{'+@TradeGuid+'}' 
	  
	SET IDENTITY_INSERT  P_trade OFF 
	insert into p_trade(Guid) values(@TradeGuid)
	set @TradeNId=(select isnull(NID,99999999) from p_trade where [guid]=@TradeGuid)
	if @TradeNId=99999999 
	begin
		select ReturnMsg='生成合并主表Guid出错，请确认！',TradeNID=0
		return 
	end
	DECLARE 
		@BillNumber VARCHAR(50)
	insert into #t 
	EXEC  P_S_CodeRuleGet 150 , @BillNumber OUTPUT
	IF (IsNull(@BillNumber,'') = '')
	begin
		SET  @BillNumber = CONVERT(VARCHAR(30), GETDATE(), 120)
	end
	BEGIN TRAN MergerOrder
	 DECLARE @ins_error int = 0  
	INSERT INTO 
	P_Trade_b([NID],[RECEIVERBUSINESS],[RECEIVEREMAIL],[RECEIVERID],[EMAIL],[PAYERID],[PAYERSTATUS],[COUNTRYCODE],[PAYERBUSINESS],
	[SALUTATION],[FIRSTNAME],[MIDDLENAME],[LASTNAME],[SUFFIX],[ADDRESSOWNER],[ADDRESSSTATUS],
	[SHIPTONAME],[SHIPTOSTREET],[SHIPTOSTREET2],[SHIPTOCITY],[SHIPTOSTATE],[SHIPTOZIP],[SHIPTOCOUNTRYCODE],
	[SHIPTOCOUNTRYNAME],[SHIPTOPHONENUM],[TRANSACTIONID],[PARENTTRANSACTIONID],[RECEIPTID],
	[TRANSACTIONTYPE],[PAYMENTTYPE],[ORDERTIME],[AMT],[CURRENCYCODE],[FEEAMT],[SETTLEAMT],[TAXAMT],
	[EXCHANGERATE],[PAYMENTSTATUS],[PENDINGREASON],[REASONCODE],[PROTECTIONELIGIBILITY],[PROTECTIONELIGIBILITYTYPE],
	[INVNUM],[CUSTOM],[NOTE],[SALESTAX],[BUYERID],[CLOSINGDATE],[MULTIITEM],[TIMESTAMP],[SHIPDISCOUNT],[INSURANCEAMOUNT],
	[CORRELATIONID],[ACK],[VERSION],[BUILD],[SHIPPINGAMT],[HANDLINGAMT],[SHIPPINGMETHOD],[SHIPAMOUNT],[SHIPHANDLEAMOUNT],
	[SUBJECT],[EXPECTEDECHECKCLEARDATE],[Guid],[BUSINESS],[User],[TotalWeight],[ExpressNID],[ExpressFare],[logicsWayNID],
	[SelFlag],[TrackNo],[ExpressFare_Close],[ExpressStatus],[EvaluateStatus],[TransMail],[FilterFlag],[PrintFlag],
	[ShippingStatus],[MergeBillID],[Memo],[AdditionalCharge],[InsuranceFee],[AllGoodsDetail],[CheckOrder],[GoodItemIDs],
	[goodscosts],[ProfitMoney],[doorplate]) 
	SELECT  
	[NID],[RECEIVERBUSINESS],[RECEIVEREMAIL],[RECEIVERID],[EMAIL],[PAYERID],[PAYERSTATUS],[COUNTRYCODE],[PAYERBUSINESS],[SALUTATION],
	[FIRSTNAME],[MIDDLENAME],[LASTNAME],[SUFFIX],[ADDRESSOWNER],[ADDRESSSTATUS],[SHIPTONAME],[SHIPTOSTREET],
	[SHIPTOSTREET2],[SHIPTOCITY],[SHIPTOSTATE],[SHIPTOZIP],[SHIPTOCOUNTRYCODE],[SHIPTOCOUNTRYNAME],[SHIPTOPHONENUM],
	[TRANSACTIONID],[PARENTTRANSACTIONID],[RECEIPTID],[TRANSACTIONTYPE],[PAYMENTTYPE],[ORDERTIME],[AMT],[CURRENCYCODE],
	[FEEAMT],[SETTLEAMT],[TAXAMT],[EXCHANGERATE],[PAYMENTSTATUS],[PENDINGREASON],[REASONCODE],[PROTECTIONELIGIBILITY],
	[PROTECTIONELIGIBILITYTYPE],[INVNUM],[CUSTOM],[NOTE],[SALESTAX],[BUYERID],[CLOSINGDATE],[MULTIITEM],[TIMESTAMP],[SHIPDISCOUNT],
	[INSURANCEAMOUNT],[CORRELATIONID],[ACK],[VERSION],[BUILD],[SHIPPINGAMT],[HANDLINGAMT],[SHIPPINGMETHOD],[SHIPAMOUNT],
	[SHIPHANDLEAMOUNT],[SUBJECT],[EXPECTEDECHECKCLEARDATE],[Guid],[BUSINESS],[User],[TotalWeight],[ExpressNID],[ExpressFare],
	[logicsWayNID],[SelFlag],[TrackNo],[ExpressFare_Close],[ExpressStatus],[EvaluateStatus],[TransMail],[FilterFlag],[PrintFlag],
	[ShippingStatus],[MergeFlag],[Memo],[AdditionalCharge],[InsuranceFee],[AllGoodsDetail],[CheckOrder],[GoodItemIDs] ,
	[goodscosts],[ProfitMoney],[doorplate]
	FROM P_Trade WHERE nid IN ( select tradenid from #MergeTradeNIDS)

	 set @ins_error=@@Error 
	 
	 INSERT INTO P_Trade_bDt([NID],[TradeNID],[L_EBAYITEMTXNID],[L_NAME],[L_NUMBER],[L_QTY],[L_SHIPPINGAMT],[L_HANDLINGAMT],
	 [L_CURRENCYCODE],[L_AMT],[L_OPTIONSNAME],[L_OPTIONSVALUE],[L_TAXAMT],[SKU],[CostPrice],[AliasCnName],[AliasEnName],
	 [Weight],[DeclaredValue],[OriginCountry],[OriginCountryCode],[BmpFileName],[eBaySKU],[GoodsName],
	 [L_ShipFee],[L_TransFee],[L_ExpressFare],[BuyerNote],[GoodsSKUID],[StoreID]) 
	 SELECT  [NID],[TradeNID],[L_EBAYITEMTXNID],[L_NAME],[L_NUMBER],[L_QTY],[L_SHIPPINGAMT],[L_HANDLINGAMT],[L_CURRENCYCODE],
	 [L_AMT],[L_OPTIONSNAME],[L_OPTIONSVALUE],[L_TAXAMT],[SKU],[CostPrice],[AliasCnName],[AliasEnName],
	 [Weight],[DeclaredValue],[OriginCountry],[OriginCountryCode],[BmpFileName],[eBaySKU],[GoodsName],
	 [L_ShipFee],[L_TransFee],[L_ExpressFare],[BuyerNote],[GoodsSKUID],[StoreID]
	 FROM P_TradeDt WHERE  tradenid IN ( select tradenid from #MergeTradeNIDS)
	 
	 set @ins_error= @ins_error + @@Error  
	if @ins_error<>0 
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '插入备份表出错！',TradeNID=0
		return
	end	  	 
    delete  from p_trade where nid =@TradeNId 
	set @ins_error= @ins_error + @@Error  
	if @ins_error<>0
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '删除新主表（后面插入记录使用）出错！',TradeNID=0
		return
	end	 
    delete  from p_trade where nid IN ( select tradenid from #MergeTradeNIDS)
	set @ins_error= @ins_error + @@Error  
	if @ins_error<>0
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '删除原主表出错！',TradeNID=0
		return
	end	 			 
	--更新合并表的ID
	update 
		p_trade_b  
	set 
		MergeBillID = @TradeNId 
	where  
		nid in ( select tradenid from #MergeTradeNIDS) 
	set @ins_error= @ins_error + @@Error  
	if @ins_error<>0
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '更新备份表MergeBillId出错！',TradeNID=0
		return
	end	
	SET IDENTITY_INSERT P_trade ON  
	insert into P_trade(NID,RECEIVERBUSINESS,RECEIVEREMAIL,RECEIVERID,EMAIL,PAYERID,PAYERSTATUS,COUNTRYCODE,PAYERBUSINESS,
		SALUTATION,FIRSTNAME,MIDDLENAME,LASTNAME,SUFFIX,ADDRESSOWNER,ADDRESSSTATUS,SHIPTONAME,SHIPTOSTREET,SHIPTOSTREET2,
		SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,PARENTTRANSACTIONID,
		RECEIPTID,TRANSACTIONTYPE,PAYMENTTYPE,ORDERTIME,AMT,CURRENCYCODE,FEEAMT,SETTLEAMT,TAXAMT,EXCHANGERATE,PAYMENTSTATUS,
		PENDINGREASON,REASONCODE,PROTECTIONELIGIBILITY,PROTECTIONELIGIBILITYTYPE,INVNUM,CUSTOM,NOTE,SALESTAX,BUYERID,CLOSINGDATE,
		TIMESTAMP,SHIPDISCOUNT,INSURANCEAMOUNT,CORRELATIONID,ACK,VERSION,BUILD,SHIPPINGAMT,HANDLINGAMT,SHIPPINGMETHOD,
		SHIPAMOUNT,SHIPHANDLEAMOUNT,SUBJECT,EXPECTEDECHECKCLEARDATE,Guid,BUSINESS,[User],TotalWeight,ExpressNID,ExpressFare,
		logicsWayNID,SelFlag,TrackNo,ExpressFare_Close,ExpressStatus,EvaluateStatus,TransMail,FilterFlag,PrintFlag,ShippingStatus,
		MergeFlag,BatchNum)  
	Select @TradeNId as nid,Max(RECEIVERBUSINESS),Max(RECEIVEREMAIL), Max(RECEIVERID),
		Max(EMAIL),Max(PAYERID),Max(PAYERSTATUS),Max(COUNTRYCODE),Max(PAYERBUSINESS),Max(SALUTATION),Max(FIRSTNAME),Max(MIDDLENAME),
		Max(LASTNAME),Max(SUFFIX),Max(ADDRESSOWNER),Max(ADDRESSSTATUS), Max(SHIPTONAME),Max(SHIPTOSTREET),Max(SHIPTOSTREET2),
		Max(SHIPTOCITY),Max(SHIPTOSTATE),Max(SHIPTOZIP),Max(SHIPTOCOUNTRYCODE),Max(SHIPTOCOUNTRYNAME),Max(SHIPTOPHONENUM),
		@TradeNId as TRANSACTIONID,Max(PARENTTRANSACTIONID),Max(RECEIPTID),Max(TRANSACTIONTYPE),Max(PAYMENTTYPE),Max(ORDERTIME),
		sum(AMT),Max(CURRENCYCODE),sum(FEEAMT),sum(SETTLEAMT),sum(TAXAMT),Max(EXCHANGERATE),Max(PAYMENTSTATUS),Max(PENDINGREASON),
		Max(REASONCODE),Max(PROTECTIONELIGIBILITY), Max(PROTECTIONELIGIBILITYTYPE),Max(INVNUM),Max(CUSTOM),'' as NOTE,sum(SALESTAX),
		Max(BUYERID),Min(CLOSINGDATE),Max(TIMESTAMP),sum(SHIPDISCOUNT),sum(INSURANCEAMOUNT),Max(CORRELATIONID),Max(ACK), 
		Max(VERSION),Max(BUILD),sum(SHIPPINGAMT),sum(HANDLINGAMT),min(isnull(SHIPPINGMETHOD,'0')),Max(SHIPAMOUNT),Max(SHIPHANDLEAMOUNT),
		'' as SUBJECT,Max(EXPECTEDECHECKCLEARDATE), Max(Guid),Max(BUSINESS),Max([User]),sum(TotalWeight) as TotalWeight,  0 as ExpressNID,
		0 as ExpressFare,0 as logicsWayNID ,Max(SelFlag),'' as TrackNo,0 as ExpressFare_Close,0 as ExpressStatus, 0 as EvaluateStatus ,
		0 as TransMail,5 as FilterFlag ,0 as PrintFlag , Max(ShippingStatus),1 as MergeFlag,@BillNumber
	 
	 from P_trade_b where isnull(MergeBillID,0) = @TradeNId and nid in ( select tradenid from #MergeTradeNIDS)
	 
	 set @ins_error= @ins_error + @@Error
	  -- 店铺单号更新一下 对应账号
	 update m
     set m.ack=case when ISNULL( b.ACK,'')<>'' then b.ACK else m.ACK end
     from P_Trade m
     left join P_Trade_b b on m.NID=b.MergeBillID and m.SUFFIX=b.SUFFIX
      where m.NID=@TradeNId
     set @ins_error= @ins_error + @@Error   	 
	if @ins_error<>0
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '生成新合并记录出错！',TradeNID=0
		return
	end		
	 update  
		p_tradedt set tradenid=@TradeNId 
	 where 
		tradenid in ( select tradenid from #MergeTradeNIDS)  
		 and tradenid in (select nid from P_trade_b where isnull(MergeBillID,0) = @TradeNId )
		 	 
	 if (select SUM(reccount) from ( 
			select 1 as reccount   from  P_trade_b where nid in ( 
					select tradenid from #MergeTradeNIDS)  group by CURRENCYCODE
				) as aa)>=2 
	 begin 
		UPDATE 
			P_trade 
		SET 
			AMT = dbo.Ex_GetUSD(@TradeNId), 
			FEEAMT = dbo.Ex_GetFeeAMTUSD(@TradeNId),
			CURRENCYCODE = 'USD' 
		WHERE NID =@TradeNId
		set @ins_error= @ins_error + @@Error  
-------------update USD- start-----
        --update p_tradedt
		DECLARE @ExchangeRate float = 0
		SET @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 		IF @ExchangeRate=0
 		  SET 	@ExchangeRate=1	
 		update 
 			d   		
 		set
 			L_AMT=L_AMT*c.ExchangeRate/@ExchangeRate,
 			L_CURRENCYCODE='USD'
 		from 
 			P_tradedt d
 		inner join 
 			B_CurrencyCode c on c.CURRENCYCODE=d.L_CURRENCYCODE
 		where 
 			TradeNID=@TradeNId
-------------update USD  end----------------				
	 end  
		 
	 set @ins_error= @ins_error + @@Error 
	if @ins_error<>0
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '更新附表TradeNID出错！',TradeNID=0
		return
	end		  	 
	 exec P_KC_AutoLinkGoodsSkuMsg @TradeNId 
	 set @ins_error= @ins_error + @@Error  	 
	 update 
		pt
	 set 
		pt.AllGoodsDetail=substring(convert(text,dbo.Ex_GetOrderSKUS(pt.NID)) ,1,8000),
		pt.NOTE = substring(convert(text,dbo.Ex_GetMergeOrderNotes(pt.nid)) ,1,4000),
		pt.[subject] = substring(convert(text,dbo.Ex_GetMergeOrderSubjects(pt.nid)),1,4000),
		pt.Memo  = '[合]'+ substring(convert(text,dbo.Ex_GetMergeOrderMemos(pt.nid)),1,3996),
		pt.PARENTTRANSACTIONID=dbo.Ex_GetMergeOrderPARENTTRANSACTIONIDs(pt.nid),
		pt.GoodItemIDs = substring(convert(text,dbo.Ex_GetMergeOrderItemIDS(pt.nid)),1,4000),							
		pt.TotalWeight=dbo.Ex_GetOrderWeights(pt.NID) ,
		pt.MULTIITEM  = ISNULL((SELECT SUM(ptd.L_QTY) 
							  FROM P_TradeDt ptd 
							  WHERE TradeNID = pt.NID),0),
		pt.SALESTAX  =  isnull((select sum(1) from (
					select sku from P_TradeDt 
					where TradeNID=pt.NID group by sku
					) as aa),0)	
	from 
		p_trade pt		 
	 where 
		pt.nid= @TradeNId
	
	 set @ins_error= @ins_error + @@Error 
		if @ins_error<>0
		begin
			rollback Tran MergerOrder
			select ReturnMsg= '更新合并出错备注等内容出错',TradeNID=0
			return
		end		 
	 declare
		@Users varchar(8000)='',
		@Acks	varchar(8000)='',
		@Logs	varchar(500)=''

	select	@Users=dbo.Ex_GetMergeOrderUsers(@TradeNId),
			@Acks =dbo.Ex_GetMergeOrderAcks(@TradeNId)	
	set
		@Logs = substring('合并为新订单,合并订单号：'+@TradeNids_Bak+'--'+@Users+'--'+@acks,1,500)	
			
	EXEC S_WriteTradeLogs @TradeNId,@Logs,@CurUserName
	-- select @ins_error= @ins_error + @@Error 	


	if @ins_error=0 
	begin
		commit tran MergerOrder 
		select ReturnMsg= '',TradeNID=@TradeNId
	end	
	else 
	begin
		rollback Tran MergerOrder
		select ReturnMsg= '合并出错，订单号：'+@TradeNIDS,TradeNID=0
	end	 
	--合并后计算仓库,算成本及利润
	begin try
	     exec P_FR_CalcLogicWay @TradeNID
			UPDATE pt
			SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.nid),0),
				pt.ExpressFare= isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0) 
			FROM P_Trade pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNId
				    
			UPDATE pt
			SET 
				pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-pt.GoodsCosts-
				ExpressFare),0)
			FROM P_Trade pt
			left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
			WHERE pt.NID = @TradeNId	
	END TRY
	BEGIN CATCH
	END CATCH				
		 
end
