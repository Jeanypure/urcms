CREATE proc [dbo].[P_XS_SaleAfterAppendData] 
	@tradenid int=0,
	@SaleAfternid int=0
as
begin
	Declare 
		@SKUS varchar(4000), @eBaySKus varchar(4000)
		
	set
		@SKUS=(select dbo.Ex_GetSaleAfterOrderSKUS(@SaleAfternid,0))
		
	set @eBaySKus= (select dbo.Ex_GetSaleAfterOrderSKUS(@SaleAfternid,1))
	
  select  m.ORDERTIME,m.CLOSINGDATE,m.SHIPTOCOUNTRYNAME,ISNULL(bl.name,'')+',[跟踪号]:'+ISNULL(m.TrackNo,'') as logicsWayNameAndNo,SALUTATION,PAYMENTTYPE,ack
   into #temp from 
 (select ORDERTIME,CLOSINGDATE,logicsWayNID,TrackNo,SHIPTOCOUNTRYNAME,SALUTATION,PAYMENTTYPE,ack 
   from   P_Trade m 
   where m.NID=@tradenid
   union
   select ORDERTIME,CLOSINGDATE,logicsWayNID,TrackNo,SHIPTOCOUNTRYNAME ,SALUTATION,PAYMENTTYPE,ack
   from   P_Trade_His  m 
   where m.NID=@tradenid
   union 
   select ORDERTIME,CLOSINGDATE,logicsWayNID,TrackNo,SHIPTOCOUNTRYNAME,SALUTATION,PAYMENTTYPE,ack 
   from   P_TradeUn  m 
   where m.NID=@tradenid
   union
   select ORDERTIME,CLOSINGDATE,logicsWayNID,TrackNo,SHIPTOCOUNTRYNAME,SALUTATION,PAYMENTTYPE,ack 
   from   P_TradeUn_His  m 
   where m.NID=@tradenid
   ) as  m
   left join B_LogisticWay bl on bl.NID=m.logicsWayNID
   
   update XS set XS.ORDERTIME=(select top 1 ORDERTIME from #temp),
				 XS.CLOSINGDATE=(select top 1 CLOSINGDATE from #temp),
				 XS.logicsWayNameAndNo=(select top 1 logicsWayNameAndNo from #temp),
				 XS.SHIPTOCOUNTRYNAME=(select top 1  SHIPTOCOUNTRYNAME from #temp),
				 xs.SALUTATION=(select top 1  SALUTATION from #temp),
				 xs.PAYMENTTYPE=(select top 1  PAYMENTTYPE from #temp),
				 xs.ack=(select top 1  ack from #temp),
				 XS.SKU=@SKUS,
				 XS.eBaySku = @eBaySKus  
		from XS_SaleAfterM XS	
		where XS.NID=@SaleAfternid		
 drop table #temp
end
