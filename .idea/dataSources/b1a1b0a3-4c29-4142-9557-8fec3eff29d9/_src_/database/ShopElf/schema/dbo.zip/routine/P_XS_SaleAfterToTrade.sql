
CREATE proc [dbo].[P_XS_SaleAfterToTrade] 
	@SaleAfterNID int=0,
	@OldTradeNID int=0,
	@CurrentUser varchar(50)
as
begin
  declare @y table (tableID int)
		Declare 
			@insError int=0,
			@ADDRESSOWNER varchar(10)=''
			
	    begin tran SaleAterToTrade
	    --先查询原有订单的地址所有者
	    if @OldTradeNID <> 0 
	    begin
	      set @ADDRESSOWNER = (select top 1 isnull(ADDRESSOWNER,'') 
	                           from (select ADDRESSOWNER from P_trade where NID = @OldTradeNID
                                     union all select ADDRESSOWNER from P_tradeun where NID = @OldTradeNID
                                     union all select ADDRESSOWNER from P_Trade_His where NID = @OldTradeNID) aa
                               order by isnull(ADDRESSOWNER,'') desc) 
	    end
	    --如果地址所有者为空，那么用 saleafter 代替
	    if @ADDRESSOWNER = '' 
	      set @ADDRESSOWNER = 'saleafter'
	    
		insert into P_trade (SHIPPINGMETHOD,VERSION,TRANSACTIONID,memo,[User],BUYERID,
				SUFFIX,SALUTATION,ORDERTIME,AMT,ADDRESSOWNER,
				CURRENCYCODE,FilterFlag,SHIPPINGAMT,PAYMENTSTATUS,
				SHIPTONAME,SHIPTOSTATE,SHIPTOCITY,SHIPTOSTREET,
				SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,
				SHIPTOSTREET2,SHIPTOZIP,SHIPTOPHONENUM,
				COUNTRYCODE,
				EMAIL,RECEIVERBUSINESS,[Guid],
				Ack,RECEIVEREMAIL,CUSTOM 	
				) output inserted.NID into @y	
		select 
		     '1', -- 重寄单默认已发货
		     k.VERSION,
		     A.NID,  
			'售后单重寄转派单 重寄类型:'+a.SaleTag++' 售后内容:'+substring(A.Memo,1,3800), 
			ISNULL(k.[User],
			isnull((select Top 1  eBayUserID from S_PalSyncInfo where NoteName = A.UserName),'')--,店铺名称取配置中的昵称 , 
				+ isnull((select Top 1  ShopName from S_TaoBaoSyncInfo where NickName = A.UserName),'')
				+ isnull((select Top 1  SellerId from S_AmazonSyncInfo where AliasName = A.UserName),'')
			),				
			buyid, 
			UserName, 
			'售后', 
			convert(varchar(30),DATEADD(hh,-8,MakeDate),121),  
			--amt=(select sum(ISNULL(Money,0)) from XS_SaleAfterD where SaleAfterNID=XS_SaleAfterM.NID), 
			SaleMoney,  
			@ADDRESSOWNER, 
			A.CurrencyCode,
			5,
			SaleMoney, 
		    'Completed',
			A.ShipToName, 
			A.ShipToState,
			A.ShiptoCity,
			SHipToStreet1,
			A.ShipToCountryCode,
			ShipToCountry, 
			A.ShipToStreet2, 
			A.Shiptozip,
			A.ShipToPhonenum,
			A.ShipToCountryCode,
			BuyerEMail,
			SellerEMail ,
			A.NID,
			k.ACK,k.RECEIVEREMAIL,k.CUSTOM 
			
		from 
			XS_SaleAfterM A
			left join (select top 1 * from 
			           (select top 1 NID,ACK,RECEIVEREMAIL,CUSTOM,[User],VERSION from P_Trade where Nid = @OldTradeNID
			           union 
			           select top 1 NID,ACK,RECEIVEREMAIL,CUSTOM,[User],VERSION from P_Trade_his where Nid = @OldTradeNID
			           union 
			           select top 1 NID,ACK,RECEIVEREMAIL,CUSTOM,[User],VERSION from P_Tradeun where Nid = @OldTradeNID
			           ) x ) k
			  on k.NID = A.OrderNumber
		where
			A.NID = @SaleAfterNID
		
		set @insError=@insError+@@ERROR	
		
		DECLARE @TradeNID INT 
		select  @TradeNid = (select top 1 tableID from @y)
		
		if @OldTradeNID=0 
		begin
			insert into P_TradeDt(TradeNID,SKU,eBaySKU,L_NAME,L_NUMBER,L_QTY,GoodsSKUID,
						L_AMT,L_CURRENCYCODE,L_EBAYITEMTXNID,OriginCountry,OriginCountryCode)
			select @Tradenid,gs.SKU,gs.SKU,g.GoodsName,'',d.Amount,d.GoodsSKUID,
					d.[Money],isnull((select top 1 CurrencyCode from XS_SaleAfterM where NID =@SaleAfterNID),''),
					'','China','CN' 
			from XS_SaleAfterD d
			left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			left outer join B_Goods g on gs.GoodsID=g.nid		
			where SaleAfterNID=@SaleAfterNID	
		
		end
		else
		begin --取原有订单的信息
			insert into P_TradeDt(TradeNID,SKU,eBaySKU,L_NAME,L_NUMBER,L_QTY,GoodsSKUID,
						L_AMT,L_CURRENCYCODE,L_EBAYITEMTXNID,OriginCountry,OriginCountryCode)
			select @Tradenid,d.SKU,d.eBaySKU,g.GoodsName,'',d.Amount,d.goodsskuId,
					d.[Money],isnull((select top 1 CurrencyCode from XS_SaleAfterM where NID =@SaleAfterNID),''),
					'','China','CN' 
			from XS_SaleAfterD d
			left outer join B_GoodsSKU gs on gs.NID=d.GoodsSKUID
			left outer join B_Goods g on gs.GoodsID=g.nid		
			where SaleAfterNID=@SaleAfterNID	
		    set @insError=@insError+@@ERROR	
		    if Exists(select nid from P_Trade where NID=@OldTradeNID)
		    begin
				update d
					set d.sku=dt.SKU,
						d.ebaysku=dt.eBaySKU,
						d.L_EBAYITEMTXNID=dt.L_EBAYITEMTXNID,
						d.L_NUMBER=dt.L_NUMBER,
						d.L_NAME=dt.L_NAME
				from 
					P_TradeDt d
				inner join P_TradeDt dt on dt.TradeNID=@OldTradeNID and d.SKU=dt.SKU
				where 
					d.TradeNID=@TradeNID
				set @insError=@insError+@@ERROR	
				-- 更新卖家平台id,不然重寄单无法和正常单合并
				update P_Trade set [User]=case when isnull((select [USER] from P_Trade where NID=@OldTradeNID),'')<>''
				then (select [USER] from P_Trade where NID=@OldTradeNID) else [user] end
				where NID=@TradeNID
		    end
		    else --历史订单
		    begin
				update d
					set d.sku=dt.SKU,
						d.ebaysku=dt.eBaySKU,
						d.L_EBAYITEMTXNID=dt.L_EBAYITEMTXNID,
						d.L_NUMBER=dt.L_NUMBER,
						d.L_NAME=dt.L_NAME
				from 
					P_TradeDt d
				inner join P_TradeDt_his dt on dt.TradeNID=@OldTradeNID and d.SKU=dt.SKU
				where 
					d.TradeNID=@TradeNID
				set @insError=@insError+@@ERROR	
				-- 更新卖家平台id,不然重寄单无法和正常单合并
				update P_Trade_His set [User]=case when isnull((select [USER] from P_Trade_His where NID=@OldTradeNID),'')<>''
				then (select [USER] from P_Trade_His where NID=@OldTradeNID) else [user] end
				where NID=@TradeNID		    
		    end		
				
		end
		
		set @insError=@insError+@@ERROR
		
		Exec P_XS_TradeDtSKU @TradeNID	
		set @insError=@insError+@@ERROR	
		
		if @insError=0 
		begin
		  update XS_SaleAfterM set NewTradeNID=@TradeNID,CompleteFlag = 1 where NID=@SaleAfterNID
		  update P_trade set TAXAMT=@TradeNID where NID=@OldTradeNID	
		  update P_Trade_His set TAXAMT=@TradeNID where NID=@OldTradeNID
		  -- P_XS_TradeDtSKU 里面包含了生成交易费FEEAMT 这里重新清零 rjf 20160831 修改	
		  update P_Trade set FEEAMT=0,SHIPDISCOUNT=0 where NID=@TradeNID		  	  
		  insert into P_TradeLogs(TradeNID,Operator,Logs)
		  values(@TradeNID,@CurrentUser,@CurrentUser+' ' + CONVERT(varchar(20), GETDATE(),121)+' 售后单重寄转派单')
		  -- 原订单也插入一条日志
		  insert into P_TradeLogs(TradeNID,Operator,Logs)
		  values(@OldTradeNID,@CurrentUser,@CurrentUser+' ' + CONVERT(varchar(20), GETDATE(),121)+' 已生成售后单重寄转派单')
		  
		  
		  commit tran SaleAterToTrade
		end  
		else
		  rollback tran SaleAterToTrade

end
