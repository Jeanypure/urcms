CREATE PROCEDURE [dbo].[P_XS_SaveFeedBackByItemID] @TradeNID VARCHAR(10) = ''
                                           ,@L_NUMBER VARCHAR(50) = ''
                                           ,@L_EBAYITEMTXNID VARCHAR(50) = ''
                                           ,@ToFeedBack VARCHAR(30) = ''
                                           ,@ToMsg VARCHAR(1000) = ''
                                           ,@GetFeedBack VARCHAR(30) = ''
                                           ,@GetMsg VARCHAR(1000) = ''
                                           ,@Flag int=0
AS
BEGIN
  --转换给出评价
  IF @ToFeedBack = 'Positive'
   SET @ToFeedBack = '1'
  ELSE IF @ToFeedBack = 'Neutral'   	
   SET @ToFeedBack = '2'
  ELSE IF @ToFeedBack = 'Negative' 
    SET @ToFeedBack = '3'
  ELSE  
  	SET @ToFeedBack = '0'
  --转换得到评价	
  IF @GetFeedBack = 'Positive'
   SET @GetFeedBack = '1'
  ELSE IF @GetFeedBack = 'Neutral'   	
   SET @GetFeedBack = '2'
  ELSE IF @GetFeedBack = 'Negative' 
    SET @GetFeedBack = '3'
  ELSE  
  	SET @GetFeedBack = '0'	
  
  IF NOT EXISTS(SELECT 1 FROM P_TradeDtExpand 
                WHERE TradeNID = @TradeNID AND L_NUMBER = @L_NUMBER AND L_EBAYITEMTXNID = @L_EBAYITEMTXNID)
  BEGIN
  	INSERT INTO P_TradeDtExpand
  	(	TradeNID,
  		L_NUMBER,
  		L_EBAYITEMTXNID,
  		ToFeedBack,
  		ToMsg,
  		GetFeedBack,
  		GetMsg
  	)
  	VALUES
  	(	@TradeNID,
  		@L_NUMBER,
  		@L_EBAYITEMTXNID,
  		@ToFeedBack,
  		@ToMsg,
  		@GetFeedBack,
  		@GetMsg
  	)
  	if @Flag=0 
  	begin
  	  update P_trade set EvaluateStatus=@GetFeedBack where NID=@TradeNID and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0)
  	end
  	else
  	begin
   	  update P_trade_his set EvaluateStatus=@GetFeedBack where NID=@TradeNID and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) 	
  	end
  END ELSE
  BEGIN
  	UPDATE P_TradeDtExpand
  	SET ToFeedBack = @ToFeedBack,
  		ToMsg = @ToMsg,
  		GetFeedBack = @GetFeedBack,
  		GetMsg = @GetMsg
  	WHERE TradeNID = @TradeNID AND L_NUMBER = @L_NUMBER AND  L_EBAYITEMTXNID = @L_EBAYITEMTXNID 
  	if @Flag=0 
  	begin
      update P_trade set EvaluateStatus=@GetFeedBack where NID=@TradeNID and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) 
    end
    else
    begin
       update P_Trade_His set EvaluateStatus=@GetFeedBack where NID=@TradeNID and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0)    
    end   	
  END	
END
