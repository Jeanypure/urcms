
CREATE PROCEDURE [dbo].[P_XS_SaveFeedBackMore] 
                 @L_NUMBER VARCHAR(50) = ''
                ,@L_EBAYITEMTXNID VARCHAR(50) = ''
              ,@CommentingUser VARCHAR(500) = ''
              ,@CommentingUserScore int=0
              ,@Followup VARCHAR(500) = ''
              ,@OrderLineItemID VARCHAR(500) = ''
              ,@ItemTitle VARCHAR(500) = ''
              ,@ItemPrice money=0
              ,@FeedbackResponse VARCHAR(500) = ''
              ,@FeedbackID VARCHAR(500) = ''
              ,@CommentTime VARCHAR(50) = ''
              ,@CommentText VARCHAR(8000) = ''
               ,@GetFeedBack VARCHAR(200) = ''
                ,@Role VARCHAR(200) = ''
                ,@eBayUserID VARCHAR(200) = ''
                ,@SKU varchar(200)=''
                ,@mnid varchar(20)=''
                ,@SHIPTOCOUNTRYNAME varchar(200)=''
                ,@ORDERTIME varchar(30)=''
	            ,@CLOSINGDATE varchar(30)=''
	            ,@Intervalday varchar(10)=''
	            ,@Memo varchar(8000)=''
                                           
                                           
AS
BEGIN
  if @L_EBAYITEMTXNID='' set @L_EBAYITEMTXNID='0'
  --转换得到评价	
  IF @GetFeedBack = 'Positive'
   SET @GetFeedBack = '1'
  ELSE IF @GetFeedBack = 'Neutral'   	
   SET @GetFeedBack = '2'
  ELSE IF @GetFeedBack = 'Negative' 
    SET @GetFeedBack = '3'
  ELSE  
  	SET @GetFeedBack = '0'	
  	
  Declare @Flag int=0

  IF NOT EXISTS(SELECT 1 FROM P_EbayEvaluate 
                WHERE   FeedbackID =@FeedbackID)
  BEGIN
  	INSERT INTO P_EbayEvaluate
  	(	
  		ItemID,
  		L_EBAYITEMTXNID,
  		ItemTitle,
  		ItemPrice,
  		CommentingUser,
  		FeedbackResponse,
  		FeedbackID,
  		CommentTime,
  		CommentingUserScore,
  		Followup,
  		OrderLineItemID,
  		Role,
  		eBayUserID,
  		CommentType,
  		CommentText
  		
  	)
  	VALUES
  	(	
  		@L_NUMBER,
  		@L_EBAYITEMTXNID,
  		@ItemTitle,
  		@ItemPrice  ,
  		@CommentingUser,
  		@FeedbackResponse,
  		@FeedbackID,
  		@CommentTime,
  		@CommentingUserScore,
  		@Followup,
  		@OrderLineItemID,
  		@Role,
  		@eBayUserID,
  		@GetFeedBack,
  		@CommentText  			
  	)

  END ELSE
  BEGIN
  	UPDATE P_EbayEvaluate
  	SET CommentType = @GetFeedBack,
  		CommentText = @CommentText,
  		ItemTitle=@ItemTitle,
  		ItemPrice=@ItemPrice,
  		CommentingUser=@CommentingUser,
  		FeedbackResponse=@FeedbackResponse,
  		ItemID=@L_NUMBER,
  		L_EBAYITEMTXNID=@L_EBAYITEMTXNID,
  		CommentTime=@CommentTime,
  		CommentingUserScore=@CommentingUserScore,
  		Followup=@Followup,
  		OrderLineItemID=@OrderLineItemID,
  		Role=@Role
  	WHERE FeedbackID =@FeedbackID  	
  END	
  --更新订单号
	if Exists(select nid from P_TradeDt(nolock) where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
	   set @Flag=1
		select 
			@mnid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Intervalday= DATEDIFF(day,m.ORDERTIME,@CommentTime) ,
	        @Memo=m.Memo
		from 
			P_TradeDt(nolock) d
		inner join 
			P_Trade(nolock) m on m.NID=d.TradeNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else
	if Exists(select nid from P_TradeDt_His(nolock) where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
	    set @Flag=2
	 	select 
			@mnid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Intervalday= DATEDIFF(day,m.ORDERTIME,@CommentTime) ,
	        @Memo=m.Memo
		from 
			P_TradeDt_His(nolock) d
		inner join 
			P_Trade_His(nolock) m on m.NID=d.TradeNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else	
	if Exists(select nid from P_TradeDtUn(nolock) where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
	    set @Flag=3
		set @mnid =(select top 1 TradeNID  from P_TradeDtUn(nolock) where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)	    
		select 
			@mnid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
	        @Intervalday= DATEDIFF(day,m.ORDERTIME,@CommentTime) ,
	        @Memo=m.Memo
		from 
			P_TradeDtUn(nolock) d
		inner join 
			P_TradeUn(nolock) m on m.NID=d.TradeNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
	else	
	if Exists(select nid from P_TradeDtUn_His where L_EBAYITEMTXNID=@L_EBAYITEMTXNID and L_NUMBER=@L_NUMBER)
	begin
	    set @Flag=4
		select 
			@mnid=m.nid,
			@SKU=d.sku,
			@SHIPTOCOUNTRYNAME=m.shiptocountryname,
			@ORDERTIME=m.ORDERTIME,
	        @CLOSINGDATE=m.CLOSINGDATE, 
            @Intervalday= DATEDIFF(day,m.ORDERTIME,@CommentTime) ,
	        @Memo=m.Memo
		from 
			P_TradeDtUn_His d
		inner join 
			P_TradeUn_His m on m.NID=d.TradeNID
		where 
			d.L_EBAYITEMTXNID=@L_EBAYITEMTXNID and d.L_NUMBER=@L_NUMBER
	end
			
	update 
		P_EbayEvaluate 
	set 
		SKU=@SKU,
		tradenid=@mnid,
		SHIPTOCOUNTRYNAME=@SHIPTOCOUNTRYNAME,
		ORDERTIME=@ORDERTIME,
	    CLOSINGDATE=@CLOSINGDATE, 
	    Intervalday= @Intervalday,
	    Memo=@Memo
	where 
		FeedbackID=@FeedbackID
		
	if @Flag=1 
  	begin
      update P_trade set EvaluateStatus=@GetFeedBack where NID=@mnid and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) and @Role='Seller'
    end	
    else if @Flag=2
    begin
     update P_Trade_His set EvaluateStatus=@GetFeedBack where NID=@mnid and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) and @Role='Seller'
    end
    else if @Flag=3
    begin
     update P_TradeUn set EvaluateStatus=@GetFeedBack where NID=@mnid and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) and @Role='Seller'
    end
    else if @Flag=4
    begin
     update P_TradeUn_His set EvaluateStatus=@GetFeedBack where NID=@mnid and cast(@GetFeedBack as int) > isnull(EvaluateStatus,0) and @Role='Seller'
    end
		
END
