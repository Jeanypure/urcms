
create PROCEDURE [dbo].[P_XS_TotalWeightImport] @NID VARCHAR(100) = '',
                                       @TotalWeight NUMERIC(10,4) = 0	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ReturnStr VARCHAR(500) = ''
	IF (LEN(@NID) < 9)
	BEGIN
	  IF EXISTS(SELECT 1 
	            FROM P_Trade WHERE NID = @NID)
	  BEGIN
	  	UPDATE P_Trade	SET TotalWeight = @TotalWeight  	WHERE NID = @NID	  
	  	SET @ReturnStr = '订单"'+@NID +'"的重量导入成功!'		
	  END ELSE
	  BEGIN
	  	SET @ReturnStr = '订单"'+@NID +'"未找到，导入失败!'	
	  END
	END ELSE
	BEGIN
	  IF EXISTS(SELECT 1 
	            FROM P_Trade WHERE TrackNo = @NID)
	  BEGIN
	  	UPDATE P_Trade	SET TotalWeight = @TotalWeight  	WHERE TrackNo = @NID	  
	  	SET @ReturnStr = '订单"'+@NID +'"的重量导入成功!'		
	  END ELSE
	  BEGIN
	  	SET @ReturnStr = '订单"'+@NID +'"未找到，导入失败!'	
	  END	
	END
	SELECT @ReturnStr AS ReturnStr
END

