Create proc [P_XS_TradeCount] -- 改成87版本的
		@Suffixs	varchar(Max),
		@BeginDate datetime,
		@EndDate   datetime
as
begin
	if @Suffixs='0' --全部
	begin
		select count(1) as ocount,'UnSettlement' as itype
		from P_TradeUn(nolock) 
		where FilterFlag = 0  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock'  
		from P_TradeUn(nolock) 
		where FilterFlag = 1 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'ReturnTrade' 
		from P_TradeUn(nolock) 
		where FilterFlag = 2 and ordertime>=@BeginDate and ordertime<=@EndDate
		Union all
		select count(1),'CancelTrade' 
		from P_TradeUn(nolock)
		where FilterFlag = 3 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'OtherPlm' 
		from P_TradeUn(nolock)
		where FilterFlag = 4  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'UnExpress' 
		from p_trade(nolock)
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		
		--正常单... modify by ylq 2016-09-01
		select count(1), 'UnExpress1'
		from p_trade(nolock) m
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate
		and ( SHIPTOzip <> '' and SHIPTONAME <> '' and SHIPTOSTATE <> '' and  SHIPTOPHONENUM <> '')  
		and (IsNull(SUBJECT,'') = '' and IsNull(Note,'') = '' )  
		and (not exists(SELECT top 1 TradeNID FROM P_TradeDt(nolock) ptdu  
		inner join P_Trade(nolock) pm on pm.NID=ptdu.tradenid  
		where pm.NID=m.NID and  FilterFlag=5  And ordertime >=@BeginDate
		and ordertime<=@EndDate and GoodsSKUID=0))  
		and (not exists  (select top 1 CID from XS_CustomerBlack where CID=m.BUYERID))  
		and (ProfitMoney>0)  and (ADDRESSOWNER<>'amazon11' 
		or (ADDRESSOWNER='amazon11'  and CUSTOM not like 'AFN%'))   
 
        union all
		select count(1),'UnExpress2' 
		from p_trade(nolock)
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate
		       and ((SHIPTOzip='' or isnull(SHIPTONAME,'')='') or  (isnull(SHIPTOSTATE,'')='') 
		or (isnull(SHIPTOPHONENUM,'')='') or  (SHIPTOCOUNTRYCODE='RU' 
		And (((LEN(REPLACE(LTRIM(RTRIM(SHIPTONAME)),' ','**')) -LEN(LTRIM(RTRIM(SHIPTONAME))))<2) 
		 or (LEN(SHIPTOZIP)<>6 or PATINDEX('%[1-9]%',SHIPTOZIP)=0))))               
        union all
		select count(1),'UnExpress3' 
		from p_trade(nolock)
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate       
               and ((len([SUBJECT])>0) or (len([note])>0))                
        union all    
        select count(1),'UnExpress4'  FROM P_Trade(nolock) m  
        WHERE FilterFlag=5  And ordertime >=@BeginDate and ordertime<=@EndDate  
        And exists  (SELECT top 1 TradeNID FROM P_TradeDt(nolock) ptdu 
						inner join P_Trade(nolock) pm on pm.NID=ptdu.tradenid 
						where pm.NID=m.NID and  FilterFlag=5  And ordertime >=@BeginDate and ordertime<=@EndDate and GoodsSKUID=0) 
        union all
		select count(1),'UnExpress5' 
		from p_trade(nolock) m
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate                    
             and exists  (select top 1 CID from XS_CustomerBlack where CID=m.BUYERID)               
 		union all
		select count(1),'UnExpress6' 
		from p_trade(nolock)
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate                                           
              and  ProfitMoney<=0     
                      union all
		select count(1),'UnExpress7' 
		from p_trade(nolock)
		where FilterFlag = 5 and ADDRESSOWNER='amazon11' and ordertime>=@BeginDate and ordertime<=@EndDate                                           
              and CUSTOM like 'AFN%'              
		union all
		select count(1),'EubTrade' 
		from p_trade(nolock) m
		inner join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 1 
		where m.FilterFlag = 6 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'EubOutLine' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 2 
		where m.FilterFlag = 6 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'Trade4PX' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 3 
		where m.FilterFlag = 6 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1) as ocount,'UnEubTrade' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and isnull(l.EUB,0) not in (1,2,3) 
		where m.FilterFlag =6  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select 0 as ocount,'AllTrade'		
	
	end
	else
	if @Suffixs<>'0' and charindex(',',@Suffixs)=0
	begin
		select count(1) as ocount,'UnSettlement' as itype
		from P_TradeUn(nolock) 
		where FilterFlag = 0 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock'  
		from P_TradeUn(nolock) 
		where FilterFlag = 1 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'ReturnTrade' 
		from P_TradeUn(nolock) 
		where FilterFlag = 2 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		Union all
		select count(1),'CancelTrade' 
		from P_TradeUn(nolock)
		where FilterFlag = 3 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'OtherPlm' 
		from P_TradeUn(nolock)
		where FilterFlag = 4 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'UnExpress' 
		from p_trade(nolock)
		where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'UnExpress1'
			from p_trade(nolock) m
			where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
			and ( SHIPTOzip <> '' and SHIPTONAME <> '' and SHIPTOSTATE <> '' and  SHIPTOPHONENUM <> '')  
			and (IsNull(SUBJECT,'') = '' and IsNull(Note,'') = '' )  
			and (not exists(SELECT top 1 TradeNID FROM P_TradeDt(nolock) ptdu  
			inner join P_Trade(nolock) pm on pm.NID=ptdu.tradenid  
			where pm.NID=m.NID and  FilterFlag=5  And ordertime >=@BeginDate
			and ordertime<=@EndDate and GoodsSKUID=0))  
			and (not exists  (select top 1 CID from XS_CustomerBlack where CID=m.BUYERID))  
			and (ProfitMoney>0)  and (ADDRESSOWNER<>'amazon11' 
			or (ADDRESSOWNER='amazon11'  and CUSTOM not like 'AFN%'))   
 	
        union all
		select count(1),'UnExpress2' 
		from p_trade(nolock)
		where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		      and ((SHIPTOzip='' or isnull(SHIPTONAME,'')='') or  (isnull(SHIPTOSTATE,'')='') 
			or (isnull(SHIPTOPHONENUM,'')='') or  (SHIPTOCOUNTRYCODE='RU' 
			And (((LEN(REPLACE(LTRIM(RTRIM(SHIPTONAME)),' ','**')) -LEN(LTRIM(RTRIM(SHIPTONAME))))<2) 
			 or (LEN(SHIPTOZIP)<>6 or PATINDEX('%[1-9]%',SHIPTOZIP)=0)))) 
        union all
		select count(1),'UnExpress3' 
		from p_trade(nolock)
		where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate       
               and ((len([SUBJECT])>0) or (len([note])>0))                
        union all    
        select count(1),'UnExpress4'  FROM P_Trade(nolock) m  
        WHERE FilterFlag=5 and SUFFIX=@Suffixs  And ordertime >=@BeginDate and ordertime<=@EndDate  
        And exists  (SELECT top 1 TradeNID FROM P_TradeDt(nolock) ptdu 
						inner join P_Trade(nolock) pm on pm.NID=ptdu.tradenid 
						where m.NID=pm.NID and  FilterFlag=5  And ordertime >=@BeginDate and ordertime<=@EndDate and GoodsSKUID=0) 

     
        union all
		select count(1),'UnExpress5' 
		from p_trade(nolock) m
		where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate                    
             and exists  (select top 1 CID from XS_CustomerBlack where CID=m.BUYERID)               
 		union all
		select count(1),'UnExpress6' 
		from p_trade(nolock)
		where FilterFlag = 5 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate                                           
              and  ProfitMoney<=0    
                   		union all
		select count(1),'UnExpress7' 
		from p_trade(nolock)
		where FilterFlag = 5 and ADDRESSOWNER='amazon11' and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate                                           
            and CUSTOM like 'AFN%'  
		union all
		select count(1),'EubTrade' 
		from p_trade(nolock) m
		inner join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 1 
		where m.FilterFlag = 6 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'EubOutLine' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 2 
		where m.FilterFlag = 6 and SUFFIX=@Suffixs and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'Trade4PX' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 3 
		where m.FilterFlag = 6 and SUFFIX=@Suffixs  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1) as ocount,'UnEubTrade' 
		from p_trade(nolock)  m
		join B_LogisticWay l on l.nid=m.logicsWayNID and isnull(l.EUB,0) not in (1,2,3) 
		where m.FilterFlag = 6 and SUFFIX=@Suffixs  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select 0 as ocount,'AllTrade'		
	end
	else
	begin
		CREATE TABLE #PCount(Suffix VARCHAR(200) ,
			  primary key (Suffix))
		IF LTRIM(RTRIM(@Suffixs)) <> ''
		BEGIN
			DECLARE @sSQLCmd VARCHAR(max) = ''
			SET @Suffixs = REPLACE(@Suffixs,',',' ) INSERT INTO #PCount(Suffix) values(') 
			SET @sSQLCmd = 'INSERT INTO #PCount(Suffix) values('+ @Suffixs +')'
			EXEC(@sSQLCmd )
		END
		select count(1) as ocount,'UnSettlement' as itype
		from P_TradeUn(nolock) m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 0  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock'  
		from P_TradeUn(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 1 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'ReturnTrade' 
		from P_TradeUn(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 2 and ordertime>=@BeginDate and ordertime<=@EndDate
		Union all
		select count(1),'CancelTrade' 
		from P_TradeUn(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 3 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'OtherPlm' 
		from P_TradeUn(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 4 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'UnExpress' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'UnExpress1' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
			and ( SHIPTOzip <> '' and SHIPTONAME <> '' and SHIPTOSTATE <> '' and  SHIPTOPHONENUM <> '')  
			and (IsNull(SUBJECT,'') = '' and IsNull(Note,'') = '' )  
			and (not exists(SELECT top 1 TradeNID FROM P_TradeDt(nolock) ptdu  
			inner join P_Trade(nolock) pm on pm.NID=ptdu.tradenid  
			where pm.NID=m.NID and  FilterFlag=5  And ordertime >=@BeginDate
			and ordertime<=@EndDate and GoodsSKUID=0))  
			and (not exists  (select top 1 CID from XS_CustomerBlack where CID=m.BUYERID))  
			and (ProfitMoney>0)  and (ADDRESSOWNER<>'amazon11' 
			or (ADDRESSOWNER='amazon11'  and CUSTOM not like 'AFN%'))    
		union all
		select count(1),'UnExpress2' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
				      and ((SHIPTOzip='' or isnull(SHIPTONAME,'')='') or  (isnull(SHIPTOSTATE,'')='') 
			or (isnull(SHIPTOPHONENUM,'')='') or  (SHIPTOCOUNTRYCODE='RU' 
			And (((LEN(REPLACE(LTRIM(RTRIM(SHIPTONAME)),' ','**')) -LEN(LTRIM(RTRIM(SHIPTONAME))))<2) 
			 or (LEN(SHIPTOZIP)<>6 or PATINDEX('%[1-9]%',SHIPTOZIP)=0)))) 
				union all
		select count(1),'UnExpress3' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
		              and ((len([SUBJECT])>0) or (len([note])>0))   
				union all
		select count(1),'UnExpress4' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
        And exists (SELECT top  1  TradeNID FROM P_TradeDt(nolock) ptdu 
						inner join P_Trade(nolock) im on im.NID=ptdu.tradenid 
						where  im.NID=m.NID and  FilterFlag=5  And ordertime >=@BeginDate and ordertime<=@EndDate and GoodsSKUID=0) 

				union all
		select count(1),'UnExpress5' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 
		          and  exists  (select CID from XS_CustomerBlack where CID=m.BUYERID)  
				union all
		select count(1),'UnExpress6' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ordertime>=@BeginDate and ordertime<=@EndDate 	
		          and  ProfitMoney<=0  	
	    union all
		select count(1),'UnExpress7' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		where FilterFlag = 5 and ADDRESSOWNER='amazon11' and ordertime>=@BeginDate and ordertime<=@EndDate 	
		and CUSTOM like 'AFN%' 		
		union all
		select count(1),'EubTrade' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX  
		inner join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 1 
		where m.FilterFlag = 6 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'EubOutLine' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX  
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 2 
		where m.FilterFlag = 6 and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1),'Trade4PX' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX  
		join B_LogisticWay l on l.nid=m.logicsWayNID and l.EUB = 3 
		where m.FilterFlag = 6  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select count(1) as ocount,'UnEubTrade' 
		from p_trade(nolock)  m
		inner join #PCount s on s.Suffix=m.SUFFIX 
		join B_LogisticWay l on l.nid=m.logicsWayNID and isnull(l.EUB,0) not in (1,2,3) 
		where m.FilterFlag =6  and ordertime>=@BeginDate and ordertime<=@EndDate
		union all
		select 0 as ocount,'AllTrade'

	end
end
