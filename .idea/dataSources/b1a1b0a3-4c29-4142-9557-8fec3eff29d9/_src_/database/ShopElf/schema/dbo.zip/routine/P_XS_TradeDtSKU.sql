CREATE proc [P_XS_TradeDtSKU]
	@TradeNID int
as
BEGIN
	declare @ADDRESSOWNER varchar(100)=''
	set @ADDRESSOWNER=(select top 1 ADDRESSOWNER from P_Trade where NID=@TradeNID);
	set @ADDRESSOWNER=ISNULL(@ADDRESSOWNER,'')
    UPDATE P_TradeDT 
    SET L_EBAYITEMTXNID = ''
    WHERE tradeNid=@TradeNID and isnull(L_EBAYITEMTXNID,'')='' 
    --判断是否使用商品名称当做英文报关
    declare
		@AliasEnNameTitle int=0 --0是不替换
	set 
		@AliasEnNameTitle=(select ISNULL(Paravalue,0) from B_SysParams where ParaCode='AliasEnNameTitle')
	if @AliasEnNameTitle=1 --替换
	begin
		update
			P_TradeDt
		set
			AliasEnName = SUBSTRING(convert(text,L_NAME),1,200)
		where
			TradeNID=@TradeNID and ISNULL(AliasEnName,'')=''
	end 

	--判断是否启用了, 指定分隔符后面的SKU内容不要。如：A001/ABCD--->A001; A001*10/ABCD--->A001*10   
	declare
		@DelimiterFlag int=0 --0是不替换
	    ,@Delimiter VARCHAR(10) = ''
	    ,@Puerto_US int=0
	    
	set @Puerto_US = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='Puerto_US')    
	
	set @DelimiterFlag = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='DelimiterFlag')
	
	if @DelimiterFlag = 1 --替换
	BEGIN
		set 
	      @Delimiter=(select ISNULL(Paravalue,'') from B_SysParams where ParaCode='Delimiter') 
	    IF @Delimiter <> '' and exists (	select NID 	from P_TradeDt D	 
				where	TradeNID=@TradeNID and  CHARINDEX(@Delimiter,isNull(d.SKU,'')) > 0 )
	    BEGIN   
			update
				P_TradeDt
			set
				SKU = SUBSTRING(SKU,1,CHARINDEX(@Delimiter,SKU)-1)
			where
				TradeNID=@TradeNID and ISNULL(SKU,'')<>'' AND CHARINDEX(@Delimiter,SKU) >0
		END 
	end 
	
	--获取配货信息是否用SKUNAME 0 不使用 1 使用
	declare
		@OrdersGoodsNameIsSKUName int=0 
	set 
	    @OrdersGoodsNameIsSKUName = (select ISNULL(Paravalue,0) from B_SysParams where ParaCode='OrdersGoodsNameIsSKUName')	
 
	--cuifeng 增加店铺多SKU设置
	--更新店铺SKU对应的商品信息
	--查找默认仓库
	    declare 
			@Store11ID int=0
		set @Store11ID=(select nid from B_Store where StoreName in (select ParaValue from B_SysParams where ParaCode='DefaultSendStock') )
		set @Store11ID=ISNULL(@Store11ID,0)
		--更新店铺SKU对应的商品
		update
		     D
		set     
			d.SKU=case when isnull(gss.sku,'') <>'' then isnull(gss.sku,'') else d.SKU end
		from 
			P_TradeDt D	 
		inner join B_GoodsSKULinkShop gss on gss.ShopSKU=d.SKU	
		inner join B_GoodsSKU gs on gs.SKU=gss.SKU			
		inner join B_Goods g on g.NID=gs.GoodsID				
		where	
			TradeNID=@TradeNID and isnull(d.sku,'')<>''
 						
	--判断组合品SKU模式，在SKU中组合的，未在商品信息中建立的，sku1+sku2*5+sku3*6
    declare
		@ZhSKUModel int=0
	set 
		@ZhSKUModel=(select ISNULL(Paravalue,0) from B_SysParams where ParaCode='ZhSKUModel')
	if @ZhSKUModel=1 
	begin      	
		Create Table #zhsku
			(
				TradeDtNid int not null default 0,
				sku varchar(100) not null default ''
			)
		declare 
			@sql varchar(4000)
		set 		
			@sql= dbo.Ex_GetOrdereZHSKU(@TradeNID)
	
		if rtrim(ltrim(@sql))<>''
		begin	
			set 		
				@sql= ' insert into #zhsku '+ @sql
				
			exec(@sql)
			 		
			--L_OPTIONSVALUE为1是已解析过
			insert into P_TradeDt(TradeNID,L_EBAYITEMTXNID,L_NAME,L_NUMBER,L_QTY,L_SHIPPINGAMT,
				L_HANDLINGAMT,L_CURRENCYCODE,L_AMT,L_OPTIONSNAME,L_OPTIONSVALUE,L_TAXAMT,
				SKU,CostPrice,AliasCnName,AliasEnName,[Weight],DeclaredValue,OriginCountry,
				OriginCountryCode,BmpFileName,GoodsName,GoodsSKUID,StoreID,eBaySKU,BuyerNote)
			select TradeNID,L_EBAYITEMTXNID,L_NAME,L_NUMBER,L_QTY,L_SHIPPINGAMT,
				L_HANDLINGAMT,L_CURRENCYCODE,L_AMT,L_OPTIONSNAME,'1',L_TAXAMT,
				z.SKU,isnull(d.CostPrice,0),g.AliasCnName,g.AliasEnName,isnull(d.[Weight],0),isnull(d.DeclaredValue,0),d.OriginCountry,
				d.OriginCountryCode,d.BmpFileName,
				SUBSTRING(convert(text, CASE WHEN ISNULL(g.MultiStyle,0)=0  THEN  g.GoodsName 
			         ELSE 
				       case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
				       else ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
				            ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,'') 
				       end                           
				     END),1,200),
				d.GoodsSKUID,d.StoreID,eBaySKU,d.BuyerNote
			from 
				#zhsku z join P_TradeDt d ON z.TradeDtNid=d.NID
				        LEFT  JOIN B_GoodsSKU gs ON gs.NID = d.GoodsSKUID
				        LEFT  JOIN B_Goods g  ON g.NID = gs.GoodsID

				
			delete from 
				P_TradeDt
			where 
				NID in (select tradedtnid from #zhsku)	
		 	
			drop table #zhsku	
			--清除其它相同list的费用，只保留一条费用信息
			SELECT min(NID) AS NID
			INTO #TempTradeDt
			FROM P_tradeDt 
			WHERE TradeNID = @TradeNID 
			GROUP BY eBaySKU
			UPDATE P_TradeDt
			SET
				L_SHIPPINGAMT = 0,
				L_HANDLINGAMT = 0,
				L_AMT = 0
			WHERE TradeNID = @TradeNID AND NID NOT IN (SELECT NID FROM #TempTradeDt)
			
			DROP TABLE #TempTradeDt			
		end
	end	
     --判断小额批发 0否，1是 单品SKU*数量，一定是*号-----start
    declare
		@SmallWholesale int=0
    declare
		@SmallWholesaleSymbol varchar(10)
	set 
		@SmallWholesale=(select ISNULL(Paravalue,0) from B_SysParams where ParaCode='Small Wholesale')
	set 
		@SmallWholesaleSymbol=(select ISNULL(Paravalue,'*') from B_SysParams where ParaCode='SmallWholesaleSymbol')		

	if @SmallWholesale=1  and exists (	select NID 	from P_TradeDt D	 
				where	TradeNID=@TradeNID and  CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,'')) > 0 )
	begin
	   -- 分隔符后面是int类型的 拆分，不是则按原来的sku和数量
		update
		     D
		set     
			 D.SKU =case when 
			     ISNUMERIC(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10))=1 then
			     case when cast(cast(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10) AS float) AS int)
			       =cast(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10) AS float)
			     then Substring(isNull(d.SKU,''),1,CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))-1) else  isNull(d.SKU,'') end
			     else   isNull(d.SKU,'') end, 
			 D.L_TAXAMT=D.L_QTY,
			 D.L_QTY = (case ISNUMERIC(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10)) 
			 when 1  then 
			 case when cast(cast(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10) AS float) AS int)
			 =cast(Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10) AS float)
			 then Substring(isNull(d.SKU,''),CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,''))+1,10)
			 else 1 end 
			 else 1 end)*D.L_QTY    
		from 
			P_TradeDt D	 
		where	
			TradeNID=@TradeNID and isNull(d.SKU,'')<>'' and isnull(D.L_TAXAMT,0)=0 and 
			CHARINDEX(@SmallWholesaleSymbol,isNull(d.SKU,'')) > 0 --小额批发模式	 EXEC P_XS_TradeDtSKU 13607
		
	end			
    --判断小额批发 0否，1是 单品SKU*数量，一定是*号-----end	
    
    --更新店铺SKU对应的商品
    --欣维发特殊处理，判断有店铺SKU，站点，对应真实SKU的表格，那以这个对应，不再以店铺SKU对应
    IF EXISTS  (SELECT  * FROM dbo.SysObjects WHERE ID = object_id(N'B_skulink') AND OBJECTPROPERTY(ID, 'IsTable') = 1) 
    begin
      --店铺运输方式包括 MFN 的 更新成原始SKU
      update d 
        set SKU= l.sku  
      from 
        p_tradedt d
      inner join 
        p_trade m on m.NID=d.TradeNID
      inner join 
        B_skulink l on l.shopsku=d.eBaySKU and m.SUFFIX=l.suffix
      where 
        d.TradeNID=@TradeNID and m.CUSTOM like '%MFN%'
      --店铺运输方式包括 AFN 的更新成带后缀的SKU  
      update d 
        set SKU= l.newsku 
      from 
        p_tradedt d
      inner join 
        p_trade m on m.NID=d.TradeNID
      inner join 
        B_skulink l on l.shopsku=d.eBaySKU and m.SUFFIX=l.suffix
      where 
        d.TradeNID=@TradeNID and m.CUSTOM like '%AFN%'  
    end
    else begin 
      --正常对应
	  update
		D
	  set     
		d.SKU=case when isnull(gss.sku,'') <>'' then isnull(gss.sku,'') else d.SKU end
	  from 
		P_TradeDt D	 
		inner join B_GoodsSKULinkShop gss on gss.ShopSKU=d.SKU	
		inner join B_GoodsSKU gs on gs.SKU=gss.SKU			
		inner join B_Goods g on g.NID=gs.GoodsID				
	  where	
		TradeNID=@TradeNID and isnull(d.sku,'')<>''
	end  
 
	--更新P_TradeDt表更新SKU对应的信息
	DECLARE @DefStoreID INT 
    SET @DefStoreID = IsNull((SELECT TOP 1 NID FROM B_Store WHERE StoreName = (SELECT ParaValue FROM B_SysParams WHERE ParaCode = 'DefaultSendStock')),0)	
	
	update
	     D
	set     
		 D.AliasCnName=g.AliasCnName,
		 d.AliasEnName=g.AliasEnName,
		 d.GoodsName =SUBSTRING(convert(text, CASE WHEN ISNULL(g.MultiStyle,0) = 0  THEN  g.GoodsName 
		        		    ELSE 
			                  case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
			                  else ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
			                       ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,'') 
			                  end                           
			                END ),1,200),		
			                                    		 
		 d.DeclaredValue=case when isnull(d.DeclaredValue,0)=0 then isnull(g.DeclaredValue,0) else d.DeclaredValue end,
		 d.Weight=(case when isnull(gs.Weight,0)<>0 
						then isnull(gs.Weight,0) else isnull(g.Weight,0) end)*d.L_QTY/1000,				 
		 d.OriginCountry=g.OriginCountry,
		 d.OriginCountryCode=g.OriginCountryCode,
		 d.StoreID=case when isnull(g.StoreID,0)<>0 then g.StoreID else @DefStoreID end ,
		 d.GoodsSKUID=isnull(gs.NID,0),
		 d.BmpFileName = case when isnull(d.BmpFileName,'') <> '' then d.BmpFileName else g.BmpFileName end    
	from 
		P_TradeDt D	 
	inner join B_GoodsSKU gs on gs.SKU=d.SKU			
	inner join B_Goods g on g.NID=gs.GoodsID				
	where	
		TradeNID=@TradeNID	and isnull(d.sku,'')<>''

        --最后更新下仓库
	update  P_TradeDt
        set StoreID=@DefStoreID 		
        where	
          TradeNID=@TradeNID and ISNULL(StoreID,0) = 0	

	--生成组合品表
	select 
		d.TradeNID,
		d.NID as TradeDtNID,
		d.SKU as OriginSKU,
		D.L_Qty as Amount,
		g.NID as goodsid
		into #P_XS_TradeDtSKU
	from 
		P_TradeDt D
	left outer Join 
		B_GoodsSKU Gs on gs.SKU =  isNull(D.SKU,'')
	left outer Join 
		B_Goods G	 on g.NID =  gs.GoodsID		
	where 
		TradeNID=@TradeNID and isNull(gs.SKU,'')<> '' and 
		G.GroupFlag =1 --非组合品	
		and ISNULL(d.L_OPTIONSVALUE,'')<>'1'
	--存在组合	
	if exists(select TradeNID from #P_XS_TradeDtSKU )
	begin
		--启用事务
		declare
			@error int
		set
			@error=0
		begin tran 	P_XS_TradeDtSKU
		
		insert into P_TradeDt(TradeNID,L_EBAYITEMTXNID,L_NAME,L_NUMBER,L_QTY,
				L_SHIPPINGAMT,L_HANDLINGAMT,
				L_CURRENCYCODE,L_AMT,L_OPTIONSNAME,L_OPTIONSVALUE,L_TAXAMT,eBaySKU,SKU,CostPrice,
				AliasCnName,AliasEnName,[Weight],DeclaredValue,OriginCountry,
				OriginCountryCode,BmpFileName,GoodsName,GoodsSKUID,StoreID,BuyerNote)		
		select 
			d.TradeNID,d.L_EBAYITEMTXNID,d.L_NAME,d.L_NUMBER,
			d.L_QTY*ISNULL(gg.Amount,1) AS amount,
			d.L_SHIPPINGAMT,
			d.L_HANDLINGAMT,
			d.L_CURRENCYCODE,d.L_AMT,d.L_OPTIONSNAME,'1',d.L_QTY,/*d.L_TAXAMT保存原店铺数量*/
			d.eBaySKU,
			gs.SKU,isnull(g.CostPrice,0)*d.L_QTY*ISNULL(gg.Amount,1),
				g.AliasCnName,g.AliasEnName,isnull(g.[Weight],0)*d.L_QTY*ISNULL(gg.Amount,1)/1000.00,isnull(g.DeclaredValue,0),d.OriginCountry,
				d.OriginCountryCode,g.BmpFileName,
				SUBSTRING(convert(text, CASE WHEN ISNULL(g.MultiStyle,0) = 0  THEN  g.GoodsName 
			         ELSE 
				       case when @OrdersGoodsNameIsSKUName = 1 then ISNULL(gs.SKUName,'') 
				       else ISNULL(g.GoodsName,'') + ' ' + ISNULL(gs.property1,'') + ' ' +
				            ISNULL(gs.property2,'')+ ' '+ ISNULL(gs.property3,'') 
				       end                           
				     END),1,200),		
			isnull(gs.NID,0),isnull(g.storeid,0),d.buyernote	
		from 
			#P_XS_TradeDtSKU pds
		left outer Join 
			P_TradeDt D on D.NID  =  pds.TradeDtNID	and d.TradeNID=@TradeNID
		left outer Join 
			B_GoodsGroup gg on pds.goodsid =  gg.GoodsID
		left outer Join 
			B_GoodsSKU Gs on gs.nid =  gg.GoodsSKUID	
		left outer Join 
			B_Goods G	 on g.NID =  gs.GoodsID		
	
		set @error=@@ERROR
		--删除原有组合记录
		delete 
			P_TradeDt 
		where 
			NID in (select TradeDtNID from #P_XS_TradeDtSKU)
		set @error=@error+@@ERROR		
		--保留一条记录有金额及交易ID
		
		update 
			P_TradeDt 
		set 
			L_AMT=0,L_EBAYITEMTXNID='',Weight=0
		where
			TradeNID=@TradeNID and 
			NID not in (select  min(nid) as nid 
						from  P_TradeDt where TradeNID=@TradeNID 
						group by eBaySKU,L_EBAYITEMTXNID,L_NUMBER) 
		----第一条有交易ID的取组合品重量
		update
			 d
		set
			d.[Weight]=isnull(g.[Weight],0)/1000.00,
			d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end,
			d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
			d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
		from 
			P_TradeDt d
		inner join 
			B_Goods g on g.SKU=d.eBaySKU
		where
			d.TradeNID=@TradeNID and  d.L_EBAYITEMTXNID <> ''
				
		set @error=@error+@@ERROR
		
		if @error=0
		  commit tran P_XS_TradeDtSKU
		else
		  rollback tran P_XS_TradeDtSKU	  			
		drop table #P_XS_TradeDtSKU
	end	
	--更新相同交易ID，Paypal返回出错的问题
    declare
		@ebayModel int=0 --0是ebaymode
	set 
		@ebayModel=(select ISNULL(Paravalue,0) from B_SysParams where ParaCode='DataSourcesFlag')
    declare
		@platform varchar(50)='' 
	set 
		@platform=isnull((select addressowner from p_trade (nolock) where nid=@TradeNID),'')
		
	if @ebayModel=0 and LOWER(@platform)='paypal' --替换paypal时才用		
	begin
		update 
			P_TradeDt 
		set 
			SKU='返回SKU出错',
			GoodsSKUID = 0
		where 
			TradeNID=@TradeNID and  
			L_EBAYITEMTXNID <> '' and  
			CHARINDEX('+',ISNULL(ebaysku,''))=0 and --有加号是组合，不更新
			NID not in (
					select Min(nid) from P_TradeDt 
					where TradeNID=@TradeNID and L_EBAYITEMTXNID <> '' 
					group by ebaysku,L_EBAYITEMTXNID,L_NUMBER)	
	end    

	----查找成本计价方法 0 库存平均价，1商品成本 价
	Declare
		@CalcCostFlag int 
	set
		@CalcCostFlag =ISNULL((select top 1 ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)

	BEGIN TRY
		if @CalcCostFlag=0 
		begin
			update
				 D
			set     
				d.Weight=(case when isnull(gs.Weight,0)<>0 
							then isnull(gs.Weight,0) else isnull(g.Weight,0) end)*d.L_QTY/1000,
				
				d.CostPrice=isnull(kc.Price ,0) *d.L_QTY		  
			from 
				P_TradeDt D	 
			inner join B_GoodsSKU gs on gs.SKU=d.SKU			
			inner join B_Goods g on g.NID=gs.GoodsID
			left outer join kc_currentstock kc on kc.GoodsSKUID=gs.nid and kc.storeid=d.storeid			
			where	
				TradeNID=@TradeNID			
		end else
		begin
			update
				 D
			set     
				d.Weight=(case when isnull(gs.Weight,0)<>0 
							then isnull(gs.Weight,0) else isnull(g.Weight,0) end)*d.L_QTY/1000,
				
				d.CostPrice=(case when isnull(gs.CostPrice,0)<>0 
								then gs.CostPrice else 
								isnull(g.CostPrice ,0) end)*d.L_QTY		  
			from 
				P_TradeDt D	 
			inner join B_GoodsSKU gs on gs.SKU=d.SKU			
			inner join B_Goods g on g.NID=gs.GoodsID		
			where	
				TradeNID=@TradeNID	
		end
	END TRY
	BEGIN CATCH
	END CATCH
	
	--把订单购买总数量\SKU个数求求和  TransMail 多仓
	BEGIN TRY
	
	  --modify by ylq 2016-07-28
	  if (@Puerto_US=1) begin 
	    update P_Trade set SHIPTOCOUNTRYCODE = 'US', SHIPTOCOUNTRYNAME = 'United States',
	      SHIPTOSTATE = 'Puerto Rico' 
	    where Nid=@TradeNID and ADDRESSOWNER<>'aliexpress' and (SHIPTOCOUNTRYCODE = 'PR' or SHIPTOCOUNTRYNAME = 'Puerto Rico')
	  end
 
		select 
			Tradenid,
			SUM([Weight]) as tw,
			SUM(L_QTY) as tq,
			count(nid) as st
		into #tttt 
		from P_TradeDt
		where TradeNID=@TradeNID
		group by TradeNID 	

		UPDATE pt
		SET pt.TotalWeight = t.tw,
			pt.MULTIITEM=t.tq,
			--pt.SALESTAX=t.st,      --这里会有个问题，万一2条相同的SKU呢
		    pt.SALESTAX =isnull((select sum(1) from (
					select sku from P_TradeDt 
					where TradeNID=pt.NID group by sku
					) as aa),0),        --modify by ylq 2015-11-13  	            
			pt.TransMail =isnull((select sum(99) from (
						select ISNULL(d.storeid,0) as storeid from P_TradeDt(nolock) d
						where TradeNID=pt.NID group by ISNULL(d.storeid,0)
						)as a),0),
			pt.AllGoodsDetail=substring(convert(text,dbo.Ex_GetOrderSKUS(pt.NID)),1,4000),
			pt.GoodItemIDs = substring(convert(text,dbo.Ex_GetOrderItemIDS(pt.nid)),1,4000)										
		FROM P_Trade pt
		inner join #tttt t on t.tradenid=pt.NID 
		WHERE pt.NID = @TradeNID	
	  --cuifeng 0112 EXEC P_KC_AutoLinkGoodsSkuMsg @TradeNID
		exec P_FR_CalcLogicWay @TradeNID
	  drop table #tttt 
	END TRY
	BEGIN CATCH
	END CATCH
  
	UPDATE
		P_TRADEDT
	SET
		 ORIGINCOUNTRY='CHINA',
		 ORIGINCOUNTRYCODE='CN'
	WHERE
		TRADENID=@TRADENID AND ISNULL(ORIGINCOUNTRYCODE,'')=''	
	
	--获取系统参数里的交易费率，如果为0，则设置为0.15	
	declare
	  @AmazonTradeFeeScale float=0, --亚马逊交易费率
	  @JDTradeFeeScale float=0, --京东交易费率
	  @shopifyTradeFeeScale float=0, --shopify交易费率
	  @MagentoTradeFeeScale float=0, --Magento交易费率
	  @AliTradeFeeScale float=0 --Ali交易费率
	set 
	  @AmazonTradeFeeScale=convert(float,ISNULL((select ISNULL(Paravalue,0) from B_SysParams where ParaCode='AmazonTradeFeeScale'),'0'))
	set 
	  @JDTradeFeeScale=convert(float,ISNULL((select ISNULL(Paravalue,0) from B_SysParams where ParaCode='JDTradeFeeScale'),'0'))
	set 
	  @shopifyTradeFeeScale=convert(float,ISNULL((select ISNULL(Paravalue,0) from B_SysParams where ParaCode='shopifyTradeFeeScale'),'0'))
	set 
	  @MagentoTradeFeeScale=convert(float,ISNULL((select ISNULL(Paravalue,0) from B_SysParams where ParaCode='MagentoTradeFeeScale'),'0'))
	set 
	  @AliTradeFeeScale=convert(float,ISNULL((select ISNULL(Paravalue,0) from B_SysParams where ParaCode='AliTradeFeeScale'),'0'))
	
	if @platform = 'amazon11'
	begin		
		UPDATE pt
		SET pt.FEEAMT=pt.AMT*@AmazonTradeFeeScale--, --放在交易费中
		--pt.TIMESTAMP=GETDATE()
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID and ADDRESSOWNER='amazon11'	--亚马逊订单 算费用	
	end
	
	-- 京东交易费
	if @platform = 'jd'
	begin	
		UPDATE pt
		SET pt.FEEAMT=pt.AMT*@JDTradeFeeScale--, --放在交易费中
		--pt.TIMESTAMP=GETDATE()
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID and ADDRESSOWNER='jd'	--京东订单 算费用
	end
	-- shopify 交易费
	if @platform = 'shopify'
	begin	
		UPDATE pt
		SET pt.FEEAMT=pt.AMT*@shopifyTradeFeeScale--, --放在交易费中
		--pt.TIMESTAMP=GETDATE()
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID and ADDRESSOWNER='shopify'	--shopify 算费用
	end
	
		
	-- Magento交易费
	if @platform = 'magento'
	begin		
		UPDATE pt
		SET pt.FEEAMT=pt.AMT*@MagentoTradeFeeScale--, --放在交易费中
		--pt.TIMESTAMP=GETDATE()
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID and ADDRESSOWNER='magento'	--京东订单 算费用
	end
	if @platform = 'aliexpress'	
	begin
	    if isnull(@AliTradeFeeScale,0)=0 
	      set @AliTradeFeeScale=0.05;
		UPDATE pt
		SET pt.FEEAMT=pt.AMT*@AliTradeFeeScale, --放在交易费中
			pt.SHIPHANDLEAMOUNT= case when  (select isnull(SUM(l_amt),0) from P_TradeDt where TradeNID =@TradeNID)-AMT+SHIPPINGAMT >0
						then (select isnull(SUM(l_amt),0) from P_TradeDt where TradeNID =@TradeNID)-AMT+SHIPPINGAMT else 0 end
		FROM P_Trade pt
		WHERE pt.NID = @TradeNID and ADDRESSOWNER='aliexpress'	--速卖通订单 算费用	
	end
    --计算运费及利润 这个必须写 不然还是有问题
	BEGIN TRY
		UPDATE pt
		SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt(nolock) where tradenid=pt.nid),0),
			pt.ExpressFare= isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0)
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
			    
		UPDATE pt
		SET 
			pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.nid),0)-
			ExpressFare),0)
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
	END TRY
	BEGIN CATCH
	END CATCH
	--申报价值过大时，按设定上限平分申报价值 
	--注意这个必须放在最后，否则客户会出现报关价值过大问题
	EXEC AVERAGE_DECLARE_VALUE_MAX @TradeNID			 	
	if LOWER(@platform)='paypal' or LOWER(@platform)='ebay' --Paypal时		 	
	  EXEC P_XS_CheckTradeDiffAddr @TradeNID
	--组合品单独考虑 cuifeng	
	update
		 d
	set
		d.[Weight]=isnull(g.[Weight],0)/1000.00,
		d.DeclaredValue = case when ISNULL(g.DeclaredValue,0)=0 then d.DeclaredValue else g.DeclaredValue end,
		d.AliasCnName = case when ISNULL(g.AliasCnName,'')='' then d.AliasCnName else g.AliasCnName end,
		d.AliasenName = case when ISNULL(g.AliasenName,'')='' then d.AliasenName else g.AliasenName end					
	from 
		P_TradeDt d
	inner join B_GoodsSKU gs on gs.SKU=d.ebaySKU
	inner join B_Goods g on g.NID=gs.GoodsID				
	where
		d.TradeNID=@TradeNID and  d.L_EBAYITEMTXNID <> '' and g.GroupFlag=1	
	--cf 20161103 	
	if isnull((select Paravalue from B_SysParams where ParaCode='AutoCalcStore'),0)>0
	 EXEC P_FR_CalcStore @TradeNID,0
  --没有默认发货仓库的改为默认发货仓库
  BEGIN TRY
    update
      D
    set     
      d.StoreID=@DefStoreID 
    from 
      P_TradeDt D	 		
    where	
      TradeNID=@TradeNID
      and ISNULL(d.StoreID,0) = 0 
  END TRY
  BEGIN CATCH
  END CATCH		
  --更新汇率
  BEGIN TRY
    update
      m
    set     
      m.EXCHANGERATE=c.ExchangeRate
    from 
      P_Trade m	
    inner join B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE 		
    where	m.nid=@TradeNID
  END TRY
  BEGIN CATCH
  END CATCH		  		
END
