
CREATE proc  [dbo].[P_XS_TradeException]
	@TradeNID int=0,
	@ExceptionType int=0,
	@ExceptionName varchar(20)=''
 as
 begin
	set nocount on 
	declare @Errorcount int=0
	declare @BatchNum varchar(50)=''
	Declare @FuncId	int=0
	Declare @FilterFlag int=0 
	set @FilterFlag=(select top 1 filterflag from P_Trade where NID=@TradeNID)
	begin tran XS_TradeException
		if @ExceptionType=0 
			set @FuncId=100
		else 
		if @ExceptionType=1 
			set @FuncId=110
		else 
		if @ExceptionType=2 
			set @FuncId=120
		else 
		if @ExceptionType=3
			set @FuncId=130
		else 
		if @ExceptionType=4
			set @FuncId=130		
		create Table #t
		(
			Maxbillcode varchar(100)
		)
		insert into #t 
		exec P_S_CodeRuleGet @FuncId,@BatchNum output
		
		set @Errorcount=@@ERROR		
		--IF (ISNULL((SELECT TOP 1 FilterFlag  
		--			FROM P_Trade WHERE NID = @TradeNID ),0) > 5) 
		--BEGIN 
		--	EXEC P_KC_FreeReservationNum @TradeNid
		--END ELSE 
		--BEGIN 
		--	SELECT 0 AS result, '' AS Msg 
		--END
		
		UPDATE 
			p_trade 
		SET 
			FilterFlag=case when @FilterFlag < 20 then @ExceptionType  else FilterFlag end
		   ,PROTECTIONELIGIBILITYTYPE=@ExceptionName 
		   ,BatchNum=@BatchNum
		WHERE 
			nid = @TradeNID
			
		set @Errorcount=@@ERROR +@Errorcount
		if @FilterFlag >=5 and @FilterFlag < 20
		begin   
			INSERT INTO P_TradeUn SELECT * FROM P_Trade WHERE NID =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount   
			INSERT INTO P_TradeDtUn  SELECT * FROM P_TradeDt WHERE TradeNID  =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount  
			if  @Errorcount=0 
			begin   
				DELETE FROM P_Trade WHERE NID =@TradeNID
				DELETE FROM P_TradeDt WHERE TradeNID = @TradeNID
				--insert into P_TradeLogs(TradeNID,Logs,Operator)
				--select @TradeNID,@CurrentUser + ' '+getDate() + ' 订单"' + @TradeNID + '" 已发货,将转至退货订单环节！',@CurrentUser
 				set @Errorcount=@@ERROR +@Errorcount  
			end else
			begin
				DELETE FROM P_TradeUn WHERE NID  = @TradeNID
				DELETE FROM P_TradeDtUn WHERE TradeNID = @TradeNID
				--insert into P_TradeLogs(TradeNID,Logs,Operator)
				--select @TradeNID,@CurrentUser + ' '+getDate() + ' 订单"' + @TradeNID + '" 已发货,将转至退货订单环节！',@CurrentUser			
				set @Errorcount=@@ERROR +@Errorcount  
			end
		end
		if @ExceptionType=1 and @FilterFlag < 20
		begin
			UPDATE 
				P_TradeDtUn SET L_SHIPPINGAMT=1
			WHERE 
				tradenid =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount  			
			EXEC P_CG_CheckNewOutOfStock  @TradeNID
			set @Errorcount=@@ERROR +@Errorcount  
		end		 
	if @Errorcount=0 
	begin
		commit tran XS_TradeException
	end
	else
	begin
		rollback tran XS_TradeException	
	end
	select @Errorcount as Errorcount
	set nocount off	
end

