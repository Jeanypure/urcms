--P_XS_TradeExists 'ebay','1','allroot','257','123-456'
CREATE proc [dbo].[P_XS_TradeExists]
	@platform	varchar(20),
	@PPTransID	varchar(30),
	@SellerID	varchar(100),
	@ACK		varchar(50),
	@OrderID	varchar(100),
	@ItemID		varchar(50),
	@TransID	varchar(100)	
as
begin
	if @platform='ebay'
	begin
			--ACK=@ack and 
			--and [guid]=@OrderID	
			--[user]=@SellerID	
			--and ADDRESSOWNER=@platform	
		if @TransID<>'' 
		begin
			select 
				top 1 p.NID 
			from 
				P_Trade p
			where
				([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
				or
				exists(select NID from P_TradeDt 
								where TradeNID=p.nid
										and L_EBAYITEMTXNID=@TransID 
										and L_NUMBER=@ItemID)
				
				
			union 
			select 
				top 1 p.NID 
			from 
				P_trade_b p
			where
				([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
				or
				exists(select NID from P_Trade_bDt 
								where TradeNID=p.nid
										and L_EBAYITEMTXNID=@TransID 
										and L_NUMBER=@ItemID)
			union 
			select 
				top 1 p.NID 
			from 
				P_tradeUn p
			where
			    ([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
				or
				exists(select NID from P_TradeDtun 
								where TradeNID=p.nid
										and L_EBAYITEMTXNID=@TransID 
										and L_NUMBER=@ItemID)
			union 
			select 
				top 1 p.NID 
			from 
				P_trade_His p
			where
			    ([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
				or
				exists(select NID from P_TradeDt_His 
								where TradeNID=p.nid
										and L_EBAYITEMTXNID=@TransID 
										and L_NUMBER=@ItemID)				
			union 
			select 
				top 1 p.NID 
			from 
				P_TradeUn_His p
			where
			    ([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
				or
				exists(select NID from P_TradeDtUn_His 
								where TradeNID=p.nid
										and L_EBAYITEMTXNID=@TransID 
										and L_NUMBER=@ItemID)
		end
		else
		begin
			select 
				top 1 p.NID 
			from 
				P_Trade p
			where
			    ([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 				
			union 
			select 
				top 1 p.NID 
			from 
				P_trade_b p
			where
			    ([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
			union 
			select 
				top 1 p.NID 
			from 
				P_tradeUn p
			where
				([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
			union 
			select 
				top 1 p.NID 
			from 
				P_trade_His p
			where
				([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 			
			union 
			select 
				top 1 p.NID 
			from 
				P_TradeUn_His p
			where
				([guid]=@OrderID) or
				( TRANSACTIONID=@PPTransID) 
		end
	end
		

end