
CREATE proc [dbo].[P_XS_TradeFailureAdd]
			@Platform  varchar(50)
           ,@SellerID varchar(100)
           ,@MarketID varchar(50)
           ,@PaypalMail varchar(100)
           ,@TRANSACTIONID varchar(50)
           ,@OrderID varchar(100)
           ,@Msg varchar(5000)
as
begin
	if (@Platform='paypal') and  (not exists( select nid from p_tradeFailure where TRANSACTIONID=@TRANSACTIONID))
	begin
		INSERT INTO [P_TradeFailure]
			   ([Platform]
			   ,[SellerID]
			   ,[MarketID]
			   ,[PaypalMail]
			   ,[TRANSACTIONID]
			   ,[OrderID]
			   ,[Msg])
		 VALUES
			   (@Platform
			   ,@SellerID
			   ,@MarketID
			   ,@PaypalMail
			   ,@TRANSACTIONID
			   ,@OrderID
			   ,@Msg)
	end		   
end

