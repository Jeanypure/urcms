create proc [dbo].[P_XS_TradeFromeBay]
	@TradeNID_A int=0
as
begin
  if (not exists(select nid from P_Trade 
					where ADDRESSOWNER='ebay' and [guid]=(select top 1 [Guid] from p_trade_A where NID=@TradeNID_A)))
		and (exists(select nid from P_Trade_ADT where tradenid=@TradeNID_A))
  begin
		BEGIN TRAN crSave_A 
		DECLARE @ins_error INT 
		DECLARE @TradeNID INT 
		--有附表再转
		INSERT INTO P_Trade(FilterFlag,PAYERID,
				  EMAIL,COUNTRYCODE,SALUTATION,ADDRESSOWNER,RECEIVERBUSINESS,RECEIVEREMAIL, 
				 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
				 SHIPTONAME, 
				 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
				 SHIPTOCOUNTRYCODE,SHIPTOCOUNTRYNAME,SHIPTOPHONENUM,TRANSACTIONID,
				 TRANSACTIONTYPE,PAYMENTTYPE,
				 ORDERTIME,TIMESTAMP,AMT,FEEAMT,CURRENCYCODE,SHIPDISCOUNT,ADDRESSSTATUS,
				 PAYMENTSTATUS,NOTE,subject,memo,BUYERID, 
				 ACK,SHIPPINGAMT,[Guid],CLOSINGDATE, 
				 CUSTOM,TrackNo,[User]) 
            SELECT FilterFlag,PAYERID,
				  EMAIL,COUNTRYCODE,SALUTATION,ADDRESSOWNER,RECEIVERBUSINESS,RECEIVEREMAIL, 
				 SUFFIX,SHIPPINGMETHOD,ExpressStatus,
				 SHIPTONAME, 
				 SHIPTOSTREET,SHIPTOSTREET2,SHIPTOCITY,SHIPTOSTATE,SHIPTOZIP,
				 SHIPTOCOUNTRYCODE,
				 --这里根据国家二字码特殊判断，目前为西班牙,德国,比利时
				 case when SHIPTOCOUNTRYCODE = 'ES' then 'Spain' 
                                      when SHIPTOCOUNTRYCODE = 'DE' then 'Germany' 
				      when SHIPTOCOUNTRYCODE = 'BE' then 'Belgium'
                                      when SHIPTOCOUNTRYCODE = 'FR' then 'France'
                                      when SHIPTOCOUNTRYCODE = 'HR' then 'Croatia'
                                      when SHIPTOCOUNTRYCODE = 'AT' then 'Austria'
				      else SHIPTOCOUNTRYNAME end,
				 SHIPTOPHONENUM,TRANSACTIONID,
				 TRANSACTIONTYPE,PAYMENTTYPE,
				 ORDERTIME,TIMESTAMP,AMT,FEEAMT,CURRENCYCODE,SHIPDISCOUNT,ADDRESSSTATUS,
				 PAYMENTSTATUS,NOTE,subject,memo,BUYERID, 
				 ACK,SHIPPINGAMT,[Guid],CLOSINGDATE, 
				 CUSTOM,TrackNo,[User]
				 
            FROM P_Trade_A
            WHERE NID =@TradeNID_A  
            SET NOCOUNT ON SELECT @TradeNid =SCOPE_IDENTITY() 
            SELECT @ins_error=@@Error 
            INSERT INTO P_TradeDt(
					TradeNID,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU,
					costprice,AliasCnName,AliasEnName,[Weight],DeclaredValue,OriginCountry,goodsname,
					OriginCountryCode,GoodsSKUID,StoreID,L_TransFee,L_ShipFee) 
				
            SELECT 
				@TradeNid,L_EBAYITEMTXNID, L_NAME, L_NUMBER, L_QTY, L_SHIPPINGAMT, L_CURRENCYCODE,L_AMT, SKU, eBaySKU ,
				isnull(costprice,0),AliasCnName,AliasEnName,isnull([Weight],0),isnull(DeclaredValue,0),
				OriginCountry,goodsname,OriginCountryCode,isnull(GoodsSKUID,0),isnull(StoreID,0),
				L_TransFee,L_ShipFee				
            FROM 
				P_Trade_ADt
            WHERE 
				TradeNID = @TradeNID_A 
            SELECT @ins_error=@ins_error+@@Error   
            UPDATE 
				t 
            SET 
				t.AllGoodsDetail=dbo.Ex_GetOrderSKUS(@TradeNID)
            FROM P_Trade t
            WHERE nid = @TradeNid 
            SELECT @ins_error=@ins_error+@@Error 
            
            --如果设置了美国军方地址修改的参数，那么把美国军方的国家英文名和国家代码修改
            if isnull((select top 1 ParaValue from B_SysParams(nolock) where ParaCode = 'IsTradeFromeBayChgAA'),'0') = '1' 
            begin
              UPDATE t 
              SET t.SHIPTOCOUNTRYNAME = 'United States',
                  t.SHIPTOCOUNTRYCODE = 'US'
              FROM P_Trade t
              WHERE nid = @TradeNid 
              and t.SHIPTOCOUNTRYNAME = 'APO/FPO'
              and t.SHIPTOCOUNTRYCODE = 'AA'
    
              SELECT @ins_error=@ins_error+@@Error 
            end
            
            exec P_XS_TradeDtSKU @TradeNID 
            SELECT @ins_error= @ins_error + @@Error 
            DELETE FROM P_Trade_ADt WHERE TradeNID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
             DELETE FROM P_Trade_A   WHERE NID = @TradeNID_A 
             SELECT @ins_error= @ins_error + @@Error 
            IF @ins_error=0 
            begin
              COMMIT TRAN crSave_A 
              exec S_WriteTradeLogs @TradeNID ,'自动','Srv-eBay'
            end
            ELSE 
             ROLLBACK TRAN crSave_A 
  end          
  else
  begin
	delete from  P_trade_A where nid=@TradeNID_A 
        delete from  P_trade_ADt where TradeNid=@TradeNID_A 
  end 
end
 
