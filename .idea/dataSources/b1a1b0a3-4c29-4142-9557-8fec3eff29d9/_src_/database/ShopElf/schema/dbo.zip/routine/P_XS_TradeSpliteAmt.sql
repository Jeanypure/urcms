create Proc [P_XS_TradeSpliteAmt]
	@TradeNID		int =0,
	@NewTradeNID	int =0,
	@OldAmt			money =0
as
begin
	declare @amt money=0,@newAmt money=0
	
	if exists(select nid from P_Trade(nolock) where nid=@TradeNID )
	begin
	    set @amt=isnull((select SUM(l_amt) from P_TradeDt(nolock) where TradeNID=@TradeNID),0)
	    set @Newamt=isnull((select SUM(l_amt) from P_TradeDt(nolock) where TradeNID=@NewTradeNID),0)
		update t
			set AMT = case when (@amt+@newamt)*@Amt<>0 then @OldAmt/(@amt+@newamt)*@Amt else 0 end
		from p_trade t
		where t.NID=@TradeNID
		update t
			set AMT =case when (@amt+@newamt)*@newAmt<>0 then @OldAmt/(@amt+@newamt)*@newAmt else 0 end
		from p_trade t
		where t.NID=@NewTradeNID
	end
	else
	begin
	    set @amt=isnull((select SUM(l_amt) from P_TradeDtun(nolock) where TradeNID=@TradeNID),0)
	    set @Newamt=isnull((select SUM(l_amt) from P_TradeDtun(nolock) where TradeNID=@NewTradeNID),0)
		update t
			set AMT =case when (@amt+@newamt)*@Amt<>0 then @OldAmt/(@amt+@newamt)*@Amt else 0 end
		from p_tradeun t
		where t.NID=@TradeNID
		update t
			set AMT =case when (@amt+@newamt)*@newAmt<>0 then @OldAmt/(@amt+@newamt)*@newAmt else 0 end
		from P_TradeUn t
		where t.NID=@NewTradeNID

	end

end
