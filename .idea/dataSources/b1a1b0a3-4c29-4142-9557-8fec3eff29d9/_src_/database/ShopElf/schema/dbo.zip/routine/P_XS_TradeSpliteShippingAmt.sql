
CREATE Proc [dbo].[P_XS_TradeSpliteShippingAmt]
	@TradeNID		int =0,
	@NewTradeNID	int =0,
	@OldAmt			money =0,
	@OldShippingAmt	money =0
as
begin
	if exists(select nid from P_Trade where nid=@TradeNID )
	begin
		update t
			set shippingAMT = t.AMT/@OldAmt*@OldShippingAmt
		from p_trade t
		where t.NID=@TradeNID
		update t
			set shippingAMT = t.AMT/@OldAmt*@OldShippingAmt
		from p_trade t
		where t.NID=@NewTradeNID
		update t
			set AMT = shippingAMT+AMT
		from p_trade t
		where t.NID=@TradeNID					
		update t
			set AMT = shippingAMT+AMT
		from p_trade t
		where t.NID=@NewTradeNID	
	end
	else
	begin
		update t
			set shippingAMT = t.AMT/@OldAmt*@OldShippingAmt
		from p_tradeun t
		where t.NID=@TradeNID
		update t
			set shippingAMT = t.AMT/@OldAmt*@OldShippingAmt
		from p_tradeun t
		where t.NID=@NewTradeNID
		update t
			set AMT = shippingAMT+AMT
		from p_tradeun t
		where t.NID=@TradeNID					
		update t
			set AMT = shippingAMT+AMT
		from p_tradeun t
		where t.NID=@NewTradeNID	
	end

end
