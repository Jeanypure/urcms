
CREATE PROCEDURE [dbo].[P_XS_TradeToTradeUn]
	@TradeNID int=0,
	@ExceptionType int=0,
	@ExceptionName varchar(20)=''
 as
 begin
	set nocount on;
	declare @BatchNum varchar(50)=''
	Declare @FuncId	int=0
	Declare @FilterFlag int=0 
	set @FilterFlag=(select top 1 FilterFlag from P_Trade where NID=@TradeNID)
	begin try
    BEGIN TRAN crSave
		if @ExceptionType=0 
			set @FuncId=100
		else 
		if @ExceptionType=1 
			set @FuncId=110
		else 
		if @ExceptionType=2 
			set @FuncId=120
		else 
		if @ExceptionType=3
			set @FuncId=130
		else 
		if @ExceptionType=4
			set @FuncId=130		
		create Table #t
		(
			Maxbillcode varchar(100)
		)
		insert into #t 
		exec P_S_CodeRuleGet @FuncId,@BatchNum output
		UPDATE 
			p_trade 
		SET 
			FilterFlag= @ExceptionType
		   ,PROTECTIONELIGIBILITYTYPE=@ExceptionName 
		   ,BatchNum=@BatchNum
		WHERE 
			nid = @TradeNID
		if @FilterFlag >=5 and @FilterFlag < 100
		begin   
		    delete from P_Trade
				output deleted.* into P_TradeUn
		    WHERE NID =@TradeNID
		    
		    delete from P_TradeDt
				output deleted.* into P_TradeDtUn
		    WHERE TradeNID  =@TradeNID
			
			update P_TradeUn 
				set RestoreStock=0 where NID=@TradeNID				
		end
		if @ExceptionType=1
		begin
			UPDATE 
				P_TradeDtUn SET L_SHIPPINGAMT=1
			WHERE 
				tradenid =@TradeNID
			SET NOEXEC ON 		
			EXEC P_CG_CheckNewOutOfStock  @TradeNID
			SET NOEXEC OFF
		end	
    	Select 0 as Errorcount      
        Commit tran crSave        
	End try                     
	Begin catch                 
		If (@@TRANCOUNT<>0)                            
			rollback tran crSave        
		Select 1 as Errorcount,ERROR_MESSAGE() as msg              
	End catch
	set nocount off;	
end 
