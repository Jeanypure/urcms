create proc [P_XS_TradeToTradeUnNew] 
	@TradeNID int=0,
	@ExceptionType int=0,
	@ExceptionName varchar(20)=''
 as
 begin
	set nocount on 
	declare @Errorcount int=0
	declare @BatchNum varchar(50)=''
	Declare @FuncId	int=0
	Declare @FilterFlag int=0 
	set @FilterFlag=isnull((select top 1 filterflag from P_Trade where NID=@TradeNID),0)
	begin tran XS_TradeException
		if @ExceptionType=0 
			set @FuncId=100
		else 
		if @ExceptionType=1 
			set @FuncId=110
		else 
		if @ExceptionType=2 
			set @FuncId=120
		else 
		if @ExceptionType=3
			set @FuncId=130
		else 
		if @ExceptionType=4
			set @FuncId=130		
		create Table #t
		(
			Maxbillcode varchar(100)
		)
		insert into #t 
		exec P_S_CodeRuleGet @FuncId,@BatchNum output
		
		set @Errorcount=@@ERROR		
		if @FilterFlag>5 and @FilterFlag<10
		begin
			exec P_KC_FreeReservationNum @TradeNID
		end		
		UPDATE 
			p_trade 
		SET 
			FilterFlag= @ExceptionType
		   ,PROTECTIONELIGIBILITYTYPE=@ExceptionName 
		   ,BatchNum=@BatchNum
		WHERE 
			nid = @TradeNID
			
		set @Errorcount=@@ERROR +@Errorcount
		if @FilterFlag >=5 and @FilterFlag < 10
		begin   
			INSERT INTO P_TradeUn SELECT * FROM P_Trade WHERE NID =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount   
			INSERT INTO P_TradeDtUn  SELECT * FROM P_TradeDt WHERE TradeNID  =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount  
			if  @Errorcount=0 
			begin   
				update P_TradeUn set RestoreStock=0 where NID=@TradeNID
				DELETE FROM P_Trade WHERE NID =@TradeNID
				DELETE FROM P_TradeDt WHERE TradeNID = @TradeNID
				
 				set @Errorcount=@@ERROR +@Errorcount  
			end else
			begin
				DELETE FROM P_TradeUn WHERE NID  = @TradeNID
				DELETE FROM P_TradeDtUn WHERE TradeNID = @TradeNID
						
				set @Errorcount=@@ERROR +@Errorcount  
			end
		end
		if @ExceptionType=1
		begin
			UPDATE 
				P_TradeDtUn SET L_SHIPPINGAMT=1
			WHERE 
				tradenid =@TradeNID
			set @Errorcount=@@ERROR +@Errorcount  
			SET NOEXEC ON 		
			EXEC P_CG_CheckNewOutOfStock  @TradeNID
			SET NOEXEC OFF
			set @Errorcount=@@ERROR +@Errorcount  
		end		 
	if @Errorcount=0 
	begin
		commit tran XS_TradeException
		EXEC S_WriteTradeLogs	@tradenid,'WishServer标记发货时判断异常，转取消单','SysUser'	
	end
	else
	begin
		rollback tran XS_TradeException	
	end
	select @Errorcount as Errorcount
	set nocount off	
end
