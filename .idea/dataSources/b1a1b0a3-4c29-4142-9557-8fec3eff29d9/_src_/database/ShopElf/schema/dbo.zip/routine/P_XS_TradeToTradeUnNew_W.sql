Create proc [dbo].[P_XS_TradeToTradeUnNew_W] 
    @TradeNID int=0
   as
 begin
   set nocount on;	--使返回的结果中不包含有关受 Transact-SQL 语句影响的行数的信息
   DECLARE 
     @FilterFlag int=0
   -- 历史订单不考虑了
   if exists(select 1 from P_TradeUn where NID=@TradeNID)
   begin
     -- 缺货订单转异常单
     EXEC P_ExceptionTradeToException @TradeNID,3,'取消订单',''
     -- 插入日志
     INSERT INTO [P_TradeLogs] ([TradeNID] ,[Operator]  ,[Logs])
      select @TradeNID,'ADMIN','ADMIN' +' '+ CONVERT(VARCHAR(30),GETDATE(),121)+' ' + '自动标记发货异常转取消单' 
     select 0 as 'result'
   end
   else
   if exists(select 1 from P_Trade where NID=@TradeNID)
   begin
     begin try 
     BEGIN TRAN crSave
		 -- 先驳回到待派单
		 EXEC OrderReturnBack @TradeNID, '1', 'ADMIN' 
		 set @FilterFlag=ISNULL((select FilterFlag from P_Trade where NID=@TradeNID),5)
		 -- 判断是否驳回成功 
		 
		 if @FilterFlag=5
		 begin
		     -- 转取消单
			 UPDATE p_trade  SET FilterFlag=3,PROTECTIONELIGIBILITYTYPE= '取消订单' where NID=@TradeNID
			 insert into P_TradeUn
			 select * from P_Trade where NID =@TradeNID
			 insert into P_TradeDtUn 
			 select * from P_TradeDt where TradeNID=@TradeNID
			 delete from P_Trade where NID=@TradeNID
			 delete from P_TradeDt where TradeNID=@TradeNID
			 -- 插入日志
			INSERT INTO [P_TradeLogs] ([TradeNID] ,[Operator]  ,[Logs])
			 select @TradeNID,'ADMIN','ADMIN' +' '+ CONVERT(VARCHAR(30),GETDATE(),121)+' ' + '自动标记发货异常转取消单'
			 Commit tran crSave
			 select 0 as 'result'
		 end
		 else
		 begin
		    rollback tran crSave
			-- 错误 
			select 1 as 'result'
		 end
	  End try    
	  Begin catch   
		  If (@@TRANCOUNT<>0) 
		  Begin    
			rollback tran crSave
			-- 错误 
			select 1 as 'result'
		  End
	  End catch   
   end
   else
   begin
     -- 插入日志
		INSERT INTO [P_TradeLogs] ([TradeNID] ,[Operator]  ,[Logs])
		 select @TradeNID,'ADMIN','ADMIN' +' '+ CONVERT(VARCHAR(30),GETDATE(),121)+' ' + '自动标记发货失败,该订单已取消!'
		 select 0 as 'result'
   end
 end
