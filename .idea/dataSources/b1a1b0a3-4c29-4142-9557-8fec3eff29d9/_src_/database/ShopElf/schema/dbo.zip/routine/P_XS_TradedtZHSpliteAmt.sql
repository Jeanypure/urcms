
CREATE Proc [P_XS_TradedtZHSpliteAmt]
	@TradeNID int =0
as
begin
	if exists(select nid from P_TradeDt where tradenid=@TradeNID and 
			eBaySKU<>SKU 
			and L_OPTIONSVALUE=1 and  eBaySKU<>'' )
	begin
		update dt
			set dt.L_OPTIONSNAME= case when isnull(L_OPTIONSNAME,'0')='0' then l_amt else  L_OPTIONSNAME end,
				dt.L_AMT = (case when isnull(sm.costmoney,0)=0 then dt.L_AMT else sm.amt*dt.CostPrice /isnull(sm.costmoney,0) end)
		from p_tradedt dt
		inner join (
			select SUM(L_AMT) as amt,eBaySKU,SUM(CostPrice) as costmoney, L_TAXAMT,L_OPTIONSVALUE,TradeNID
			from P_tradedt 
			where tradenid=@TradeNID 
			group by eBaySKU,L_TAXAMT,L_OPTIONSVALUE,TradeNID 
		) as sm on sm.ebaysku=dt.eBaySKU and sm.L_TAXAMT=dt.L_TAXAMT 
					and sm.L_OPTIONSVALUE=dt.L_OPTIONSVALUE and sm.tradenid=dt.TradeNID
		where dt.TradeNID=@TradeNID
	end

end
