CREATE proc [P_XS_UpdateAmazonOrderFees]
	@settlementid		varchar(30)
as
begin
	Create Table  #Settlement
	(
		  orderid varchar(30),
		  feessum numeric(10, 4),
		  primary key (orderid)
	)	
	Create Table  #Settlementhb
	(
		  tradenid int,
		  feessum numeric(10, 4),
		  primary key (tradenid)
	)	
	--汇总	
	insert into #Settlement
	select 
		orderid,
		abs(SUM(itemfeeamount)+SUM(otherfeeamount)+SUM(promotionamount)+SUM(otheramount)+SUM(priceamount)) as feessum
	from 
		XS_AmazonSettlement
	where 
		settlementid=@settlementid 
		and transactiontype='order' 
		and pricetype <> 'Principal'
		and (pricetype <> 'Shipping'  and fulfillmentid='MFN')
		--and itemfeetype <>'ShippingChargeback' 
		--and promotiontype <> 'Shipping'
		and promotiontype <> 'Principal' --促销减款
		and itemfeetype <> 'GiftwrapChargeback'
	group by 
		orderid
	union 
	select 
		orderid,
		abs(SUM(itemfeeamount)+SUM(otherfeeamount)+SUM(promotionamount)+SUM(otheramount)+SUM(priceamount)) as feessum
	from 
		XS_AmazonSettlement
	where 
		settlementid=@settlementid 
		and transactiontype='order' 
		and pricetype <> 'Principal'
		and  fulfillmentid='AFN'
		--and itemfeetype <>'ShippingChargeback' 
		--and promotiontype <> 'Shipping'
		and promotiontype <> 'Principal' --促销减款
		and itemfeetype <> 'GiftwrapChargeback'
	group by 
		orderid			
	--合并订单
	insert into #Settlementhb
	select 
		p.MergeBillID ,
		abs(SUM(s.feessum)) as feessum
	from P_Trade_b p 
	inner join #Settlement s on s.orderid=p.ACK		
	group by p.MergeBillID
	--s.feessum*p.amt/(isnull((select sum(AMT)  from P_Trade_His where ACK=p.ack),1)*1.0000)			
	--p_trade--非合并的
	update P
	set p.FEEAMT=case when isnull((select sum(AMT)  from P_Trade where ACK=p.ack),0)=0 then 0 
	   else s.feessum*p.amt/(isnull((select sum(AMT)  from P_Trade where ACK=p.ack),1)*1.0000) end 
	--s.feessum*p.amt/(isnull((select sum(AMT)  from P_Trade_His where ACK=p.ack),1)*1.0000)
	from P_Trade p 
	inner join #Settlement s on s.orderid=p.ACK		
	where isnull(MergeFlag,0)=0 --非合并的
	--p_trade--合并的
	update P
	set p.FEEAMT=s.feessum
	from P_Trade p 
	inner join #Settlementhb s on s.tradenid=p.nid		
	where isnull(MergeFlag,0)=1

	--p_trade_his--非合并的
	update P
	set p.FEEAMT=case when isnull((select sum(AMT)  from P_Trade_His where ACK=p.ack),0)=0 then 0 else s.feessum*p.amt/(isnull((select sum(AMT)  from P_Trade_His where ACK=p.ack),1)*1.0000) end
	from p_trade_his p 
	inner join #Settlement s on s.orderid=p.ACK		
	where isnull(MergeBillID,0)=0 --非合并的
	--p_trade_his--合并的
	update P
	set p.FEEAMT=s.feessum
	from p_trade_his p 
	inner join #Settlementhb s on s.tradenid=p.nid		
	where isnull(MergeBillID,0)=1		
	
	--p_tradeun--非合并的
	update P
	set p.FEEAMT=case when isnull((select sum(AMT)  from P_Tradeun where ACK=p.ack),0)=0 
				then 0 else s.feessum*p.amt/(isnull((select sum(AMT)  from p_tradeun where ACK=p.ack),1)*1.0000) end
	from p_tradeun p 
	inner join #Settlement s on s.orderid=p.ACK		
	where isnull(MergeFlag,0)=0 --非合并的
	--p_tradeun--合并的
	update P
	set p.FEEAMT=s.feessum
	from p_tradeun p 
	inner join #Settlementhb s on s.tradenid=p.nid		
	where isnull(MergeFlag,0)=1	
end

