CREATE PROCEDURE [P_XS_UpdateProfitMoney] 
	@TradeNid INT = 0
AS
BEGIN

	BEGIN TRY
		UPDATE pt
		SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.nid),0),
			pt.ExpressFare=isnull((dbo.Ex_Fr_CalcShippingCost(pt.ExpressNID,pt.logicsWayNID,SHIPTOCOUNTRYCODE,pt.TotalWeight,pt.shiptozip)),0)
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
			    
		UPDATE pt
		SET pt.GoodsCosts=ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.NID),0),
			pt.ProfitMoney=isnull(((pt.AMT-pt.SHIPDISCOUNT-pt.FEEAMT)*c.ExchangeRate-ISNULL((select sum(costprice) from p_tradedt where tradenid=pt.nid),0)-
			ExpressFare),0)
		FROM P_Trade pt
		left outer join B_currencycode c on c.CURRENCYCODE=pt.CURRENCYCODE
		WHERE pt.NID = @TradeNID
	END TRY
	BEGIN CATCH
	END CATCH	 
END
