create proc [P_XS_WaitPackageCount]
		@Suffixs	varchar(50),
		@BeginDate datetime,
		@EndDate   datetime,
		@UserId		varchar(20)
as
begin
   set nocount on
	if @UserId='0' --全部
	begin
		select count(1) as ocount,'UnIsPacking' as itype from P_Trade (nolock) 
		where FilterFlag = 20
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'UnChecked' from P_Trade (nolock)
		where FilterFlag = 22
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'UnPackage' from P_Trade (nolock)
		where FilterFlag = 24
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'CancelTrade' from P_TradeUn (nolock)
		where FilterFlag = 3  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OtherPlm' from P_TradeUn (nolock)
		where FilterFlag = 4  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock' from P_Trade (nolock)
		where FilterFlag = 26  
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStockWaitPacking' from P_Trade(nolock) 
		where FilterFlag = 28   
				and ordertime>=@BeginDate and ordertime<=@EndDate 	
	end
	else
	if @Suffixs<>'0' and charindex(',',@Suffixs)=0
	begin
		select count(1) as ocount,'UnIsPacking' as itype from P_Trade(nolock) 
		where FilterFlag = 20
				and ordertime>=@BeginDate and ordertime<=@EndDate 
				and SUFFIX = @Suffixs
		union all
		select count(1),'UnChecked' from P_Trade (nolock)
		where FilterFlag = 22
				and ordertime>=@BeginDate and ordertime<=@EndDate 
				and SUFFIX = @Suffixs
		union all
		select count(1),'UnPackage' from P_Trade (nolock)
		where FilterFlag = 24
				and ordertime>=@BeginDate and ordertime<=@EndDate 
				and SUFFIX = @Suffixs
		union all
		select count(1),'CancelTrade' from P_TradeUn (nolock)
		where FilterFlag = 3 and SUFFIX=@Suffixs  
		        and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OtherPlm' from P_TradeUn (nolock)
		where FilterFlag = 4 and SUFFIX=@Suffixs   
		        and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock' from P_Trade (nolock)
		where FilterFlag = 26   
				and ordertime>=@BeginDate and ordertime<=@EndDate 
				and SUFFIX = @Suffixs
		union all
		select count(1),'OutStockWaitPacking' from P_Trade (nolock)
		where FilterFlag = 28  
				and ordertime>=@BeginDate and ordertime<=@EndDate 	
				and SUFFIX = @Suffixs
	end
	else
	begin

		select count(1) as ocount,'UnIsPacking' as itype 
		from P_Trade(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 20
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'UnChecked' 
		from P_Trade(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 22
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'UnPackage' 
		from P_Trade(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 24
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'CancelTrade' 
		from P_TradeUn(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 3  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OtherPlm' 
		from P_TradeUn(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 4  and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStock' 
		from P_Trade(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 26 
				and ordertime>=@BeginDate and ordertime<=@EndDate 
		union all
		select count(1),'OutStockWaitPacking' 
		from P_Trade(nolock)  m
		inner join S_UserSuffix s on s.Suffix=m.SUFFIX and s.UserID=@UserID
		where FilterFlag = 28 
				and ordertime>=@BeginDate and ordertime<=@EndDate 	
				
	end
end
