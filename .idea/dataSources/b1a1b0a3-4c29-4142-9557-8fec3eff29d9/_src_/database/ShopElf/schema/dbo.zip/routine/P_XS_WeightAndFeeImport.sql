create PROCEDURE [dbo].[P_XS_WeightAndFeeImport] 
@NID VARCHAR(100) = '',
@TotalWeight NUMERIC(10,4) = 0,
@ExpressFee  NUMERIC(10,2) = 0,
@iType  int,
@IsZeroIn int 	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ReturnStr VARCHAR(500) = '', @Sql varchar(1000),@TempNid varchar(100) = ''
	IF (@iType = 0)   --按订单号导入
	BEGIN
	set @TempNid = @NID 	            
	  IF EXISTS(SELECT 1 FROM P_Trade WHERE NID = @NID) 
			or EXISTS(SELECT 1 FROM P_Trade_His WHERE NID = @NID)          
	  BEGIN	  	
	    if @IsZeroIn = 1 begin 
	  	  UPDATE P_Trade	SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE NID = @NID
	  	  UPDATE P_Trade_His	SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE NID = @NID	 
	  	end
	  	else begin
	  	  if (@TotalWeight <> 0) and (@ExpressFee <> 0) begin
	  	    UPDATE P_Trade	SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee WHERE NID = @NID 
	  	    UPDATE P_Trade_His	SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee WHERE NID = @NID 
	  	  end
	  	  else if (@TotalWeight <> 0) begin
	  	    UPDATE P_Trade	SET TotalWeight = @TotalWeight  WHERE NID = @NID 
	  	    UPDATE P_Trade_His	SET TotalWeight = @TotalWeight  WHERE NID = @NID 
	  	  end
	  	  else if (@ExpressFee <> 0) begin
	  	    UPDATE P_Trade	SET ExpressFare = @ExpressFee  WHERE NID = @NID 
	  	    UPDATE P_Trade_His	SET ExpressFare = @ExpressFee  WHERE NID = @NID 
	  	  end 
	  	end
		  
	  	SET @ReturnStr = '订单号"'+@NID +'"的重量和运费导入成功!'		
	  END ELSE
	  BEGIN
	  	SET @ReturnStr = '订单号"'+@NID +'"未找到，导入失败!'	
	  END
	END ELSE
	BEGIN      --按跟踪号导入
	  IF EXISTS(SELECT 1 FROM P_Trade WHERE TrackNo = @NID) 
			or EXISTS(SELECT 1 FROM P_Trade_His WHERE TrackNo = @NID) 
	  BEGIN	
	  set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade where TrackNo = @NID),'0')
	  if @TempNid = '0' begin
	    set @TempNid = IsNull((select top 1 convert(varchar(32),Nid) from p_Trade_His where TrackNo = @NID),'0')
	  end
	    	
	    if @IsZeroIn = 1 begin 
	  	  UPDATE P_Trade SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE TrackNo = @NID
	   	  UPDATE P_Trade_His SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE TrackNo = @NID		 
	  	end
	  	else begin
	  	  if (@TotalWeight <> 0) and (@ExpressFee <> 0) begin
	  	    UPDATE P_Trade SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE TrackNo = @NID
	   	    UPDATE P_Trade_His SET TotalWeight = @TotalWeight,ExpressFare = @ExpressFee  	WHERE TrackNo = @NID	
	  	  end
	  	  else if (@TotalWeight <> 0) begin
	  	    UPDATE P_Trade SET TotalWeight = @TotalWeight WHERE TrackNo = @NID
	   	    UPDATE P_Trade_His SET TotalWeight = @TotalWeight WHERE TrackNo = @NID
	  	  end
	  	  else if (@ExpressFee <> 0) begin
	  	    UPDATE P_Trade SET ExpressFare = @ExpressFee WHERE TrackNo = @NID
	   	    UPDATE P_Trade_His SET ExpressFare = @ExpressFee WHERE TrackNo = @NID
	  	  end 
	  	end
  
	  	SET @ReturnStr = '跟踪号"'+@NID +'"的重量和运费导入成功!'		
	  END ELSE
	  BEGIN
	  	SET @ReturnStr = '跟踪号"'+@NID +'"未找到，导入失败!'	
	  END	
	END
	SELECT @ReturnStr AS ReturnStr, @TempNid as Nid
END
