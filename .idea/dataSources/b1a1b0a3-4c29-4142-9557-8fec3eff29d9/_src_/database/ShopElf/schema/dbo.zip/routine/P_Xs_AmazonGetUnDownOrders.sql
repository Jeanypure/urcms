
CREATE proc [dbo].[P_Xs_AmazonGetUnDownOrders]
as
begin
	select 
		top 5000
		a.ACK as orderid,
		a.NID,
		a.suffix as AliasName,
		s.MarketplaceId,
		s.SellerId,
		s.SecretKey,
		s.WebSite,
		s.AWSAccessKeyId
	from 
		P_Trade_A a
	inner join 
		S_AmazonSyncInfo s on a.[User]=s.SellerId and a.INVNUM = s.MarketplaceId
	where
		a.ADDRESSOWNER='amazon11' 
		and DATEDIFF(dd,a.ORDERTIME,getdate())<60
		and not exists(select NID from P_Trade_ADt where TradeNID=a.NID)
end

