create proc [P_Xs_AmazonGetUnDownOrdersNew]
	@sellerid varchar(50),
	@MarketplaceId varchar(50)
as
begin
	select 
	    distinct top 1000
		a.ACK as orderid,
		a.NID,
		a.suffix as AliasName,
		s.MarketplaceId,
		s.SellerId,
		s.SecretKey,
		s.WebSite,
		s.AWSAccessKeyId
	from 
		P_Trade_A a
	inner join 
		S_AmazonSyncInfo s on a.[User]=s.SellerId and s.AliasName=a.SUFFIX
	where
		a.ADDRESSOWNER='amazon11' 
		and a.[user]=@sellerid 
		and s.MarketplaceId=@MarketplaceId
		and DATEDIFF(dd,a.ORDERTIME,getdate())<90
		and not exists(select NID from P_Trade_ADt where TradeNID=a.NID)

end
