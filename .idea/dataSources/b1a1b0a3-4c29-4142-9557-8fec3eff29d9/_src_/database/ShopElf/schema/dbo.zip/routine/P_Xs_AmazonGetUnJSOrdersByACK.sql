Create proc [P_Xs_AmazonGetUnJSOrdersByACK]
	@ACK varchar(50)
as
begin
	select 
	    distinct top 2
		a.ACK as orderid,
		a.NID,
		hbnid=0,
		a.suffix as AliasName,
		s.MarketplaceId,
		s.SellerId,
		s.SecretKey,
		s.WebSite,
		s.AWSAccessKeyId,
		'0' as MergeFlag,
		'0' as TableFlag,
		shipType=case when CHARINDEX('AFN',a.custom)>0 then 'AFN' else 'MFN' end
	from 
		P_Trade(nolock) a
	inner join 
		S_AmazonSyncInfo s on a.[User]=s.SellerId and s.AliasName=a.SUFFIX
	where
		a.ADDRESSOWNER='amazon11' and FilterFlag=100 and isnull(MergeFlag,0)=0  --非合并
		and isnull(a.PAYERSTATUS,'')<>'999' --999是已经下载的
		and a.[ack]=@ACK 
		and SALUTATION<>'售后'
		and DATEDIFF(dd,a.ORDERTIME,getdate())<65
	union all
	select 
	    distinct top 2
		a.ACK as orderid,
		tt.NID,
		hbnid=a.nid,
		a.suffix as AliasName,
		s.MarketplaceId,
		s.SellerId,
		s.SecretKey,
		s.WebSite,
		s.AWSAccessKeyId,
		'1' as MergeFlag,
		'0' as TableFlag,
		shipType=case when CHARINDEX('AFN',tt.custom)>0 then 'AFN' else 'MFN' end
	from 
		P_Trade_b(nolock) a
	inner join P_Trade(nolock) tt on tt.NID=a.MergeBillID 
	inner join 
		S_AmazonSyncInfo s on tt.[User]=s.SellerId and s.AliasName=tt.SUFFIX
	where
		a.ADDRESSOWNER='amazon11' and tt.FilterFlag=100 and isnull(tt.MergeFlag,0)=1 
		and isnull(tt.PAYERSTATUS,'')<>'999' --999是已经下载的
		and a.[ack]=@ACK 
		and tt.SALUTATION<>'售后'
		and DATEDIFF(dd,tt.ORDERTIME,getdate())<65
end
