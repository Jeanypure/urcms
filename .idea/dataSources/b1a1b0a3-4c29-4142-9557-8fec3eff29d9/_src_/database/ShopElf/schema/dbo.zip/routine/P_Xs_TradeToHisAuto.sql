
CREATE Proc [dbo].[P_Xs_TradeToHisAuto]
	@Days int =15
as
begin
	declare @ErrorCount int=0  
	declare @RMaxBillCode varchar(20)
	exec  P_S_CodeRuleGet 230,@RMaxBillCode OUTPUT
	if isnull(@RMaxBillCode,'')=''
	  set @RMaxBillCode='ZLSD-'+CONVERT(varchar(10),GETDATE(),121)+'-0001'
	else
	  set @RMaxBillCode = 'Z'+@RMaxBillCode
	begin tran turntohis  
		UPDATE p_trade 
		SET ExpressStatus=1,FilterFlag=200,BatchNum=@RMaxBillCode 
		WHERE FilterFlag=100  And CONVERT(varchar(10),ordertime,121) <= CONVERT(varchar(10),DATEADD(DD,-@Days, GETDATE()),121) 
		 delete from  P_TradeDt_His  
		 WHERE TradeNID in (SELECT NID FROM P_Trade WHERE FilterFlag = 200)  
		 select @ErrorCount=@@Error  
		 INSERT INTO P_TradeDt_His   SELECT * FROM P_TradeDt 
		 WHERE TradeNID in (SELECT NID FROM P_Trade WHERE FilterFlag = 200)  
		 select @ErrorCount=@@Error +@ErrorCount   
		 DELETE FROM P_TradeDt WHERE TradeNID in (SELECT NID FROM P_Trade WHERE FilterFlag = 200)  
		 select @ErrorCount=@@Error +@ErrorCount   
		 delete from P_Trade_His where  nid in (SELECT nid FROM P_trade WHERE FilterFlag = 200)  
		 select @ErrorCount=@@Error +@ErrorCount   
		 INSERT INTO P_Trade_His 
		 SELECT * FROM P_trade WHERE FilterFlag = 200 
		 select @ErrorCount=@@Error +@ErrorCount  
		 DELETE FROM P_trade WHERE FilterFlag = 200  
		 select @ErrorCount=@@Error +@ErrorCount   
	if @ErrorCount=0 
	begin 
		commit tran turntohis 
	end  
	else 
	begin 
		rollback tran turntohis 
	end  
end

