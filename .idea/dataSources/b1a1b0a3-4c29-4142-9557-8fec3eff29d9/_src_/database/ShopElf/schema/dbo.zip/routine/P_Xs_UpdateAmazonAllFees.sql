create proc [P_Xs_UpdateAmazonAllFees]
as
begin
	declare @settlementid varchar(200)
	Declare 
				amaCur Cursor For select distinct settlementid  from XS_AmazonSettlement where ISNULL(settlementid,'')<>''
			Open amaCur
			Fetch Next From amaCur Into @settlementid
			While (@@Fetch_Status=0)
			begin
              exec P_XS_UpdateAmazonOrderFees  @settlementid

			  Fetch Next From amaCur Into @settlementid
			end
			Close amaCur
			Deallocate amaCur

end
