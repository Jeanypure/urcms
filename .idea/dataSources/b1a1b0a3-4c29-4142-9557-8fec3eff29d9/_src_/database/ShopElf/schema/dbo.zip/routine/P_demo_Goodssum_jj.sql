CREATE PROCEDURE [dbo].[P_demo_Goodssum_jj]
--ljj 上海幽然2016-09-27 测试统计报表中商品统计
--@Suffix varchar(20),  
@BeginDate  varchar(20),
@EndDate varchar(20)
 

AS
BEGIN
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
CREATE TABLE #fGoods(
sku VARCHAR(100),
l_qty int,
l_AMT money,
costmoney money,
Interest money
)

INSERT INTO #fGoods
SELECT 
ISNULL(d.SKU, '') as SKU ,
sum(d.l_qty) as l_qty,
sum(isnull(d.l_amt*isnull(b.ExchangeRate,1),0))as l_ATM,
sum(d.costprice) as costmoney,
sum(d.l_amt*isnull(b.ExchangeRate,1)-d.costprice) as Interest FROM P_TradeDtUn d 
left OUTER JOIN P_TradeUn m on m.nid=d.tradenid 
LEFT OUTER JOIN  B_CurrencyCode b on b.currencycode =m.currencycode
WHERE DateAdd(hour,8,ordertime)>= @BeginDate 
AND DateAdd(hour,8,ordertime)<= @EndDate
--AND SUFFIX in (@Suffix) and ExpressStatus=0 and (isnull(d.sku,'')<>'')
group by isnull(d.SKU,'') UNION all
SELECT isnull(d.SKU,'') as SKU,
sum(d.l_qty) as l_qty,
sum(isnull(d.l_amt*isnull(b.ExchangeRate,1),0)) as l_ATM,
sum(d.costprice) as costmoney,
sum(d.l_amt*(isnull(b.ExchangeRate,1)-d.costprice)) as Interest From P_Tradedt d 
		left outer join p_trade m on m.nid=d.tradenid 
		left outer join B_CurrencyCode b on b.currencycode=m.currencycode 
		WHERE DateAdd(hour,8,ordertime)>=@BeginDate AND DateAdd(hour,8,ordertime)<=@EndDate 
		--AND SUFFIX in (@Suffix) and ExpressStatus=0 and (isnull(d.sku,'')<>'')
		group by isnull(d.sku,'') union all 
		SELECT isnull(d.SKU,'') as SKU,
		sum(d.l_qty) as l_qty,
		sum(isnull(d.l_amt*isnull(b.ExchangeRate,1),0)) as l_ATM,
		sum(d.costprice) as costmoney,
		sum(d.l_amt*isnull(b.ExchangeRate,1)-d.costprice) as Interest from P_TradeDt_His d 
		left outer join P_Trade_His m on m.nid=d.tradenid 
		left outer join B_CurrencyCode b on b.currencycode=m.currencycode
WHERE  DateAdd(hour,8,ordertime)>=@BeginDate AND DateAdd(hour,8,ordertime)<=@EndDate
--AND SUFFIX in (@Suffix) and ExpressStatus=0 and (isnull(d.sku,'')<>'')
group by isnull(d.SKU,'')

SELECT
--图片	SKU	商品编码	商品名称	型号	规格	款式1	款式2	商品类别	销售数量	销售额	销售成本	利润	业绩归属人1	业绩归属人2	采购员	商品创建时间	商品开发时间
d.SKU as SKU,           
g.goodsCode as 商品编码,                 --商品编码
g.goodsName as 商品名称,                        --商品名称
g.Class as 规格,                         
g.Model as 型号,  
isnull(gs.property1,'') as 款式1,
isnull(gs.property2,'') as 款式2,

isnull(gl.CategoryName,'') as 商品类别, --产品类别

sum(d.l_qty) as 销售数量,                  --销售数量
sum(d.l_amt) as 销售额,
sum(d.costmoney) as 销售成本,         --销售成本
sum(d.Interest) as 利润 ,          --利润
                  
                           
g.salername as 业绩归属人1,
g.salername2 as 业绩归属人2,
isnull(g.Purchaser,'') as 采购员,
g.CreateDate as 商品创建日期,
  --转换为 nvarchar类型 使得格式化 能够正确输出

SUBSTRING(convert(nvarchar(50),g.devdate,120),0,12) as 商品开发时间                 -- 开发日期

 from #fGoods d
left outer join B_GoodsSKU gs on isnull(gs.SKU,'')=isnull(d.SKU,'')
left outer join B_Goods g on g.NID =gs.GoodsID left outer join B_Goodscats gl on gl.NID=g.GoodsCategoryID 

group by g.GoodsCode,g.goodsName,g.Class,g.Model,d.SKU,g.salername,g.salername2,g.CreateDate,isnull(gs.property1,'')
,isnull(gs.property2,''),isnull(g.Purchaser,''),g.devdate,
isnull(gl.CategoryName,'')


drop table #fGoods

END




