CREATE PROCEDURE [dbo].[P_demo_zongheyitian]
--@suffix VARCHAR(100)='',--卖家简称
--@SalerName VARCHAR(50)=''--业绩归属人
AS
 
BEGIN

set nocount on 
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
create table #jinyitian(
suffix VARCHAR(100),
SKU varchar(20),
GoodsCode varchar(20),
GoodsName varchar(200),
Categoryname varchar(200),
GoodsSKUStatus varchar(100),
CreateDate varchar(50),
SalerName varchar(50),
SalerName2 varchar(50),
jintian int
)

create table #shangyitian(
suffix VARCHAR(100),
SKU varchar(20),
GoodsCode varchar(20),
GoodsName varchar(200),
Categoryname varchar(200),
GoodsSKUStatus varchar(100),
CreateDate varchar(50),
SalerName varchar(50),
SalerName2 varchar(50),
shangyitian int
)

CREATE table #jinwutian(  --近5天的临时表
suffix VARCHAR(100),
SKU varchar(20),
GoodsCode varchar(20),
GoodsName varchar(200),
Categoryname varchar(200),
GoodsSKUStatus varchar(100),
CreateDate varchar(50),
SalerName varchar(50),
SalerName2 varchar(50),
jinwutian int
)

CREATE table #shangwutian(  --近5天的临时表
suffix VARCHAR(100),
SKU varchar(20),
GoodsCode varchar(20),
GoodsName varchar(200),
Categoryname varchar(200),
GoodsSKUStatus varchar(100),
CreateDate varchar(50),
SalerName varchar(50),
SalerName2 varchar(50),
shangwutian int
)

CREATE TABLE #TempInfotable(
suffix VARCHAR(100),
GoodsCode VARCHAR(20),
GoodsName VARCHAR(200),
Categoryname VARCHAR(200),
GoodsSKUStatus VARCHAR(100),
CreateDate VARCHAR(50),
SalerName VARCHAR(50),
SalerName2 VARCHAR(50),
jinyitian int,
shangyitian int,
changeOneDay int,
jinwutian int,
shangwutian int,
changeFiveDay int
)


insert into #jinyitian 
Exec P_demo_salechange2 @DateFlag=0
 
insert into #shangyitian 
Exec P_xiaoliangchange @DateFlag=0

insert into #jinwutian
EXEC P_demo_jinwutian @DateFlag=0

INSERT into #shangwutian 
EXEC P_demo_shangwutian @DateFlag=0



--INSERT INTO #TempInfotable
select * 

from #jinyitian j
full OUTER JOIN #shangyitian s on j.SKU = s.SKU AND j.suffix =s.suffix
full OUTER JOIN #shangwutian sw on sw.SKU =s.SKU AND sw.suffix =s.suffix
FULL OUTER JOIN #jinwutian jw on jw.SKU = s.SKU AND jw.suffix = s.suffix


--,jw.SKU
--ORDER BY GoodsCode ASC
--SELECT * from #TempInfotable

--where SalerName = @SalerName AND suffix= @suffix

--drop #jinyitian
--drop #shangyitian
--drop #jinwutian
--DROP #shangwutian




END