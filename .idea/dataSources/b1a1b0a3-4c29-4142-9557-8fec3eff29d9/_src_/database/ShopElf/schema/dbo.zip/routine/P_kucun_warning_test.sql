CREATE PROCEDURE [dbo].[P_kucun_warning_test]

   --这个是2016-09-21号改写的 缺货商品分析 (上海悠然实业 ljj) 模仿P_KC_StockWarning
	  @MoreStoreID varchar(500),
	  @Used		int,
	  @cg		int,
	  @GoodsCatsCode varchar(200),
	  @index varchar(50),
	  @KeyStr varchar(2000),/*关键字*/
	  @WarningCats VARCHAR(1000),
	  @SupplierName varchar(2000),
      @PageNum int = 100,             --每页记录数
      @PageIndex int = 1,             --页码
      @Purchaser VARCHAR(100),   
      @GoodsUsed varchar(32),  --商品停用情况
      @GoodsState  varchar(2000), --商品sku状态
      @LocationName varchar(120) = '',  --库位
      @MoreSKU  varchar(3000)
AS
BEGIN
SET NOCOUNT ON --一定要加上不然我PHP脚本调用这个存储过程没有返回数据

	declare
		@PageCount int =0,          --输出页数
		@RecCount int=0,            --输出记录数	
		@TmpUsed1 int,
		@TmpUsed2 int,
		@TmpCount int
		SET NOCOUNT ON

		if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end
		
		 
		IF (ISNULL(@Purchaser,'') = '')
	    SET @Purchaser = ''
	    
	    -- add by ylq 2015-04-29  库存预警类别表
	    --创建字段列表
    DECLARE @SqlStr VarChar(Max)
    
    Create Table #StoreTab
    (
      Nid int
    )
    
	CREATE TABLE #WarningCats
	(
		cName varchar(100)
	)
	--add by ylq 2015-05-15  商品sku状态
	CREATE TABLE #SkuState
	(
		cName varchar(100)
	)
	
	--add by ylq 2015-08-31
	Create table #TmpSup
	(
	  cName varchar(200)
	) 
	
	--add by ylq 2015-06-17 商品sku
	Create Table #TmpSku
	(
	  Sku varchar(100)
	 )
	 
--	Create Table #TmpKey
--	(  TmpStr varchar(100)	)
	
	 
	if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
 
	if @GoodsState <> '' 
	begin 
	  SET @SqlStr = 'insert into #SkuState(cName) select ''' + Replace(@GoodsState, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	if @SupplierName <> ''
	begin
	  SET @SqlStr = 'insert into #TmpSup(cName) select ''' + Replace(@SupplierName, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	
	if @WarningCats <> '' 
	begin 
	  SET @SqlStr = 'insert into #WarningCats(cName) select ' + Replace(@WarningCats, ',', ' union select ') 
	  EXEC(@SqlStr) 
	end
	
	if @MoreSKU <> '' 
	begin
	  set @SqlStr = 'insert into #TmpSku(Sku) select ''' + Replace(@MoreSKU, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	
	-- 因为如果是wrNone,也包含空的值
	if EXISTS (select  cName from  #WarningCats where cName = 'wrNone') 
	begin
      insert into #WarningCats(cName) values ('') 	
	end

	    IF (ISNULL(@WarningCats,'') = '')
	    SET @WarningCats = ''
		/*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int,/*ID*/
			  StoreName Varchar(50)
		)			
		
			
		/*生成商品查询*/
		--set @TmpCount = ( select COUNT(*) from #TmpKey)
		
		--if @TmpCount < 2 begin
		if @index = '0'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsCode like '%'+@KeyStr+'%')
		end
		if @index = '1'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsName like '%'+@KeyStr+'%')
		end
		if @index = '2'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or g.SKU like '%'+@KeyStr+'%' or gs.SKU like '%'+@KeyStr+'%' )
		end
		if @index = '3'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.BarCode like '%'+@KeyStr+'%')
		end
		if @index = '4'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.SalerName like '%'+@KeyStr+'%')
		end
		if @index = '5'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.FitCode like '%'+@KeyStr+'%')
		end	  
			    
		 
		 
 		
	    /*采购未入库数*/
	    --已完全入库订单商品
	     create table #InStoreD(StockOrderID int,StoreID int,GoodsSKUID int,Number int)
	     insert into  #InStoreD
	     select 
	       om.NID,
	       m.StoreID,
	       d.GoodsSKUID,
	       sum(d.Amount)
	     from CG_StockInD d
	     join CG_StockInM m on d.StockInNID = m.NID
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM om on m.StockOrder = om.BillNumber
	     where m.CheckFlag = 1
	     group by om.NID,d.GoodsSKUID,m.StoreID
	     --select * from #InStoreD
	     --未入库商品
	     create table #UnInStore(GoodsSKUID int,StoreID int,UnInNum numeric(18,8))
	     insert into #UnInStore(GoodsSKUID,storeid,UnInNum)
	     select 
		    d.GoodsSKUID,
		    m.StoreID,
		    SUM(case when (d.Amount - isnull(id.Number,0)) <= 0 then null else (d.Amount - isnull(id.Number,0)) end )
	     from CG_StockOrderD d
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM m on d.StockOrderNID = m.NID
	     left join #InStoreD id on d.StockOrderNID = id.StockOrderID and d.GoodsSKUID = id.GoodsSKUID and id.StoreID=m.StoreID
	     where 
		     (m.CheckFlag = 1)--审核通过的订单
	     and (m.Archive = 0)--不统计归档订单
	     group by d.GoodsSKUID,m.StoreID
	     --缺货或未派单的记录
	     create table #UnPaiDNum(GoodsSKUID int,UnPaiDNum numeric(10,4),StoreID int,)--ordertime datetime
	     insert into #UnPaiDNum
		SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum, StoreID-- ,ordertime	 	
		FROM (  --未派单的销售商品 和  数量(Trade)
				SELECT ISNULL(gs.NID,0) as GoodsSKUID, 
					SUM(case when pt.RestoreStock=-1 then 0 else ptd.L_QTY end) AS SaleNum,
					ISNULL(ptd.StoreID,0)AS StoreID
				FROM P_TradeDt(nolock) ptd 
				inner join P_trade(nolock) pt on pt.NID=ptd.TradeNID
				inner join B_GoodsSKU gs on gs.SKU=ptd.SKU	   
				inner join #Goods g on gs.nid = g.GoodsSKUID	             
				WHERE pt.FilterFlag <= 5 
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
		UNION all  --异常单的销售商品 和   数量(TradeUn)
			   SELECT 
						ISNULL(gs.NID,0) as GoodsSKUID, 
						SUM(case when pt.RestoreStock=-1 then 0 else ptdu.L_QTY end ) AS SaleNum ,
						ISNULL(ptdu.StoreID,0) AS StoreID
			   FROM P_TradeDtUn(nolock) ptdu 
			   inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID 
			   inner join B_GoodsSKU gs on gs.SKU=ptdu.SKU
			   inner join #Goods g on gs.nid = g.GoodsSKUID		       
			   WHERE pt.FilterFlag = 1                         
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0) 
			 ) AS C
		GROUP BY GoodsSKUID,StoreID--,ordertime	  	
	   
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
		
		--根据selldays更新sellercount  
		declare @AutoCalcSellCount int
		set @AutoCalcSellCount=ISNULL((select top 1 paravalue from b_sysparams where paracode='AutoCalcSellCount'),0)
		if @AutoCalcSellCount=0 
		begin
		  exec P_XS_CalGoodsSKUSellCount
		end
		--查询	
		--查找销售时间范围
		Declare @SellDay1 int=5
		declare @SellDay2 int=15
		declare @SellDay3 int=30  
	        
		select  @SellDay1= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='1' and ISNUMERIC(DictionaryName)=1
		select  @SellDay2= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='2' and ISNUMERIC(DictionaryName)=1
		select  @SellDay3= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='3' and ISNUMERIC(DictionaryName)=1			    
		if @SellDay1=0
		  set @SellDay1=5
		if @SellDay2=0
		  set @SellDay2=15
		if @SellDay3=0
		  set @SellDay3=30    
		
		--在途商品		 
		 SELECT  cd.goodsskuid,sum(cd.amount) as onroadamount,cm.storeid              into #OnRoad 
         FROM CG_StockInD cd  
         inner join CG_StockInM cm on cm.nid=cd.stockinnid
         inner join kc_stocksplitm km on cm.StockSplitNid=km.nid and km.checkflag=1 
         group by cd.goodsskuid,cm.storeid 
         
       --调拨单保存之后的预期入库
       
       select cd.GoodsSKUID,sum(cd.amount) as hopenum,cm.StoreInID                    into #StockChange
       from  KC_StockChangeD cd 
       inner join KC_StockChangeM cm on cm.nid=cd.StockChangenid and cm.checkflag=0
       group by cd.GoodsSKUID,cm.StoreInID 
       
       
          
		
		
	--	IF (@WarningCats <> 'wrNone')	
	--	BEGIN 	
			SELECT 
				@RecCount=count(1)
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	    			
			left join 
				B_Goods b on b.NID = gs.GoodsID	
			left join
				B_Supplier p on p.NID=b.SupplierID		
			left join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left join #WarningCats tmp on tmp.cName = d.WarningCats 
			-- WHERE (@WarningCats = '') OR  (d.WarningCats = @WarningCats)	
			WHERE (@WarningCats = '') OR  (tmp.cName is Not null)	
	-------------------计算记录数和页数
		   if @RecCount % @PageNum = 0
		   begin
			  set @PageCount = @RecCount/@PageNum
		   end
		   else
		   begin
			  set @PageCount = @RecCount/@PageNum+1
		   end		
		   
 
		   				
		 SELECT   *  INTO #KCtemp FROM  -- TOP(@PageNum)
			(SELECT
			     0 as SelFlag,
				 row_number() OVER(ORDER BY b.goodscode ) AS rowid,
				@PageCount as fpagecount,
				@RecCount as RecCount,
				gs.SKU,              --商品的SKU 
        gs.GoodsSKUStatus,  -- 商品状态				
				b.goodscode,           --商品编码
				b.goodsname,          --商品名称					
				d.SellCount as SellCount,
				d.SellCount1 as  SellCount1,             --5天销量
				d.SellCount2 as SellCount2,              --10天销量
				d.SellCount3  as SellCount3,             --20天销量
      -- gs.GoodsID as GoodsID,
       --count(gs.SKU) as skunum,                ---张容让对加上一列 商品编码对应的子SKU数 

        d.Number as Number,                           --库存数量
				d.ReservationNum as ReservationNum,                   --占用数量
				--SUM(d.Number-d.ReservationNum) as usenum, --可用数量
        
				ISNULL(UnPaiDNum,0) as UnPaiDNum,
				Number-ReservationNum-ISNULL(UnPaiDNum,0)	as factStockNum,         --实际库存数量=库存量-占用量-缺货及未派单量
				case when d.SellDays=0 then b.SellDays else d.SellDays end as sellDays, --预警销售天数		
		        b.SalerName as SalerName,                      --业绩归属人		      
		        b.Purchaser,                                   --采购
		    case when d.StockDays=0 then  b.StockDays else d.StockDays end as StockDays,--采购到货天数

				u.UnInNum as NotInStore	,	--zan 采购未入库

				d.Number-d.ReservationNum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) + isnull(sc.hopenum,0) as hopeUseNum --预计可用库存																										--预计可用库存
		      
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT outer JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	
		    -- add by ylq 2015-05-19 
			left join  B_StoreLocation bsll on bsll.nid = isNull(bgs.LocationID,0)    			
			left outer join 
				B_Goods b on b.NID = gs.GoodsID
		    left outer join B_Store sto on b.StoreID = sto.NID 
			left outer join	
			    B_GoodsCats c on c.NID=b.GoodsCategoryID	
			left outer join
				B_Supplier p on p.NID=b.SupplierID		
			left outer join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left outer join #UnPaiDNum up on up.GoodsSKUID = d.GoodsSKUID and d.StoreID=up.StoreID
		    left outer join #WarningCats tmp on tmp.cName = IsNull(d.WarningCats,'')
		    left outer join #OnRoad onroad on onroad.goodsskuid = d.goodsskuid and onroad.storeid=d.storeid 
		    left outer join #StockChange sc on sc.goodsskuid = d.goodsskuid and sc.storeinid = d.storeid
		    left outer join #SkuState tmp1 on tmp1.cName = ISNULL(gs.GoodsSKUStatus,'')
		    left outer join B_DictionaryCats bdc on bdc.CategoryName='库存预警类别'
		    left outer join B_Dictionary  bd on bd.fitcode=d.WarningCats and isnull(bd.fitcode,'')<>'' and bd.CategoryID=bdc.nid		    
			
			WHERE  ((IsNull(b.Used,0)= @TmpUsed1) or (IsNull(b.Used,0) = @TmpUsed2))  
			   and   ((@WarningCats = '') OR  (tmp.cName is Not Null)) -- add by ylq 2015-04-20
			   and   ((@GoodsState = '') OR  (tmp1.cName is Not Null)) -- add by ylq 2015-05-15 
			   AND ((@Purchaser = '') OR (ISNULL(b.Purchaser,'') = @Purchaser) )
				and  (@cg='0' or  (@cg='1' and (d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0)) )
				-- add by yq 2015-05-19  增加库位条件
				and ((@LocationName = '') or (ISNULL(bsll.LocationName,'') like '%'+@LocationName+'%'))	
		    --GROUP BY B_GoodsSKU.GoodsID--gs.GoodsSKUStatus, b.goodsname,b.SalerName,b.Purchaser,b.goodscode,b.SellDays,b.StockDays,D.SellDays,D.StockDays 
) A
			WHERE A.factStockNum<=-1 and rowid > (@PageNum*(@PageIndex-1))
			ORDER BY A.goodscode
				




select
g.Season as Season, 
B.goodscode as goodscode,
B.goodsname as goodsname,
B.GoodsSKUStatus as GoodsSKUStatus,
g.Purchaser as Purchaser,
g.SalerName as SalerName,
B.sellDays as sellDays,
B.StockDays as StockDays,

SUM(B.SellCount1) as SellCount1,
SUM(B.SellCount2) as SellCount2,
SUM(B.SellCount3) as SellCount3,
--cast(SUM(B.Number) as int) as Number,
--cast(SUM(B.ReservationNum) as int) as ReservationNum,
--cast(SUM(B.UnPaiDNum) as int) as UnPaiDNum,
cast(SUM(Number-ReservationNum-UnPaiDNum) as int)  as factStockNum,
CAST(SUM(B.NotInStore) as int) as NotInStore ,-- 采购没入库
CAST(SUM(B.hopeUseNum) as int) as hopeUseNum--预计可用库存  
INTO #LastTemptable
FROM 
(select
k.GoodsSKUStatus,  
k.goodscode as goodscode,
k.goodsname as goodsname,
k.sellDays,
k.StockDays,
SUM(k.NotInStore) as NotInStore ,-- 采购没入库
SUM(k.hopeUseNum) as hopeUseNum,--预计可用库存
SUM(k.SellCount1) as SellCount1,
SUM(k.SellCount2) as SellCount2,
SUM(k.SellCount3) as SellCount3,
SUM(k.Number) as Number,
SUM(k.ReservationNum) as ReservationNum,
SUM(k.UnPaiDNum) as UnPaiDNum,
SUM(k.Number)-SUM(k.ReservationNum)-SUM(k.UnPaiDNum) as factStockNum  --cast(SUM(k.factStockNum) as int)
from #KCtemp k  --WHERE k.factStockNum <=-1 
group by k.goodscode,k.goodsname,factStockNum,k.StockDays,k.GoodsSKUStatus,k.sellDays ) as B  
LEFT JOIN B_Goods g ON g.GoodsCode = B.goodscode 
GROUP BY B.goodsCode,B.goodsname,B.StockDays,B.sellDays,B.GoodsSKUStatus,g.Season,g.Purchaser,g.SalerName--,B.purchase,B.hopeUseNum--,B.factStockNum 
ORDER BY factStockNum asc

SELECT
 count(gs.SKU) as num,    --num是商品编码对应的子SUK数目 
g.GoodsCode  INTO #SKUnum  
FROM B_Goods g LEFT JOIN B_GoodsSKU gs ON g.NID=gs.GoodsID GROUP BY g.GoodsCode --gs.NID--,--最

---临时表存放延迟天数和编码
select 
bg.goodscode as goodscode, 
max(datediff(day,DATEADD(hour,8, pun.ordertime),getdate()))as delay_days
 INTO #tempdelay_days
from p_tradeun as pun 
LEFT JOIN p_tradedtun as ptu 
on pun.nid = ptu.tradenid
LEFT JOIN B_Goodssku as bgs
on bgs.nid = ptu.goodsskuid
LEFT JOIN b_goods as bg
on bgs.goodsid= bg.nid
where pun.filterflag=1
group by bg.goodscode 


--SELECT * FROM  #LastTemptable 
--最后出来的结果集
	

SELECT lt.Season , --季节
lt.goodscode,      --商品编码
S.num,             --这个字段是拿出商品编码下对应的子ＳＫＵ个数
lt.goodsname,      --商品名称
lt.GoodsSKUStatus, --商品状态
lt.Purchaser,       --采购人
lt.SalerName,       --业绩归属
lt.StockDays,         --到货天数
lt.sellDays,         --预警天数
lt.SellCount1,        --5天销量
lt.SellCount2,        --10天销量
lt.SellCount3,        --20天销量
lt.factStockNum,       --实际库存数
lt.NotInStore,        -- 采购没入库
lt.hopeUseNum        --预计可用库存
,d.delay_days					--延迟天数
 FROM #LastTemptable lt
LEFT JOIN #SKUnum S ON lt.goodscode =S.GoodsCode  
LEFT JOIN #tempdelay_days d ON d.goodscode=lt.goodscode

    DROP TABLE #SKUnum
	  DROP TABLE #LastTemptable
		drop table #KCtemp				
    drop table #SkuState
		Drop Table #Store
		Drop Table #Goods
		Drop Table #WarningCats
		Drop Table #OnRoad
		Drop Table #StockChange
DROP TABLE #tempdelay_days
		
END
