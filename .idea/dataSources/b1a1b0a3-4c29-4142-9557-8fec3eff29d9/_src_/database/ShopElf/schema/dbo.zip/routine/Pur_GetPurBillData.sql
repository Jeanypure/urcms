
CREATE proc [dbo].[Pur_GetPurBillData] 
@GoodIDs VARCHAR(max) = NULL,
@StoreID1 varchar(100)=''
AS 
BEGIN
 DECLARE @tp VARCHAR(10)= ''
 --如果仓库ID是空的，那么取默认仓库的ID 
 DECLARE @StoreID INT 
 if @StoreID1 <> '' 
   set @StoreID = convert(int,@StoreID1)
 else
   SET @StoreID = (SELECT TOP 1 NID FROM B_Store bs )
   
 SET @GoodIDs = REPLACE(@GoodIDs,'"','') --13,335;7,705;
 SET @tp = SUBSTRING(@GoodIDs,len(@GoodIDs),1)
 IF (@tp = ';')
 SET  @GoodIDs = SUBSTRING(@GoodIDs,1,len(@GoodIDs)-1)
 
 SET @GoodIDs = REPLACE(@GoodIDs,';',' UNION SELECT ' + convert(varchar(100),@StoreID) + ',') --13,335 union setect 7,705 union select 8,711 
 CREATE TABLE #aa
 ( StoreID INT DEFAULT 0,
   GoodsID INT DEFAULT 0,
   pCount  INT DEFAULT 0
   
	)                       
 EXEC('INSERT INTO #aa(StoreID,GoodsID,pCount) SELECT '+@StoreID+','+@GoodIDs )

   /*1.生成商品表结构*/
	CREATE TABLE #SaleTable
	(  StoreID INT,
	   GoodsSKUID INT ,
	   SaleNum NUMERIC(18,2))	
	   
	/*2.生成仓库表结构*/
	CREATE TABLE #Store
	( StoreID Int,
	  StoreName Varchar(50) )
	  
	INSERT INTO #Store 
	SELECT  nid,StoreName 
	FROM B_store 
	WHERE (@StoreID=0 or nid= @StoreID)		
	  
	  
	  				
	/*3.生成所有销售未派单的商品表*/	
	INSERT INTO #SaleTable
	SELECT StoreID,GoodsID, SUM(pCount) AS SaleNum 	
	FROM #aa
	GROUP BY StoreID,GoodsID

	 DROP TABLE #aa	    
	                                                      	  
    		
	--8.查询					
	SELECT 
	    0 AS SelFlag,  		gs.SKU,		    gs.property1,		gs.property2,		gs.property3,
		b.BarCode,		    b.goodscode,	b.goodsname,		b.model,		    b.unit,
		b.class,	     	b.maxnum,		b.minnum,		    b.SupplierID,		p.SupplierName,
		s.storeName,		b.MinPrice,
		d.StoreID,		d.GoodsID,		   g.GoodsSKUID,		d.Number,           gs.skuname,
		d.ReservationNum,
		isnull(d.sellcount1,0) as sellcount1,  isnull(d.sellcount2,0) as sellcount2,  isnull(d.sellcount3,0) as sellcount3,	
		
	--case when isNull(sys1.paraValue,'0') = '1' then   因为生成的是采购订单，取的还是商品成本价，跟库存关系不大
        case when ISNULL(gs.CostPrice,0) <> 0 then gs.CostPrice else IsNull(b.CostPrice,0) end as Price,
         --    else 
         --        case when   isnull(D.price,0)  = 0 then 
         --          case when ISNULL(gs.CostPrice,0) <> 0 then gs.CostPrice else IsNull(b.CostPrice,0) end 
         --       else 
         --         isnull(d.price,0)  end 
        --      end as Price,   
		g.SaleNum AS Amount,
		b.BmpFileName, isnull(b.PackageCount,0) PackageCount,b.GoodsStatus,      
		(SELECT TOP 1 bsl.LocationName
		 FROM B_StoreLocation bsl WHERE bsl.nid = ISNULL(gs.LocationID,0)) AS LocationName,
		 p.Mobile,p.OfficePhone,p.Address, gs.Weight,b.StockMinAmount
 	  
	INTO #Temp	 
	FROM #SaleTable g 				
	                       left JOIN KC_CurrentStock D ON g.GoodsSKUID = d.GoodsSKUID and d.StoreID=g.StoreID	
						   left JOIN B_Store s         ON s.NID = d.StoreID	                       
	                       LEFT  JOIN B_GoodsSKU gs    ON gs.NID = g.GoodsSKUID				
	                       LEFT  JOIN B_Goods b        ON b.NID = gs.GoodsID	
	                       LEFT  JOIN  B_Supplier p     ON p.NID=b.SupplierID
	               --       left join B_SysParams sys1 on sys1.ParaCode = 'CalCostFlag' 
	WHERE /*ISNULL(b.used,0) = 0 AND*/ ISNULL(b.GoodsCode,'') <> '' 
    
    
    SELECT * FROM #Temp
    
	DROP TABLE #SaleTable
	
	DROP TABLE #Store

	DROP TABLE #Temp
END
