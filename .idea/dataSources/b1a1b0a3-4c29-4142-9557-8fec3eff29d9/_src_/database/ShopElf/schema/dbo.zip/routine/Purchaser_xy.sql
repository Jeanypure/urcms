CREATE PROCEDURE [dbo].[Purchaser_xy] 
AS
BEGIN
 select 0,'全部' union all
 select distinct b.NID,bg.Purchaser  
from B_Goods bg inner join b_person b on b.personname=bg.Purchaser           
END
