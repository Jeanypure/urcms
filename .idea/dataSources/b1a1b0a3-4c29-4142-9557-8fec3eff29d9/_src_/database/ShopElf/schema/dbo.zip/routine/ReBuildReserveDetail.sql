CREATE PROCEDURE ReBuildReserveDetail(@OrigTradeNid VARCHAR(10) = '', @SplitTradeNid VARCHAR(10) = '')
AS
BEGIN
  IF (ISNULL(@OrigTradeNid,'') = '')
  SET @OrigTradeNid = '0'
  IF (ISNULL(@SplitTradeNid,'') = '')
  SET @SplitTradeNid = '0'
  DELETE FROM KC_ReserveDetail WHERE BillNID = @OrigTradeNid	
  --重新生成原订单明细的占用信息
  INSERT INTO KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)  
  SELECT   5, ptd.TradeNID, ptd.GoodsSKUID, ptd.StoreID, ptd.L_QTY, 0, 'system'     
  FROM P_TradeDt ptd
  WHERE ptd.TradeNID = @OrigTradeNid 
  --重新生成新订单明细的占用信息
  INSERT INTO KC_ReserveDetail(BillType, BillNID, GoodsSKUID, StoreID, Amount, UseFlag, MakeUser)  
  SELECT   5, ptd.TradeNID, ptd.GoodsSKUID, ptd.StoreID, ptd.L_QTY, 0, 'system'     
  FROM P_TradeDt ptd
  WHERE ptd.TradeNID = @SplitTradeNid
END
