CREATE PROCEDURE [dbo].[ReSetSplitTradeDefMsg](@OrigTradeNid VARCHAR(10) = '', @SplitTradeNid VARCHAR(10) = '')
AS
BEGIN
  IF (ISNULL(@OrigTradeNid,'') = '')
  SET @OrigTradeNid = '0'
  IF (ISNULL(@SplitTradeNid,'') = '')
  SET @SplitTradeNid = '0'
 
  DECLARE @PackingMen varchar(50),@PackageMen varchar(50) 
  DECLARE @PaiDanDate datetime , @PaidanMen varchar(50)
  DECLARE @ScanningMen varchar(50), @WeighingMen varchar(50)
  IF EXISTS (SELECT 1 
             FROM P_Trade WHERE NID = @OrigTradeNid)	
  BEGIN 	    
  	   ---设置明细表信息
  	   DECLARE @TotalWeight NUMERIC(18,4) = 0
	   UPDATE  d
	   SET     d.AliasCnName=g.AliasCnName,
		  	   d.AliasEnName=g.AliasEnName,
			   d.BmpFileName=g.BmpFileName,
			   d.DeclaredValue=isnull(g.DeclaredValue,0),
			   d.Weight=case when isnull(g.Weight,0)=0 then d.[Weight] else  isnull(g.Weight,0)*d.L_QTY/1000 end,			 
			   d.OriginCountry=g.OriginCountry,
			   d.OriginCountryCode=g.OriginCountryCode
	  FROM 
			P_TradeDt d	 
		LEFT JOIN B_GoodsSKU gs on gs.SKU=d.SKU
		LEFT JOIN B_Goods g on g.NID=gs.GoodsID	
	 	LEFT JOIN B_StoreLocation bsl ON g.LocationID = bsl.NID		
	  WHERE TradeNID = @OrigTradeNid		
  	  SET @TotalWeight = ISNULL((SELECT SUM([Weight]) FROM P_tradedt WHERE TradeNID = @OrigTradeNid),0)  	  
  	  UPDATE P_Trade SET TotalWeight = @TotalWeight WHERE NID = @OrigTradeNid
  	  
  	  UPDATE  d
	   SET     d.AliasCnName=g.AliasCnName,
		  	   d.AliasEnName=g.AliasEnName,
			   d.BmpFileName=g.BmpFileName,
			   d.DeclaredValue=isnull(g.DeclaredValue,0),
			   d.Weight=case when isnull(g.Weight,0)=0 then d.[Weight] else  isnull(g.Weight,0)*d.L_QTY/1000 end,			 
			   d.OriginCountry=g.OriginCountry,
			   d.OriginCountryCode=g.OriginCountryCode
	  FROM 
			P_TradeDt d	 
		LEFT JOIN B_GoodsSKU gs on gs.SKU=d.SKU
		LEFT JOIN B_Goods g on g.NID=gs.GoodsID	
	 	LEFT JOIN B_StoreLocation bsl ON g.LocationID = bsl.NID		
	  WHERE TradeNID = @SplitTradeNid	
	  	
  	  SET @TotalWeight = ISNULL((SELECT SUM([Weight]) FROM P_tradedt WHERE TradeNID = @SplitTradeNid),0)
  	  
	  SELECT   @PackingMen = [PackingMen]
			  ,@PackageMen = [PackageMen]
			  ,@PaiDanDate = [PaiDanDate]
			  ,@PaidanMen = [PaidanMen]
			  ,@ScanningMen = [ScanningMen]
			  ,@WeighingMen = [WeighingMen]
	  FROM P_Trade
	  WHERE NID = @OrigTradeNid


	  UPDATE P_trade 
	  SET    [PackingMen] = @PackingMen
			  ,[PackageMen] = @PackageMen
			  ,[PaiDanDate] = GetDate() --@PaiDanDate
			  ,[PaidanMen]  = @PaidanMen
			  ,[ScanningMen] = @ScanningMen
			  ,[WeighingMen] = @WeighingMen
			  ,TotalWeight = @TotalWeight
	 WHERE NID = @SplitTradeNid
	 
	 --强制将拆分后订单的明细更新成完成
	 UPDATE CG_OutofStock
	 SET OutOfStockStatus = 4
	 WHERE TradeNID = @OrigTradeNid AND  OutOfStockStatus <> 4 AND TradeDtNID IN (SELECT NID FROM P_TradeDt WHERE TradeNID = @SplitTradeNid) 
	 
   END ELSE
   BEGIN
   	 ---设置明细表信息
  	   DECLARE @TotalWeightUn NUMERIC(18,4) = 0
	   UPDATE  d
	   SET     d.AliasCnName=g.AliasCnName,
		  	   d.AliasEnName=g.AliasEnName,
			   d.BmpFileName=g.BmpFileName,
			   d.DeclaredValue=isnull(g.DeclaredValue,0),
			   d.Weight=case when isnull(g.Weight,0)=0 then d.[Weight] else  isnull(g.Weight,0)*d.L_QTY/1000 end,			 
			   d.OriginCountry=g.OriginCountry,
			   d.OriginCountryCode=g.OriginCountryCode
	  FROM 
			P_TradeDtUn d	 
		LEFT JOIN B_GoodsSKU gs on gs.SKU=d.SKU
		LEFT JOIN B_Goods g on g.NID=gs.GoodsID	
	 	LEFT JOIN B_StoreLocation bsl ON g.LocationID = bsl.NID		
	  WHERE TradeNID = @OrigTradeNid		
  	  SET @TotalWeightUn = ISNULL((SELECT SUM([Weight]) FROM P_tradedtUn WHERE TradeNID = @OrigTradeNid),0)  	  
  	  UPDATE P_TradeUn SET TotalWeight = @TotalWeightUn WHERE NID = @OrigTradeNid
  	  
  	  UPDATE  d
	   SET     d.AliasCnName=g.AliasCnName,
		  	   d.AliasEnName=g.AliasEnName,
			   d.BmpFileName=g.BmpFileName,
			   d.DeclaredValue=isnull(g.DeclaredValue,0),
			   d.Weight=case when isnull(g.Weight,0)=0 then d.[Weight] else  isnull(g.Weight,0)*d.L_QTY/1000 end,			 
			   d.OriginCountry=g.OriginCountry,
			   d.OriginCountryCode=g.OriginCountryCode
	  FROM 
			P_TradeDtUn d	 
		LEFT JOIN B_GoodsSKU gs on gs.SKU=d.SKU
		LEFT JOIN B_Goods g on g.NID=gs.GoodsID	
	 	LEFT JOIN B_StoreLocation bsl ON g.LocationID = bsl.NID		
	  WHERE TradeNID = @SplitTradeNid	
	  	
  	  SET @TotalWeightUn = ISNULL((SELECT SUM([Weight]) FROM P_tradedtUn WHERE TradeNID = @SplitTradeNid),0)
  	  
	  
   	 SELECT   @PackingMen = [PackingMen]
			  ,@PackageMen = [PackageMen]
			  ,@PaiDanDate = [PaiDanDate]
			  ,@PaidanMen = [PaidanMen]
			  ,@ScanningMen = [ScanningMen]
			  ,@WeighingMen = [WeighingMen]
	  FROM P_TradeUn
	  WHERE NID = @OrigTradeNid


	  UPDATE P_tradeUn 
	  SET    [PackingMen] = @PackingMen
			  ,[PackageMen] = @PackageMen
			  ,[PaiDanDate] = GetDate()--@PaiDanDate
			  ,[PaidanMen]  = @PaidanMen
			  ,[ScanningMen] = @ScanningMen
			  ,[WeighingMen] = @WeighingMen
			  ,TotalWeight = @TotalWeightUn
	 WHERE NID = @SplitTradeNid
	 
	 --强制将拆分后订单的明细更新成完成
	 UPDATE CG_OutofStock
	 SET OutOfStockStatus = 4
	 WHERE TradeNID = @OrigTradeNid AND  OutOfStockStatus <> 4 AND TradeDtNID IN (SELECT NID FROM P_TradeDtUn WHERE TradeNID = @SplitTradeNid) 
   END 
END
