CREATE procedure [dbo].[SP_DropIndex] @tableName varchar(50)=null --表名
as 
begin
	if @tableName is null 
	begin 
		 raiserror('必须提供@tableName参数',12,1) 
		 return 
	end 

	create table # ( 
		 id int identity, 
		 index_name varchar(50), 
		 index_description varchar(1000), 
		 index_keys varchar(100) 
	) 

	insert #(index_name,index_description,index_keys) 
	exec sp_helpindex @tableName 
	declare @i int
	declare @sql varchar(100)
	 
	set @i = 1 

	while @i<=(select max(id) from #) 
	begin 
		if (select index_keys from # where id = @i)<>'nid' --nid是主键，不删除
		begin
			if exists(select 1 from sysobjects A join # B on A.name=B.index_name where B.id=@i and A.xtype in ('PK','UQ')) 
			begin 
				select @sql = 'alter table '+ @tableName +' drop constraint ' + (select index_name from # where id = @i) 
			end 
			else 
			begin 
				select @sql = 'drop index '+ @tableName + '.' + (select index_name from # where id=@i) 
			end 
			exec(@sql) 	
			--print(@sql) 	
		end
		else
		begin
			if  (select substring(index_name,1,3) from # where id = @i)<>'PK_'
			begin
				if exists(select 1 from sysobjects A join # B on A.name=B.index_name where B.id=@i and A.xtype in ('PK','UQ')) 
				begin 
					select @sql = 'alter table '+ @tableName +' drop constraint ' + (select index_name from # where id = @i) 
				end 
				else 
				begin 
					select @sql = 'drop index '+ @tableName + '.' + (select index_name from # where id=@i) 
				end 
				exec(@sql) 				
			end		
		end
		set @i=@i+1 
	end 

	drop table # 
end
