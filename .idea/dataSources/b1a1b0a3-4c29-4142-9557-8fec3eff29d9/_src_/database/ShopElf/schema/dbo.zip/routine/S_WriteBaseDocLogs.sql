CREATE PROCEDURE [dbo].[S_WriteBaseDocLogs] 
     @DocType varchar(100),
	 @DocNid int,
	 @Logs VARCHAR(1000),
  	 @CurrUserName VARCHAR(50)
AS
begin
	DECLARE @WriteDate VARCHAR(30)
	SET @WriteDate = CONVERT(VARCHAR(30),GETDATE(),121)
    SET @Logs = @CurrUserName +' '+ @WriteDate+' ' + ISNULL(@Logs,'')
	INSERT INTO B_BaseDocLogs([DocType],[DocNid] ,[Operator]  ,[Logs])
    VALUES(@DocType,@DocNid,@CurrUserName,@Logs)
end 
