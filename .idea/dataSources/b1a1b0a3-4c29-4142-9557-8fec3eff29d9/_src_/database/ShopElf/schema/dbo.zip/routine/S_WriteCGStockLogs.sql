CREATE PROCEDURE [dbo].[S_WriteCGStockLogs] 
     @OrderType varchar(20),
	 @TradeNid VARCHAR(20),
	 @Logs VARCHAR(500),
  	 @CurrUserName VARCHAR(50)
AS
begin
	DECLARE @WriteDate VARCHAR(30)
	SET @WriteDate = CONVERT(VARCHAR(30),GETDATE(),121)
    SET @Logs = @CurrUserName +' '+ @WriteDate+' ' + ISNULL(@Logs,'')
	INSERT INTO CG_StockLogs([OrderType],[OrderNID] ,[Operator]  ,[Logs])
    VALUES(@OrderType,@TradeNid,@CurrUserName,@Logs)
end  
 
