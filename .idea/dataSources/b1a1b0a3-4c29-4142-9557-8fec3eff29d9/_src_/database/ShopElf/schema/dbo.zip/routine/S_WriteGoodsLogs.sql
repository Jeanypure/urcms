
CREATE PROCEDURE [dbo].[S_WriteGoodsLogs] 
	 @GoodsCode VARCHAR(50),
	 @Logs VARCHAR(2000),
  	 @CurrUserName VARCHAR(50)
AS
BEGIN
	DECLARE @WriteDate VARCHAR(30)
	SET @WriteDate = CONVERT(VARCHAR(30),GETDATE(),121)
	SELECT @WriteDate
    SET @Logs = @CurrUserName +' '+ @WriteDate+' ' + ISNULL(@Logs,'')
	INSERT INTO [B_GoodsLogs] ([GoodsCode] ,[Operator]  ,[Logs])
    VALUES(@GoodsCode,@CurrUserName,@Logs)
END

