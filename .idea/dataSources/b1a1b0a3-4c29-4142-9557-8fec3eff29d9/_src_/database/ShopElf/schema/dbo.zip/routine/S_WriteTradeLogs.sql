CREATE PROCEDURE [dbo].[S_WriteTradeLogs] 
	 @TradeNid VARCHAR(20),
	 @Logs VARCHAR(500),
  	 @CurrUserName VARCHAR(50)
AS
BEGIN
	DECLARE @WriteDate VARCHAR(30)
	SET @WriteDate = CONVERT(VARCHAR(30),GETDATE(),121)
    SET @Logs = @CurrUserName +' '+ @WriteDate+' ' + ISNULL(@Logs,'')
	INSERT INTO [P_TradeLogs] ([TradeNID] ,[Operator]  ,[Logs])
    VALUES(@TradeNid,@CurrUserName,@Logs)
END
