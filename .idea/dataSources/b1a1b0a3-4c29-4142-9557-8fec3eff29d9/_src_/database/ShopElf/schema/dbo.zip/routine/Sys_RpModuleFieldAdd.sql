CREATE PROCEDURE [dbo].[Sys_RpModuleFieldAdd]
	@RPID varchar(10) = '' ,--模块代码
	@ProduceName	Varchar(50),	--存储过程名称
    @ErrorMsg VarChar(50)   = '' Output--返回错误
AS
BEGIN
	IF ((@ProduceName ='' ) OR (@RPID = ''))
	BEGIN
		SET @ErrorMsg = '模块代码及存储过程不能为空'
		RETURN 
	END
	--创建被传入过程已经存在参数的临时表
	CREATE TABLE #ExistsParam( 
   	                          ParamName VARCHAR(50) 
                            )
	--把存在的参数存入临时表中
	INSERT INTO #ExistsParam(ParamName)
	SELECT FieldEn
	FROM Sys_RpQueryField 
	WHERE ((@RPID    IS NULL )OR(RPID    = @RPID   ))
    --生成存储过程自身的条件 cf
     SELECT
		SYSCOLUMNS.NAME As FieldEn  
     into #ProcsParam
     FROM SYSCOLUMNS 
     WHERE OBJECT_ID(@ProduceName)=ID AND SYSCOLUMNS.ISOUTPARAM = 0 
	--把该存储过程所有参数查询出来   
	SELECT * 
	into #_ModuleParam
	FROM (
         SELECT
          @RPID  As RPID ,
          '' As FieldCh     ,
          SYSCOLUMNS.NAME As FieldEn   , 
          '' As ComponentType , 
          '' As DisplayValue ,
          '' As RealValue  , 
          '' As GetValueWay , 
          0  As IsSysDict , 
          0  As Sequence      ,
          0  As IsUse
         FROM SYSCOLUMNS 
         WHERE OBJECT_ID(@ProduceName)=ID AND SYSCOLUMNS.ISOUTPARAM = 0 AND SYSCOLUMNS.NAME NOT IN (SELECT ParamName 
                                                                                                  FROM #ExistsParam)
       UNION   --联合     
         SELECT RPID  , FieldCh        , FieldEn    , ComponentType  , DisplayValue ,
                RealValue   , GetValueWay  , IsSysDict  , Sequence       ,  CASE WHEN IsUsed = 0 THEN 1 --此表中存在的参数为0的变为 1 ，因为界面要用CheckBox显示
                                                                                 WHEN IsUsed = 1 THEN 0 --此表中参数为1的，说明被停用，要变为0 ，因为界面要用CheckBox显示
                                                                                 ELSE  0         END            As IsUse --其它特殊情况，默认为未启用
         FROM Sys_RpQueryField 
         WHERE ((@RPID   IS NULL )OR(RPID    = @RPID   )) and fielden in (select fieldEn from #ProcsParam)
        ) AS ModuleParam
   ORDER BY IsUse DESC , Sequence
    --删除原有记录
    delete Sys_RpQueryField where RPID=@RPID
	insert into Sys_RpQueryField(RPID,FieldCh,FieldEn,ComponentType,Sequence,WindowCaption,WindowHeight,ProduceName,Isused,IsSysDict)
	select    
		@RPID,FieldCh,FieldEn,'',1,'报表查询',500,@ProduceName,0,0
	FROM #_ModuleParam
    if not exists(select 1 from S_TwoMenus where ProjectName =  'TSys_ReportShowfrm'+@RPID) 
     begin 
		 INSERT INTO S_TwoMenus(One_ID, Two_Name, [Enable], ProjectName, PurviewList, ProjectWay, NOrder) 
		 select r.ManageID,r.ReportName,1,'TSys_ReportShowfrm'+@rpid,
				'QO','form',(select isnull(Max(norder),0)+1 from S_TwoMenus 
								   where One_ID=r.ManageID)
		from Sys_RpDesign r
		where RpID=@RPID
	end
   TRUNCATE TABLE #_ModuleParam
   DROP TABLE #_ModuleParam
	--删除临时表记录
   TRUNCATE TABLE #ExistsParam
	--删除临时表   
   DROP TABLE #ExistsParam  
END
