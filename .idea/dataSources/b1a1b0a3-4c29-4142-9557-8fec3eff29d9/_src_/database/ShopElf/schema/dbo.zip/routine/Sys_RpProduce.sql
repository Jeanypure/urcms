CREATE PROCEDURE [dbo].[Sys_RpProduce]
	@ProcedureName	varchar(50)	,	--存储过程名,
	@ColNameStrs	VarChar(4000),	--字段的字符串拼写'col1,col2'
	@RpID		int = 0 		--报表ID
AS
begin
	select ErrorMsg = ''
	--缺少参数
	IF @RpID = 0 OR @ProcedureName = ''
	BEGIN
		select ErrorMsg = '缺少参数，报表或存储过程名为空'
		RETURN
	END
	--判断存储过程是否存在
	IF not EXISTS(SELECT 1 FROM sysobjects eec WHERE eec.[name] = @ProcedureName)
	BEGIN
		select ErrorMsg = '存储过程名不存在'
		RETURN
	END
	--创建字段列表
	CREATE TABLE #ColTable
	(
		ColName varchar(50)
	)
	DECLARE @SqlStr VarChar(Max)
	SET @SqlStr = 'insert into #ColTable(ColName) select ' + Replace(@ColNameStrs, ',', ' union select ')
	EXEC(@SqlStr)
	--判断字段是否存在,不存在插入
	insert into Sys_RpCol(RpID,ColZhName,ColField,ColAligent,ColWidth,
						ColKind,ColChartProperty,ColChartKink)
	select @RpID,ColName,ColName,4,80,0,0,0
	from #ColTable 
	where 
		ColName  not in (select ColField from Sys_RpCol where RpID =@RpID )
	--删除Sys_RpCol中有，#ColTable中没有的
	delete Sys_RpCol
	where RpID =@RpID and ColField not in (select ColName from #ColTable)
	--生成查询条件 ,定义报表编码
	if IsNull(@RPID,'') <> '' 
	begin
		declare @Errcode varchar(50)
		set @Errcode = ''
		EXEC Sys_RpModuleFieldAdd @RPID,@ProcedureName,@Errcode
        select ErrorMsg =@Errcode		
	end
end
