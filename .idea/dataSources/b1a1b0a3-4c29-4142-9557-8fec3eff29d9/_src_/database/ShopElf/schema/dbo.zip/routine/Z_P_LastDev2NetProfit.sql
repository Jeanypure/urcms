CREATE PROCEDURE [dbo].[Z_P_LastDev2NetProfit]
@salername2 varchar(max)=''   --业绩归属人2
AS             
BEGIN
SET NOCOUNT ON 
 --分解业绩归属人放到表格里	
   CREATE TABLE #tbSalerAliasName( salername2 VARCHAR(100))
  IF LTRIM(RTRIM(@salername2)) <> ''
  BEGIN
	DECLARE @sSQLCmd VARCHAR(max) = ''
	SET @salername2 = REPLACE(@salername2,',','''))UNION SELECT ltrim(rtrim(''') 
    SET @sSQLCmd = 'INSERT INTO #tbSalerAliasName(salername2) SELECT ltrim(rtrim('+ @salername2+'))'
	EXEC(@sSQLCmd )
	END

select 
timegroup,  salername2,  '' as demo,
sum(salemoneyrmbzn) as  salemoneyrmbzn,  
sum(salemoneyrmbus) as  salemoneyrmbus,
sum(costmoneyrmb) as costmoneyrmb,
sum(ppebayus) as ppebayus,  
sum(ppebayzn) as ppebayzn,
sum(inpackagefeermb) as inpackagefeermb,
sum(expressfarermb) as expressfarermb,
sum(devofflinefee) as devofflinefee,
sum(netprofit) as netprofit,
sum(netrate) as netrate
 into #tmp0 from Y_devNetprofit where timegroup='0-6月'
group by timegroup,salername2
select 
timegroup,  salername2,  '' as demo,  
sum(salemoneyrmbzn) as  salemoneyrmbzn,  
sum(salemoneyrmbus) as  salemoneyrmbus,
sum(costmoneyrmb) as costmoneyrmb,
sum(ppebayus) as ppebayus,  
sum(ppebayzn) as ppebayzn,
sum(inpackagefeermb) as inpackagefeermb,
sum(expressfarermb) as expressfarermb,
sum(devofflinefee) as devofflinefee,
sum(netprofit) as netprofit,
sum(netrate) as netrate
 into #tmp6 from Y_devNetprofit where timegroup='6-12月'
group by timegroup,salername2

select 
timegroup,  salername2,  '' as demo,  
sum(salemoneyrmbzn) as  salemoneyrmbzn,  
sum(salemoneyrmbus) as  salemoneyrmbus,
sum(costmoneyrmb) as costmoneyrmb,
sum(ppebayus) as ppebayus,  
sum(ppebayzn) as ppebayzn,
sum(inpackagefeermb) as inpackagefeermb,
sum(expressfarermb) as expressfarermb,
sum(devofflinefee) as devofflinefee,
sum(netprofit) as netprofit,
sum(netrate) as netrate
 into #tmp12 from Y_devNetprofit where timegroup='12月以上'
group by timegroup,salername2


select  
t0.timegroup as timegroupZero, 
t0.salername2 as salername2Zero,
t0.salemoneyrmbus as salemoneyrmbusZero,
t0.salemoneyrmbzn as salemoneyrmbznZero,
t0.costmoneyrmb as costmoneyrmbZero,
t0.ppebayus as ppebayusZero,
t0.ppebayzn as ppebayznZero,
t0.inpackagefeermb as inpackagefeermbZero,
t0.expressfarermb as expressfarermbZero,
t0.devofflinefee as devofflinefeeZero,
t0.netprofit as netprofitZero,
t0.netrate as netrateZero,
t6.timegroup as timegroupSix, 
--t6.salername2 as salername2Six,
t6.salemoneyrmbus as salemoneyrmbusSix,
t6.salemoneyrmbzn as salemoneyrmbznSix,
t6.costmoneyrmb as costmoneyrmbSix,
t6.ppebayus as ppebayusSix,
t6.ppebayzn as ppebayznSix,
t6.inpackagefeermb as inpackagefeermbSix,
t6.expressfarermb as expressfarermbSix,

t6.devofflinefee as devofflinefeeSix,
t6.netprofit as netprofitSix,
t6.netrate as netrateSix,
t12.timegroup as timegroupTwe, 
--t12.salername2 as salername2Twe,
t12.salemoneyrmbus as salemoneyrmbusTwe,
t12.salemoneyrmbzn as salemoneyrmbznTwe,
t12.costmoneyrmb as costmoneyrmbTwe,
t12.ppebayus as ppebayusTwe,
t12.ppebayzn as ppebayznTwe,
t12.inpackagefeermb as inpackagefeermbTwe,
t12.expressfarermb as expressfarermbTwe,

t12.devofflinefee as devofflinefeeTwe,
t12.netprofit as netprofitTwe,
t12.netrate as netrateTwe

 
from #tmp0 t0 
left join #tmp6 t6 on t0.salername2=t6.salername2 
LEFT JOIN #tmp12 t12 on t12.salername2=t0.salername2 
where  t0.salername2 LIKE '%'+@salername2+'%' OR  t0.salername2 IN (SELECT salername2 FROM #tbSalerAliasName)    --开发

drop table #tmp0
drop table #tmp6
drop table #tmp12
DROP TABLE #tbSalerAliasName
END
