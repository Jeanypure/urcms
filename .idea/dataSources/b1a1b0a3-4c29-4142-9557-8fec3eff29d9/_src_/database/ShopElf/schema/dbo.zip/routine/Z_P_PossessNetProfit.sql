CREATE PROCEDURE [dbo].[Z_P_PossessNetProfit]
--ALTER PROCEDURE [dbo].[zz_testtest] --美工的毛利表 2017-03-20 ljj mend

--ALTER proc [dbo].[P_RP_SKUlirun_shyr_sku_rjf]
	@DateFlag int=1,                         --时间标记 0 交易时间 1 发货时间
	@BeginDate	varchar(20),               --开始时间
	@EndDate	Varchar(20),               --结束时间		
	@possessMan1 VARCHAR(MAX)                --责任归属人1
	
    
AS
begin
SET  NOCOUNT ON 

		set @BeginDate	=	SUBSTRING(@BeginDate,1,10)
		set @EndDate	=	SUBSTRING(@EndDate,1,10)
  if @DateFlag=0
	begin
		set @BeginDate	=	DATEADD(HH,-8,@BeginDate)
		set @EndDate	=	DATEADD(HH,-8,dateadd(DD,1,@EndDate))
	end
IF @DateFlag=1


--分解美工到临时表里

CREATE TABLE #tbPossess(PossessMan varchar(100))
 IF LTRIM(RTRIM(@possessMan1)) <> ''
  BEGIN
	set @possessMan1=''''+@possessMan1+''''
	DECLARE @sSQLCmd2 VARCHAR(max) = ''
	SET @possessMan1 = REPLACE(@possessMan1,',','''))UNION SELECT ltrim(rtrim(''') 
    SET @sSQLCmd2 = 'INSERT INTO #tbPossess(PossessMan) SELECT ltrim(rtrim('+ @possessMan1+'))'
	EXEC(@sSQLCmd2)

  END
  DECLARE @SelDataUser VARCHAR(Max),
          @SqlCmd VARCHAR(Max), 
          @Username VARCHAR(200),
					--@possessRate VARCHAR(10)= isnull((select devRate from Y_Ratemanagement) ,'')
					@possessRate varchar(10)= isnull((SELECT exchangerate FROM B_CurrencyCode WHERE currencycode='USD'),'')

  -- 创建临时表用来存储信息
  create Table #TmpTradeInfo(
    Nid int not null,                          --订单号
    AllWeight float Null,                      --总重量
    AllQty int Null,                           --总数量
    amt float null,                            --总销售金额
    SHIPPINGAMT float null,                    --买家付运费
    SHIPDISCOUNT float null,                   --ebay交易费
    FeeAmt float null,                         --交易费(pp手续费)
    ExpressFare float null,                    --快递费
    INSURANCEAMOUNT float null,                --包装费
    SKUPACKFEE float null,                     --SKU包装费
    SKU varchar(100) null,                     --SKU
    SKUQty int null,                           --Sku数量
    SKUWeight float null,                      --SKU重量
    SKUCostPrice float null,                   --订单SKU成本价
    SKUamt float null,                         --订单SKU销售金额
    ExchangeRate float null,                   --汇率
    goodsid int null                           --商品ID
  )  
  create Table #TmpSkuFreeInfo(
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --Sku数量
    SaleMoneyRmb float null,                   --SKU 销售金额￥
    ShippingAmtRmb float null,                 --SKU 买家付运费￥
    CostMoneyRmb float null,                   --SKU 销售成本￥
    eBayFeeRmb float null,                     --SKU ebay成交费￥
    PaypalFeeRmb float null,                   --SKU PP手续费￥
    ExpressFareRmb float null,                 --SKU 运费成本￥	
    InPackageFeeRmb float null,                --SKU 包装成本￥
    OutPackageFeeRmb float null,               --SKU 外包装成本￥
  )  
  create Table #TmpSumSkuFreeInfo(
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --销售数量
    SaleMoneyRmb float null,                   --成交价￥
    ShippingAmtRmb float null,                 --买家付运费￥
    CostMoneyRmb float null,                   --销售成本￥
    ProfitRmb float null,                      --实收利润￥
    eBayFeeRmb float null,                     --ebay成交费￥
    PaypalFeeRmb float null,                   --PP手续费￥
    ExpressFareRmb float null,                 --运费成本￥	
    InPackageFeeRmb float null,                  --包装成本￥
    OutPackageFeeRmb float null,               --外包装成本￥
    AverageSaleMoneyRmb float null,            --平均售价￥
    AverageProfitRmb float null                --平均利润价￥
  )  
  
  --查找美元的汇率	
  Declare  @ExchangeRate float  
  set @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode  where CURRENCYCODE='USD'),1) 
  --查找成本计价方法
  Declare @CalcCostFlag int 
  set @CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)
  -- 重寄单数据 不行 重寄单会自动删除
  --select m.OrderNumber as nid into #Tmpchongji from XS_SaleAfterM m 
   --  where m.SaleType='重寄'	
  
  --正常表的数据插入数据库 
  insert into #TmpTradeInfo 
  select m.Nid,                                                                        --订单号
         isnull((select Sum(IsNull(a.Weight,0))   
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))   
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量        
         isnull((select Sum(IsNull(a.l_amt,0))    
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as amt,         --总销售金额  
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end,  --买家付运费 特殊运费
          m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
          m.FeeAmt 
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice 
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice  
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                      --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID     
  FROM  p_tradedt(nolock) d  
  inner join p_trade(nolock) m on m.nid=d.tradenid 
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU 
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID  
  left join B_CurrencyCode c on c.currencycode=m.currencycode 
  where  ((@DateFlag=1 and m.FilterFlag=100 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )
   AND ((ISNULL(@possessMan1,'') = '0') OR (isnull(bg.possessMan1,'') in (select PossessMan from #tbPossess))) 
 	
  

  
  	
  --历史表的数据插入数据库 不用判断发货状态  m.FilterFlag = 10 
  insert into #TmpTradeInfo 
  select m.Nid,                                                                            --订单号
         isnull((select Sum(IsNull(a.Weight,0))   
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))   
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量        
         isnull((select Sum(IsNull(a.l_amt,0))    
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as amt,     --总销售金额  
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end ,  --买家付运费 特殊运费
        m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
         m.FeeAmt 
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice 
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice  
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                       --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID     
  FROM  p_tradedt_his(nolock) d  
  inner join p_trade_his(nolock) m on m.nid=d.tradenid 
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU 
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID  
  left join B_CurrencyCode c on c.currencycode=m.currencycode 
  where  ((@DateFlag=1 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )                              
                                            --SKU
  
 	
   AND ((ISNULL(@possessMan1,'') = '0') OR (isnull(bg.possessMan1,'') in (select PossessMan from #tbPossess))) 
 		
  
       
  --更新总重量和总金额,总数量如果是0 那么改成1
  update #TmpTradeInfo set allweight = 1 where ISNULL(allweight,0) = 0 
  update #TmpTradeInfo set amt = 1 where ISNULL(amt,0) = 0 
  update #TmpTradeInfo set AllQty = 1 where ISNULL(AllQty,0) = 0 
  --select * from #TmpTradeInfo
  --计算金额并插入临时表
  --SKU 销售金额￥    = SKU费用 * 币种汇率
  --SKU 买家付运费￥  = (买家付运费 * 币种汇率) * SKU重量 / 总重量
  --SKU 销售成本￥    = 订单SKU成本价
  --SKU ebay成交费￥  = (ebay交易费 * 美元汇率) * SKU费用 / 总费用
  --SKU PP手续费￥    = (pp手续费 * 币种汇率) * SKU费用 / 总费用
  --SKU 运费成本￥    = 快递费 * SKU重量 / 总重量 
  --SKU 包装成本￥    = (包装费 * 1.0) * SKU数量 / 总数量 + sku包装费 
  insert into #TmpSkuFreeInfo 
  select SKU,                                                    --SKU
         SKUQty ,                                                --Sku数量
         SKUamt * ExchangeRate,                                  --SKU 销售金额￥
         (SHIPPINGAMT * ExchangeRate) * SKUamt/amt ,             --SKU 买家付运费￥
         SKUCostPrice ,                                          --SKU 销售成本￥
         (SHIPDISCOUNT * @ExchangeRate) * SKUamt/amt,            --SKU ebay成交费￥
         (FeeAmt * ExchangeRate) * SKUamt/amt,                   --SKU PP手续费￥
         ExpressFare * SKUWeight / AllWeight,                    --SKU 运费成本￥	
         SKUPACKFEE,                                             --SKU 内包装成本￥
        (INSURANCEAMOUNT * 1.0) * SKUQty / AllQty                --sku 外包装成本
  from #TmpTradeInfo  
  --select * from #TmpSkuFreeInfo
  --统计金额插入临时表
  --成交价￥       = sum(SKU 销售金额￥ + SKU 买家付运费￥)
  --买家付运费￥   = sum(SKU 买家付运费￥)
  --销售成本￥     = sum(SKU 销售成本￥)
  --实收利润￥     = sum(SKU 销售金额￥ + SKU 买家付运费￥ - SKU 销售成本￥ - SKU ebay成交费￥ 
  --                     - SKU PP手续费￥ - SKU 运费成本￥ - SKU 包装成本￥)
  --ebay成交费￥   = sum(SKU ebay成交费￥)
  --PP手续费￥     = sum(SKU PP手续费￥)
  --运费成本￥     = sum(SKU 运费成本￥)
  --包装成本￥     = sum(SKU 包装成本￥)
  --平均售价￥     = 成交价￥ / sum(Sku数量) 
  --平均利润价￥   = 实收利润￥ / sum(Sku数量) 
  insert into #TmpSumSkuFreeInfo 
  select SKU,                                                  --SKU
         SKUQty,                                               --销售数量
         SaleMoneyRmb,                                         --成交价￥
         ShippingAmtRmb,                                       --买家付运费￥
         CostMoneyRmb,                                         --销售成本￥
         ProfitRmb,                                            --实收利润￥                             
         eBayFeeRmb  ,                                         --ebay成交费￥                    
         PaypalFeeRmb ,                                        --PP手续费￥
         ExpressFareRmb ,                                      --运费成本￥	
         InPackageFeeRmb ,                                     --内包装成本￥ 
         OutPackageFeeRmb ,                                       --外包装成本￥ 
         case when SKUQty = 0 then 0 
              else SaleMoneyRmb/SKUQty end,                    --平均售价￥
         case when SKUQty = 0 then 0 
              else ProfitRmb/SKUQty end                        --平均利润价￥
  from 
  (select SKU,                                                  --SKU
         sum(SKUQty) as SKUQty,                                --数量
         SUM(SaleMoneyRmb + ShippingAmtRmb) as SaleMoneyRmb,   --成交价￥
         SUM(ShippingAmtRmb) as ShippingAmtRmb,                --买家付运费￥
         SUM(CostMoneyRmb) as CostMoneyRmb,                    --销售成本￥
         SUM(SaleMoneyRmb + ShippingAmtRmb - CostMoneyRmb 
             - eBayFeeRmb - PaypalFeeRmb - ExpressFareRmb 
             - InPackageFeeRmb-OutPackageFeeRmb) as ProfitRmb,   --实收利润￥                             
         SUM(eBayFeeRmb) as eBayFeeRmb  ,                      --ebay成交费￥                    
         SUM(PaypalFeeRmb) as PaypalFeeRmb ,                   --PP手续费￥
         SUM(ExpressFareRmb) as ExpressFareRmb ,               --运费成本￥	
         SUM(InPackageFeeRmb) as InPackageFeeRmb,                   --内包装成本￥ 
         SUM(OutPackageFeeRmb) as OutPackageFeeRmb                   --外包装成本￥ 
  from #TmpSkuFreeInfo
  group by SKU) aa
--select * from #TmpSumSkuFreeInfo	

  --最后关联统计	
  select	 	
		g.possessMan1 as  possessMan1 ,                       					--'责任归属人1',	
		isnull(g.CreateDate,'') as CreateDate ,               				--'创建日期',		
		round(fg.CostMoneyRmb,2) as CostMoneyRmb,        							--'商品成本￥',
		round(fg.SaleMoneyRmb,2) as SaleMoneyRmb,           					--'销售额￥',
		round(fg.PaypalFeeRmb+fg.eBayFeeRmb,2) as PPebay,							--手续费=PP手续费￥+ebay成交费￥
		round(fg.InPackageFeeRmb,2) as InPackageFeeRmb,               -- '内包装成本￥',		
		round(fg.ExpressFareRmb,2) as ExpressFareRmb,                 -- '运费成本￥',	
		round(fg.ProfitRmb,2) as ProfitRmb                          --'实收利润￥',			
				
		--round(case when isnull(fg.SaleMoneyRmb,0)=0 then 0 else fg.ProfitRmb*100/fg.SaleMoneyRmb end,2) as '利润率%'			
	INTO #TmpPossessGrossprofit
	from #TmpSumSkuFreeInfo fg
	left join B_GoodsSKU gs on gs.SKU=fg.sku
	left join B_goods g on gs.GoodsID=g.NID	
--#TmpPossessGrossprofit临时表中包含 责任人所有的数据
	--select  * FROM #TmpPossessGrossprofit

--责任人的清仓表 满足交易时间段 之后要group by (跨时间段的)
select pos.possess,pos.timegroup,sum(pos.amount)as Amount
INTO #possessOfflinefee 
from 
(SELECT
 possess,
timegroup,
sum(amount) as amount,
possessClearnTime 
FROM Y_possessOfflineClearn 
WHERE possessClearnTime  BETWEEN @BeginDate  AND @EndDate
group by possess,timegroup,possessClearnTime) pos
group  by pos.possess,pos.timegroup

--SELECT * from #possessOfflinefee 
--责任人的运营费用 满足交易时间段
select pos.possess,pos.timegroup,sum(pos.amount)as Amount
INTO #possessOperateFee  
from
(SELECT
 possess,
timegroup,
sum(amount) as amount,
possessOperateTime
FROM Y_possessOperateFee
WHERE possessOperateTime  BETWEEN @BeginDate  AND @EndDate
group by possess,timegroup,possessOperateTime
) pos
group  by pos.possess,pos.timegroup

--select * from #possessOperateFee

--0-6个月的产品 责任人possess
SELECT
'0-6月' as 'TimeGroup' ,
isnull(ss.possessMan1,'') as possessMan1,
cast(SUM(SaleMoneyRmb) / @ExchangeRate as DECIMAL(10,2)) as SaleMoneyRmbUS,              	 	--销售额$
cast((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate  as DECIMAL(10,2)) as SaleMoneyRmbZn ,  	--销售额￥
cast(SUM(CostMoneyRmb) as DECIMAL(10,2)) as CostMoneyRmb,	    															--商品成本
cast(SUM(PPebay) / @ExchangeRate as DECIMAL(10,2)) as PPebayUS,                           --手续费$
cast((SUM(PPebay) / @ExchangeRate) * @possessRate as DECIMAL(10,2)) as PPebayZn,              --手续费￥
cast(SUM(InPackageFeeRmb) as DECIMAL(10,2)) as InPackageFeeRmb,                           --包装成本
cast(SUM(ExpressFareRmb) as DECIMAL(10,2)) as ExpressFareRmb                              --运费成本
,cast(isnull(dof.Amount,0) as DECIMAL(10,2)) as 'possessOfflineFee'														--死库费用
,cast(isnull(dpf.Amount,0) as DECIMAL(10,2)) as 'possessOpeFee'																--运营杂费
,cast(
(SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)
-isnull(dpf.Amount,0)

as DECIMAL(10,2)) as NetProfit                                        --毛利润
 , cast( 100*((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)-isnull(dpf.Amount,0))/((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate) as DECIMAL(10,2)) as netRate                                                                     --毛利率
INTO #ZeroToSixM
from
(
	select
	CreateDate,
	possessMan1,
	sum(CostMoneyRmb) as	CostMoneyRmb,
	sum(SaleMoneyRmb) as SaleMoneyRmb,

	sum(PPebay)  as PPebay ,
	sum(InPackageFeeRmb) as InPackageFeeRmb,
	sum(ExpressFareRmb) as ExpressFareRmb,
	sum(ProfitRmb) as ProfitRmb
from #TmpPossessGrossprofit
WHERE ISNULL(CreateDate, '') BETWEEN CONVERT(VARCHAR(10),DATEADD(dd, -180, @EndDate),121) AND @EndDate
GROUP BY
	CreateDate,	possessMan1
) ss
LEFT JOIN #possessOfflinefee dof ON dof.possess = ss.possessMan1 AND dof.TimeGroup='0-6月'
LEFT JOIN #possessOperateFee dpf ON dpf.possess = ss.possessMan1 AND dpf.TimeGroup='0-6月'
group by
isnull(ss.possessMan1,''),isnull(dof.Amount,0),isnull(dpf.Amount,0)

--select * FROM #ZeroToSixM

--6-12月的产品 责任人possess
SELECT
'6-12月' as 'TimeGroup' ,
isnull(ss.possessMan1,'') as possessMan1,
cast(SUM(SaleMoneyRmb) / @ExchangeRate as DECIMAL(10,2)) as SaleMoneyRmbUS,              	 	--销售额$
cast((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate  as DECIMAL(10,2)) as SaleMoneyRmbZn ,  	--销售额￥
cast(SUM(CostMoneyRmb) as DECIMAL(10,2)) as CostMoneyRmb,	    															--商品成本
cast(SUM(PPebay) / @ExchangeRate as DECIMAL(10,2)) as PPebayUS,                           --手续费$
cast((SUM(PPebay) / @ExchangeRate) * @possessRate as DECIMAL(10,2)) as PPebayZn,              --手续费￥
cast(SUM(InPackageFeeRmb) as DECIMAL(10,2)) as InPackageFeeRmb,                           --包装成本
cast(SUM(ExpressFareRmb) as DECIMAL(10,2)) as ExpressFareRmb                              --运费成本
,cast(isnull(dof.Amount,0) as DECIMAL(10,2)) as 'possessOfflineFee'														--死库费用
,cast(isnull(dpf.Amount,0) as DECIMAL(10,2)) as 'possessOpeFee'																--运营杂费
,cast(
(SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)
-isnull(dpf.Amount,0)

as DECIMAL(10,2)) as NetProfit                                        --毛利润
 , cast( 100*((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)-isnull(dpf.Amount,0))/((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate) as DECIMAL(10,2)) as netRate                                                                     --毛利率
INTO #SixToTweM
from
(
	select
	CreateDate,
	possessMan1,
	sum(CostMoneyRmb) as	CostMoneyRmb,
	sum(SaleMoneyRmb) as SaleMoneyRmb,
	sum(PPebay)  as PPebay ,
	sum(InPackageFeeRmb) as InPackageFeeRmb,
	sum(ExpressFareRmb) as ExpressFareRmb,
	sum(ProfitRmb) as ProfitRmb
from #TmpPossessGrossprofit
WHERE ISNULL(CreateDate, '') BETWEEN CONVERT(VARCHAR(10),DATEADD(dd, -360, @EndDate),121) AND CONVERT(VARCHAR(10),DATEADD(dd, -180, @EndDate),121)
GROUP BY
	CreateDate,	possessMan1
) ss
LEFT JOIN #possessOfflinefee dof ON dof.possess = ss.possessMan1 AND dof.TimeGroup='6-12月'
LEFT JOIN #possessOperateFee dpf ON dpf.possess = ss.possessMan1 AND dpf.TimeGroup='6-12月'
group by
isnull(ss.possessMan1,''),isnull(dof.Amount,0),isnull(dpf.Amount,0)
--SELECT * from #SixToTweM

	
--12月以上的产品 责任人possess
SELECT
'12月以上' as 'TimeGroup' ,
isnull(ss.possessMan1,'') as possessMan1,
cast(SUM(SaleMoneyRmb) / @ExchangeRate as DECIMAL(10,2)) as SaleMoneyRmbUS,              	 	--销售额$
cast((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate  as DECIMAL(10,2)) as SaleMoneyRmbZn ,  	--销售额￥
cast(SUM(CostMoneyRmb) as DECIMAL(10,2)) as CostMoneyRmb,	    															--商品成本
cast(SUM(PPebay) / @ExchangeRate as DECIMAL(10,2)) as PPebayUS,                           --手续费$
cast((SUM(PPebay) / @ExchangeRate) * @possessRate as DECIMAL(10,2)) as PPebayZn,              --手续费￥
cast(SUM(InPackageFeeRmb) as DECIMAL(10,2)) as InPackageFeeRmb,                           --包装成本
cast(SUM(ExpressFareRmb) as DECIMAL(10,2)) as ExpressFareRmb                              --运费成本
,cast(isnull(dof.Amount,0) as DECIMAL(10,2)) as 'possessOfflineFee'														--死库费用
,cast(isnull(dpf.Amount,0) as DECIMAL(10,2)) as 'possessOpeFee'																--运营杂费
,cast(
(SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)
-isnull(dpf.Amount,0)

as DECIMAL(10,2)) as NetProfit                                        --毛利润
 , cast( 100*((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate
-SUM(CostMoneyRmb)
-(SUM(PPebay) / @ExchangeRate) * @possessRate
-SUM(InPackageFeeRmb)
-SUM(ExpressFareRmb)
-isnull(dof.Amount,0)-isnull(dpf.Amount,0))/((SUM(SaleMoneyRmb) / @ExchangeRate)* @possessRate) as DECIMAL(10,2)) as netRate                                                                     --毛利率
INTO #AboveTwe
from
(
	select
	CreateDate,
	possessMan1,
	sum(CostMoneyRmb) as	CostMoneyRmb,
	sum(SaleMoneyRmb) as SaleMoneyRmb,

	sum(PPebay)  as PPebay ,
	sum(InPackageFeeRmb) as InPackageFeeRmb,
	sum(ExpressFareRmb) as ExpressFareRmb,
	sum(ProfitRmb) as ProfitRmb
from #TmpPossessGrossprofit
WHERE ISNULL(CreateDate, '') <=CONVERT(VARCHAR(10),DATEADD(dd, -361, @EndDate),121)
GROUP BY
	CreateDate,	possessMan1
) ss
LEFT JOIN #possessOfflinefee dof ON dof.possess = ss.possessMan1 AND dof.TimeGroup='12月以上'
LEFT JOIN #possessOperateFee dpf ON dpf.possess = ss.possessMan1 AND dpf.TimeGroup='12月以上'
group by
isnull(ss.possessMan1,''),isnull(dof.Amount,0),isnull(dpf.Amount,0)

--SELECT * from #AboveTwe



select
'责任人表' as tableType,
t0.timegroup as timegroupZero,
CASE WHEN t0.possessman1 ='' 
THEN '无人'
ELSE t0.possessman1 
END
as possessman1Zero,
t0.salemoneyrmbus as salemoneyrmbusZero,
t0.salemoneyrmbzn as salemoneyrmbznZero,
t0.costmoneyrmb as costmoneyrmbZero,
t0.ppebayus as ppebayusZero,
t0.ppebayzn as ppebayznZero,
t0.inpackagefeermb as inpackagefeermbZero,
t0.expressfarermb as expressfarermbZero,
t0.possessofflinefee as possessofflinefeeZero,
t0.possessOpeFee as possessOpeFeeZero,
t0.netprofit as netprofitZero,
t0.netrate as netrateZero,
t6.timegroup as timegroupSix,
t6.salemoneyrmbus as salemoneyrmbusSix,
t6.salemoneyrmbzn as salemoneyrmbznSix,
t6.costmoneyrmb as costmoneyrmbSix,
t6.ppebayus as ppebayusSix,
t6.ppebayzn as ppebayznSix,
t6.inpackagefeermb as inpackagefeermbSix,
t6.expressfarermb as expressfarermbSix,
t6.possessofflinefee as possessofflinefeeSix,
t6.possessOpeFee as possessOpeFeeSix,
t6.netprofit as netprofitSix,
t6.netrate as netrateSix,
t12.timegroup as timegroupTwe,
t12.salemoneyrmbus as salemoneyrmbusTwe,
t12.salemoneyrmbzn as salemoneyrmbznTwe,
t12.costmoneyrmb as costmoneyrmbTwe,
t12.ppebayus as ppebayusTwe,
t12.ppebayzn as ppebayznTwe,
t12.inpackagefeermb as inpackagefeermbTwe,
t12.expressfarermb as expressfarermbTwe,
t12.possessofflinefee as possessofflinefeeTwe,
t12.possessOpeFee as possessOpeFeeTwe,
t12.netprofit as netprofitTwe,
t12.netrate as netrateTwe,
(isnull(t0.salemoneyrmbzn,0) + isnull(t6.salemoneyrmbzn,0) + isnull(t12.salemoneyrmbzn,0)) as salemoneyrmbtotal,
(isnull(t0.netprofit,0) + isnull(t6.netprofit,0) + isnull(t12.netprofit,0)) as netprofittotal,
case when isnull(t0.salemoneyrmbzn,0) + isnull(t6.salemoneyrmbzn,0) + isnull(t12.salemoneyrmbzn,0)=0
then 0
else
cast((isnull(t0.netprofit,0) + isnull(t6.netprofit,0) + isnull(t12.netprofit,0))/(isnull(t0.salemoneyrmbzn,0) + isnull(t6.salemoneyrmbzn,0) + isnull(t12.salemoneyrmbzn,0))*100 as DECIMAL(20,2))
end
as netratetotal
--INTO #possess1Alldata
from  #ZeroToSixM t0
left join #SixToTweM t6 on t0.possessman1=t6.possessman1
LEFT JOIN #AboveTwe t12 on t12.possessman1=t0.possessman1
--where  t0.possessman1 LIKE '%'+@possessman1+'%' OR  t0.possessman1 IN (SELECT possessman1 FROM #tbpossessman1)
	
	drop table #TmpTradeInfo
	drop table #TmpSkuFreeInfo	
	drop table #TmpSumSkuFreeInfo
	drop table #TmpPossessGrossprofit
	drop table #possessOperateFee 
	drop table #possessOfflinefee 
  drop TABLE #ZeroToSixM
	drop TABLE #SixToTweM
	drop table #AboveTwe
end	
