create FUNCTION [dbo].[ex_KC_CalcSKUBalMoney]
(
	@StoreID int,
	@GoodsSKUID int
)
RETURNS
	 numeric(18,4)
AS
BEGIN	
		Declare @BalanceMoney numeric(18,4)
		Set @BalanceMoney=0				
/*生成前期数--start*/
	/*--rk*/
		Select 
			@BalanceMoney	= @BalanceMoney + ISNULL(sum(case when M.BillType =2 then -IsNull(D.Money,0) 
			else IsNull(D.Money,0) end),0)
		
		From 
			CG_StockInD  D
		inner join 
			CG_StockInM  M on M.NID = D.StockInNID 				
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
	
	/*--ck*/
		Select 
			@BalanceMoney	= @BalanceMoney +	ISNULL(sum(-IsNull(D.Money,0)),0)
		From 
			CK_StockOutD  D
		inner join 
			CK_StockOutM  M on M.NID = D.StockOutNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 		
			
	/*调拔的--rk*/
		Select 
			@BalanceMoney	= @BalanceMoney +	ISNULL(sum(IsNull(D.Money,0)),0)		
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		Where 
			m.StoreInID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
			
	/*调拔的--ck*/
		Select 
			@BalanceMoney	= @BalanceMoney +	ISNULL(sum(-IsNull(D.Money,0)),0)
		From 
			KC_StockChangeD  D
		inner join 
			KC_StockChangeM  M on M.NID = D.StockChangeNID 
		Where 
			m.StoreOutID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
			
	/*盘点--rk*/
		Select 
			@BalanceMoney	= @BalanceMoney +	ISNULL(sum(IsNull(D.Money,0)),0)		
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 
			and	(IsNull(D.Amount,0)>0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)>0))
			 	
	/*盘点的--ck*/
		Select 
			@BalanceMoney	= @BalanceMoney +	ISNULL(sum(IsNull(D.Money,0)),0)
		From 
			KC_StockCheckD  D
		inner join 
			KC_StockCheckM  M on M.NID = D.StockCheckNID 
		Where 
			m.StoreID=@StoreID 
			and D.GoodsSKUID=@GoodsSKUID 
			and M.CheckFlag =1 	
			and	(IsNull(D.Amount,0)<0 or (IsNull(D.Amount,0)=0 and IsNull(D.money,0)<0))
       RETURN isnull(@BalanceMoney,-999999)  			
		      
END
