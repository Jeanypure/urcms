create Proc [p_CopyRule_EmsFare]
	@SoureNid	int,
	@NewNid  int
as
begin
  delete from B_EmsFareCountry where FareID in (select NID 
      from B_EmsFare where LogisticWayID  = @NewNid)
  delete from B_EmsFare where LogisticWayID  = @NewNid
  
  insert into B_EmsFare (OrderNo, regionName,RegionCountrys, Beginweight,BeginMoneyGoods,BeginMoneyFIle,
      AddWeight, AddMoney, LogisticWayID,copyid) 
  select OrderNo, regionName,RegionCountrys, Beginweight,BeginMoneyGoods,BeginMoneyFIle,
      AddWeight, AddMoney, @NewNid,NID 
  from B_EmsFare where LogisticWayID = @SoureNid

  select distinct A.CountryID, C.Nid as NewNid into #TmpTable1 
  from B_EmsFareCountry A
     inner join B_EmsFare B on A.FareID = B.NID and B.LogisticWayID = @SoureNid
     inner join B_EmsFare C on C.copyid = B.nid and  C.LogisticWayID = @NewNid 
  
 -- select * from #TmpTable1
  insert into B_EmsFareCountry(FareID, CountryID)
     select distinct NewNid,CountryID from #TmpTable1
  --1128copy postcode   
   
  insert into B_EmsFarePostCode(postcodeS, postcodeE, EmsFareCountryID, postName)
  select distinct postcodeS, postcodeE, cc.NID, postName 
  from B_EmsFarePostCode  b 
  inner join B_EmsFareCountry c on c.NID=b.EmsFareCountryID
  inner join B_EmsFare f on f.NID=c.FareID 
  inner join B_EmsFare fc on fc.CopyID=f.NID
  inner join B_EmsFareCountry cc on cc.FareID=fc.NID and cc.CountryID=c.CountryID
  where f.LogisticWayID= @SoureNid and fc.LogisticWayID=@NewNid
     
  drop table #TmpTable1
end
