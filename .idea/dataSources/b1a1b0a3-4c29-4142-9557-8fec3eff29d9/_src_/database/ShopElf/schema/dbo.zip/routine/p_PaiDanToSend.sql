create procedure [dbo].[p_PaiDanToSend] 
  @nids varchar(max),
  @UserName varchar(100),
  @BatchNum varchar(40)
as 
begin
 create table #TabNid(TradeNid int)
 
 DECLARE 
    @sSQLCmd varchar(max) = '',
    @iNid  int,
    @TradeNid int,
    @StoreID int,
    @GoodsSkuID int,
    @L_Qty int,
    @L_Amt numeric(20,4),
    @flag int,
    @OldTradeNid int=0
 
 select @sSQLCmd =  'insert into #TabNid(TradeNid) select ' +	REPLACE(@nids,',',' union select ');
 EXEC(@sSQLCmd);

 begin tran  
 
 declare myCur cursor --定义游标 
 For( 
   SELECT ptd.TradeNID, Max(ptd.nid) as nid,  isnull(ptd.StoreID,0) as StoreID, 
       isnull(ptd.GoodsSKUID,0) as GoodsSKUID, 
       sum(ptd.L_QTY) as L_QTY, sum(ptd.L_AMT) as L_AMT  
       FROM P_TradeDt ptd 
       WHERE ptd.TradeNID in (select TradeNID from #TabNid)
       group by isnull(ptd.StoreID,0),isnull(ptd.GoodsSKUID,0),TradeNID      
    )
	    
	open myCur  
	fetch next from myCur into @TradeNid, @iNid, @StoreID,@GoodsSkuID,@L_Qty,@L_Amt
	set @flag=0 
	while @@fetch_status=0 
	begin 
	  EXEC P_KC_Insert_CK_StockOut @TradeNid,@iNid,@StoreID,@GoodsSkuID,@L_Qty,@L_Amt,@UserName
	  if @@error <> 0 
	  begin 
	    goto labend  
	  end 
	  
	  if @TradeNid <> @OldTradeNid begin 
	    exec S_WriteTradeLogs @TradeNid,'手工转至已发货',@UserName
	  end 
	  
	  set @OldTradeNid = @TradeNid

	  fetch next from myCur into  @TradeNid, @iNid, @StoreID,@GoodsSkuID,@L_Qty,@L_Amt
	end 
	close myCur 
	deallocate myCur 
	
	UPDATE P_Trade  
    SET SHIPPINGMETHOD = (case when SHIPPINGMETHOD='1'  then '1' else '0' end) 
        ,ExpressStatus=1, FilterFlag=100, 
        CLOSINGDATE=CONVERT(varchar(16),GETDATE(),121),BatchNum= @BatchNum
    WHERE NID in (select TradeNID from #TabNid)
	
	drop table #TabNid
	commit tran 
	return 0 
    
    
  labend:
    drop table #TabNid
    rollback tran 
    return -1
          
end
