create  procedure [dbo].[p_Query_GongZhiReportGroup]
  @Type int ,
  @BeginDate datetime,
  @EndDate datetime,
  @PersonName varchar(50),
  @OrderNo varchar(50)
 
as
begin
  --@Type：
  --1. 验货统计报表
  --2. 上架统计报表
  --3. 发货拣货统计报表
  --4. 预包装统计报表
    create table #TabLocation(
     LocationName varchar(200),
     GoodsSkuID int
     )
     
   create table #TabTradeNid3(
      Nid int 
      )
 
  insert into #TabLocation(LocationName,GoodsSkuID)
  select distinct max(LocationName), GoodsSKuID
     from B_GoodsSKULocation A
     inner join B_StoreLocation B on (A.LocationID = B.NID)
     group by GoodsSKUID 
     
     
  if @Type = 3 begin    
   insert into #TabTradeNid3(Nid)  
      select Nid from P_Trade A
        where 1=1 and (A.Nid = @OrderNo) or (@OrderNo = '')
            -- and  A.SHIPPINGMETHOD = 1 //modify by ylq 2015-12-09 因为修改了filterflag, 这个发货标志就不需要了
                and A.FilterFlag >=20
                and A.CLOSINGDATE >= convert(varchar(10),@BeginDate,120)
                and A.CLOSINGDATE <= Convert(varchar(19),@EndDate,120) 
                and ((IsNull(A.PackingMen,'') = @PersonName) or (@PersonName = ''))       
  end 
  
  if @Type = 1 begin
  
    select MakeDate,PersonName,SUM(Money) as Money
    from 
    (
    
    select convert(varchar(10), MakeDate,120) as MakeDate, BillNumber, gs.SKU, cat.CategoryName, 
      A.Recorder as PersonName, xs.price, 
      Sum(b.Amount) as Amount,
      case when  xs.xs2 = 0 then
        xs.price * xs.XS2_2 
      else 
         xs.price * xs.XS2 * Sum(B.Amount)
      end as Money,
      case when  xs.xs2 = 0 then '按个数' else '按数量' end as TypeName,
      case when  xs.xs2 = 0 then xs.xs2_2 else xs.xs2 end as xs,
      g.GoodsName, 
      tb1.LocationName 
      from CG_StockInM A
      inner join CG_StockInD B on A.NID = B.StockInNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID 
      inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      where A.MakeDate >= @BeginDate and A.MakeDate <= @EndDate and
        ((IsNull(A.Recorder,'') = @PersonName) or (@PersonName = ''))
        and ((A.BillNumber = @OrderNo) or (@OrderNo = ''))
      group by convert(varchar(10), MakeDate,120),BillNumber, gs.SKU, cat.CategoryName,       
         A.Recorder,xs.price,xs.XS2, xs.XS2_2,g.GoodsName,tb1.LocationName 
      ) A group by MakeDate,PersonName
 end
 else if ( @Type = 2) begin
 
    select MakeDate,PersonName,SUM(Money) as Money
    from 
    ( 
    select convert(varchar(10), MakeDate,120) as MakeDate, BillNumber, gs.SKU, cat.CategoryName, 
      per.PersonName,xs.price,
      Sum(b.Amount) as Amount,
      case when  xs.xs3 = 0 then
        xs.price * xs.XS3_2 
      else 
         xs.price * xs.XS3 * Sum(B.Amount)
      end as Money,
      case when  xs.xs3 = 0 then '按个数' else '按数量' end as TypeName,
      case when  xs.xs3 = 0 then xs.xs3_2 else xs.xs3 end as xs,
      g.GoodsName, 
      tb1.LocationName  
      from CG_StockInM A
      inner join CG_StockInD B on A.NID = B.StockInNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID 
      left join  B_Person per on per.Nid = A.QualityID  
      inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      where A.MakeDate >= @BeginDate and A.MakeDate <= @EndDate and
        ((IsNull(per.PersonName,'') = @PersonName) or (@PersonName = ''))
        and ((A.BillNumber = @OrderNo) or (@OrderNo = ''))
     group by convert(varchar(10), MakeDate,120),BillNumber, gs.SKU, cat.CategoryName,       
         per.PersonName,xs.price,xs.XS3, xs.XS3_2,g.GoodsName,tb1.LocationName   
     ) A group by MakeDate,PersonName
            
 end
 else if (@Type = 3) begin
    select MakeDate,PersonName,SUM(Money) as Money
    from 
    ( 
       select convert(varchar(10),A.CLOSINGDATE,120) as MakeDate,
          A.NID as BillNumber, gs.SKU, cat.CategoryName, b.L_QTY,
          A.PackingMen as PersonName,xs.Price,xs.price * xs.XS1 * ISNULL(xsl.XS,1) as Money,
          logi.name as logicsWayName,
          g.GoodsName, 
          xs.XS1 * ISNULL(xsl.XS,1) as xs,
          B.L_QTY as AMount,
          '按个数'   as TypeName,
          tb1.LocationName
    from P_Trade A   
      inner join P_TradeDt B on A.NID = B.TradeNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID  
      inner join B_LogisticWay logi on logi.NID = A.logicsWayNID    
      inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
      left join B_GongZhi_LogisXiShu xsl on xsl.LogicsWayNid = A.logicsWayNID 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      inner join #TabTradeNid3 tb2 on tb2.Nid = A.NID 
      where A.MULTIITEM <= 1         --单SKU的
	union 
		select convert(varchar(10),A.CLOSINGDATE,120) as MakeDate,
			  A.NID as BillNumber, gs.SKU, cat.CategoryName, b.L_QTY,
			  A.PackingMen as PersonName,xs.Price,xs.price * xs.XS1_2 * ISNULL(xsl.XS2,1) as Money,
			  logi.name as logicsWayName,
			  g.GoodsName, 
			  xs.XS2 * ISNULL(xsl.XS2,1) as xs,
			  B.L_QTY as AMount,
			  '按个数'   as TypeName,
			  tb1.LocationName 
		from P_Trade A   
		  inner join P_TradeDt B on A.NID = B.TradeNID 
		  inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
		  inner join B_Goods g on gs.GoodsID = g.NID 
		  left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID  
		  inner join B_LogisticWay logi on logi.NID = A.logicsWayNID    
		  inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
		  left join B_GongZhi_LogisXiShu xsl on xsl.LogicsWayNid = A.logicsWayNID 
		  left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
		  inner join #TabTradeNid3 tb2 on tb2.Nid = A.NID 
		  where A.MULTIITEM > 1         --多SKU的

    ) A group by MakeDate,PersonName 
 end
 else if (@Type = 4) begin
   select MakeDate,PersonName,SUM(Money) as Money
    from 
    (
     select convert(varchar(10), MakeDate,120) as MakeDate, BillNumber, gs.SKU, cat.CategoryName, 
      A.Recorder as PersonName, xs.price, 
      Sum(b.Amount) as Amount,
      xs.price * xs.XS4 * Sum(B.Amount) as Money,
      '按数量'   as TypeName,
      xs.XS4 as xs,
      g.GoodsName, 
      tb1.LocationName 
      from CG_StockInM A
      inner join CG_StockInD B on A.NID = B.StockInNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID 
      inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      where A.MakeDate >= @BeginDate and A.MakeDate <= @EndDate and
        ((IsNull(A.Recorder,'') = @PersonName) or (@PersonName = ''))
        and ((A.BillNumber = @OrderNo) or (@OrderNo = ''))
        and xs.XS4 <> 0 
      group by convert(varchar(10), MakeDate,120),BillNumber, gs.SKU, cat.CategoryName,       
         A.Recorder,xs.price,xs.XS4,g.GoodsName,gs.NID,tb1.LocationName 
      ) A group by MakeDate,PersonName   
 
 end
 else if (@Type = 5) begin
    
    select MakeDate ,CategoryName, SUM(Money) as Money
    from 
    ( 
    select convert(varchar(10),A.CLOSINGDATE,120) as MakeDate, A.NID as BillNumber, gs.SKU, cat.CategoryName, b.L_QTY,
        A.PackageMen as PersonName,xs.Price,xs.price * xs.XS5 * b.L_QTY as Money,
        logi.name as logicsWayName,
        xs.XS5 as xs,
        g.GoodsName, 
        tb1.LocationName  
    from P_Trade A   
      inner join P_TradeDt B on A.NID = B.TradeNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID   
      inner join B_LogisticWay logi on logi.NID = A.logicsWayNID  
      inner join B_GongZhi_XiShu xs on xs.sku = g.SKU 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID   
      where 1=1 
    --  and A.SHIPPINGMETHOD = 1 //modify by ylq 2015-12-09 因为修改了filterflag, 这个发货标志就不需要了
      and A.FilterFlag >=20
      and A.CLOSINGDATE >= @BeginDate and A.CLOSINGDATE <= @EndDate and
        ((IsNull(A.PackageMen,'') = @PersonName) or (@PersonName = ''))
       and ((A.Nid = @OrderNo) or (@OrderNo = ''))
     ) A group by MakeDate,CategoryName 
     
 end

end

