
CREATE procedure [dbo].[p_Query_GongZhiReport_2]
  @Nid int ,
  @TableFlag int,
  @PersonField varchar(32),
  @BeginDate datetime,
  @EndDate datetime,
  @PersonName varchar(30),
  @OrderNo varchar(50)
  
as
begin
  	DECLARE @SqlStr VarChar(Max), @TempPersonField varchar(32)
	
  create table #TabLocation(
     LocationName varchar(200),
     GoodsSkuID int
     )
     
   create table #TabTradeNid3(
      Nid int 
      )
      
   create Table #CGStockNid(
     Nid int,
     iSkuCount int
     )

  insert into #TabLocation(LocationName,GoodsSkuID)
  select distinct max(LocationName), GoodsSKuID
     from B_GoodsSKULocation A
     inner join B_StoreLocation B on (A.LocationID = B.NID)
     group by GoodsSKUID 
     
  if @TableFlag = 1 begin    
   insert into #TabTradeNid3(Nid)  
      select Nid from P_Trade A
        where 1=1 and (A.Nid = @OrderNo) or (@OrderNo = '')
                and A.FilterFlag >=20
                and A.CLOSINGDATE >= convert(varchar(10),@BeginDate,120)
                and A.CLOSINGDATE <= Convert(varchar(19),@EndDate,120) 
                and ((IsNull(A.PackingMen,'') = @PersonName) or (@PersonName = '')) 
                
   insert into #TabTradeNid3(Nid)  
      select Nid from P_Trade_His A
        where 1=1 and (A.Nid = @OrderNo) or (@OrderNo = '')
                and A.FilterFlag >=20
                and A.CLOSINGDATE >= convert(varchar(10),@BeginDate,120)
                and A.CLOSINGDATE <= Convert(varchar(19),@EndDate,120) 
                and ((IsNull(A.PackingMen,'') = @PersonName) or (@PersonName = ''))        
  end 
  
  if @TableFlag = 0 begin
    if @PersonField = 'QualityMan' begin
      set @PersonField = 'bp.PersonName '
    end
    if @PersonField = 'recorder' begin
      set @PersonField = 'A.recorder '
    end
 
    SET @SqlStr = 'insert into #CGStockNid(Nid, iSkuCount)
       select StockInNID, COUNT(1) from CG_StockInD B
       inner join CG_StockInM A on B.StockInNID = A.NID 
       left join B_Person bp on bp.Nid = A.QualityID
       where A.CheckFlag = 1 and A.MakeDate >= ''' + convert(varchar(10),@BeginDate,120) + 
       ''' and A.MakeDate <= ''' + Convert(varchar(19),@EndDate,120) +
        ''' and ((IsNull(' + @PersonField + ','''') = ''' + @PersonName + ''' ) or (''' + @PersonName  + 
        ''' = '''')) and ((A.BillNumber = ''' +  @OrderNo + ''' ) or ( ''' + @OrderNo + ''' = ''''))
       group by StockInNID '
    EXEC(@SqlStr)
  end
  
  if @TableFlag = 0 begin
    if @PersonField = 'QualityMan' begin
      set @PersonField = 'bp.PersonName '
    end
    if @PersonField = 'recorder' begin
      set @PersonField = 'A.recorder '
    end
    
    set @SqlStr =
    '  select convert(varchar(10), MakeDate,120) as MakeDate, BillNumber, gs.SKU, cat.CategoryName, ' +
      @PersonField + ' as PersonName, xs.price, 
      Sum(b.Amount) as Amount,
      case when xs.IsOne = 1 then ''按个数'' else ''按数量'' end as TypeName,
      case when xs.IsOne = 1 and tb0.iSkuCount = 1 then xs.Price * xs.XS1 
           when xs.IsOne = 1 and tb0.iSkuCount > 1 then xs.Price * xs.XS2 * tb0.iSkuCount 
           when xs.IsOne = 0 and tb0.iSkuCount = 1 then xs.Price * xs.XS1 * Sum(b.Amount)
           when xs.IsOne = 0 and tb0.iSkuCount > 1 then xs.Price * xs.XS2 * SUM(b.Amount)
      end as Money,
      case when tb0.iSkuCount = 1 then xs.XS1 else xs.xs2 end as xs,
      g.GoodsName, 
      tb1.LocationName 
      from CG_StockInM A
      inner join CG_StockInD B on A.NID = B.StockInNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID 
      inner join B_Gongzhi_StationXiSu xs on xs.Nid = ' + convert(varchar(10),@Nid) + ' 
      inner join #CGStockNid tb0 on tb0.Nid = A.NID 
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      left join B_Person bp on bp.Nid = A.QualityID
      group by convert(varchar(10), MakeDate,120),BillNumber, gs.SKU, cat.CategoryName,       
         xs.price,xs.XS1,xs.XS2,g.GoodsName,tb1.LocationName,xs.IsOne,tb0.iSkuCount, ' + @PersonField
         
     
   print (@SqlStr)
 
 end
 else  begin
   set @SqlStr = 'select convert(varchar(10),A.ORDERTIME,120) as MakeDate,
          A.NID as BillNumber, gs.SKU, cat.CategoryName, b.L_QTY,' +
          @PersonField + ' as PersonName,xs.Price,
          case when xs.IsOne = 1 then ''按个数'' else ''按数量'' end as TypeName,
           case when xs.IsOne = 1 and A.MULTIITEM = 1 then xs.Price * xs.XS1 
           when xs.IsOne = 1 and A.MULTIITEM  > 1 then xs.Price * xs.XS2 -- * A.MULTIITEM  
           when xs.IsOne = 0 and A.MULTIITEM  = 1 then xs.Price * xs.XS1 * B.L_QTY
           when xs.IsOne = 0 and A.MULTIITEM  > 1 then xs.Price * xs.XS2 * B.L_QTY
          end as Money,
          case when A.MULTIITEM = 1 then xs.XS1 else xs.xs2 end as xs, 
          logi.name as logicsWayName,
          g.GoodsName, 
          B.L_QTY as AMount,
          tb1.LocationName
    from P_Trade A   
      inner join P_TradeDt B on A.NID = B.TradeNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID  
      inner join B_LogisticWay logi on logi.NID = A.logicsWayNID    
      inner join B_Gongzhi_StationXiSu xs on xs.Nid = ' + convert(varchar(10),@Nid)  + '    
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      inner join #TabTradeNid3 tb2 on tb2.Nid = A.NID 
  union
      select convert(varchar(10),A.ORDERTIME,120) as MakeDate,
          A.NID as BillNumber, gs.SKU, cat.CategoryName, b.L_QTY,' +
          @PersonField + ' as PersonName,xs.Price,
          case when xs.IsOne = 1 then ''按个数'' else ''按数量'' end as TypeName,
           case when xs.IsOne = 1 and A.MULTIITEM = 1 then xs.Price * xs.XS1 
           when xs.IsOne = 1 and A.MULTIITEM  > 1 then xs.Price * xs.XS2 -- * A.MULTIITEM  
           when xs.IsOne = 0 and A.MULTIITEM  = 1 then xs.Price * xs.XS1 * B.L_QTY
           when xs.IsOne = 0 and A.MULTIITEM  > 1 then xs.Price * xs.XS2 * B.L_QTY
          end as Money,
          case when A.MULTIITEM = 1 then xs.XS1 else xs.xs2 end as xs, 
          logi.name as logicsWayName,
          g.GoodsName, 
          B.L_QTY as AMount,
          tb1.LocationName
    from P_Trade_His A   
      inner join P_TradeDt_his B on A.NID = B.TradeNID 
      inner join B_GoodsSKU gs on gs.NID = B.GoodsSKUID 
      inner join B_Goods g on gs.GoodsID = g.NID 
      left join B_GoodsCats cat on cat.NID = g.GoodsCategoryID  
      inner join B_LogisticWay logi on logi.NID = A.logicsWayNID    
      inner join B_Gongzhi_StationXiSu xs on xs.Nid = ' + convert(varchar(10),@Nid)  + '    
      left join #TabLocation tb1 on tb1.GoodsSkuID = gs.NID 
      inner join #TabTradeNid3 tb2 on tb2.Nid = A.NID    
      '       
 end  
 
 
 EXEC(@SqlStr)
 
 
 drop table #TabLocation
 drop table #TabTradeNid3
 drop table #CGStockNid

end

