create PROCEDURE [dbo].[p_UpLineGoodsByDev] @nids varchar(500) 
AS
BEGIN

 set @nids = '0,'+@nids+',0'
	CREATE TABLE #TmpNids
	(
		Nid INT NOT NULL DEFAULT 0
	) 
 
    declare @MaxNID int   
    
    --简化一下订单号的插入代码 陈卫
    DECLARE @sSQLCmd varchar(max) = '' 
	select @sSQLCmd =  'insert into #TmpNids(Nid) select ' +	REPLACE(@nids,',',' union select ') 	
    EXEC(@sSQLCmd) 
    
  delete from B_Goods_Dev where NID in (select MAX(Nid) from B_Goods_Dev where Sku <> '' group by SKU having COUNT(*)>1)
  delete from B_GoodsSku_Dev where GoodsID not in (select NID from B_Goods_Dev)
     
  insert into B_GOODS(GoodsCategoryID, CategoryCode,GoodsCode,GoodsName,ShopTitle,SKU, BarCode,FitCode,MultiStyle,Material,Class,
     Model,Unit,Style,Brand,LocationID,Quantity,SalePrice,CostPrice,AliasCnName,AliasEnName,Weight,DeclaredValue,OriginCountry,
     OriginCountryCode,ExpressID,Used,BmpFileName,BmpUrl,MaxNum,MinNum,GoodsCount,SupplierID,Notes,SampleFlag,SampleCount,SampleMemo,
     CreateDate,GroupFlag,SalerName,SellCount,SellDays,PackFee,PackName,GoodsStatus,DevDate,SalerName2,BatchPrice,MaxSalePrice,
     RetailPrice,MarketPrice,PackageCount,ChangeStatusTime,StockDays,StoreID,Purchaser,LinkUrl,LinkUrl2,LinkUrl3,StockMinAmount,
     MinPrice,HSCODE,InLong,InWide,InHigh,InGrossweight,InNetweight,OutLong,OutWide,OutHigh,OutGrossweight,OutNetweight,ShopCarryCost,
     ExchangeRate,WebCost,PackWeight,LogisticsCost,GrossRate,PackMsg,ItemUrl,IsCharged)
  select GoodsCategoryID, CategoryCode,GoodsCode,GoodsName,ShopTitle,SKU, BarCode,FitCode,MultiStyle,Material,Class,
     Model,Unit,Style,Brand,LocationID,Quantity,SalePrice,CostPrice,AliasCnName,AliasEnName,Weight,DeclaredValue,OriginCountry,
     OriginCountryCode,ExpressID,Used,BmpFileName,BmpUrl,MaxNum,MinNum,GoodsCount,SupplierID,Notes,SampleFlag,SampleCount,SampleMemo,
     CreateDate,GroupFlag,SalerName,SellCount,SellDays,PackFee,PackName,GoodsStatus,DevDate,SalerName2,BatchPrice,MaxSalePrice,
     RetailPrice,MarketPrice,PackageCount,ChangeStatusTime,StockDays,StoreID,Purchaser,LinkUrl,LinkUrl2,LinkUrl3,StockMinAmount,
     MinPrice,HSCODE,InLong,InWide,InHigh,InGrossweight,InNetweight,OutLong,OutWide,OutHigh,OutGrossweight,OutNetweight,ShopCarryCost,
     ExchangeRate,WebCost,PackWeight,LogisticsCost,GrossRate,PackMsg,ItemUrl,IsCharged
  from B_Goods_Dev A
  inner join #TmpNids B on A.NID = B.Nid 
  
  set @MaxNID = SCOPE_IDENTITY()
  
  
  update B_Goods_Dev set DevState = 4, UpDateTime = GETDATE() where NID in (select NID from #TmpNids)
   
  insert into B_GoodsSupplier (GoodsID,SupplierName,LinkMan,Phone,Price,Remark,Url,SupIndex)
    select A.Nid, B.SupplierName,B.LinkMan,B.Phone,B.Price,B.Remark,B.Url,B.SupIndex from
    B_GOODS A 
    inner join B_Goods_Dev C on A.SKU = C.SKU 
    inner join #TmpNids D on C.NID = D.Nid 
    inner join B_GoodsSupplier_Dev B on C.NID = B.GOodsID
    
  
   
  delete from B_GoodsSku where GoodsID = @MaxNID
  
  
  insert into B_GoodsSku(GoodsID,SKU,property1,property2,property3,SKUName,LocationID,BmpFileName,SellCount,
     Remark,SellCount1,SellCount2, SellCount3,Weight,CostPrice,RetailPrice,MaxNum,MinNum, GoodsSKUStatus,
     UPC,ASINN 
     )
  select @MaxNID,C.SKU,property1,property2,property3,SKUName,C.LocationID,C.BmpFileName,C.SellCount,
     Remark,SellCount1,SellCount2, SellCount3,C.Weight,C.CostPrice,C.RetailPrice,C.MaxNum,C.MinNum,  GoodsSKUStatus,
     E.UPC, E.[ASIN]  
  from B_GoodsSku_Dev C 
  inner join B_Goods_Dev E on C.GoodsID = E.NID 
  
  inner join #TmpNids D on C.GoodsID = D.Nid 
 
  drop table #TmpNids 
  
end 
  
  
