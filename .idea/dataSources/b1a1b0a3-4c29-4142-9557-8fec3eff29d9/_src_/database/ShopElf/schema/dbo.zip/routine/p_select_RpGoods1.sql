
-- 多业绩归属查询
create procedure [dbo].[p_select_RpGoods1]  
  @WhereStr varchar(2000)
as
begin
  declare @Sql varchar(max)
  	
  --查找美元的汇率	
  Declare  @ExchangeRate float  
  set @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode  where CURRENCYCODE='USD'),1) 	

  -- 创建临时表用来存储信息
  create Table #TmpTradeInfo(
    Nid int not null,                          --订单号
    AllWeight float Null,                      --总重量
    AllQty int Null,                           --总数量
    amt float null,                            --总销售金额
    SHIPPINGAMT float null,                    --买家付运费
    SHIPDISCOUNT float null,                   --ebay交易费
    FeeAmt float null,                         --交易费
    ExpressFare float null,                    --快递费
    INSURANCEAMOUNT float null,                --包装费
    SKUPACKFEE float null,                     --SKU包装费
    SKU varchar(100) null,                     --SKU
    SKUQty int null,                           --Sku数量
    SKUWeight float null,                      --SKU重量
    SKUCostPrice float null,                   --订单SKU成本价
    SKUamt float null,                         --订单SKU销售金额
    ExchangeRate float null,                   --汇率
    goodsid int null                           --商品ID 
    )  
  create Table #TmpSkuFreeInfo(
    SKU varchar(100)  null,                    --SKU
    goodsid int null,                          --商品ID 
    SKUQty int null,                           --Sku数量
    SKUCostPrice float null,                   --订单SKU成本价
    SKUAMT float null                          --订单SKU销售金额  
    )  
  --正常表，异常表，和历史表的数据插入数据库 
  --查找成本计价方法
  set @Sql = 'Declare @CalcCostFlag int' 
    + ' set @CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode =''CalCostFlag''),0)'
  --正常表 
  set @Sql = @Sql + ' insert into #TmpTradeInfo '
    + ' select m.Nid,'                                             --订单号
    + 'isnull((select Sum(IsNull(a.Weight,0)) '   
    + ' from p_tradedt(nolock) a where a.tradenid = m.nid),0) as allweight ,'  --总重量
    + 'isnull((select Sum(IsNull(a.L_QTY,0)) '   
    + ' from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,'     --总数量
    + 'isnull((select Sum(IsNull(a.l_amt,0)) '   
    + ' from p_tradedt(nolock) a where a.tradenid = m.nid),0) as amt,'         --总销售金额  
    + 'm.SHIPPINGAMT,'                                             --买家付运费
    + 'm.SHIPDISCOUNT,'                                            --ebay交易费
    + 'm.FeeAmt,'                                                  --交易费
    + 'm.ExpressFare,'                                             --快递费
    + 'm.INSURANCEAMOUNT,'                                         --包装费
    + 'case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,'                              --SKU包装费
    + 'd.sku,'                                                     --SKU
    + 'd.l_qty,'                                                   --SKU数量
    + 'd.weight,'                                                  --SKU重量
    + 'case when @CalcCostFlag =0 then d.CostPrice '
    + ' else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice ' 
    +                ' else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,'  --订单SKU成本价
    + 'd.l_amt,'                                                   --订单SKU销售金额
    + 'isnull(c.ExchangeRate,1),'                                  --汇率
    + 'bg.nid as goodsid'                                          --商品ID     
    + ' FROM  p_tradedt(nolock) d'  
    + ' inner join p_trade(nolock) m on m.nid=d.tradenid' 
    + ' LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID'  
    + ' LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID'  
    + ' left join B_CurrencyCode c on c.currencycode=m.currencycode ' 
    + @WhereStr 
  --异常表
  set @Sql = @Sql + ' insert into #TmpTradeInfo '
    + ' select m.Nid,'                                             --订单号
    + 'isnull((select Sum(IsNull(a.Weight,0)) '   
    + ' from p_tradedtun(nolock) a where a.tradenid = m.nid),0) as allweight ,'  --总重量
    + 'isnull((select Sum(IsNull(a.L_QTY,0)) '   
    + ' from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,'       --总数量
    + 'isnull((select Sum(IsNull(a.l_amt,0)) '   
    + ' from p_tradedtun(nolock) a where a.tradenid = m.nid),0) as amt,'         --总销售金额                                                   
    + 'm.SHIPPINGAMT,'                                             --买家付运费
    + 'm.SHIPDISCOUNT,'                                            --ebay交易费
    + 'm.FeeAmt,'                                                  --交易费
    + 'm.ExpressFare,'                                             --快递费
    + 'm.INSURANCEAMOUNT,'                                         --包装费
    + 'case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,'                              --SKU包装费
    + 'd.sku,'                                                     --SKU
    + 'd.l_qty,'                                                   --SKU数量
    + 'd.weight,'                                                  --SKU重量
    + 'case when @CalcCostFlag =0 then d.CostPrice '
    + ' else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice ' 
    +                ' else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,'  --订单SKU成本价
    + 'd.l_amt,'                                                   --订单SKU销售金额
    + 'isnull(c.ExchangeRate,1),'                                  --汇率
    + 'bg.nid as goodsid'                                          --商品ID     
    + ' FROM  p_tradedtun(nolock) d'  
    + ' inner join p_tradeun(nolock) m on m.nid=d.tradenid' 
    + ' LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID'  
    + ' LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID'  
    + ' left join B_CurrencyCode c on c.currencycode=m.currencycode ' 
    + @WhereStr 
  --历史表
  set @Sql = @Sql + ' insert into #TmpTradeInfo '
    + ' select m.Nid,'                                             --订单号
    + 'isnull((select Sum(IsNull(a.Weight,0)) '   
    + ' from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as allweight ,'  --总重量
    + 'isnull((select Sum(IsNull(a.L_QTY,0)) '   
    + ' from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,'         --总数量
    + 'isnull((select Sum(IsNull(a.l_amt,0)) '   
    + ' from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as amt,'         --总销售金额  
    + 'm.SHIPPINGAMT,'                                             --买家付运费
    + 'm.SHIPDISCOUNT,'                                            --ebay交易费
    + 'm.FeeAmt,'                                                  --交易费
    + 'm.ExpressFare,'                                             --快递费
    + 'm.INSURANCEAMOUNT,'                                         --包装费
    + 'case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,'                              --SKU包装费
    + 'd.sku,'                                                     --SKU
    + 'd.l_qty,'                                                   --SKU数量
    + 'd.weight,'                                                  --SKU重量
    + 'case when @CalcCostFlag =0 then d.CostPrice '
    + ' else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice ' 
    +                ' else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,'  --订单SKU成本价
    + 'd.l_amt,'                                                   --订单SKU销售金额
    + 'isnull(c.ExchangeRate,1),'                                  --汇率
    + 'bg.nid as goodsid'                                          --商品ID     
    + ' FROM  p_tradedt_his(nolock) d'  
    + ' inner join p_trade_his(nolock) m on m.nid=d.tradenid' 
    + ' LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID'  
    + ' LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID'  
    + ' left join B_CurrencyCode c on c.currencycode=m.currencycode ' 
    + @WhereStr 
  exec(@Sql)
  
  --更新总重量和总金额如果是0 那么改成1
  update #TmpTradeInfo set allweight = 1 where ISNULL(allweight,0) = 0 
  update #TmpTradeInfo set amt = 1 where ISNULL(amt,0) = 0 
  
  --计算金额并插入临时表
  --销售金额 = SKU销售金额  * 汇率
  --           - ((ebay交易费 * 美元汇率) +  (交易费 * 币种汇率)) * 费用/总费用
  --           - (包装费 * 1.0) * SKU数量 / 总数量 - sku包装费 
  --           - 快递费 * SKU重量 / 总重量 
  --           + (买家付运费 * 币种汇率) * SKU重量 / 总重量
  insert into #TmpSkuFreeInfo 
  select SKU,                     --SKU
         isnull(goodsid,0),       --商品ID 关联多业绩归属人用
         isnull(SKUQty,0),        --SKU数量
         isnull(SKUCostPrice,0),  --订单SKU成本
         SKUamt * ExchangeRate 
         - case when amt =0 then 0 else (SHIPDISCOUNT * @ExchangeRate + FeeAmt * ExchangeRate) * SKUamt/amt end
         - case when AllQty = 0 then 0 else (INSURANCEAMOUNT * 1.0) * SKUQty / AllQty end - SKUPACKFEE 
         - case when AllWeight = 0 then 0 else ExpressFare * SKUWeight / AllWeight end
         + case when AllWeight = 0 then 0 else (SHIPPINGAMT * ExchangeRate) * SKUWeight / AllWeight end  as SKUAMT    --计算后的SKU销售金额
  from #TmpTradeInfo
  
  --最后关联下多业绩归属人信息
  
  SELECT  
    IsNull(d.SKU,'''') as SKU,   
    bgs.SalerName , 
    sum(isnull(d.SKUQty,0)) as l_qty,
    SUM((d.SKUamt-d.SKUCostPrice) * isnull(bgs.LrRate,0)/100) as ProfitMoney,
    SUM(d.SKUamt * isnull(bgs.MoneyRate,0)/100) as SaleMoney, 
    SUM(d.SKUamt) as l_AMT
  FROM  #TmpSkuFreeInfo d  
  left outer join B_GoodsSaler bgs on d.GoodsID=bgs.GoodsNID  
  group by  IsNull(d.SKU,'''') , bgs.SalerName
   
  drop table #TmpTradeInfo
  drop table #TmpSkuFreeInfo
end
