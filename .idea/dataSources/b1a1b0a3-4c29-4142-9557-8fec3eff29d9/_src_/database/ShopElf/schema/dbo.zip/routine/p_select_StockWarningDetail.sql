-- 库存预警细表查询 
CREATE proc [dbo].[p_select_StockWarningDetail] 
  @Sku varchar(100),
  @StoreID varchar(100)
as
begin
  SELECT m.ordertime,m.BUYERID,m.SHIPTONAME,m.shiptostreet,m.shiptostreet2, m.shiptocity,m.shiptostate,
	m.shiptozip,m.shiptocountrycode, m.shiptocountryname,m.shiptophonenum,m.TRANSACTIONID,m.nid, m.PAYMENTSTATUS,
	m.note,m.ack,m.subject,m.trackno,m.CURRENCYCODE, m.amt,d.ebaysku,d.sku,d.l_qty, dateadd(hour,8,m.ordertime) as OrderTimeCN, 
	m.SelFlag,l.name as logicsWayName,l.code as logicsWayCode,d.l_number,m.SUFFIX,m.REASONCODE,
	 CASE WHEN  (m.FilterFlag = 5)  THEN '等待派单'
  WHEN   (m.FilterFlag = 6) AND (l.eub = 1)  THEN '派至E邮宝' 
 WHEN   (m.FilterFlag = 6) AND (l.eub = 2) THEN '派至E线下邮宝' 
 WHEN   (m.FilterFlag = 6) AND (l.eub = 3) THEN '派4PX独立帐户' 
 WHEN  (m.FilterFlag = 6) AND (l.eub = 4)  THEN '派至非E邮宝'
  WHEN   (m.FilterFlag = 20) THEN '等待拣货'
 WHEN   (m.FilterFlag = 22) THEN '待审核出库' 
 WHEN   (m.FilterFlag = 24) THEN '等待包装'
  WHEN   (m.FilterFlag = 40) THEN '等待发货' 
  WHEN   (m.FilterFlag = 26) THEN '订单缺货(仓库)' 
  WHEN   (m.FilterFlag = 28) THEN '缺货待包装' 
  WHEN   (m.FilterFlag = 100) THEN '已发货'  END AS OrderStatus  
	FROM P_TradeDt(nolock) d  
	left outer join  P_Trade(nolock) m on m.nid=d.tradenid  
	LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID  
	 where m.FilterFlag > 5 and m.FilterFlag < 100 and  d.sku=@Sku and d.StoreID=@StoreID
  union all  
    SELECT m.ordertime,m.BUYERID,m.SHIPTONAME,m.shiptostreet,m.shiptostreet2, m.shiptocity,m.shiptostate,
    m.shiptozip,m.shiptocountrycode, m.shiptocountryname,m.shiptophonenum,m.TRANSACTIONID,m.nid, m.PAYMENTSTATUS,
    m.note,m.ack,m.subject,m.trackno,m.CURRENCYCODE, m.amt,d.ebaysku,d.sku,d.l_qty, dateadd(hour,8,m.ordertime) as OrderTimeCN, 
    m.SelFlag,l.name as logicsWayName,l.code as logicsWayCode,d.l_number,m.SUFFIX,m.REASONCODE,
	 CASE WHEN  (m.FilterFlag = 5)  THEN '等待派单'
  WHEN   (m.FilterFlag = 6) AND (l.eub = 1)  THEN '派至E邮宝' 
 WHEN   (m.FilterFlag = 6) AND (l.eub = 2) THEN '派至E线下邮宝' 
 WHEN   (m.FilterFlag = 6) AND (l.eub = 3) THEN '派4PX独立帐户' 
 WHEN  (m.FilterFlag = 6) AND (l.eub = 4)  THEN '派至非E邮宝'
  WHEN   (m.FilterFlag = 20) THEN '等待拣货'
 WHEN   (m.FilterFlag = 22) THEN '待审核出库' 
 WHEN   (m.FilterFlag = 24) THEN '等待包装'
  WHEN   (m.FilterFlag = 40) THEN '等待发货' 
  WHEN   (m.FilterFlag = 26) THEN '订单缺货(仓库)' 
  WHEN   (m.FilterFlag = 28) THEN '缺货待包装' 
  WHEN   (m.FilterFlag = 100) THEN '已发货'  END AS OrderStatus  
    FROM P_TradeDt(nolock) d  
    left outer join  P_Trade(nolock) m on m.nid=d.tradenid  
    LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID   
    where m.FilterFlag =5 and m.RestoreStock=-1 and  d.sku=@Sku and d.StoreID=@StoreID 
  union all  
    SELECT m.ordertime,m.BUYERID,m.SHIPTONAME,m.shiptostreet,m.shiptostreet2, m.shiptocity,m.shiptostate,m.shiptozip,
    m.shiptocountrycode, m.shiptocountryname,m.shiptophonenum,m.TRANSACTIONID,m.nid, m.PAYMENTSTATUS,m.note,m.ack,m.subject,
    m.trackno,m.CURRENCYCODE, m.amt,d.ebaysku,d.sku,d.l_qty, dateadd(hour,8,m.ordertime) as OrderTimeCN, m.SelFlag,
    l.name as logicsWayName,l.code as logicsWayCode,d.l_number,m.SUFFIX,m.REASONCODE,
     CASE WHEN    (m.FilterFlag = 1) THEN '订单缺货' 
   WHEN   (m.FilterFlag = 2) THEN '订单退货' 
   WHEN   (m.FilterFlag = 3) THEN '订单取消' 
   WHEN  (m.FilterFlag = 4) THEN '异常单' END AS OrderStatus  
    FROM P_TradeDtun(nolock) d  
    left outer join  P_Tradeun(nolock) m on m.nid=d.tradenid  
    LEFT JOIN B_LogisticWay l on l.nid=m.logicsWayNID  
     where m.FilterFlag =1 and m.RestoreStock=-1 and  d.sku=@Sku  and d.StoreID=@StoreID 
    ORDER BY m.ordertime
 
end
