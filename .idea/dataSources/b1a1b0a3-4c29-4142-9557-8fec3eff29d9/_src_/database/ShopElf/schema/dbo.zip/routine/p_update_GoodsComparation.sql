--运费重量对比有问题修改增加OrderNo<>'Del' 不存在的记录不更新
create procedure [p_update_GoodsComparation] 
  @TrackNo varchar(100),
  @TotalWeight float,
  @ExpressFare float
as 
begin
  declare @Date varchar(19)
  
  set @Date = CONVERT(varchar(19),getDate(),120)
  
  
 if exists (select 1 from B_GoodsComparation where trackno=@TrackNo) 
 begin 
   update B_GoodsComparation 
      set OrderNo = 'update重量:旧' + CONVERT(varchar(32),TotalWeight) + ';新' + CONVERT(varchar(32),@TotalWeight) +
                    '   运费:旧' +  CONVERT(varchar(32),ExpressFare) + ';新' + CONVERT(varchar(32),@ExpressFare)
      where trackno= @TrackNo and OrderNo<>'Del'
   update B_GoodsComparation set TotalWeight=@TotalWeight, ExpressFare=@ExpressFare, importtime=@Date where trackno= @TrackNo
 end 
 else begin  
   if exists (select 1 from P_Trade where Trackno =@TrackNo) 
      or exists (select 1 from P_Trade_His where Trackno = @TrackNo) 
      or exists (select 1 from P_TradeUn where Trackno = @TrackNo) 
   begin 
     insert into B_GoodsComparation ( TrackNo, TotalWeight, ExpressFare,importtime)
        values(@TrackNo, @TotalWeight,  @ExpressFare, @Date) 
   end
   else begin
     insert into B_GoodsComparation ( TrackNo, TotalWeight, ExpressFare,importtime,OrderNo)
        values(@TrackNo, @TotalWeight,  @ExpressFare, @Date, 'Del') 
   end
 end  
 update p_trade set ExpressFare_Close=1 where trackno = @TrackNo
 update p_trade_his set ExpressFare_Close=1 where trackno= @TrackNo
         
end
