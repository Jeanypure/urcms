

CREATE proc [dbo].[wgx_test1]
	@DateFlag int,
	@BeginDate	varchar(20),
	@EndDate	Varchar(20),
	@Sku		Varchar(100),
	@Flag		INT,
	@SalerName VARCHAR(50),
	@SalerName2 VARCHAR(50),
	@chanel VARCHAR(50),
	@SaleType VARCHAR(50),	
	@SalerAliasName VARCHAR(max) = '',
	@eBayUserID VARCHAR(100)='',
	@fNo	VARCHAR(100)='',		
	@DevDate varchar(20),
	@DevDateEnd varchar(20),
	@RateFlag  int
AS
begin
	if @DateFlag=0
	begin
		set @BeginDate	=	DATEADD(HH,-8,@BeginDate)
		set @EndDate	=	DATEADD(HH,-8,dateadd(DD,1,@EndDate))
	end
	create Table #FinancialProfit
	(
			nid int,
			ACK VARCHAR(50),
			[User] VARCHAR(100),
			PaiDanMen VARCHAR(50),
			OrderDay varchar(20),	
			SKU varchar(8000),
			Suffix varchar(100),
			TrackNo varchar(200),
			CurrencyCode varchar(10),
     		        wlWay Varchar(200),
			SHIPTOCOUNTRYNAME varchar(100),
			TRANSACTIONID varchar(50),  
			BuyerID nvarchar(120),  						
			ExchangeRate	money  default 0,	     			
			SaleMoney money default 0,
			SHIPPINGAMT  money default 0,
			eBayFee  money default 0,
			eBayFeeZn  money default 0,	
			ppFee  money default 0,
			ppFeeZn  money default 0,	
			ppMoney  money default 0,
			sdMoney  money default 0,
			sdMoneyUs  money default 0,			
			sdMoneyZn  money default 0,	
			CostMoney  money default 0,
			ExpressFare  money default 0,
			packageMoney  money default 0,
			InpackageMoney  money default 0,		
			OutpackageMoney  money default 0,					
			lrMoney  money default 0,
			TotalWeight  money default 0,
			SaleItemsCount NUMERIC(10,0) DEFAULT 0,
			SaleSKUCount NUMERIC(10,0) DEFAULT 0,
			SHIPTOCOUNTRYCODE varchar(100),
			DevDate dateTime null,
			ItemCostPrice numeric(18,2) default 0
	)
		create Table #FinancialProfit1
	(
			nid int,
			ACK VARCHAR(50),
			[User] VARCHAR(100),
			PaiDanMen VARCHAR(50),
			OrderDay varchar(20),	
			SKU varchar(8000),
			Suffix varchar(100),			
			TrackNo varchar(200),
			CurrencyCode varchar(10),
     		        wlWay Varchar(200),
			TRANSACTIONID varchar(50),  
			BuyerID nvarchar(120),  				   		
			SHIPTOCOUNTRYNAME varchar(100),
			ExchangeRate	money  default 0,	     			
			SaleMoney money default 0,
			SHIPPINGAMT  money default 0,
			eBayFee  money default 0,
			eBayFeeZn  money default 0,	
			ppFee  money default 0,
			ppFeeZn  money default 0,	
			ppMoney  money default 0,
			sdMoney  money default 0,
			sdMoneyUs  money default 0,			
			sdMoneyZn  money default 0,	
			CostMoney  money default 0,
			ExpressFare  money default 0,
			packageMoney  money default 0,
			InpackageMoney  money default 0,		
			OutpackageMoney  money default 0,				
			lrMoney  money default 0,
			TotalWeight  money default 0,
			SaleItemsCount  NUMERIC(10,0) DEFAULT 0,
			SaleSKUCount NUMERIC(10,0) DEFAULT 0,
			SHIPTOCOUNTRYCODE varchar(100),
			DevDate dateTime null,
			ItemCostPrice numeric(18,2) default 0
	)
	
	CREATE TABLE #tbSalerAliasName( SalerAliasName VARCHAR(100) )
	IF LTRIM(RTRIM(@SalerAliasName)) <> ''
	BEGIN
		DECLARE @sSQLCmd VARCHAR(max) = ''
		SET @SalerAliasName = REPLACE(@SalerAliasName,',','''))UNION SELECT ltrim(rtrim(''') 
        SET @sSQLCmd = 'INSERT INTO #tbSalerAliasName(SalerAliasName) SELECT ltrim(rtrim('+ @SalerAliasName+'))'
        PRINT @sSQLCmd
		EXEC(@sSQLCmd )
	END
	--查找USD的汇率
	Declare
		@ExchangeRate float 
	set
		@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 	if @ExchangeRate=0
 	  set 	@ExchangeRate=1	
	--查找成本计价方法
	Declare
		@CalcCostFlag int 
	set
		@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
 	  
	if @Flag=0 
	begin
	    
	
		insert into #FinancialProfit
		select
			m.nid,
			m.ACK,
			m.[User],
			m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			Max(m.AllGoodsDetail) as sku ,
			m.Suffix,			
			m.TrackNo,	
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			m.SHIPTOCOUNTRYNAME,
			MAX(m.TRANSACTIONID) as TRANSACTIONID,
			MAX(m.BUYERID) as BUYERID,
			case when @RateFlag = 1 then MAX(m.EXCHANGERATE) else MAX(c.ExchangeRate) end as ExchangeRate,			
			max(m.AMT) as SaleMoney,		
			max(m.SHIPPINGAMT) as SHIPPINGAMT,
			max(m.SHIPDISCOUNT) as eBayFee,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT) as ppFee ,
			max(m.FEEAMT* (case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end) ) as ppFeeZn ,	
			max((m.AMT-m.FEEAMT)* (case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate  as ppMoney,
			max(m.AMT-m.FEEAMT) as sdMoney,
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate-max(m.SHIPDISCOUNT) as sdMoneyUs,			
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			sum(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*0 end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			max(((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end) -m.SHIPDISCOUNT*@ExchangeRate)-m.ExpressFare)-
					(case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end) as lrMoney,
			max(m.TotalWeight*1000) as TotalWeight,
			max(m.MULTIITEM) AS SaleItemsCount,
			max(m.SALESTAX) AS SaleSKUCount,
			m.SHIPTOCOUNTRYCODE as SHIPTOCOUNTRYCODE,
			MAX(bg.DevDate) as DevDate,
			--add by ylq 2015-08-27  增加商品成本价(彭提)
			sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) as ItemCostPrice	 
			
			
		from 
			P_TradeDt(nolock) d
		left outer join 
			P_Trade(nolock) m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID			
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
--		LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			((@DateFlag=1 and m.FilterFlag=10 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )
			AND isnull(d.SKU,'') like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName) )
			--AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX=@SalerAliasName )			
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName) 
			AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 			
			AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)
			AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 			
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
			AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)
			and (ISNULL(@DevDate,'') ='' or 
			    (convert(varchar(10),bg.DevDate,121) >= @DevDate 
			    and convert(varchar(10),bg.DevDate,121) <= @DevDateEnd))
		group by 
			m.NID,
			m.ACK,
			m.[user],
			m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name,
			m.SHIPTOCOUNTRYNAME,
			m.SHIPTOCOUNTRYCODE 
		union all	
		select
			m.NID,
			m.ACK,
			m.[User],
			m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			Max(m.AllGoodsDetail) as sku ,
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			m.SHIPTOCOUNTRYNAME,
			MAX(m.TRANSACTIONID) as TRANSACTIONID,	
			MAX(m.BUYERID) as BUYERID,								
			case when @RateFlag = 1 then MAX(m.EXCHANGERATE) else MAX(c.ExchangeRate) end as ExchangeRate,  				
			max(m.AMT) as SaleMoney,
			max(m.SHIPPINGAMT) as SHIPPINGAMT,
			max(m.SHIPDISCOUNT) as eBayFee,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT) as ppFee ,
			max(m.FEEAMT*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)) as ppFeeZn ,	
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate  as ppMoney,
			max(m.AMT-m.FEEAMT) as sdMoney,
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate-max(m.SHIPDISCOUNT) as sdMoneyUs,			
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			sum(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*0 end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			max(((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)-m.SHIPDISCOUNT*@ExchangeRate)-m.ExpressFare)-
					(case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end) as lrMoney,
			max(m.TotalWeight*1000) as TotalWeight,
			max(m.MULTIITEM) AS SaleItemsCount,
			max(m.SALESTAX) AS SaleSKUCount,
			m.SHIPTOCOUNTRYCODE as SHIPTOCOUNTRYCODE,
			MAX(bg.DevDate) as DevDate,
			--add by ylq 2015-08-27  增加商品成本价(彭提)
			sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) as ItemCostPrice	 
			
		from 
			P_TradeDt_His(nolock) d
		left outer join 
			P_Trade_His(nolock) m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID					
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		--LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			((@DateFlag=1 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )
			AND isnull(d.SKU,'') like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName) )
			--AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX=@SalerAliasName )
			AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 				
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)
			AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)
			AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 				
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
			AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)
			and (ISNULL(@DevDate,'') ='' or 
			    (convert(varchar(10),bg.DevDate,121) >= @DevDate 
			    and convert(varchar(10),bg.DevDate,121) <= @DevDateEnd))
		group by 
			m.NID,
			m.ACK,
			m.[User],
			m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name	,
			m.SHIPTOCOUNTRYNAME,
			m.SHIPTOCOUNTRYCODE		
			
	    select * 	from #FinancialProfit f 	
			
		--统计	
		select 
			nid,
			ACK,
			[User],
			PaiDanMen,
			OrderDay,	
			SKU,
			Suffix,
			TrackNo,
			CurrencyCode,
			wlWay	,	
			SHIPTOCOUNTRYNAME ,
			MAX(TRANSACTIONID) as TRANSACTIONID,		
			MAX(BuyerID) as buyerid,					
			max(ISNULL(f.ExchangeRate,1)) as ExchangeRate ,				
			sum(SaleMoney) as SaleMoney ,
			sum(SaleMoney)*max(ISNULL(f.ExchangeRate,1)) as SaleMoneyzn,
			sum(SHIPPINGAMT) as SHIPPINGAMT  ,
			sum(eBayFee) as eBayFee  ,
			sum(eBayFeeZn) as eBayFeeZn  ,	
			sum(ppFee) as ppFee  ,
			sum(ppFeeZn) as ppFeeZn  ,	
			sum(ppMoney) as ppMoney  ,
			sum(sdMoney) as sdMoney  ,
			sum(sdMoneyUs) as sdMoneyUs  ,			
			sum(sdMoneyZn) as sdMoneyZn  ,	
			sum(CostMoney) as CostMoney  ,
			sum(ExpressFare) as ExpressFare  ,
			sum(inpackageMoney)+sum(outpackageMoney) as packageMoney  ,
			sum(inpackageMoney) as inpackageMoney  ,
			sum(outpackageMoney) as outpackageMoney  ,						
			sum(lrMoney)-sum(inpackageMoney)-sum(outpackageMoney) as lrMoney  ,
			sum(TotalWeight) as TotalWeight,
			sum(SaleItemsCount) AS SaleItemsCount,
			sum(SaleSKUCount) AS SaleSKUCount,
			case when sum(SaleMoney)*max(ISNULL(f.ExchangeRate,1))=0 then 0 else
					round((sum(lrMoney)-sum(inpackageMoney)-sum(outpackageMoney))/(sum(SaleMoney)*max(ISNULL(f.ExchangeRate,1)))*100,2) end as lrl,
		    SHIPTOCOUNTRYCODE, 
			MAX(DevDate) as DevDate,
			SUM(ItemCostPrice) as ItemCostPrice
	    from #FinancialProfit f 
	    group by 
			nid,
			ACK,
			[User],
			PaiDanMen,
			OrderDay,	
			SKU ,
			Suffix,
			TrackNo,
			CurrencyCode,
			wlWay,
			SHIPTOCOUNTRYNAME,SHIPTOCOUNTRYCODE							
	end
	else
	if @Flag=2
	BEGIN
		insert into #FinancialProfit1
		select
			m.nid,
			'',
			m.[User],
			'',
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			Max(m.AllGoodsDetail) as sku ,
			m.Suffix,			
			m.TrackNo,	
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			m.SHIPTOCOUNTRYNAME,
			MAX(m.TRANSACTIONID) as TRANSACTIONID,	
			MAX(m.BUYERID) as BUYERID,								
			case when @RateFlag = 1 then MAX(m.EXCHANGERATE) else MAX(c.ExchangeRate) end as ExchangeRate,  								
			max(m.AMT) as SaleMoney, 
			max(m.SHIPPINGAMT) as SHIPPINGAMT,
			max(m.SHIPDISCOUNT) as eBayFee,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT) as ppFee ,
			max(m.FEEAMT*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)) as ppFeeZn ,	
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate  as ppMoney,
			max(m.AMT-m.FEEAMT) as sdMoney,
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate-max(m.SHIPDISCOUNT) as sdMoneyUs,			
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			Max(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*0 end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			max(((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)-m.SHIPDISCOUNT*@ExchangeRate)-m.ExpressFare)-
					(case when @CalcCostFlag =0 then sum(d.CostPrice) else sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end) as lrMoney,
			max(m.TotalWeight*1000) as TotalWeight,
			max(m.MULTIITEM) AS SaleItemsCount,
			max(m.SALESTAX) AS SaleSKUCount,
			m.SHIPTOCOUNTRYCODE as SHIPTOCOUNTRYCODE,
			MAX(bg.DevDate) as DevDate,
			--add by ylq 2015-08-27  增加商品成本价(彭提)
			sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) as ItemCostPrice	 
				
		from 
			P_TradeDt(nolock) d
		left outer join 
			P_Trade(nolock) m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID			
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		--LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			((@DateFlag=1 and m.FilterFlag=10 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )
			AND isnull(d.SKU,'') like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName) )
			--AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX=@SalerAliasName )
			AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 				
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)
			AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)
			AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 				
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
			AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)
			and (ISNULL(@DevDate,'') ='' or 
			    (convert(varchar(10),bg.DevDate,121) >= @DevDate 
			    and convert(varchar(10),bg.DevDate,121) <= @DevDateEnd))
		group by 
			m.NID,
			--m.ACK,
			m.[User],
			--m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name,
			m.SHIPTOCOUNTRYNAME,
			m.SHIPTOCOUNTRYCODE			
		union all	
		select
			m.NID,
			'',
			m.[User],
			'',
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
					else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	
			Max(m.AllGoodsDetail) as sku ,
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE as CurrencyCode,
			l.name as wlWay	,
			m.SHIPTOCOUNTRYNAME,
			MAX(m.TRANSACTIONID) as TRANSACTIONID,	
			MAX(m.BUYERID) as BUYERID,								
			--Max(c.ExchangeRate) as ExchangeRate,
			case when @RateFlag = 1 then MAX(m.EXCHANGERATE) else MAX(c.ExchangeRate) end as ExchangeRate, 	
			max(m.AMT)  as SaleMoney,    
			max(m.SHIPPINGAMT) as SHIPPINGAMT,
			max(m.SHIPDISCOUNT) as eBayFee,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT) as ppFee ,
			max(m.FEEAMT*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)) as ppFeeZn ,	
			max((m.AMT-m.FEEAMT)*c.ExchangeRate)/@ExchangeRate  as ppMoney,
			max(m.AMT-m.FEEAMT) as sdMoney,
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))/@ExchangeRate-max(m.SHIPDISCOUNT) as sdMoneyUs,			
			max((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end))-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			Max(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*1 end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			max(((m.AMT-m.FEEAMT)*(case when @RateFlag = 1 then m.EXCHANGERATE
			  else  c.ExchangeRate end)-m.SHIPDISCOUNT*@ExchangeRate)-m.ExpressFare)-
					(case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) end) as lrMoney,
			max(m.TotalWeight*1000) as TotalWeight,
			max(m.MULTIITEM) AS SaleItemsCount,
			max(m.SALESTAX) AS SaleSKUCount,
			m.SHIPTOCOUNTRYCODE as SHIPTOCOUNTRYCODE,
			MAX(bg.DevDate) as DevDate,
			--add by ylq 2015-08-27  增加商品成本价(彭提)
			sum(d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice else isnull(bg.CostPrice,0) end )) as ItemCostPrice	 
				
		from 
			P_TradeDt_His(nolock) d
		left outer join 
			P_Trade_His(nolock) m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID					
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		--LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			((@DateFlag=1 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )
			AND isnull(d.SKU,'') like '%'+@Sku+'%'
			AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName) )
			--AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX=@SalerAliasName )	
			AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 			
			AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName )
			AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)
			AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 				
			AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)
			AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)
			and (ISNULL(@DevDate,'') ='' or 
			    (convert(varchar(10),bg.DevDate,121) >= @DevDate 
			    and convert(varchar(10),bg.DevDate,121) <= @DevDateEnd))
		group by 
			m.NID,
			--m.ACK,
			m.[User],
			--m.PaidanMen,
			case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) else convert(varchar(10),m.CLOSINGDATE,121) end,	
			m.Suffix,			
			m.TrackNo,
			m.CURRENCYCODE,
			l.name	,
			m.SHIPTOCOUNTRYNAME,
			m.SHIPTOCOUNTRYCODE	

		insert into #FinancialProfit	
		select
			0,		
			'',
			'',
			'',
			convert(varchar(7),OrderDay) as OrderDay,	
			'' as SKU,
			Suffix,
			'' as TrackNo,	
			'' as CurrencyCode,
			'' as wlWay	,
			'' as TRANSACTIONID,
			'' as buyerid,
			'',
			--0,								
			sum(ExchangeRate) as ExchangeRate,			
			sum(SaleMoney*ExchangeRate /@ExchangeRate) as SaleMoney,   --这里转换成美元
			sum(SHIPPINGAMT) as SHIPPINGAMT,
			sum(eBayFee) as eBayFee,
			sum(eBayFeeZn) as eBayFeeZn,	
			sum(ppFee) as ppFee ,
			sum(ppFeeZn) as ppFeeZn ,	
			sum(ppMoney)  as ppMoney,
			sum(sdMoney) as sdMoney,
			sum(sdMoneyUs) as sdMoneyUs,			
			sum(sdMoneyZn) as sdMoneyZn,	
			sum(CostMoney) as CostMoney,
			sum(ExpressFare) as ExpressFare ,
			SUM(inpackageMoney)+max(outpackageMoney)  as packageMoney,
			SUM(inpackageMoney) as inpackageMoney,
			sum(outpackageMoney) as outpackageMoney,				
			sum(lrMoney) as lrMoney,
			sum(TotalWeight) as TotalWeight,
			sum(SaleItemsCount) AS SaleItemsCount,
			sum(SaleSKUCount) AS SaleSKUCount,
			'',
			MAX(devDate),
			--add by ylq 2015-08-27  增加商品成本价(彭提)
			SUM(ItemCostPrice) 
			 

		from 
			#FinancialProfit1	
		GROUP BY convert(varchar(7),OrderDay),Suffix 
		
	  --统计	
	  select 
			nid,
			ACK,
			[User],
			PaiDanMen,
			OrderDay,	
			SKU,
			Suffix,
			TrackNo,
			CurrencyCode,
			wlWay	,	
			SHIPTOCOUNTRYNAME ,
			MAX(TRANSACTIONID) as TRANSACTIONID,		
			MAX(BuyerID) as buyerid,					
			max(ISNULL(f.ExchangeRate,1)) as ExchangeRate ,				
			sum(SaleMoney) as SaleMoney ,
			SUM(SaleMoney * @ExchangeRate) as SaleMoneyzn,
			sum(SHIPPINGAMT) as SHIPPINGAMT  ,
			sum(eBayFee) as eBayFee  ,
			sum(eBayFeeZn) as eBayFeeZn  ,	
			sum(ppFee) as ppFee  ,
			sum(ppFeeZn) as ppFeeZn  ,	
			sum(ppMoney) as ppMoney  ,
			sum(sdMoney) as sdMoney  ,
			sum(sdMoneyUs) as sdMoneyUs  ,			
			sum(sdMoneyZn) as sdMoneyZn  ,	
			sum(CostMoney) as CostMoney  ,
			sum(ExpressFare) as ExpressFare  ,
			sum(inpackageMoney)+sum(outpackageMoney) as packageMoney  ,
			sum(inpackageMoney) as inpackageMoney  ,
			sum(outpackageMoney) as outpackageMoney  ,						
			sum(lrMoney)-sum(inpackageMoney)-sum(outpackageMoney) as lrMoney  ,
			sum(TotalWeight) as TotalWeight,
			sum(SaleItemsCount) AS SaleItemsCount,
			sum(SaleSKUCount) AS SaleSKUCount,
			case when sum(SaleMoney * @ExchangeRate)=0 then 0 else
					round((sum(lrMoney)-sum(inpackageMoney)-sum(outpackageMoney))/(sum(SaleMoney * @ExchangeRate))*100,2) end as lrl,
		    SHIPTOCOUNTRYCODE,
			MAX(DevDate) as DevDate,
			SUM(ItemCostPrice) as ItemCostPrice
	    from #FinancialProfit f 
	    group by
	        nid,
			ACK,
			[User],
			PaiDanMen,
			OrderDay,	
			SKU ,
			Suffix,
			TrackNo,
			CurrencyCode,
			wlWay,
			SHIPTOCOUNTRYNAME,
			SHIPTOCOUNTRYCODE	
	end
		
	drop table 	#FinancialProfit	
	drop table 	#FinancialProfit1
end		
		
