CREATE procedure [dbo].[wo_test_sale_suffix] (

	@BeginDate	varchar(10) ='',
	@EndDate	Varchar(10) =''
	)
AS
begin
	create Table #FinancialProfit
	(
			nid	int,
			suffix varchar(100),		     			
			SaleMoneyZn money default 0,
			SaleMoneyUS money default 0,
			eBayFeeZn  money default 0,	
			ppFeeZn  money default 0,
			OrderCount int default 0 ,
			CustomerPrice money default 0,
			sdMoneyZn  money default 0,	
			CostMoney  money default 0,
			ExpressFare  money default 0,
			packageMoney  money default 0,
			InpackageMoney  money default 0,		
			OutpackageMoney  money default 0,					
			lrMoney  money default 0,
			SaleSKUCount int DEFAULT 0
	)	

	--查找USD的汇率
	Declare
		@ExchangeRate float 
	set
		@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
 	if @ExchangeRate=0
 	  set 	@ExchangeRate=1	
	--查找成本计价方法
	Declare
		@CalcCostFlag int 
	set
		@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
 	  

		insert into #FinancialProfit
		select
		    m.nid,
			m.suffix  as OrderDay,		     			
											
			max(m.AMT*c.ExchangeRate) as SaleMoneyzn,
			max(m.AMT*c.ExchangeRate/@ExchangeRate) as SaleMoneyus,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT*@ExchangeRate) as ppFee ,	
			1  as OrderCount,
			0.00 as CustomerPrice,		
			max((m.AMT-m.FEEAMT)*c.ExchangeRate)-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*isnull(bg.CostPrice,0)) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			SUM(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*ISNULL(bgg.PackFee,0) end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			0.00 as lrMoney,
			max(m.SALESTAX) AS SaleSKUCount
			
		from 
			P_TradeDt d
		left outer join 
			P_Trade m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID			
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate
		group by 
			m.NID,
			m.suffix 	
		union all
		select
		    m.nid,
			m.suffix  as OrderDay,		     			
											
			max(m.AMT*c.ExchangeRate) as SaleMoneyzn,
			max(m.AMT*c.ExchangeRate/@ExchangeRate) as SaleMoneyus,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT*@ExchangeRate) as ppFee ,	
			1  as OrderCount,
			0.00 as CustomerPrice,		
			max((m.AMT-m.FEEAMT)*c.ExchangeRate)-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*isnull(bg.CostPrice,0)) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			SUM(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*ISNULL(bgg.PackFee,0) end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			0.00 as lrMoney,
			max(m.SALESTAX) AS SaleSKUCount
			
		from 
			P_TradeDtun d
		left outer join 
			P_Tradeun m on m.NID=d.TradeNID
		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID			
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate
			and m.PROTECTIONELIGIBILITYTYPE = '缺货订单'  
		group by 
			m.NID,
			m.suffix 
		union all	
		select
			m.nid,
			m.SUFFIX  as OrderDay,				
			max(m.AMT*c.ExchangeRate) as SaleMoneyzn,
			max(m.AMT*c.ExchangeRate/@ExchangeRate) as SaleMoneyus,
			max(m.SHIPDISCOUNT*@ExchangeRate) as eBayFeeZn,	
			max(m.FEEAMT*@ExchangeRate) as ppFee ,	
			1  as OrderCount,
			0.00 as CustomerPrice,		
			max((m.AMT-m.FEEAMT)*c.ExchangeRate)-max(m.SHIPDISCOUNT*@ExchangeRate) as sdMoneyZn,	
			case when @CalcCostFlag =0 then SUM(d.CostPrice) else SUM(d.L_QTY*isnull(bg.CostPrice,0)) end as CostMoney,
			max(m.ExpressFare) as ExpressFare ,
			0 as packageMoney,
			SUM(case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) else d.L_TAXAMT*ISNULL(bgg.PackFee,0) end ) as inpackageMoney,
			max(m.INSURANCEAMOUNT) as outpackageMoney,						
			0.00 as lrMoney,
			max(m.SALESTAX) AS SaleSKUCount
			
		from 
			P_TradeDt_His d
		left outer join 
			P_Trade_His m on m.NID=d.TradeNID

		left outer join 
			B_LogisticWay l on l.NID=m.logicsWayNID					
		left outer join 
			B_CurrencyCode c on c.CURRENCYCODE=m.CURRENCYCODE
		LEFT JOIN B_GoodsSKU bgs ON bgs.NID = d.GoodsSKUID
		LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
		LEFT JOIN B_Goods bgg ON d.eBaySKU = bgg.SKU 		
		where 
			convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate
			
		group by 
			m.NID,
			m.suffix 	
									
	select 
			suffix,	
							
			round(sum(SaleMoneyZn),2) as SaleMoneyZn ,
			round(sum(SaleMoneyUS),2) as SaleMoneyUS,
			round(sum(eBayFeeZn),2) as eBayFeeZn  ,
			round(sum(ppFeeZn),2) as ppFeeZn  ,
			sum(OrderCount) as OrderCount  ,	
			round( sum(SaleMoneyUS)/sum(OrderCount) ,2) as CustomerPrice  ,
			round(sum(sdMoneyZn),2) as sdMoneyZn  ,	
			round(sum(CostMoney),2) as CostMoney  ,
			round(sum(ExpressFare),2) as ExpressFare  ,
			round(sum(inpackageMoney)+sum(outpackageMoney),2) as packageMoney  ,					
			round(sum(SaleMoneyZn)-sum(eBayFeeZn)-sum(ppFeeZn)-sum(CostMoney)-sum(ExpressFare)-sum(inpackageMoney)-sum(outpackageMoney),2) as lrMoney  ,
			sum(SaleSKUCount) AS SaleSKUCount,
			case when sum(SaleMoneyzn)=0 then 0 else
					round((sum(SaleMoneyZn)-sum(eBayFeeZn)-sum(ppFeeZn)-sum(inpackageMoney)-sum(CostMoney)-sum(ExpressFare)-sum(outpackageMoney))/(sum(SaleMoneyzn))*100,2) end as lrl
	from #FinancialProfit f 
	group by 
			suffix	
				
	drop table 	#FinancialProfit	
end	

