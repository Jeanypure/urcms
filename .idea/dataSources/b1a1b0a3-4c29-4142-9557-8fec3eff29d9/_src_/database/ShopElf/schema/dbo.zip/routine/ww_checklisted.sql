CREATE PROCEDURE [dbo].[ww_checklisted]
 @BeginCreateDate DATE,
 @EndCreateDate date,
@salername1 varchar(30),
@salername2 varchar(30),
@catname1 varchar(30),
@catname2 varchar(30)
AS
BEGIN
DECLARE @saler1 varchar(30)
DECLARE @saler2 varchar(30)
DECLARE @cat varchar(30)
if @salername1=''
BEGIN
set @saler1='%%'
END
ELSE
Begin
set @saler1=@SalerName1 + '%'
END
if @salername2=''
BEGIN
set @saler2=''
END
else
begin

set @saler2=@salername2 + '%'
end
if @catname1=''
BEGIN
set @cat='%%'
END
ELSE
set @cat= '0|' + @catname1+ '|' + @catname2 +'%'
DECLARE @site varchar(2)
set @site=0
 create table #store_sku (
	ebayid varchar(100),
	ebayname varchar(100),
	catname varchar(50),
	catid varchar(20)
 ) 
insert into #store_sku values ('08-xea','aatq','女人世界','0|25|')
insert into #store_sku values ('03-aatq','sunshinegirl678','女人世界','0|25|')
insert into #store_sku values ('16-sunshine','east_culture_2008','女人世界','0|25|')
insert into #store_sku values ('02-2008','exao','女人世界','0|25|')
insert into #store_sku values ('15-exao','shuai.hk','女人世界','0|25|')
insert into #store_sku values ('18-shuai','showgirl668','女人世界','0|25|')
insert into #store_sku values ('12-showgirl','7_su061','饰品配件','0|60|')
insert into #store_sku values ('17-su061','newfashion66','饰品配件','0|60|')
insert into #store_sku values ('11-newfashion','china_cheong','饰品配件','0|60|')
insert into #store_sku values ('04-cheong','happysmile336','饰品配件','0|60|')
insert into #store_sku values ('07-smile','girlspring88','母婴','0|145|')
insert into #store_sku values ('10-girlspring','buy_clothing','母婴','0|145|')
insert into #store_sku values ('01-buy','happygirl366','母婴','0|145|')
insert into #store_sku values ('06-happygirl','5avip','家居','0|29|')
insert into #store_sku values ('05-5avip','showtime688','家居','0|29|')
insert into #store_sku values ('13-showtime','degage88','家居','0|29|')
insert into #store_sku values ('14-degage','niceday666','家居','0|29|')
insert into #store_sku values ('09-niceday','xea','家居','0|29|')
insert into #store_sku values ('08-xea','aatq','男人海洋','0|55|')
insert into #store_sku values ('03-aatq','sunshinegirl678','男人海洋','0|55|')
insert into #store_sku values ('16-sunshine','east_culture_2008','男人海洋','0|55|')
insert into #store_sku values ('02-2008','exao','男人海洋','0|55|')
insert into #store_sku values ('15-exao','shuai.hk','男人海洋','0|55|')
insert into #store_sku values ('18-shuai','showgirl668','男人海洋','0|55|')
insert into #store_sku values ('12-showgirl','7_su061','户外','0|84|')
insert into #store_sku values ('17-su061','newfashion66','户外','0|84|')
insert into #store_sku values ('11-newfashion','china_cheong','母婴','0|145|')
insert into #store_sku values ('04-cheong','happysmile336','母婴','0|145|')
insert into #store_sku values ('07-smile','girlspring88','饰品配件','0|60|')
insert into #store_sku values ('10-girlspring','buy_clothing','饰品配件','0|60|')
insert into #store_sku values ('01-buy','happygirl366','家居','0|29|')
insert into #store_sku values ('06-happygirl','5avip','电子','0|28|')
insert into #store_sku values ('05-5avip','showtime688','饰品配件','0|60|')
insert into #store_sku values ('13-showtime','degage88','母婴','0|145|')
insert into #store_sku values ('14-degage','niceday666','饰品配件','0|60|')
insert into #store_sku values ('09-niceday','girlspring88','母婴','0|145|')
insert into #store_sku values ('10-girlspring','degage88','电子','0|28|')
insert into #store_sku values ('14-degage','','电子','0|28|')

select bgs.sku,bg.goodscode,bg.categorycode, #store_sku.ebayname,
bgs.RetailPrice as price,
bgs.remark as Remark,
bgs.BmpFileName as filename,
bg.categorycode as cat,
bg.salername as salername,
bg.salername2 as salername2 into #shouldbelisted  from B_goodssku as bgs LEFT JOIN  B_Goods as bg on bgs.goodsid= bg.nid inner JOIN #store_sku on bg.categorycode= #store_sku.catid  where bg.createdate  BETWEEN @BeginCreateDate and @EndCreateDate and
bg.salername like @saler1 and bg.salername2 like @saler2 and bg.categorycode like @cat
SELECT @site as site, should.*, isnull(had.itemid, '') as itemid, isnull(had.ebayid, '') as ebayid, isnull(had.sku,'') as pysku into #tolist  from #shouldbelisted  as should LEFT JOIN z_allroot_listed as  had on  should.ebayname = had.ebayid
select goodscode,ebayname,min(price) as price,min(categorycode) as catcode,max(remark) as remark from #tolist where ebayid='' and ebayname !='' group by goodscode, ebayname
--SELECT * from #store_sku
drop table #store_sku
drop table #shouldbelisted
END