CREATE PROCEDURE [dbo].[ww_checklisted2]
 @BeginCreateDate DATE,
 @EndCreateDate date,
@salername1 varchar(30),
@salername2 varchar(30),
@catname1 varchar(30),
@catname2 varchar(30)
AS
BEGIN
DECLARE @saler1 varchar(30)
DECLARE @saler2 varchar(30)
DECLARE @cat varchar(30)
if ISNULL(@salername1, '')=''
BEGIN
set @saler1='%%'
END
ELSE
Begin
set @saler1=@SalerName1 + '%'
END
if isnull(@salername2,'')=''
BEGIN
set @saler2=''
END
else
begin

set @saler2=@salername2 + '%'
end
if ISNULL(@catname1,'')=''
BEGIN
set @cat='%%'
END
ELSE
BEGIN
--set @cat= '0|' + @catname1+ '|' + @catname2 +'%'
if isnull(@catname2,'')=''
BEGIN
set @cat= ISNULL(@catname1,'') + '%'
END
ELSE
BEGIN
set @cat= ISNULL(@catname2, '')
end
end

DECLARE @site varchar(2)
set @site=0
 --create table z_store_sku (
	--ebayid varchar(100),
	--owner varchar(50),
	--ebayname varchar(100),
	--catname varchar(50),
	--catid varchar(20)
 --) 

--select itemid,ebayid,isvar,max(sku1)as sku into #allroot_listed from z_allroot_auto GROUP BY itemid,ebayid,isvar 
create table #lisetd_details(
ebayid varchar(30),
sku varchar(30),
goodscode varchar(30)
)


select 
bg.goodscode as SKU, 
bg.goodsname, 
bg.createdate,
bg.salername,
bg.salername2,
store.ebayid,
store.ebayname,
store.owner,
gcats.categoryname, 
gcats.categoryparentname 
into #shouldlisted 
from  B_Goods as bg 
LEFT JOIN  B_GoodsCats as gcats 
on bg.goodscategoryid = gcats.nid 
LEFT JOIN  z_store_sku  as store
on bg.categorycode like store.catid +'%' 
where bg.createdate  BETWEEN @BeginCreateDate and @EndCreateDate 
and bg.salername like @saler1 
and bg.salername2 like @saler2 
and bg.categorycode like @cat 
and ISNULL(store.ebayid,'') != ''


insert into #lisetd_details 
select listed.ebayid,
listed.sku,
bg.goodscode  
from z_allroot_listed as listed 
LEFT JOIN B_Goodssku as bgs
on listed.sku = bgs.sku  
LEFT JOIN B_Goods as bg
on bgs.goodsid = bg.nid     
where ISNULL(bg.goodscode, '')!=''
--insert into #lisetd_details select listed.ebayid, listed.sku,bg.goodscode  from z_allroot_listed as listed LEFT JOIN B_Goods as bg on listed.sku = bg.goodscode where ISNULL(listed.isvar, 0)= 0 and ISNULL(bg.goodscode,'')!=''



select should.* from
#shouldlisted as should 
LEFT JOIN #lisetd_details as detail
on  should.sku= detail.goodscode 
where ISNULL(detail.ebayid, '') ='' 
--select * from #shouldlisted as should LEFT JOIN #lisetd_details as detail on  should.sku= detail.goodscode 

drop table #lisetd_details
drop table #shouldlisted

END