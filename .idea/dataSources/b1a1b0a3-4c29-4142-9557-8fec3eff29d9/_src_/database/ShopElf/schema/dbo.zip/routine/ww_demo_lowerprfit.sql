 CREATE proc [dbo].[ww_demo_lowerprfit]

	@DateFlag int,                         --时间标记 0 交易时间 1 发货时间
	@BeginDate	varchar(20),               --开始时间
	@EndDate	Varchar(20),               --结束时间
	@Flag		INT,                       --按天还是按月查询 0 天 2 月	
	@RateFlag  int                         --是否使用订单保存的汇率 1 使用 0 使用汇率表里的汇率
	
AS
begin
SET NOCOUNT ON 
 -- 存放订单副表信息
   create table #tempskucostprice(
  PackFee money default 0,
  goodcostprice money default 0,
  costprice money default 0,
  tradenid int default 0)
  -- 创建临时表用来存储信息
  create Table #TempTradeInfo
  (
    nid int,                                 --nid
	OrderDay varchar(20),                    --时间显示到日(yyyy-mm-dd) 0 交易 1 发货  	
	OrderMonth varchar(20),                  --时间显示到月(yyyy-mm) 0 交易 1 发货  
	Suffix varchar(100),                     --卖家简称			
	ExchangeRate float default 0,            --销售汇率 包括(销售价,PP手续费,买家付运费) 根据系统参数取 系统汇率还是订单里面的汇率     			
	SaleMoney float default 0,               --销售价 AMT
	SHIPPINGAMT  float default 0,            --买家付运费
	ppFee  float default 0,                  --PP手续费
	ebayExchangeRate float,                  --平台手续费汇率 ebay paypal的取美元  否则 根据系统参数取 系统汇率还是订单里面的汇率
	eBayFee  float default 0,                --平台手续费
	CostMoney  float default 0,              --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价）
	ExpressFare  float default 0,            --快递费￥
	InpackageMoney  float default 0,         --内包装金额￥		
	OutpackageMoney  float default 0,        --外包装金额￥					
	TotalWeight  float default 0,            --总重量 G
	DevDate varchar(50) null,                   --最大商品开发时间
	ItemCostPrice float default 0,           --商品信息的成本价（商品成本加一起）
	ACK VARCHAR(50),                         --店铺单号
	[User] VARCHAR(100),                     --卖家id
	PaiDanMen VARCHAR(50),                   --派单人
	SKU varchar(8000),                       --sku明细
	TrackNo varchar(200),                    --跟踪号
	CurrencyCode varchar(10),                --币种
	wlWay Varchar(200),                      --物流方式名称
	SHIPTOCOUNTRYNAME varchar(100),          --收货人国家
	TRANSACTIONID varchar(50),               --PP交易ID
	BuyerID nvarchar(120),                   --买家ID	
	SaleItemsCount NUMERIC(10,0) DEFAULT 0,  --销售总数量
	SaleSKUCount NUMERIC(10,0) DEFAULT 0,    --SKU数量
	SHIPTOCOUNTRYCODE varchar(100),          --收件人国家代码
	CountryZnName  varchar(100)              --收件人国家中文名
  )
  --临时的NID	
  create Table #TempTradeInfo_TempNID
  (
    nid int,                                 --nid
    constraint PK_Temp_TempTradeInfo_TempNID primary key(nid)
  )	
  --最终的NID
  create Table #TempTradeInfo_NID
  (
    nid int,                                 --nid
    constraint PK_Temp_TempTradeInfo_NID primary key(nid)
  )	


	
--临时的表ww
CREATE Table #Temp_tb
(
  nid varchar(50),
  ACK varchar(100),
  [User] varchar(100),
  PaiDanMen varchar(100),
  OrderDay varchar(50),
  SKU varchar(800),
  Suffix varchar(50),                        --
  TrackNo varchar(100),
  CurrencyCode varchar(50),
  wlWay varchar(800),
  SHIPTOCOUNTRYNAME varchar(200),
  TRANSACTIONID varchar(100),
  BuyerID varchar(100),
  ExchangeRate float default 0,
  SaleMoney float default 0,
  SaleMoneyUS float default 0,
  SaleMoneyzn float default 0,
  SHIPPINGAMT float default 0,
  SHIPPINGAMTUS float default 0,
  SHIPPINGAMTzn float default 0,
  eBayFeeYs float default 0,
  eBayFee float default 0,
  eBayFeezn float default 0,
  ppFee float default 0,
  ppFeeUS float default 0,
  ppFeezn float default 0,
  sdMoney float default 0,
  ppMoney float default 0,
  ppMoneyzn float default 0,  
  sdMoneyUs float default 0,
  sdMoneyZn float default 0,
  CostMoney float default 0,
  ExpressFare float default 0,
  packageMoney float default 0,
  inpackageMoney float default 0,
  outpackageMoney float default 0,
  lrMoney float default 0,
  TotalWeight float default 0,
  SaleItemsCount float default 0,
  SaleSKUCount float default 0,
  lrl float default 0,
  SHIPTOCOUNTRYCODE varchar(800),
  CountryZnName varchar(200) ,
  DevDate varchar(50),
  ItemCostPrice float default 0
)  
--临实的表从B_Goods里面根据#Temp_tb里的SKU拿出 商品编码 商品状态 业绩归属人 采购人 商品状态 等
create Table #Temp_bg_ww  
(
	goodscode varchar(50),
	salername varchar(50),
  purchaser varchar(50),
	aliascnname varchar(50),
  goodsname varchar(200),
  goodsskustatus varchar(50),
  SKU varchar(50)
)
--创建临时表存放根据商品编码和店铺号分组后的结果(last)
create Table #Temp_last_ww 
(
	suffix varchar(50),
	GoodsName varchar(50),
  SalerName varchar(50),
	Purchaser varchar(50),
  GoodsCode varchar(200),
  aliascnname varchar(200),
  GoodsSKUStatus varchar(50),  
  zsale float default 0,
  zlr float default 0
)

create Table #Temp_last_ww2 
(
	suffix varchar(50),
	GoodsName varchar(50),
  SalerName varchar(50),
	Purchaser varchar(50),
  GoodsCode varchar(200),
  aliascnname varchar(200),
  GoodsSKUStatus varchar(50),  
  zsale float default 0,
  zlr float default 0
)

--存放GoodsSKU表中没有的#Temp_tb.SKU ,去B_Goods表中找和财务报表中sku 列对应的，
CREATE Table #Temp_goodsCode_sku
(
	goodscode varchar(50),
  SKU varchar(50)
)


create Table #Temp_goods
(
	suffix varchar(50),
	GoodsName varchar(50),
  SalerName varchar(50),
	Purchaser varchar(50),
  GoodsCode varchar(200),
  aliascnname varchar(200),
  GoodsSKUStatus varchar(50),  
  zsale float default 0,
  zlr float default 0
)

  --查找USD的汇率
  Declare

	@ExchangeRate float 
  set
	@ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode where CURRENCYCODE='USD'),0)	
  if @ExchangeRate=0
    set @ExchangeRate=1	
    
  --查找成本计价方法
  Declare
	@CalcCostFlag int 
  set
	@CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)	
	

  --数据插入临时表 --正常表
  --先查询主表条件里面的订单编号
  insert into #TempTradeInfo_TempNID
  select 
    m.NID 
  from P_Trade(nolock) m
  where		
    ((@DateFlag=1 and m.FilterFlag=100 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
	 or (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate))
	--AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName))    --卖家简称	
	--AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 	                                       --卖家ID		
	--AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)                                --销售渠道
	--AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 			                       --销售类型
	--AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)                                     --订单号或店铺单号
	
  --再查询最终的明细的订单编号	 
  insert into #TempTradeInfo_NID
  select 
    D.TradeNid 
  from (select TradeNid,SKU from P_TradeDt(nolock) where TradeNid in (select NID from #TempTradeInfo_TempNID)) d
  left join B_GoodsSKU(nolock) bgs on bgs.SKU = d.SKU 
  left join b_goods(nolock) bg on bg.NID = bgs.GoodsID 

 
  group by  
    D.TradeNid 
      -- 正常表 sku数据
    insert into #tempskucostprice(tradenid,goodcostprice,costprice,PackFee)
    select
    dt.TradeNID,
    sum(dt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                                      else bg.CostPrice end)),
	SUM(dt.CostPrice),
	sum(dt.L_QTY*(ISNULL(bg.PackFee,0)))
	                                  
    from P_TradeDt dt with(nolock) 
    inner join B_GoodsSKU bgs with(nolock)  on bgs.SKU = dt.SKU 
	inner join b_goods bg with(nolock)  on bg.NID = bgs.GoodsID
    where dt.tradenid in (select NID from #TempTradeInfo_NID)
    group by dt.TradeNID 
  
  --再根据查询的NID插入详细信息
  insert into #TempTradeInfo
  select                             
	m.nid,                                                                                --nid  
	case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	                  --时间显示到日(yyyy-mm-dd) 0 交易 1 发货 
	case when @DateFlag=0  then convert(varchar(7),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(7),m.CLOSINGDATE,121) end as OrderMonth,                    --时间显示到月(yyyy-mm) 0 交易 1 发货   	   
	m.Suffix,	                                                                          --卖家简称	
	case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	     else isnull(c.ExchangeRate,1) end as ExchangeRate,                               --销售汇率 包括(销售价,pp手续费,买家付运费)
	m.AMT as SaleMoney,			                                                          --销售价 AMT
	m.SHIPPINGAMT as SHIPPINGAMT,		                                                  --买家付运费
	m.FEEAMT as ppFee ,                                                                   --PP手续费  
	case when m.ADDRESSOWNER = 'ebay' or m.ADDRESSOWNER = 'paypal' then @ExchangeRate 
		 else case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
		           else isnull(c.ExchangeRate,1) end end as ebayExchangeRate,             --平台手续费汇率  
	m.SHIPDISCOUNT as eBayFee,		                                                      --平台手续费  
	isnull( (case when @CalcCostFlag =0 then ts.costprice else ts.goodcostprice end),0) as CostMoney,                                    --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价） 
	m.ExpressFare,                                                                        --快递费￥      
	isnull(ts.PackFee,0) as InpackageMoney,                               --内包装金额￥
	m.INSURANCEAMOUNT as outpackageMoney,	                                              --外包装金额￥
	m.TotalWeight*1000 as TotalWeight,                                                    --总重量 G
	'' as DevDate,                                              --最大商品开发时间
	isnull(ts.goodcostprice,0) as ItemCostPrice,                                --商品信息的成本价（商品成本加一起） 
	m.ACK,                                                                                --店铺单号
	m.[User],	                                                                          --卖家id
	m.PaiDanMen,	                                                                      --派单人	
	m.AllGoodsDetail as sku,	                                                          --sku明细
	m.TrackNo,                                                                            --跟踪号
	m.CURRENCYCODE as CurrencyCode,                                                       --币种
	l.name as wlWay,                                                                      --物流方式名称
	m.SHIPTOCOUNTRYNAME,                                                                  --收货人国家
	m.TRANSACTIONID,		                                                              --PP交易ID
	m.BuyerID,                                                                            --买家ID	
	m.MULTIITEM AS SaleItemsCount,			                                              --销售总数量
	m.SALESTAX AS SaleSKUCount,                                                           --SKU数量
	m.SHIPTOCOUNTRYCODE,		                                                          --收件人国家代码	
	bc.CountryZnName	                                                                  --国家中文名
  from 
	P_Trade(nolock) m		
	left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID		
	left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
	left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE
	left join #tempskucostprice ts with(nolock) on ts.tradenid=m.NID		
  where 
	m.NID in (select NID from #TempTradeInfo_NID) 
	
  --清除不用的数据
  Truncate Table #TempTradeInfo_TempNID
  Truncate Table #TempTradeInfo_NID	
  truncate table #tempskucostprice
				  
  --数据插入临时表 --历史表		
  --先查询主表条件里面的订单编号
  insert into #TempTradeInfo_TempNID
  select 
    m.NID 
  from P_Trade_his(nolock) m
  where		
    ((@DateFlag=1 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate) 
	 or (@DateFlag=0 and convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) between @BeginDate and @endDate))
--	AND (ISNULL(@SalerAliasName,'') = '' OR m.SUFFIX IN (SELECT SalerAliasName FROM #tbSalerAliasName))    --卖家简称	
--	AND (ISNULL(@eBayUserID,'') = '' OR m.[User] = @eBayUserID) 	                                       --卖家ID		
	--AND (ISNULL(@chanel,'') = '' OR isnull(m.TRANSACTIONTYPE,'') = @chanel)                                --销售渠道
	--AND (ISNULL(@SaleType,'') = '' OR isnull(m.SALUTATION,'') = @SaleType) 			                       --销售类型
	--AND (@fno = '' OR cast(m.nid as varchar(50)) = @fno or m.ACK=@fno)                                     --订单号或店铺单号
	
  --再查询最终的明细的订单编号	 
  insert into #TempTradeInfo_NID
  select 
    D.TradeNid 
  from (select TradeNid,SKU from P_TradeDt_his(nolock) where TradeNid in (select NID from #TempTradeInfo_TempNID)) d
  left join B_GoodsSKU(nolock) bgs on bgs.SKU = d.SKU 
  left join b_goods(nolock) bg on bg.NID = bgs.GoodsID 
  --where 
   -- (isnull(@Sku,'') = '' or isnull(d.SKU,'') like '%'+@Sku+'%')                             --SKU                           	
    --AND (ISNULL(@SalerName,'') = '' OR bg.SalerName = @SalerName)                            --业绩归属人1
    --AND (ISNULL(@SalerName2,'') = '' OR bg.SalerName2 = @SalerName2)                         --业绩归属人2	
    --AND (ISNULL(@DevDate,'') ='' or convert(varchar(10),bg.DevDate,121) >= @DevDate)         --商品开发开始时间
    --AND (ISNULL(@DevDateEnd,'') ='' or convert(varchar(10),bg.DevDate,121) <= @DevDateEnd)   --商品开发结束时间
    --AND (ISNULL(@Purchaser,'') = '' OR bg.Purchaser = @Purchaser) 
  group by  
    D.TradeNid 
     -- 历史表sku数据
    insert into #tempskucostprice(tradenid,goodcostprice,costprice,PackFee)
    select
    dt.TradeNID,
    sum(dt.L_QTY*(case when bgs.costprice<>0 then bgs.costprice 
	                                      else bg.CostPrice end)),
	SUM(dt.CostPrice),
	sum(dt.L_QTY*(ISNULL(bg.PackFee,0)))
    from P_TradeDt_His dt with(nolock) 
    inner join B_GoodsSKU bgs with(nolock)  on bgs.SKU = dt.SKU 
	inner join b_goods bg with(nolock)  on bg.NID = bgs.GoodsID
    where dt.tradenid in (select NID from #TempTradeInfo_NID) 
    group by dt.TradeNID
  
  --再根据查询的NID插入详细信息	  
  insert into #TempTradeInfo
  select                             
	m.nid,                                                                                --nid  
	case when @DateFlag=0  then convert(varchar(10),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(10),m.CLOSINGDATE,121) end as OrderDay,	                  --时间显示到日(yyyy-mm-dd) 0 交易 1 发货 
	case when @DateFlag=0  then convert(varchar(7),DATEADD(HOUR,8,m.ORDERTIME),121) 
	     else convert(varchar(7),m.CLOSINGDATE,121) end as OrderMonth,                    --时间显示到月(yyyy-mm) 0 交易 1 发货   	   
	m.Suffix,	                                                                          --卖家简称	
	case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	     else isnull(c.ExchangeRate,1) end as ExchangeRate,                               --销售汇率 包括(销售价,pp手续费,买家付运费)
    m.AMT as SaleMoney,			                                                          --销售价 AMT
	m.SHIPPINGAMT as SHIPPINGAMT,		                                                  --买家付运费
	m.FEEAMT as ppFee ,                                                                   --PP手续费  
	case when m.ADDRESSOWNER = 'ebay' or m.ADDRESSOWNER = 'paypal' then @ExchangeRate 
	     else case when @RateFlag = 1 then isnull(m.EXCHANGERATE,1) 
	               else isnull(c.ExchangeRate,1) end end as ebayExchangeRate,             --平台手续费汇率  
	m.SHIPDISCOUNT as eBayFee,		                                                      --平台手续费  
	isnull((case when @CalcCostFlag =0 then ts.costprice 
	               else ts.goodcostprice end),0) as CostMoney,        --成本价￥  dt表的商品成本加一起（根据系统参数取商品成本还是库存平均价） 
	m.ExpressFare,                                                                        --快递费￥      
	isnull(ts.PackFee,0) as InpackageMoney,   --内包装金额￥
	m.INSURANCEAMOUNT as outpackageMoney,	                                              --外包装金额￥
	m.TotalWeight*1000 as TotalWeight,                                                    --总重量 G
	'' as DevDate,                   --最大商品开发时间
	isnull(ts.goodcostprice,0) as ItemCostPrice,    --商品信息的成本价（商品成本加一起） 
	m.ACK,                                                                                --店铺单号
	m.[User],	                                                                          --卖家id
	m.PaiDanMen,	                                                                      --派单人	
	m.AllGoodsDetail as sku,	                                                          --sku明细
	m.TrackNo,                                                                            --跟踪号
	m.CURRENCYCODE as CurrencyCode,                                                       --币种
	l.name as wlWay,                                                                      --物流方式名称
	m.SHIPTOCOUNTRYNAME,                                                                  --收货人国家
	m.TRANSACTIONID,		                                                              --PP交易ID
	m.BuyerID,                                                                            --买家ID	
	m.MULTIITEM AS SaleItemsCount,			                                              --销售总数量
	m.SALESTAX AS SaleSKUCount,                                                           --SKU数量
	m.SHIPTOCOUNTRYCODE,		                                                          --收件人国家代码	
	bc.CountryZnName	                                                                  --国家中文名	
  from 
	P_Trade_his(nolock) m		
	left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID			
	left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
	left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE
	left join #tempskucostprice ts with(nolock) on ts.tradenid=m.NID	
  where 
	m.NID in (select NID from #TempTradeInfo_NID)  				    

 --再查询最终的明细的订单编号	 
  --insert into #Temp_finacial_tb

  --0日期 2月份
  if @Flag=0 
  begin
  insert into #Temp_tb
	--统计信息 	
	--扣除PP手续费 = 销售价 - pp手续费 	
	--实得金额 = 销售价 - pp手续费 - 平台手续费
	--包装成本 = 内包装 + 外包装
	--利润 =  销售价 - pp手续费 - 平台手续费 - 商品成本价 - 内包装 - 外包装 - 快递费
	--利润率 = 利润 / 销售价
	select 
	  nid,                                     --nid
	  ACK,                                     --店铺单号
	  [User],                                  --卖家ID
	  PaiDanMen,                               --派单员
	  OrderDay,	                               --时间-日
	  left(SKU,CHARINDEX('*', sku)-1),                          --商品明细
	  Suffix,                                  --卖家简称
	  TrackNo,                                 --跟踪号
	  CurrencyCode,                            --币种
	  wlWay,	                               --物流方式
	  SHIPTOCOUNTRYNAME ,                      --收件人国家名称
	  TRANSACTIONID,		                   --PP交易ID
	  BuyerID,                                 --买家ID				
	  ExchangeRate,                            --平台汇率				
	  SaleMoney,                                                        --销售价
	  round(SaleMoney * ExchangeRate / @ExchangeRate,2) as SaleMoneyUS,          --销售价$
	  round(SaleMoney * ExchangeRate,2) as SaleMoneyzn,                          --销售价￥
	  SHIPPINGAMT,                                                      --买家付运费
	  round(SHIPPINGAMT * ExchangeRate / @ExchangeRate,2) as SHIPPINGAMTUS,      --买家付运费$
	  round(SHIPPINGAMT * ExchangeRate,2) as SHIPPINGAMTzn,                      --买家付运费￥
	  eBayFee as eBayFeeYs,                                             --平台交易费
	  round(eBayFee * ebayExchangeRate / @ExchangeRate,2) as eBayFee,            --平台交易费$
	  round(eBayFee * ebayExchangeRate,2) as eBayFeezn,                          --平台交易费￥
	  ppFee,                                                            --pp手续费
	  round(ppFee * ExchangeRate / @ExchangeRate,2) as ppFeeUS,                  --pp手续费$
	  round(ppFee * ExchangeRate,2) as ppFeezn,                                  --pp手续费￥
	  SaleMoney - ppFee as sdMoney  ,                                   --扣除PP手续费
	  round((SaleMoney - ppFee) * ExchangeRate / @ExchangeRate,2) as ppMoney,    --扣除PP手续费$
	  round((SaleMoney - ppFee) * ExchangeRate,2) as ppMoneyzn,                  --扣除PP手续费￥
	  round(SaleMoney * ExchangeRate / @ExchangeRate  
	  - eBayFee * ebayExchangeRate / @ExchangeRate
	  - ppFee * ExchangeRate / @ExchangeRate,2) as sdMoneyUs,              --实得金额$
	  round(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate 
	  - ppFee * ExchangeRate,2)  as sdMoneyZn,                             --实得金额￥
	  CostMoney,                                                        --商品成本价￥		
	  ExpressFare,                                                      --快递费￥	
	  inpackageMoney + outpackageMoney as packageMoney,                 --包装成本￥
	  inpackageMoney  ,                                                 --内包装成本￥
	  outpackageMoney  ,                                                --外包装成本￥	
	  round(SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare,2) as lrMoney,                                         --利润￥
	  TotalWeight,                                                      --总重量                                    
	  SaleItemsCount,                                                   --销售总数量
	  SaleSKUCount,                                                     --销售SKU数量
	  case when SaleMoney * ExchangeRate = 0 then 0
	  else round((SaleMoney * ExchangeRate 
	  - eBayFee * ebayExchangeRate
	  - ppFee * ExchangeRate
	  - CostMoney 
	  - inpackageMoney
	  - outpackageMoney
      - ExpressFare) / (SaleMoney * ExchangeRate) * 100,2) end as lrl,  --利润率	
	  SHIPTOCOUNTRYCODE,                                                --国家代码
	  CountryZnName,                                                    --国家中文
	  DevDate,                                                          --商品开发日期
	  ItemCostPrice                                                     --商品信息成本价
	  from #TempTradeInfo  where SaleSKUCount =1 --group by SKU
--insert into #
	 insert into #Temp_bg_ww 
	 select 
	bg.goodscode as goodscode,
	bg.salername as salername,
	bg.purchaser as purchaser,
	bg.aliascnname as aliascnname,
	bg.goodsname as goodsname,
	bgs.goodsskustatus as goodsskustatus,
	bg.SKU as SKU
	from B_Goods bg LEFT JOIN B_GoodsSKU bgs on bg.NID=bgs.GoodsID
	where bgs.SKU in (select SKU from #TempTradeInfo) 
  
insert into  #Temp_last_ww
select 
#temp_tb.suffix ,
--#temp_tb.sku as SKU,
bg.GoodsName ,
bg.SalerName ,
bg.Purchaser ,
bg.GoodsCode ,
bgc.CategoryName,     --管理类别
B_GoodsSKU.GoodsSKUStatus ,
round(sum(#temp_tb.SaleMoneyzn),1) as zsale,
round(sum(#temp_tb.lrMoney),1) as zlr
--case when sum(#temp_tb.SaleMoneyzn)=0 then 0 else round(sum(#temp_tb.lrMoney)/sum(#temp_tb.SaleMoneyzn)*100,1) end
--round(sum(#temp_tb.SaleMoneyzn)/sum(#temp_tb.lrMoney),1) as lrl
from #Temp_tb 
LEFT JOIN B_GoodsSKU on #temp_tb.sku = B_GoodsSKU.sku 
LEFT JOIN  B_Goods bg on bg.NID=B_GoodsSKU.GoodsID
LEFT JOIN B_GoodsCats bgc on bgc.NID=bg.GoodsCategoryID
-- full  JOIN B_Goods on #temp_tb.sku = B_Goods.sku
 GROUP BY #temp_tb.suffix,bg.GoodsCode,bg.GoodsName,bg.SalerName,bg.Purchaser,bgc.CategoryName,B_GoodsSKU.GoodsSKUStatus order by sum(#temp_tb.lrMoney) asc
 
insert into  #Temp_goods --这个是#Temp_tb 表中对应的sku=B_Goods.GoodsCode中的,对商品编码进行匹配的
select 
#temp_tb.suffix ,
--#temp_tb.sku as SKU,
bg.GoodsName ,
bg.SalerName ,
bg.Purchaser ,
bg.GoodsCode ,
bgc.CategoryName,     --管理类别
B_GoodsSKU.GoodsSKUStatus ,
round(sum(#temp_tb.SaleMoneyzn),1) as zsale,
round(sum(#temp_tb.lrMoney),1) as zlr
--case when sum(#temp_tb.SaleMoneyzn)=0 then 0 else round(sum(#temp_tb.lrMoney)/sum(#temp_tb.SaleMoneyzn)*100,1) end
--round(sum(#temp_tb.SaleMoneyzn)/sum(#temp_tb.lrMoney),1) as lrl
from #Temp_tb 
left JOIN B_Goods bg on #temp_tb.sku = bg.GoodsCode
LEFT JOIN  B_GoodsSKU  on bg.NID=B_GoodsSKU.GoodsID  --这里注意连接很重要，一定要清楚 join ,left join ,right join 
LEFT JOIN B_GoodsCats bgc on bgc.NID=bg.GoodsCategoryID
GROUP BY #temp_tb.suffix,bg.GoodsCode,bg.GoodsName,bg.SalerName,bg.Purchaser,bgc.CategoryName,B_GoodsSKU.GoodsSKUStatus order by sum(#temp_tb.lrMoney) asc 

--这个才是最后的表 #Temp_last_ww2
--insert into #Temp_last_ww2
--select * from #Temp_last_ww --UNION select * from #Temp_goods



--最后筛选出我们要的来的字段
SELECT 
suffix ,
case when  suffix IN('01-buy','02-2008','03-88','04-cheong','05-eshop','06-happygirl','07-smile','08-fashion','09-niceday','10-girlspring','11-newfashion','12-showgirl','13-showtime','14-degage','15-zone','16-sunshine','17-su061','18-shuai','05-5avip','08-xea','03-aatq','15-exao')
 THEN 'eBay' 
 WHEN suffix IN('AMZ01-CA','AMZ01-DE','AMZ01-ES','AMZ01-FR','AMZ01-IT','AMZ01-UK','AMZ02-JP','AMZ02-US','AMZ02-CA','AMZ04-US','AMZ04-CA','AMZ05-US','AMZ06-US','AMZ06-CA')
THEN 'Amazon'
WHEN suffix IN('LZD01-eeeshopping-ID','LZD01-eeeshopping-MY','LZD01-eeeshopping-SG')
THEN 'Lazada'
WHEN suffix IN('SMT01-eshop','SMT02-great','SMT03-happygirl','SMT05-fashion','SMT06-niceday','SMT07-girlspring','SMT08-newfashion','SMT09-showgirl','SMT10-showtime','SMT11-degaga','SMT12-fashionzone','SMT14-foxlady','SMT15-charmgarden','SMT16-girlswardrobe','SMT18-my5aVIP','SMT19-YRSMT19','SMT17-magicspace66')
THEN 'SMT'
WHEN suffix IN('WIS01-eshop','WIS02-zone','WIS03-world','WIS04-hapyshop','WIS05-fashionp','WIS06-hones','WIS07-Rosa','WIS08-angel','WIS09-universe','WIS10-gossipgirl','WIS11-fashiontribe','WIS12-fantasticgirl','WIS13-decorationsector','WIS14-wednesdayshop','WISE08-Highhigh','WISE14-Fantasticfairyland','WISE09-Singledog','WISE05-Ifyou521',
'WISE07-Coldbone','WISE10-Womenflowers','WISE13-Fastcar269','WISE16-Badgirl','WISE17-Sunshinegirl','WISE19-Highhigh2016','WISE21-Hopefine','WISE03-Sixtyplus','WISE20-Goodday125','WISE22-Feifeimarket','WISE24-Lonelybar','WISE15-Hanoba','WISE26-Privatecorner','WISE27-Travelgirl','WISE29-Girlswardrobe','WISE28-Foreverbeauty521')
THEN 'Wish'
WHEN suffix IN('Top-01')
THEN 'Tophatter'
ELSE NULL
END as pingtai,--ISNUMERIC([SUBSTRING](`suffix`, 0, 1)) then set Ebay end as pingtai,
GoodsName ,
SalerName ,
Purchaser ,
aliascnname,     --管理类别
GoodsSKUStatus,
GoodsCode ,
round(zsale,1) as zsale,
round(zlr,1) as zlr ,
case when zsale=0 then 0 else round((zlr/zsale)*100,1) end as lrl
FROM #Temp_last_ww --UNION #Temp_goods
GROUP BY suffix ,GoodsCode,GoodsName,SalerName,aliascnname,Purchaser,GoodsSKUStatus,zsale,zlr order by zlr asc


--select * from #Temp_goods;  
 end             
  
		
  drop table #TempTradeInfo 
  drop table #TempTradeInfo_NID
  drop table #TempTradeInfo_TempNID
  drop table #tempskucostprice 
	drop table #Temp_tb
  drop table #Temp_goods
	drop table #Temp_last_ww
	drop table #Temp_bg_ww 
drop table #Temp_last_ww2
end				
