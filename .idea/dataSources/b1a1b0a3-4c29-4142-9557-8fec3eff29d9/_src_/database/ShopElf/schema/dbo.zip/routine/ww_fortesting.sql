CREATE PROCEDURE [dbo].[ww_fortesting]
@mindelayDay int,
@maxdelayDay int

AS
BEGIN
DECLARE @curtime varchar(20)
set @curtime =  datediff(ss,'1970-01-01',GETDATE())
select DATEADD(HOUR,8,ORDERTIME) as tradetime,trackno as realtrackno,suffix,ack,nid, shiptocountrycode + cast(row_number()over(partition by  shiptocountrycode order by getdate() ) as varchar(10))  as coun,memo into #wishtrade from P_tradeun where DATEDIFF(day, DATEADD(HOUR,8,ORDERTIME), getdate()) BETWEEN @mindelayDay and @maxdelayDay and suffix like 'wise%' AND
not EXISTS (SELECT * from z_trackno as t where t.tradenid = P_TradeUn.nid) and protectioneligibilitytype = '缺货订单' order by ordertime
select shiptocountrycode + cast(row_number()over(partition by  shiptocountrycode order by getdate()) as varchar(10)) as country,trackNo into #ebaytrade from P_Trade where FilterFlag in (22,24) and DATEDIFF(day, PaidanDate, GETDATE())<=3 and ADDRESSOWNER='ebay' and ExpressNID=2 
and not EXISTS (select * from z_trackno as t where t.trackno = P_Trade.TrackNo) order by ordertime
select  *  into #out from #wishtrade as w left JOIN #ebaytrade as e on w.coun = e.country
--select count(*) from #wishtrade
SELECT (select count(*) from  #out where ISNULL(trackno, '')='' or  ISNULL(nid, '')='' ) as matched,(select count(*)from #wishtrade) as total,@curtime as curtime,* from #out where ISNULL(trackno, '')='' or  ISNULL(nid, '')=''
drop table #wishtrade
drop table #ebaytrade
drop table #out
END