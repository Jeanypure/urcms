CREATE PROCEDURE [dbo].[ww_skudetail]
@sku varchar(30)
AS
BEGIN
  select  
case isnull(bgs.property1,'') 
WHEN '白色' THEN 'white'
WHEN '米色' THEN 'beige'
WHEN '黑色' THEN 'black'
WHEN '蓝色' THEN 'blue'
WHEN '酒红色' THEN 'Burgundy'
WHEN '褐色' THEN 'brown'
WHEN '深灰色' THEN 'dark grey'
WHEN '金色' THEN 'gold'
WHEN '灰色' THEN 'gray'
WHEN '褐' THEN 'brown'
WHEN '蓝' THEN 'blue'
WHEN '黑' THEN 'black'
WHEN '米' THEN 'beige'
WHEN '军绿' THEN 'army green'
WHEN '黄色' THEN 'yellow'
WHEN '天蓝色' THEN 'sky blue'
WHEN '银色' THEN 'silver'
WHEN '红色' THEN 'red'
WHEN '紫色' THEN 'purple'
WHEN '粉色' THEN 'pink'
WHEN '橙色' THEN 'orange'
WHEN '紫罗兰' THEN 'lavender'
WHEN '卡其色' THEN 'khaki'
WHEN '象牙白' THEN 'ivory'
WHEN '绿色' THEN 'green'
WHEN '橘红' THEN 'orange'
WHEN '玫红色' THEN 'rosy'
WHEN '玫红' THEN 'rosy'
WHEN '黄' THEN 'yellow'
WHEN '白' THEN 'white'
WHEN '天蓝' THEN 'sky Blue'
WHEN '银' THEN 'silver'
WHEN '红' THEN 'red'
WHEN '紫' THEN 'purple'
WHEN '粉' THEN 'pink'
WHEN '粉红色' THEN 'pink'
WHEN '粉色' THEN 'pink'
WHEN '橙' THEN 'orange'
WHEN '紫罗' THEN 'lavender'
WHEN '深灰' THEN 'dark Grey'
WHEN '金' THEN 'gold'
WHEN '灰' THEN 'gray'
WHEN '绿' THEN 'green'
WHEN '象牙' THEN 'ivory'
WHEN '卡其' THEN 'khaki'
ELSE isnull(bgs.property1,'') END  
as color, bgs.sku,bgs.bmpfilename as pic,
bgs.property2 as size,bgs.retailprice as  price from B_Goodssku as bgs
 LEFT JOIN B_goods as bg on bgs.goodsid = bg.nid where bg.goodscode = @sku-- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
END