CREATE PROCEDURE [dbo].[www_checklisted_products]
 @BeginCreateDate DATE, -- 起始时间
 @EndCreateDate date, -- 截至时间
@storeOwner varchar(30), -- 账号负责人
@storeName varchar(60), -- 账号名称
@goodsStatus varchar(30), -- 产品状态
@salername1 varchar(30),-- 业绩归属人1
@salername2 varchar(30),-- 业绩归属人2
@catname1 varchar(30),-- 主目录
@catname2 varchar(30) -- 子目录

-- 考虑参数为空的情形
AS
BEGIN
DECLARE @saler1 varchar(30) 
DECLARE @saler2 varchar(30)
DECLARE @cat varchar(30)
DECLARE @owner varchar(30)
DECLARE @store varchar(60)
DECLARE @status varchar(30)


create table #goodsstatus(status varchar(30))
IF isnull(@goodsStatus, '')=''
BEGIN
insert #goodsstatus select '爆款' UNION select '旺款' 
end  
ELSE
begin
insert #goodsstatus select @goodsStatus

END

BEGIN
set @status=@goodsStatus
end

IF isnull(@storeOwner, '')=''
BEGIN
set @owner='%%'
END
ELSE
BEGIN
set @owner=@storeOwner + '%'
end
IF isnull(@storeName, '')=''
BEGIN
set @store='%%'
END
ELSE
BEGIN
set @store=@storeName + '%'
end

if ISNULL(@salername1, '')=''
BEGIN
set @saler1='%%'
END
ELSE
Begin
set @saler1=@SalerName1 + '%'
END
if isnull(@salername2,'')=''
BEGIN
set @saler2=''
END
else
begin

set @saler2=@salername2 + '%'
end
if ISNULL(@catname1,'')=''
BEGIN
set @cat='%%'
END
ELSE
BEGIN
--set @cat= '0|' + @catname1+ '|' + @catname2 +'%'
if isnull(@catname2,'')=''
BEGIN
set @cat= ISNULL(@catname1,'') + '%'
END
ELSE
BEGIN
set @cat= ISNULL(@catname2, '')
end
end

DECLARE @site varchar(2)
set @site=0

-- 已经上架的sku列表
create table #lisetd_details(
ebayid varchar(30),
sku varchar(30),
goodscode varchar(30)
)

--根据子sku的状态计算产品的状态 存在爆款，旺款就是。
select max(bgs.goodsskustatus) as goodsstatus,bg.goodscode into #productsstatus FROM
B_Goodssku as bgs 
LEFT JOIN B_Goods as bg ON
bgs.goodsid = bg.nid
where 
bgs.goodsskustatus in (select * from #goodsstatus) --限定产品状态
and  bg.createdate  BETWEEN @BeginCreateDate and @EndCreateDate  --限定创建时间
group by bg.goodscode




-- 得到应该上架产品 
select 
bg.goodscode as SKU,
pros.goodsstatus,
bg.goodsname, 
bg.createdate,
bg.salername,
bg.salername2,
store.ebayid,
store.ebayname,
store.owner,
gcats.categoryname, 
gcats.categoryparentname 
into #shouldlisted 
from #productsstatus as pros 
LEFT JOIN B_Goods as bg
on pros.goodscode=bg.goodscode
LEFT JOIN  B_GoodsCats as gcats 
on bg.goodscategoryid = gcats.nid
LEFT JOIN  z_store_sku  as store
on bg.categorycode like store.catid +'%' 
where
bg.salername like @saler1  -- 业绩归属人1
and bg.salername2 like @saler2 -- 业绩归属人2
and bg.categorycode like @cat -- 目录
and store.owner like @owner -- 账号负责人
and store.ebayid like @store -- 账号筛选
and isnull(store.ebayid,'') != '' --只显示能匹配到账号的产品

-- 已上架sku详情
insert into #lisetd_details 
select listed.ebayid,
listed.sku,
bg.goodscode  
from z_allroot_listed as listed 
LEFT JOIN B_Goodssku as bgs
on listed.sku = bgs.sku  
LEFT JOIN B_Goods as bg
on bgs.goodsid = bg.nid     
where ISNULL(bg.goodscode, '')!=''



-- 得到已上架产品就好
select 
ebayid,goodscode 
into #listedProducts
from #lisetd_details 
group by goodscode,ebayid 
ORDER BY goodscode


-- 应该上架但未上架的sku列表

select should.* from
#shouldlisted as should 
LEFT JOIN #listedProducts as pros
on  should.sku= pros.goodscode 
where ISNULL(pros.ebayid, '') ='' 
drop table #goodsstatus
drop table #productsstatus
drop table #listedProducts
drop table #lisetd_details
drop table #shouldlisted

END