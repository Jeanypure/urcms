CREATE PROCEDURE [dbo].[www_ebay_bad_trades]
AS
BEGIN
--  protectioneligibilitytype='缺货订单'
  select dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype, nid,shiptozip,shiptostreet,buyerid,'p_tradeun' as tablename from P_Tradeun where protectioneligibilitytype='缺货订单' and memo not like '%钓鱼账号%'  and  TRANSACTIONtype='ebay' and shiptozip like '%60604%'
UNION 
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype, nid,shiptozip,shiptostreet,buyerid,'p_tradeun' as tablename from P_Tradeun where protectioneligibilitytype='缺货订单' and memo not like '%钓鱼账号%'  and  TRANSACTIONtype='ebay' and shiptozip like '%60621-%'
UNION
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype, nid,shiptozip,shiptostreet,buyerid,'p_tradeun' as tablename from P_Tradeun where protectioneligibilitytype='缺货订单' and memo not like '%钓鱼账号%'  and  TRANSACTIONtype='ebay' and  shiptozip='60621'
UNION
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype, nid,shiptozip,shiptostreet,buyerid ,'p_tradeun' as tablename from P_Tradeun where protectioneligibilitytype='缺货订单' and memo not like '%钓鱼账号%'  and  TRANSACTIONtype='ebay' and shiptozip like '%00736%' 
UNION
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype,nid,shiptozip,shiptostreet,buyerid ,'p_trade' as tablename from P_Trade where TRANSACTIONtype='ebay' and memo not like '%钓鱼账号%'  and shiptozip like '%60604%' 
UNION 
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype,nid,shiptozip,shiptostreet,buyerid ,'p_trade' as tablename from P_Trade where TRANSACTIONtype='ebay'and memo not like '%钓鱼账号%'   and shiptozip like '%60621-%'
UNION
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype,nid,shiptozip,shiptostreet,buyerid ,'p_trade' as tablename from P_Trade where TRANSACTIONtype='ebay'and memo not like '%钓鱼账号%'   and shiptozip='60621'
UNION
select  dateadd(hour,8,ordertime) as ordertime,protectioneligibilitytype,nid,shiptozip,shiptostreet,buyerid  ,'p_trade' as tablename from P_Trade where TRANSACTIONtype='ebay'and memo not like '%钓鱼账号%'   and shiptozip like '%00736%' 

END