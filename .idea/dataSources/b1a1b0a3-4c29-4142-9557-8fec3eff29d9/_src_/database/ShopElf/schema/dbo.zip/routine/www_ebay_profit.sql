CREATE PROCEDURE [dbo].[www_ebay_profit]
@begindate varchar(20),
@enddate varchar(20)
AS
BEGIN
DECLARE @beginning varchar(40),@endding varchar(40)
set @beginning= @begindate + ' 00:00:00'
set @endding = @enddate + ' 23:59:59'

--创建临时表
create table #tmp_ebay(
nid int,
suffix varchar(30),
sku varchar(20),
ebaysku varchar(50),
itemid varchar(25),
currency varchar(6),
price FLOAT,
goodsskustatus varchar(20),
goodsname varchar(80),
goodsstatus varchar(20),
closingdate datetime,
ordertime datetime
)


-- 待派单数据
INSERT into #tmp_ebay 
select pt.nid,pt.suffix,pdt.sku,pdt.eBaySKU,pdt.L_NUMBER as itemid,pdt.L_CURRENCYCODE as currency,pdt.l_amt,bgs.GoodsSKUStatus,bg.GoodsName,bg.GoodsStatus,pt.closingdate ,
dateadd(hour,8,pt.ordertime) as ordertime
from p_trade as pt LEFT JOIN P_TradeDt as pdt on pt.nid=pdt.TradeNID
LEFT JOIN B_GoodsSKU as bgs
LEFT JOIN B_Goods as bg
on bgs.GoodsID=bg.nid
on bgs.nid=pdt.GoodsSKUID 
--where dateadd(hh,8,pt.ordertime) BETWEEN @begindate and @enddate 订单时间
where  @beginning<=pt.closingdate  and pt.closingdate<@endding  --发货时间
and pt.addressowner='ebay'


-- 归档订单数据

INSERT into #tmp_ebay 
select pt.nid,pt.suffix,pdt.sku,pdt.eBaySKU,pdt.L_NUMBER as itemid,pdt.L_CURRENCYCODE as currentcy,pdt.l_amt,bgs.GoodsSKUStatus,bg.GoodsName,bg.GoodsStatus,pt.closingdate,
left(dateadd(hour,8,pt.ordertime),10) as ordertime
from p_trade_his as pt LEFT JOIN P_TradeDt_His as pdt on pt.nid=pdt.TradeNID
LEFT JOIN B_GoodsSKU as bgs
LEFT JOIN B_Goods as bg
on bgs.GoodsID=bg.nid
on bgs.nid=pdt.GoodsSKUID 
--where dateadd(hh,8,pt.ordertime) BETWEEN @begindate and @enddate 订单时间
where   @beginning<=pt.closingdate  and pt.closingdate<@endding     --发货时间
--查询结果
select nid,suffix,sku,ebaysku,itemid,currency,price,goodsskustatus,goodsname,goodsstatus,LEFT(closingdate,10) as closingdate ,
convert(varchar(100),ordertime,23) as ordertime From #tmp_ebay 


-- 删除临时表

drop table #tmp_ebay
END