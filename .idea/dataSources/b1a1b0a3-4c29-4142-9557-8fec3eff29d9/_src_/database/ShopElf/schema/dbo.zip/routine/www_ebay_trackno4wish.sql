CREATE PROCEDURE [dbo].[www_ebay_trackno4wish]
 @ordertime datetime,
 @coun VARCHAR(5),
 @tradenid int
AS
BEGIN
create table #tmpebay(trackno varchar(30),tradenid varchar(30),createdate datetime,logicswaynid int)
set @ordertime= dateadd(hh,8,@ordertime)


	BEGIN tran james
	insert into #tmpebay
	select top 1
		pt.trackno,
		@tradenid as tradenid,
		getdate() as createdate,
		logicswaynid
		from p_trade_his  as pt -- 从归档订单中找假单号
		where not EXISTS
		(select * from z_trackno as t
		where t.trackno =pt.trackno) -- 用过的单号不再用
		and datediff(mi,@ordertime, pt.closingdate)>0  --发货时间再wish单的交易时间之后
		and datediff(day, @ordertime, pt.closingdate)  BETWEEN 0 and 2 -- 发货时间是wish单延迟俩天内
		--and datediff(mi,@ordertime, dateadd(hh,8,pt.ordertime))>0  -- ebay交易时间在wish交易时间之后/控制单号上传日期
		and pt.shiptocountrycode=@coun
		and pt.addressowner = 'ebay' -- 必须是ebay的单号
		
		and logicswaynid in (123,52,94) -- 123 北京中邮（燕文）Yanwen-- 52  wis邮政平邮 WishPost--  94 wish邮南京 WishPost
		order by closingdate desc -- 发货时间和交易时间接近的优先匹配

		insert into #tmpebay
		select top 1
		pt.trackno,
		@tradenid as tradenid,
		getdate() as createdate,
		logicswaynid
		from p_trade  as pt -- 从待派订单中找假单号
		where not EXISTS
		(select * from z_trackno as t
		where t.trackno =pt.trackno) -- 用过的单号不再用
		and datediff(mi,@ordertime, pt.closingdate)>0  --发货时间再wish单的交易时间之后
		and datediff(day, @ordertime, pt.closingdate)  BETWEEN 0 and 2 -- 发货时间是wish单延迟俩天内
		--and datediff(mi,@ordertime, dateadd(hh,8,pt.ordertime))>0  -- ebay交易时间在wish交易时间之后/控制单号上传日期
		and pt.shiptocountrycode=@coun
		and pt.addressowner = 'ebay' -- 必须是ebay的单号
		
		and logicswaynid in (123,52,94) -- 123 北京中邮（燕文）Yanwen-- 52  wis邮政平邮 WishPost--  94 wish邮南京 WishPost
		order by closingdate desc -- 发货时间和交易时间接近的优先匹配


		insert into z_trackno(trackno,tradenid,createddate) SELECT top 1 trackno,tradenid,createdate from #tmpebay -- 存在一条记录即可

		COMMIT tran james
	
SELECT top 1 * from #tmpebay
drop table #tmpebay
END