CREATE PROCEDURE [dbo].[www_markedunpurchasing]
AS
BEGIN
   create table #UnPaiDNum( goodsskuid int,sku varchar(30),UnPaiDNum numeric(10,2),StoreID int)
	     insert into #UnPaiDNum
		SELECT goodsskuid, sku, SUM(SaleNum) AS SaleNum, StoreID	
		FROM (  --未派单的销售商品 和  数量(Trade)
				SELECT ISNULL(gs.NID,0) as GoodsSKUID,
				isnull(gs.sku, '') as sku,
					SUM(case when pt.RestoreStock=-1 then 0 else ptd.L_QTY end) AS SaleNum,
					ISNULL(ptd.StoreID,0)AS StoreID
				FROM P_TradeDt(nolock) ptd 
				inner join P_trade(nolock) pt on pt.NID=ptd.TradeNID
				inner join B_GoodsSKU gs on gs.SKU=ptd.SKU
			
				WHERE pt.FilterFlag = 5 
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0),isnull(gs.sku,'') 
			 ) AS C
		GROUP BY GoodsSKUID,StoreID,sku



-- 计算订单包含sku的个数
select count(*) as skunum, tradenid into #skucount from P_TradeDtUn GROUP BY tradenid


-- 计算停产缺货sku的售出和排序 并存入#tmpun临时表中
select ptun.tradenid,pt.addressowner,bgs.nid,bg.purchaser, pt.reasoncode,ptun.sku, sc.skunum,ptun.l_qty,row_number() 
over(partition by ptun.sku order by pt.ordertime) as rank, bgs.goodsskustatus
into #tmpun
from P_tradedtun as ptun 
LEFT JOIN P_tradeun as pt on ptun.tradenid= pt.nid 
LEFT JOIN B_goodssku as bgs on ptun.sku=bgs.sku 
LEFT JOIN B_Goods as bg on bgs.goodsid= bg.nid 
LEFT JOIN #skucount as sc on ptun.tradenid= sc.tradenid
where isnull(ptun.sku,'')!=''  and pt.PROTECTIONELIGIBILITYTYPE='缺货订单'
and bgs.goodsskustatus in ('清仓','停产','禁售') 


-- 计算停产缺货sku的可用数量 并 存入#tmpusable 临时表中
select outstock.*, (isnull(cs.number,0)-isnull(cs.reservationnum,0)) as usablenum
into #tmpusable
from #tmpun as outstock 
LEFT JOIN KC_CurrentStock as cs on outstock.nid=cs.goodsskuid
--and isnull(pt.REASONCODE,'')  not like '%不采购%'



-- 计算停产缺货sku的缺货占用数量，并存到#tempoutnum中 
select a.sku,a.nid,a.skunum,a.rank,a.l_qty,a.tradenid, a.addressowner, a.reasoncode,a.goodsskustatus,a.purchaser, 
sum(b.l_qty)-a.l_qty as total into #tempoutnum
from #tmpun as a LEFT JOIN #tmpun as b on a.sku=b.sku 
where a.rank >= b.rank 
GROUP BY a.sku,a.nid, a.rank,a.tradenid,a.l_qty, a.addressowner, a.reasoncode,a.goodsskustatus,a.purchaser,a.skunum
ORDER BY a.sku,a.rank



-- 根据#tmpusable #temooutnum 计算出停产缺货skud的实际可用数量，并返回查询结果
select tmo.sku as sku,tmo.tradenid as nid
from #tempoutnum as tmo LEFT JOIN #tmpusable as tmu on tmo.nid=tmu.nid and tmo.tradenid=tmu.tradenid
where tmu.usablenum >0
and tmu.usablenum-tmo.total >=0


drop table #tmpusable
drop table #tempoutnum
drop table #skucount
drop table #tmpun
drop table #unpaidnum  	
END