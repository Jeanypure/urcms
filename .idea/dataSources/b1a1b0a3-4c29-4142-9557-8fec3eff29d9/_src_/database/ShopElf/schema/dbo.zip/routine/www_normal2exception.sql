CREATE PROCEDURE [dbo].[www_normal2exception]
@tradenid int,
@Batchnum varchar(50)=''
AS
BEGIN

 begin tran test
BEGIN Try 
	DECLARE
	@errorcount int=0
	set identity_insert p_trade on 
	set @errorcount=@@ERROR
	update P_Trade set filterFlag=4,protectioneligibilitytype='其它异常单',
	batchnum=@Batchnum where nid=@tradenid 
	set @ErrorCount=@@ERROR + @ErrorCount
	insert into P_tradeun select * from p_trade where nid=@tradenid 
	and not EXISTS(select 1 from p_tradeun where nid=@tradenid) set @Errorcount=@@Error + @errorCount
	insert into P_Tradedtun select * from P_TradeDt where tradenid =@tradenid
	set @ErrorCount=@@Error + @ErrorCOunt
	DELETE from P_Trade where nid =@tradenid
	set @ErrorCount=@@Error + @ErrorCOunt
	DELETE from p_tradedt where tradenid=@tradenid
	set @ErrorCount=@@Error + @ErrorCOunt
END Try 
BEGIN catch 
set @ErrorCount =1 
END catch 
if @ErrorCount=0
BEGIN commit tran test END
else begin rollback tran test END
SELECT Errorcount = isnull(@Errorcount,0)	
END