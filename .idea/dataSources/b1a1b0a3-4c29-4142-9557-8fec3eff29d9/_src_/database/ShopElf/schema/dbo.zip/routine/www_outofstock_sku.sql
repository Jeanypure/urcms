CREATE PROCEDURE [dbo].[www_outofstock_sku]
		@MoreStoreID varchar(500),
    @GoodsState  varchar(2000) --商品sku状态
      
      
		
As
BEGIN
	declare
    -- 参数内化
		@cg int = 0,
		@GoodsCatsCode varchar(200) = '',
		@index varchar(50) ='2', 
		@KeyStr varchar(2000) ='',
		@WarningCats VARCHAR(1000)= '',
		@SupplierName varchar(2000) ='',
		@GoodsUsed varchar(32) = '0',
		@Purchaser VARCHAR(100) = '',
		@LocationName varchar(120) = '',  --库位
		@MoreSKU  varchar(3000) = '',



    -- 内部变量
		@PageCount int =0,          --输出页数
		@RecCount int=0,            --输出记录数	
		@TmpUsed1 int,
		@TmpUsed2 int,
		@TmpCount int
		
-- 主体部分
		if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end
		
		 
		IF (ISNULL(@Purchaser,'') = '')
	    SET @Purchaser = ''
	    
	    -- add by ylq 2015-04-29  库存预警类别表
	    --创建字段列表
    DECLARE @SqlStr VarChar(Max)
    
    Create Table #StoreTab
    (
      Nid int
    )
    
	CREATE TABLE #WarningCats
	(
		cName varchar(100)
	)
	--add by ylq 2015-05-15  商品sku状态
	CREATE TABLE #SkuState
	(
		cName varchar(100)
	)
	
	--add by ylq 2015-08-31
	Create table #TmpSup
	(
	  cName varchar(200)
	) 
	
	--add by ylq 2015-06-17 商品sku
	Create Table #TmpSku
	(
	  Sku varchar(100)
	 )
	 
--	Create Table #TmpKey
--	(  TmpStr varchar(100)	)
	
	 
	if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
 
	if @GoodsState <> '' 
	begin 
	  SET @SqlStr = 'insert into #SkuState(cName) select ''' + Replace(@GoodsState, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	if @SupplierName <> ''
	begin
	  SET @SqlStr = 'insert into #TmpSup(cName) select ''' + Replace(@SupplierName, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	
	if @WarningCats <> '' 
	begin 
	  SET @SqlStr = 'insert into #WarningCats(cName) select ' + Replace(@WarningCats, ',', ' union select ') 
	  EXEC(@SqlStr) 
	end
	
	if @MoreSKU <> '' 
	begin
	  set @SqlStr = 'insert into #TmpSku(Sku) select ''' + Replace(@MoreSKU, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	/* if @KeyStr <> ''
    begin
      --set @SqlStr = ' insert into #TmpKey select ''' + REPLACE(@KeyStr,',', '''union select ''') + ''''
      --Exec(@SqlStr) 
      
      if @index = '0'
      set @KeyStr='and G.goodsCode like ''%'+@KeyStr+'%'' '
       if @index = '1'
      set @KeyStr='and G.goodsName like ''%'+@KeyStr+'%'' '
       if @index = '2'
      set @KeyStr='and G.SKU like ''%'+@KeyStr+'%'' '
       if @index = '3'
      set @KeyStr='and G.BarCode like ''%'+@KeyStr+'%'' '
       if @index = '4'
      set @KeyStr='and G.SalerName like ''%'+@KeyStr+'%'' ' 
      if @index = '5'
      set @KeyStr='and G.FitCode like ''%'+@KeyStr+'%'' '     
    end */
	
	-- 因为如果是wrNone,也包含空的值
	if EXISTS (select  cName from  #WarningCats where cName = 'wrNone') 
	begin
      insert into #WarningCats(cName) values ('') 	
	end

	    IF (ISNULL(@WarningCats,'') = '')
	    SET @WarningCats = ''
		/*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int,/*ID*/
			  StoreName Varchar(50)
		)			
		
			
		/*生成商品查询*/
		--set @TmpCount = ( select COUNT(*) from #TmpKey)
		
		--if @TmpCount < 2 begin
		if @index = '0'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsCode like '%'+@KeyStr+'%')
		end
		if @index = '1'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsName like '%'+@KeyStr+'%')
		end
		if @index = '2'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or g.SKU like '%'+@KeyStr+'%' or gs.SKU like '%'+@KeyStr+'%' )
		end
		if @index = '3'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.BarCode like '%'+@KeyStr+'%')
		end
		if @index = '4'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.SalerName like '%'+@KeyStr+'%')
		end
		if @index = '5'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.FitCode like '%'+@KeyStr+'%')
		end	  
			    
		 /*end 
		 else begin    
		   insert into #Goods 
		     select distinct  gs.NID from B_GoodsSKU gs 
			 inner join B_Goods G on g.NID=gs.GoodsID  
			 inner join #TmpKey tmp1 on (G.GoodsName like '%' + tmp1.TmpStr + '%') 
			    or (gs.SKU like '%' + tmp1.TmpStr + '%') 
			    or (G.BarCode like '%' + tmp1.TmpStr + '%') 
			    or (G.SalerName like '%' + tmp1.TmpStr + '%')
			    or (G.FitCode like '%' + tmp1.TmpStr + '%')
			 left join #TmpSku tmp on gs.SKU = tmp.Sku  
			 left join B_Supplier sup on sup.NID = g.SupplierID 	
             where ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))
                and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
		       and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 
			   and ((@MoreSKU = '') or (tmp.Sku is Not Null))  --增加多选条件 
		 end */ 
		 
		 
		 
		 
 		
	    /*采购未入库数*/
	    --已完全入库订单商品
	     create table #InStoreD(StockOrderID int,StoreID int,GoodsSKUID int,Number numeric(18,8))
	     insert into  #InStoreD
	     select 
	       om.NID,
	       m.StoreID,
	       d.GoodsSKUID,
	       sum(d.Amount)
	     from CG_StockInD d
	     join CG_StockInM m on d.StockInNID = m.NID
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM om on m.StockOrder = om.BillNumber
	     where m.CheckFlag = 1
	     group by om.NID,d.GoodsSKUID,m.StoreID
	     --select * from #InStoreD
	     --未入库商品
	     create table #UnInStore(GoodsSKUID int,StoreID int,UnInNum numeric(18,8))
	     insert into #UnInStore(GoodsSKUID,storeid,UnInNum)
	     select 
		    d.GoodsSKUID,
		    m.StoreID,
		    SUM(case when (d.Amount - isnull(id.Number,0)) <= 0 then null else (d.Amount - isnull(id.Number,0)) end )
	     from CG_StockOrderD d
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM m on d.StockOrderNID = m.NID
	     left join #InStoreD id on d.StockOrderNID = id.StockOrderID and d.GoodsSKUID = id.GoodsSKUID and id.StoreID=m.StoreID
	     where 
		     (m.CheckFlag = 1)--审核通过的订单
	     and (m.Archive = 0)--不统计归档订单
	     group by d.GoodsSKUID,m.StoreID
	     --缺货或未派单的记录
	     create table #UnPaiDNum(GoodsSKUID int,UnPaiDNum numeric(10,2),StoreID int)
	     insert into #UnPaiDNum
		SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum, StoreID 	
		FROM (  --未派单的销售商品 和  数量(Trade)
				SELECT ISNULL(gs.NID,0) as GoodsSKUID, 
					SUM(case when pt.RestoreStock=-1 then 0 else ptd.L_QTY end) AS SaleNum,
					ISNULL(ptd.StoreID,0)AS StoreID
				FROM P_TradeDt(nolock) ptd 
				inner join P_trade(nolock) pt on pt.NID=ptd.TradeNID
				inner join B_GoodsSKU gs on gs.SKU=ptd.SKU	   
				inner join #Goods g on gs.nid = g.GoodsSKUID	             
				WHERE pt.FilterFlag <= 5 
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
-- 计算缺货订单的sku的预计可用库存数量，不应包含缺货订单占用的库存
		/*UNION all  --异常单的销售商品 和   数量(TradeUn)
			   SELECT 
						ISNULL(gs.NID,0) as GoodsSKUID, 
						SUM(case when pt.RestoreStock=-1 then 0 else ptdu.L_QTY end ) AS SaleNum ,
						ISNULL(ptdu.StoreID,0) AS StoreID
			   FROM P_TradeDtUn(nolock) ptdu 
			   inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID 
			   inner join B_GoodsSKU gs on gs.SKU=ptdu.SKU
			   inner join #Goods g on gs.nid = g.GoodsSKUID		       
			   WHERE pt.FilterFlag = 1                         
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0)
       */ 
			 ) AS C
		GROUP BY GoodsSKUID,StoreID	  	
	   
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
		
         
       --调拨单保存之后的预期入库
       
       select cd.GoodsSKUID,sum(cd.amount) as hopenum,cm.StoreInID                    into #StockChange
       from  KC_StockChangeD cd 
       inner join KC_StockChangeM cm on cm.nid=cd.StockChangenid and cm.checkflag=0
       group by cd.GoodsSKUID,cm.StoreInID 
       
       
          
		
		
		
			SELECT 
				@RecCount=count(1)
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	    			
			left join 
				B_Goods b on b.NID = gs.GoodsID	
			left join
				B_Supplier p on p.NID=b.SupplierID		
			left join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left join #WarningCats tmp on tmp.cName = d.WarningCats 
			-- WHERE (@WarningCats = '') OR  (d.WarningCats = @WarningCats)	
			WHERE (@WarningCats = '') OR  (tmp.cName is Not null)	
	-------------------计算记录数和页数
		  
		    
		   				
		 SELECT * INTO #KCtemp FROM
			(SELECT
				gs.SKU,	
				d.GoodsID,
				d.GoodsSKUID,
				d.Number,
				d.ReservationNum,
				d.Number-d.ReservationNum as usenum,
				d.Number-d.ReservationNum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) + isnull(sc.hopenum,0) as hopeUseNum
				-- 
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT outer JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	
		    -- add by ylq 2015-05-19 
			left join  B_StoreLocation bsll on bsll.nid = isNull(bgs.LocationID,0)    			
			left outer join 
				B_Goods b on b.NID = gs.GoodsID
		    left outer join B_Store sto on b.StoreID = sto.NID 
			left outer join	
			    B_GoodsCats c on c.NID=b.GoodsCategoryID	
			left outer join
				B_Supplier p on p.NID=b.SupplierID		
			left outer join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left outer join #UnPaiDNum up on up.GoodsSKUID = d.GoodsSKUID and d.StoreID=up.StoreID
		    left outer join #WarningCats tmp on tmp.cName = IsNull(d.WarningCats,'')
		    left outer join #StockChange sc on sc.goodsskuid = d.goodsskuid and sc.storeinid = d.storeid
		    left outer join #SkuState tmp1 on tmp1.cName = ISNULL(gs.GoodsSKUStatus,'')
		    left outer join B_DictionaryCats bdc on bdc.CategoryName='库存预警类别'
		    left outer join B_Dictionary  bd on bd.fitcode=d.WarningCats and isnull(bd.fitcode,'')<>'' and bd.CategoryID=bdc.nid		    
			
			WHERE  ((IsNull(b.Used,0)= @TmpUsed1) or (IsNull(b.Used,0) = @TmpUsed2))  
			   and   ((@WarningCats = '') OR  (tmp.cName is Not Null)) -- add by ylq 2015-04-20
			   and   ((@GoodsState = '') OR  (tmp1.cName is Not Null)) -- add by ylq 2015-05-15 
			   AND ((@Purchaser = '') OR (ISNULL(b.Purchaser,'') = @Purchaser) )
				and  (@cg='0' or  (@cg='1' and (d.Number-d.ReservationNum-
						(case when d.KcMinNum>0 then d.KcMinNum else gs.MinNum end)
						+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) 
					and  d.SellCount3>0 ))
				--(d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0)) )  //错的建议采购
				-- add by yq 2015-05-19  增加库位条件
				and ((@LocationName = '') or (ISNULL(bsll.LocationName,'') like '%'+@LocationName+'%'))	
		     ) A
			
			ORDER BY A.sku

-- 特殊状态订单的sku 此处为缺货
select pd.tradenid,pt.ordertime,addressowner,bgs.sku,bgs.goodsskustatus,pd.l_qty as soldnum, row_number() over(partition by bgs.sku order by Pt.ordertime desc) as rank
into #tmpoutsku
from p_tradeun as pt LEFT JOIN P_TradeDtun as pd on pt.nid= pd.TradeNID
left join B_goodssku as bgs on pd.goodsskuid = bgs.nid
LEFT JOIN #SkuState as skustatus on skustatus.cName = bgs.goodsskustatus  -- sku状态过滤
where pt.filterflag=1 -- 缺货订单



-- 按订单时间降序，考察每个订单里的sku不包含自身的历史销售数量
select upsku.sku,upsku.rank, isnull(sum(backsku.soldnum),'0') as total_his 
into #persku_his from #tmpoutsku as upsku 
LEFT JOIN #tmpoutsku as backsku 
on upsku.sku=backsku.sku and upsku.rank>backsku.rank 
group by upsku.sku,upsku.rank
ORDER BY upsku.sku, upsku.rank

SELECT upup.*,backback.total_his into #outsku  from #tmpoutsku as upup 
LEFT JOIN #persku_his as backback 
on upup.sku = backback.sku and upup.rank = backback.rank


-- 根据每个sku的预计可用库存数量，计算每个订单中sku的实际可用库存数量

select osk.tradenid as nid, ckt.sku,(ckt.hopeusenum - osk.total_his-osk.soldnum) as realnum from #KCtemp 
as ckt right JOIN #outsku as osk on ckt.sku=osk.sku
where (ckt.hopeusenum - osk.total_his-osk.soldnum) >=0 -- 只取实际可用数量小于零的订单的sku






-- 删除临时表
	drop table #KCtemp				
   drop table #SkuState
		Drop Table #Store
		Drop Table #Goods
		Drop Table #WarningCats
		drop table #tmpoutsku
		drop table #outsku
		drop table #persku_his
		Drop Table #StockChange
END
