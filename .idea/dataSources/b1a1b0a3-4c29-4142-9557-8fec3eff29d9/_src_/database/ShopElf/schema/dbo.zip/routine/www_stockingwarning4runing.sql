CREATE PROCEDURE [dbo].[www_stockingwarning4runing]
@MoreStoreID varchar(500),
	  @Used		int,
	  @cg		int,
	  @GoodsCatsCode varchar(200),
	  @index varchar(50),
	  @KeyStr varchar(2000),/*关键字*/
	  @WarningCats VARCHAR(1000),
	  @SupplierName varchar(2000),
                  --每页记录数
      @Purchaser VARCHAR(100),   
      @GoodsUsed varchar(32),  --商品停用情况
      @GoodsState  varchar(2000), --商品sku状态
      @LocationName varchar(120) = '',  --库位
      @MoreSKU  varchar(3000)
		
As
BEGIN
	declare
		@BeginDate	varchar(40),              
		@EndDate	Varchar(40), 
		@PageCount int =0,          --输出页数
		@RecCount int=0,            --输出记录数	
		@TmpUsed1 int,
		@TmpUsed2 int,
		@TmpCount int
		set @BeginDate = DATEADD(day, -30, GETDATE())
		set @EndDate = GETDATE()
		if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end
		
		 
		IF (ISNULL(@Purchaser,'') = '')
	    SET @Purchaser = ''
	    
	    -- add by ylq 2015-04-29  库存预警类别表
	    --创建字段列表
    DECLARE @SqlStr VarChar(Max)
    
    Create Table #StoreTab
    (
      Nid int
    )
    
	CREATE TABLE #WarningCats
	(
		cName varchar(100)
	)
	--add by ylq 2015-05-15  商品sku状态
	CREATE TABLE #SkuState
	(
		cName varchar(100)
	)
	
	--add by ylq 2015-08-31
	Create table #TmpSup
	(
	  cName varchar(200)
	) 
	
	--add by ylq 2015-06-17 商品sku
	Create Table #TmpSku
	(
	  Sku varchar(100)
	 )
	 
--	Create Table #TmpKey
--	(  TmpStr varchar(100)	)
	-- create table sku_sold by james 2016-11-24


	-- 30 天利润和销量计算开始

create Table #TmpTradeInfo(
    Nid int not null,                          --订单号
    AllWeight float Null,                      --总重量
    AllQty int Null,                           --总数量
    amt float null,                            --总销售金额
    SHIPPINGAMT float null,                    --买家付运费
    SHIPDISCOUNT float null,                   --ebay交易费
    FeeAmt float null,                         --交易费(pp手续费)
    ExpressFare float null,                    --快递费
    INSURANCEAMOUNT float null,                --包装费
    SKUPACKFEE float null,                     --SKU包装费
    SKU varchar(100) null,                     --SKU
    SKUQty int null,                           --Sku数量
    SKUWeight float null,                      --SKU重量
    SKUCostPrice float null,                   --订单SKU成本价
    SKUamt float null,                         --订单SKU销售金额
    ExchangeRate float null,                   --汇率
    goodsid int null                           --商品ID
  )  
  create Table #TmpSkuFreeInfo(
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --Sku数量
    SaleMoneyRmb float null,                   --SKU 销售金额￥
    ShippingAmtRmb float null,                 --SKU 买家付运费￥
    CostMoneyRmb float null,                   --SKU 销售成本￥
    eBayFeeRmb float null,                     --SKU ebay成交费￥
    PaypalFeeRmb float null,                   --SKU PP手续费￥
    ExpressFareRmb float null,                 --SKU 运费成本￥	
    InPackageFeeRmb float null,                --SKU 包装成本￥
    OutPackageFeeRmb float null,               --SKU 外包装成本￥
  )  
  create Table #TmpSumSkuFreeInfo(
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --销售数量
    SaleMoneyRmb float null,                   --成交价￥
    ShippingAmtRmb float null,                 --买家付运费￥
    CostMoneyRmb float null,                   --销售成本￥
    ProfitRmb float null,                      --实收利润￥
    eBayFeeRmb float null,                     --ebay成交费￥
    PaypalFeeRmb float null,                   --PP手续费￥
    ExpressFareRmb float null,                 --运费成本￥	
    InPackageFeeRmb float null,                  --包装成本￥
    OutPackageFeeRmb float null,               --外包装成本￥
    AverageSaleMoneyRmb float null,            --平均售价￥
    AverageProfitRmb float null                --平均利润价￥
  )  
  
  --查找美元的汇率	
  Declare  @ExchangeRate float  
  set @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode  where CURRENCYCODE='USD'),1) 
  --查找成本计价方法
  Declare @CalcCostFlag int 
  set @CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)
  -- 重寄单数据 不行 重寄单会自动删除
  --select m.OrderNumber as nid into #Tmpchongji from XS_SaleAfterM m 
   --  where m.SaleType='重寄'	
  
  --正常表的数据插入数据库 
  insert into #TmpTradeInfo 
  select m.Nid,                                                                        --订单号
         isnull((select Sum(IsNull(a.Weight,0))   
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))   
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量        
         isnull((select Sum(IsNull(a.l_amt,0))    
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as amt,         --总销售金额  
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end,  --买家付运费 特殊运费
          m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
          m.FeeAmt 
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice 
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice  
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                      --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID     
  FROM  p_tradedt(nolock) d  
  inner join p_trade(nolock) m on m.nid=d.tradenid 
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU 
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID  
  left join B_CurrencyCode c on c.currencycode=m.currencycode 
  where   DATEADD(HH,8,m.ORDERTIME) between @BeginDate and @endDate                                       --SKU	
  

          
 -- 缺货订单也插入数据库
    
  	
  --历史表的数据插入数据库 不用判断发货状态  m.FilterFlag = 10 
  insert into #TmpTradeInfo 
  select m.Nid,                                                                            --订单号
         isnull((select Sum(IsNull(a.Weight,0))   
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))   
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量        
         isnull((select Sum(IsNull(a.l_amt,0))    
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as amt,     --总销售金额  
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end ,  --买家付运费 特殊运费
        m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
         m.FeeAmt 
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0) 
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice 
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice  
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                       --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID     
  FROM  p_tradedt_his(nolock) d  
  inner join p_trade_his(nolock) m on m.nid=d.tradenid 
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU 
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID  
  left join B_CurrencyCode c on c.currencycode=m.currencycode 
  where DATEADD(HH,8,m.ORDERTIME) between @BeginDate and @endDate                                                                  --SKU	
  
 
       
  --更新总重量和总金额,总数量如果是0 那么改成1
  update #TmpTradeInfo set allweight = 1 where ISNULL(allweight,0) = 0 
  update #TmpTradeInfo set amt = 1 where ISNULL(amt,0) = 0 
  update #TmpTradeInfo set AllQty = 1 where ISNULL(AllQty,0) = 0 
  
  --计算金额并插入临时表
  --SKU 销售金额￥    = SKU费用 * 币种汇率
  --SKU 买家付运费￥  = (买家付运费 * 币种汇率) * SKU重量 / 总重量
  --SKU 销售成本￥    = 订单SKU成本价
  --SKU ebay成交费￥  = (ebay交易费 * 美元汇率) * SKU费用 / 总费用
  --SKU PP手续费￥    = (pp手续费 * 币种汇率) * SKU费用 / 总费用
  --SKU 运费成本￥    = 快递费 * SKU重量 / 总重量 
  --SKU 包装成本￥    = (包装费 * 1.0) * SKU数量 / 总数量 + sku包装费 
  insert into #TmpSkuFreeInfo 
  select SKU,                                                    --SKU
         SKUQty ,                                                --Sku数量
         SKUamt * ExchangeRate,                                  --SKU 销售金额￥
         (SHIPPINGAMT * ExchangeRate) * SKUamt/amt ,             --SKU 买家付运费￥
         SKUCostPrice ,                                          --SKU 销售成本￥
         (SHIPDISCOUNT * @ExchangeRate) * SKUamt/amt,            --SKU ebay成交费￥
         (FeeAmt * ExchangeRate) * SKUamt/amt,                   --SKU PP手续费￥
         ExpressFare * SKUWeight / AllWeight,                    --SKU 运费成本￥	
         SKUPACKFEE,                                             --SKU 内包装成本￥
        (INSURANCEAMOUNT * 1.0) * SKUQty / AllQty                --sku 外包装成本
  from #TmpTradeInfo  
  
  --统计金额插入临时表
  --成交价￥       = sum(SKU 销售金额￥ + SKU 买家付运费￥)
  --买家付运费￥   = sum(SKU 买家付运费￥)
  --销售成本￥     = sum(SKU 销售成本￥)
  --实收利润￥     = sum(SKU 销售金额￥ + SKU 买家付运费￥ - SKU 销售成本￥ - SKU ebay成交费￥ 
  --                     - SKU PP手续费￥ - SKU 运费成本￥ - SKU 包装成本￥)
  --ebay成交费￥   = sum(SKU ebay成交费￥)
  --PP手续费￥     = sum(SKU PP手续费￥)
  --运费成本￥     = sum(SKU 运费成本￥)
  --包装成本￥     = sum(SKU 包装成本￥)
  --平均售价￥     = 成交价￥ / sum(Sku数量) 
  --平均利润价￥   = 实收利润￥ / sum(Sku数量) 
  insert into #TmpSumSkuFreeInfo 
  select SKU,                                                  --SKU
         SKUQty,                                               --销售数量
         SaleMoneyRmb,                                         --成交价￥
         ShippingAmtRmb,                                       --买家付运费￥
         CostMoneyRmb,                                         --销售成本￥
         ProfitRmb,                                            --实收利润￥                             
         eBayFeeRmb  ,                                         --ebay成交费￥                    
         PaypalFeeRmb ,                                        --PP手续费￥
         ExpressFareRmb ,                                      --运费成本￥	
         InPackageFeeRmb ,                                     --内包装成本￥ 
         OutPackageFeeRmb ,                                       --外包装成本￥ 
         case when SKUQty = 0 then 0 
              else SaleMoneyRmb/SKUQty end,                    --平均售价￥
         case when SKUQty = 0 then 0 
              else ProfitRmb/SKUQty end                        --平均利润价￥
  from 
  (select SKU,                                                  --SKU
         sum(SKUQty) as SKUQty,                                --数量
         SUM(SaleMoneyRmb + ShippingAmtRmb) as SaleMoneyRmb,   --成交价￥
         SUM(ShippingAmtRmb) as ShippingAmtRmb,                --买家付运费￥
         SUM(CostMoneyRmb) as CostMoneyRmb,                    --销售成本￥
         SUM(SaleMoneyRmb + ShippingAmtRmb - CostMoneyRmb 
             - eBayFeeRmb - PaypalFeeRmb - ExpressFareRmb 
             - InPackageFeeRmb-OutPackageFeeRmb) as ProfitRmb,   --实收利润￥                             
         SUM(eBayFeeRmb) as eBayFeeRmb  ,                      --ebay成交费￥                    
         SUM(PaypalFeeRmb) as PaypalFeeRmb ,                   --PP手续费￥
         SUM(ExpressFareRmb) as ExpressFareRmb ,               --运费成本￥	
         SUM(InPackageFeeRmb) as InPackageFeeRmb,                   --内包装成本￥ 
         SUM(OutPackageFeeRmb) as OutPackageFeeRmb                   --外包装成本￥ 
  from #TmpSkuFreeInfo
  group by SKU) aa
	
  --最后关联统计	
  select 
		isnull(fg.SKU,'') as sku,	
		fg.SKUQty as sold,
		round(fg.ProfitRmb,2) as yield
	into #tempskusold		
	from #TmpSumSkuFreeInfo fg
	left join B_GoodsSKU gs on gs.SKU=fg.sku
	left join B_goods g on gs.GoodsID=g.NID	
	left join B_GoodsCats abgs on abgs.NID=g.GoodsCategoryID 

  -- 30 天利润和销量计算结束



if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
 
	if @GoodsState <> '' 
	begin 
	  SET @SqlStr = 'insert into #SkuState(cName) select ''' + Replace(@GoodsState, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	if @SupplierName <> ''
	begin
	  SET @SqlStr = 'insert into #TmpSup(cName) select ''' + Replace(@SupplierName, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	
	if @WarningCats <> '' 
	begin 
	  SET @SqlStr = 'insert into #WarningCats(cName) select ' + Replace(@WarningCats, ',', ' union select ') 
	  EXEC(@SqlStr) 
	end
	
	if @MoreSKU <> '' 
	begin
	  set @SqlStr = 'insert into #TmpSku(Sku) select ''' + Replace(@MoreSKU, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	if EXISTS (select  cName from  #WarningCats where cName = 'wrNone') 
	begin
      insert into #WarningCats(cName) values ('') 	
	end

	    IF (ISNULL(@WarningCats,'') = '')
	    SET @WarningCats = ''
		/*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int,/*ID*/
			  StoreName Varchar(50)
		)			
		
			
		/*生成商品查询*/
		--set @TmpCount = ( select COUNT(*) from #TmpKey)
		
		--if @TmpCount < 2 begin
		if @index = '0'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsCode like '%'+@KeyStr+'%')
		end
		if @index = '1'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsName like '%'+@KeyStr+'%')
		end
		if @index = '2'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or g.SKU like '%'+@KeyStr+'%' or gs.SKU like '%'+@KeyStr+'%' )
		end
		if @index = '3'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.BarCode like '%'+@KeyStr+'%')
		end
		if @index = '4'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.SalerName like '%'+@KeyStr+'%')
		end
		if @index = '5'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.FitCode like '%'+@KeyStr+'%')
		end	  
			    
		 /*end 
		 else begin    
		   insert into #Goods 
		     select distinct  gs.NID from B_GoodsSKU gs 
			 inner join B_Goods G on g.NID=gs.GoodsID  
			 inner join #TmpKey tmp1 on (G.GoodsName like '%' + tmp1.TmpStr + '%') 
			    or (gs.SKU like '%' + tmp1.TmpStr + '%') 
			    or (G.BarCode like '%' + tmp1.TmpStr + '%') 
			    or (G.SalerName like '%' + tmp1.TmpStr + '%')
			    or (G.FitCode like '%' + tmp1.TmpStr + '%')
			 left join #TmpSku tmp on gs.SKU = tmp.Sku  
			 left join B_Supplier sup on sup.NID = g.SupplierID 	
             where ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))
                and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
		       and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 
			   and ((@MoreSKU = '') or (tmp.Sku is Not Null))  --增加多选条件 
		 end */ 
		 
		 
		 
		 
 		
	    /*采购未入库数*/
	    --已完全入库订单商品
	     create table #InStoreD(StockOrderID int,StoreID int,GoodsSKUID int,Number numeric(18,8))
	     insert into  #InStoreD
	     select 
	       om.NID,
	       m.StoreID,
	       d.GoodsSKUID,
	       sum(d.Amount)
	     from CG_StockInD d
	     join CG_StockInM m on d.StockInNID = m.NID
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM om on m.StockOrder = om.BillNumber
	     where m.CheckFlag = 1
	     group by om.NID,d.GoodsSKUID,m.StoreID
	     --select * from #InStoreD
	     --未入库商品
	     create table #UnInStore(GoodsSKUID int,StoreID int,UnInNum numeric(18,8))
	     insert into #UnInStore(GoodsSKUID,storeid,UnInNum)
	     select 
		    d.GoodsSKUID,
		    m.StoreID,
		    SUM(case when (d.Amount - isnull(id.Number,0)) <= 0 then null else (d.Amount - isnull(id.Number,0)) end )
	     from CG_StockOrderD d
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM m on d.StockOrderNID = m.NID
	     left join #InStoreD id on d.StockOrderNID = id.StockOrderID and d.GoodsSKUID = id.GoodsSKUID and id.StoreID=m.StoreID
	     where 
		     (m.CheckFlag = 1)--审核通过的订单
	     and (m.Archive = 0)--不统计归档订单
	     group by d.GoodsSKUID,m.StoreID
	     --缺货或未派单的记录
	     create table #UnPaiDNum(GoodsSKUID int,UnPaiDNum numeric(10,2),StoreID int)
	     insert into #UnPaiDNum
		SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum, StoreID 	
		FROM (  --未派单的销售商品 和  数量(Trade)
				SELECT ISNULL(gs.NID,0) as GoodsSKUID, 
					SUM(case when pt.RestoreStock=-1 then 0 else ptd.L_QTY end) AS SaleNum,
					ISNULL(ptd.StoreID,0)AS StoreID
				FROM P_TradeDt(nolock) ptd 
				inner join P_trade(nolock) pt on pt.NID=ptd.TradeNID
				inner join B_GoodsSKU gs on gs.SKU=ptd.SKU	   
				inner join #Goods g on gs.nid = g.GoodsSKUID	             
				WHERE pt.FilterFlag <= 5 
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
		UNION all  --异常单的销售商品 和   数量(TradeUn)
			   SELECT 
						ISNULL(gs.NID,0) as GoodsSKUID, 
						SUM(case when pt.RestoreStock=-1 then 0 else ptdu.L_QTY end ) AS SaleNum ,
						ISNULL(ptdu.StoreID,0) AS StoreID
			   FROM P_TradeDtUn(nolock) ptdu 
			   inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID 
			   inner join B_GoodsSKU gs on gs.SKU=ptdu.SKU
			   inner join #Goods g on gs.nid = g.GoodsSKUID		       
			   WHERE pt.FilterFlag = 1                         
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0) 
			 ) AS C
		GROUP BY GoodsSKUID,StoreID	  	
	   
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
		
		--根据selldays更新sellercount  
		declare @AutoCalcSellCount int
		set @AutoCalcSellCount=ISNULL((select top 1 paravalue from b_sysparams where paracode='AutoCalcSellCount'),0)
		if @AutoCalcSellCount=0 
		begin
		  exec P_XS_CalGoodsSKUSellCount
		end
		--查询	
		--查找销售时间范围
		Declare @SellDay1 int=5
		declare @SellDay2 int=15
		declare @SellDay3 int=30  
	        
		select  @SellDay1= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='1' and ISNUMERIC(DictionaryName)=1
		select  @SellDay2= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='2' and ISNUMERIC(DictionaryName)=1
		select  @SellDay3= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='3' and ISNUMERIC(DictionaryName)=1			    
		if @SellDay1=0
		  set @SellDay1=5
		if @SellDay2=0
		  set @SellDay2=15
		if @SellDay3=0
		  set @SellDay3=30    
		
		--在途商品		 
		 SELECT  cd.goodsskuid,sum(cd.amount) as onroadamount,cm.storeid              into #OnRoad 
         FROM CG_StockInD cd  
         inner join CG_StockInM cm on cm.nid=cd.stockinnid
         inner join kc_stocksplitm km on cm.StockSplitNid=km.nid and km.checkflag=1 
         group by cd.goodsskuid,cm.storeid 
         
       --调拨单保存之后的预期入库
       
       select cd.GoodsSKUID,sum(cd.amount) as hopenum,cm.StoreInID                    into #StockChange
       from  KC_StockChangeD cd 
       inner join KC_StockChangeM cm on cm.nid=cd.StockChangenid and cm.checkflag=0
       group by cd.GoodsSKUID,cm.StoreInID 
       
       
          
		
		
	--	IF (@WarningCats <> 'wrNone')	
	--	BEGIN 	
			SELECT 
				@RecCount=count(1)
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	    			
			left join 
				B_Goods b on b.NID = gs.GoodsID	
			left join
				B_Supplier p on p.NID=b.SupplierID		
			left join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left join #WarningCats tmp on tmp.cName = d.WarningCats 
			-- WHERE (@WarningCats = '') OR  (d.WarningCats = @WarningCats)	
			WHERE (@WarningCats = '') OR  (tmp.cName is Not null)	
	-------------------计算记录数和页数
		  
		    
		   				
	
			SELECT
			    0 as SelFlag,
				row_number() OVER(ORDER BY gs.sku ) AS rowid,
				b.season ,-- 季节
				b.purchaser, -- 采购员
				
				gs.SKU, -- SKU
				b.goodscode, -- 商品编码
				b.goodsname, -- 商品名称	
				--b.aliascnname, -- 管理类别
				c.categoryname, --管理类别
				case when d.StockDays=0 then  b.StockDays else d.StockDays end as StockDays, -- 采购到货天数
				case when d.SellDays=0 then b.SellDays else d.SellDays end as sellDays, -- 预警销售天数
				d.SellCount,
				d.SellCount1 as  SellCount1, -- 5天销量
				d.SellCount2 as SellCount2, -- 10 天销量
				d.SellCount3  as SellCount3, -- 20 天销量
				d.Number, -- 库存数量
				d.ReservationNum, -- 保留数量
				d.Number-d.ReservationNum as usenum, -- 占用数量
				d.Price as costprice, -- 库存单价
				d.money as costmoney, -- 库存金额
				--case when (d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0) then 1 else 0  end as purchase,
		       -- ISNULL(b.GoodsStatus,'') AS GoodsStatus,
		     --IsNull(gs.GoodsSKUStatus,'') as GoodsStatus, -- add by ylq 2015-04-15 取的是sku表的状态信息
				case gs.goodsskustatus  when  '停产' then '' else  gs.goodsskustatus  end as  GoodsStatus,
		     b.SalerName as SalerName,
		     b.SalerName2 as SalerName2,
         u.UnInNum as NotInStore	, -- 采购未入库数量
		     goodsPrice=case when gs.CostPrice<>0 then gs.CostPrice else b.CostPrice end,
		     up.UnPaiDNum, -- 缺货未派单数量			
				d.Number-d.ReservationNum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) + isnull(sc.hopenum,0) as hopeUseNum, -- 预计可用库存数量
				
-- 增加预计可用金额
			d.money -d.ReservationNum*d.price + isnull(u.UnInNum,0)*gs.Costprice +  isnull(sc.hopenum,0)* ( case   when d.price > 0 then d.price else gs.costprice end) as hopeUsemoney -- 预计可用库存金额 
			INTO #KCtemp 
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT outer JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	
		    -- add by ylq 2015-05-19 
			left join  B_StoreLocation bsll on bsll.nid = isNull(bgs.LocationID,0)    			
			left outer join 
				B_Goods b on b.NID = gs.GoodsID
		    left outer join B_Store sto on b.StoreID = sto.NID 
			left outer join	
			    B_GoodsCats c on c.NID=b.GoodsCategoryID	
			left outer join
				B_Supplier p on p.NID=b.SupplierID		
			left outer join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left outer join #UnPaiDNum up on up.GoodsSKUID = d.GoodsSKUID and d.StoreID=up.StoreID
		    left outer join #WarningCats tmp on tmp.cName = IsNull(d.WarningCats,'')
		    left outer join #OnRoad onroad on onroad.goodsskuid = d.goodsskuid and onroad.storeid=d.storeid 
		    left outer join #StockChange sc on sc.goodsskuid = d.goodsskuid and sc.storeinid = d.storeid
		    left outer join #SkuState tmp1 on tmp1.cName = ISNULL(gs.GoodsSKUStatus,'')
		    left outer join B_DictionaryCats bdc on bdc.CategoryName='库存预警类别'
		    left outer join B_Dictionary  bd on bd.fitcode=d.WarningCats and isnull(bd.fitcode,'')<>'' and bd.CategoryID=bdc.nid		    
				
			WHERE  ((IsNull(b.Used,0)= @TmpUsed1) or (IsNull(b.Used,0) = @TmpUsed2))  
			   and   ((@WarningCats = '') OR  (tmp.cName is Not Null)) -- add by ylq 2015-04-20
			   and   ((@GoodsState = '') OR  (tmp1.cName is Not Null)) -- add by ylq 2015-05-15 
			   AND ((@Purchaser = '') OR (ISNULL(b.Purchaser,'') = @Purchaser) )
				and  (@cg='0' or  (@cg='1' and (d.Number-d.ReservationNum-
						(case when d.KcMinNum>0 then d.KcMinNum else gs.MinNum end)
						+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) 
					and  d.SellCount3>0 ))
				--(d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0)) )  //错的建议采购
				-- add by yq 2015-05-19  增加库位条件
				and ((@LocationName = '') or (ISNULL(bsll.LocationName,'') like '%'+@LocationName+'%'))	
		     
			
			
				
--select CK.sku,cast(Ck.hopeusenum as int)  hopeusenum,CK.goodsstatus,listed.skucount from #KCtemp as ck LEFT JOIN z_listed_sku_count as listed on ck.sku = listed.sku where isnull(listed.sku,'')!=''
--select max(isnull(k.season,'')) as season, case when max(isnull(k.goodsstatus,''))= '' then '停产' ELSE max(isnull(k.goodsstatus,'')) end as goodsstatus,max(isnull(k.purchaser,'')) as purchaser,k.goodscode,count(isnull(k.sku,0)) as skunum,max(isnull(k.goodsname,'')) as goodsname,max(isnull(k.aliascnname,'')) as aliascnname,sum(isnull(k.sellcount1,0)) as sellcount1,sum(isnull(k.sellcount2,0)) as sellcount2,sum(isnull(k.sellcount3,0)) as sellcount3,  sum(isnull(k.number,0)) as number,sum(isnull(k.costmoney,0)) as costmoney,sum(isnull(k.hopeusemoney,0)) as hopeusemoney,sum(isnull(k.hopeusenum,0))as hopeusenum,sum(isnull(s.sold,0)) as sellcount4,sum(isnull(s.yield,0)) as yield, case when sum(isnull(k.sellcount3,0))=0 then 0 ELSE (sum(isnull(k.hopeusenum,0))*20)/sum(isnull(k.sellcount3,0)) end as turnover  from #KCtemp as k LEFT JOIN #tempskusold as s ON 
--k.sku=s.sku   GROUP BY k.goodscode
select
max(isnull(k.season,'')) as season, 
case when max(isnull(k.goodsstatus,''))= '' then '停产' ELSE max(isnull(k.goodsstatus,'')) end as goodsstatus,
max(isnull(k.purchaser,'')) as purchaser,
k.goodscode as goodscode,
count(isnull(k.sku,0)) as skuNumber,
max(isnull(k.goodsname,'')) as goodsname,
max(isnull(k.categoryname,'')) as categoryname, 
max(isnull(k.StockDays, 0)) as stockdays,
max(isnull(k.selldays,0)) as  selldays, --预警销售天数,
sum(isnull(k.sellcount1,0)) as selllcount5, --近5天销量,
sum(isnull(k.sellcount2,0)) as sellcount10,--近10天销量,
sum(isnull(k.sellcount3,0)) as sellcount20,--近20天销量, 
sum(isnull(k.number,0)) as number, --库存数量,
sum(isnull(k.costmoney,0)) as costmoney, --库存金额 ,
sum(isnull(k.hopeusemoney,0)) as hopeusemoney,--预计可用库存金额,
sum(isnull(k.hopeusenum,0))as hopeusenum, --预计可用库存数量,
sum(isnull(s.sold,0)) as sold30,--近30天销量,
sum(isnull(s.yield,0)) as yield30,--近30天利润, 
case when sum(isnull(k.sellcount3,0))=0 then 0 ELSE (sum(isnull(k.hopeusenum,0))*20)/sum(isnull(k.sellcount3,0)) end as turnoverdays --库存周转天数 
from #KCtemp as k LEFT JOIN #tempskusold as s ON 
k.sku=s.sku   GROUP BY k.goodscode
--select * from #kctemp
	
	drop table #KCtemp				
        drop table #SkuState
		Drop Table #Store
		Drop Table #Goods
		Drop Table #WarningCats
		Drop Table #OnRoad
		Drop Table #StockChange
		
		drop table #tempskusold
		drop table #TmpTradeInfo
	  drop table #TmpSkuFreeInfo	
	  drop table #TmpSumSkuFreeInfo
END