CREATE PROCEDURE [dbo].[www_test]
AS
BEGIN
 select m.addressowner,
							case WHEN m.addressowner='aliexpress'
							THEN 'SMT'
							WHEN m.addressowner='amazon11'
							THEN 'Amazon'
							WHEN m.addressowner='ebay'
							THEN 'eBay'
							WHEN m.addressowner='wish'
							THEN 'Wish'
							WHEN m.addressowner='shopee'
							THEN 'Shopee'
							ELSE '其他平台'
							end as pingtai ,
            isnull(sum(m.ExpressFare),0) as ExpressFare ,
            convert(varchar(10),m.CLOSINGDATE,121) as CLOSINGDATE,
            l.name as wlway,
            CASE WHEN l.name ='4PX海外仓美东'
            THEN '4PX(海外仓)'
            WHEN l.name='4PX海外美东仓'
            THEN '4PX(海外仓)'
            WHEN l.name='DHL'
            THEN '佳成国际快递'
            WHEN l.name='DHL普通小包'
            THEN '德国小包DHL'
            WHEN l.name='EMS'
            THEN '佳成国际快递'
            WHEN l.name='E邮宝'
            THEN '金华E邮宝'
            WHEN l.name='E邮宝线下（常州）'
            THEN '铭志物流'
            WHEN l.name='FBW WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='LWE马来西亚东'
            THEN '利威供应链'
            WHEN l.name='LWE马来西亚西'
            THEN '利威供应链'
            WHEN l.name='LWE新加坡小包'
            THEN '利威供应链'
            WHEN l.name='WISH邮挂号'
            THEN 'wish邮'
            WHEN l.name='wish邮南京'
            THEN '铭志物流'
            WHEN l.name='WISH邮平邮'
            THEN 'wish邮'
            WHEN l.name='国内快递'
            THEN '顺丰快递运费'
            WHEN l.name='佳成专线'
            THEN '佳成国际快递'
            WHEN l.name='捷德宝'
            THEN '捷买送物流'
            WHEN l.name='顺丰俄罗斯小包挂号'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺丰俄罗斯小包平邮'
            THEN '顺丰俄罗斯小包金华'
            WHEN l.name='顺邮宝挂号'
            THEN '顺友物流'
            WHEN l.name='顺邮宝平邮'
            THEN '顺友物流'		
            WHEN l.name='土耳其平邮'
            THEN '捷买送物流'
            WHEN l.name='香港平邮'
            THEN '三态物流'
            WHEN l.name='新加坡挂号'
            THEN '4PX(递四方物流)'
            WHEN l.name='新加坡平邮+'
            THEN '4PX(递四方物流)'
            WHEN l.name='中国邮政挂号小包'
            THEN 'SMT小包平邮+'
            WHEN l.name='中国邮政平常小包+(义乌)'
            THEN 'SMT小包平邮+'
            WHEN l.name='中邮挂号(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮挂号(常熟)'
            THEN '铭志物流'
            WHEN l.name='中邮平邮(北京)'
            THEN '燕文专线快递'
            WHEN l.name='中邮平邮(常熟)'
            THEN '燕文专线快递'
            WHEN l.name='中邮小包平邮义乌'
            THEN '金华邮局小包'
            WHEN l.name='万邑通线上平邮'
            THEN '万邑通'
            ELSE '物流方式找不到物流公司'
            End as wlCompany--物流公司  
            into #Tempfaretable
            FROM P_Trade_His m 
            left outer join B_LogisticWay(nolock) l on l.NID=m.logicsWayNID
            left outer join B_CurrencyCode(nolock) c on c.CURRENCYCODE=m.CURRENCYCODE
            left join B_Country(nolock) bc on bc.CountryCode=m.SHIPTOCOUNTRYCODE 
            WHERE l.name<>''
            AND convert(varchar(10),m.CLOSINGDATE,121) BETWEEN '2016-12-24' AND '2016-12-24'
						
            group by m.addressowner,l.name,convert(varchar(10),m.CLOSINGDATE,121)


select wlCompany as '物流公司',
SUM(eBay) as 'eBay',
SUM(Wish) as 'Wish',
SUM(Amazon) as 'Amazon',
SUM(SMT) as 'SMT',
SUM(Shopee) as 'Shopee' ,
SUM(eBay) + Sum(wish) +SUM(Amazon) + SUM(SMT) + ISNULL(sum(Shopee), 0) as 'Total'
FROM #Tempfaretable
pivot(
		SUM(ExpressFare) for pingtai
in(eBay,Wish,Amazon,SMT,Shopee)
) as newfare
group by wlCompany
order by wlCompany 

drop table #Tempfaretable

END