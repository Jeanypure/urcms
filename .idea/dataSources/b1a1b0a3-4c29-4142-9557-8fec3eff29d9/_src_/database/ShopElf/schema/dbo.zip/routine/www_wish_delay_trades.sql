CREATE PROCEDURE [dbo].[www_wish_delay_trades]
AS
BEGIN

 select row_number() over(ORDER BY ordertime ) as rowid,
DATEADD(HOUR,8,ORDERTIME) as tradetime,trackno as realtrackno,
suffix,
ack,
P_tradeun.nid as nid,
shiptocountrycode as coun,
ordertime,
memo,
AccessToken
from P_tradeun LEFT JOIN S_WishSyncInfo on P_TradeUn.suffix= S_WishSyncInfo.AliasName
where DATEDIFF(day, DATEADD(HOUR,8,ORDERTIME), getdate()) BETWEEN 2 and 2
and isnull(suffix,'') like 'wise%'
AND not EXISTS (SELECT * from z_trackno as t where t.tradenid = P_TradeUn.nid) -- 匹配过的单子不在匹配
and protectioneligibilitytype = '缺货订单' 
--and filterflag=1

--修改2017-01-19:2017-01-19 的临时语句
and isnull(memo,'') not like '%假单号%' -- 空字符串不会执行like



END