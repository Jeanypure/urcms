CREATE PROCEDURE [dbo].[www_wish_join_trades_upload]
AS
BEGIN
  -- 查询已归档订单
select tablename='p_trade_his',t.ordertime,t.nid,t.Suffix,t.shippingmethod,t.logicswaynid,t.trackno,l.CarrierEN , b.transactionid,s.accesstoken into #wish_join_his  from P_trade_b  as b LEFT JOIN 
 P_trade_his as t on b.mergebillid=t.nid LEFT JOIN B_LogisticWayReg as l on t.logicswaynid=l.logisticwaynid and l.platform=t.addressowner LEFT JOIN S_WishSyncInfo as s on t.suffix=s.AliasName
where isnull(t.trackno,'')!='' 
 and t.addressowner ='wish'  
and t.shippingmethod =0 
and t.mergebillid =1
and DATEDIFF(day, DATEADD(HOUR,8,t.ORDERTIME), getdate()) BETWEEN 1  and 5


 -- 查询正常订单
select tablename='p_trade',t.ordertime,t.nid,t.Suffix,t.shippingmethod,t.logicswaynid,t.trackno,l.CarrierEN , b.transactionid,s.accesstoken into #wish_join  from P_trade_b  as b LEFT JOIN 
 P_trade as t on b.mergebillid=t.nid LEFT JOIN B_LogisticWayReg as l on t.logicswaynid=l.logisticwaynid and l.platform=t.addressowner LEFT JOIN S_WishSyncInfo as s on t.suffix=s.AliasName
where isnull(t.trackno,'')!='' 
 and t.addressowner ='wish'  
and t.shippingmethod =0 
and t.mergeflag =1
and DATEDIFF(day, DATEADD(HOUR,8,t.ORDERTIME), getdate()) BETWEEN 1  and 5


-- 查询未处理订单
select tablename='p_tradeun',t.ordertime,t.nid,t.Suffix,t.shippingmethod,t.logicswaynid,t.trackno,l.CarrierEN , b.transactionid,s.accesstoken into #wish_joinun  from P_trade_b  as b LEFT JOIN 
 P_tradeun as t on b.mergebillid=t.nid LEFT JOIN B_LogisticWayReg as l on t.logicswaynid=l.logisticwaynid and l.platform=t.addressowner LEFT JOIN S_WishSyncInfo as s on t.suffix=s.AliasName
where isnull(t.trackno,'')!='' 
 and t.addressowner ='wish'  
and t.shippingmethod =0 
and t.mergeflag =1
and DATEDIFF(day, DATEADD(HOUR,8,t.ORDERTIME), getdate()) BETWEEN 1  and 5


-- 合并查询

select * from #wish_join_his UNION select *  from #wish_join UNION  select *  from #wish_joinun
--SELECT top 2 * from #wish_join


-- 删除临时表
drop table #wish_join_his
drop table #wish_join
drop table #wish_joinun
END