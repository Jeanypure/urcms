CREATE PROCEDURE [dbo].[yy_test]

--2016-09-29 上海幽然[ljj]  销量变化 近1天销量变化  前1天销量变化

    (
  
  @BeginDate DATE ='2017-01-10' ,
	@EndDate DATETIME ='2017-01-20'

    )
AS
begin
SET NOCOUNT ON

  -- 创建临时表用来存储信息
  create Table #TmpTradeInfo(
		suffix VARCHAR(100) not null,                  --卖家简称
    SKU varchar(100) null,                         --SKU
    SKUQty int null                                 --Sku数量
  )

  create Table #TmpSkuFreeInfo(
    suffix varchar(100) not null,
    SKU varchar(100)  null,                    --SKU
    SKUQty int null                           --Sku数量

  )
  create Table #TmpSumSkuFreeInfo(
    suffix varchar(100) not null,
    SKU varchar(100)  null,                    --SKU
    SKUQty int null                           --销售数量 ----------i want

  )

  --正常表的数据插入数据库
  insert into #TmpTradeInfo
  select
 m.SUFFIX,
         d.sku,                                                                        --SKU
         d.l_qty                                                                      --SKU数量

  FROM  p_tradedt(nolock) d
  inner join p_trade(nolock) m on m.nid=d.tradenid

  where
			DATEADD(HH,8,m.ORDERTIME) between @BeginDate and @endDate                                       --SKU

 -- 缺货订单也插入数据库
   insert into #TmpTradeInfo
  select
m.suffix,
         d.sku,                                                                        --SKU
         d.l_qty                                                                     --SKU数量
  FROM  p_tradedtun(nolock) d
  inner join p_tradeun(nolock) m on m.nid=d.tradenid
 
  where
    DATEADD(HH,8,m.ORDERTIME) between @BeginDate and @endDate                                     --SKU
  
and m.PROTECTIONELIGIBILITYTYPE = '缺货订单'

  --历史表的数据插入数据库 不用判断发货状态  m.FilterFlag = 10
  insert into #TmpTradeInfo
  select
m.suffix,
         d.sku,                                                                        --SKU
         d.l_qty                                                                     --SKU数量
  FROM  p_tradedt_his(nolock) d
  inner join p_trade_his(nolock) m on m.nid=d.tradenid
  
  where
			 DATEADD(HH,8,m.ORDERTIME) between @BeginDate and @endDate                                                                  --SKU



  insert into #TmpSkuFreeInfo
  select
   suffix, --卖家简称
		SKU,                                                    --SKU
		SKUQty                                                --Sku数量

  from #TmpTradeInfo

	--select * from #TmpSkuFreeInfo --这个临时表也是正常的
--统计金额插入临时表


end
DROP table #TmpSkuFreeInfo

