CREATE PROCEDURE [dbo].[z_P_piliangkandeng]
 @BeginCreateDate DATE,
 @EndCreateDate date,
 @SalerName1 VARCHAR(100),
 @SalerName2 varchar(100),
 @parentcode varchar(50),
 @childcode varchar(50)

AS
BEGIN
SET nocount ON
declare @saler1 varchar(max)
declare @saler2 varchar(max)
if @SalerName1=''
BEGIN
set @saler1='%%'
end
else 
BEGIN
set @saler1= @SalerName1 + '%'
END
if @SalerName2=''
BEGIN
set @saler2='%%'
end
else 
BEGIN
set @saler2= @SalerName2 + '%'
END
DECLARE @categorycode VARCHAR(100)
if @parentcode=''
BEGIN
set @categorycode='%%'
END
ELSE
BEGIN
set @categorycode = '0|' + @parentcode + '|' + @childcode + '%'
END


SELECT  
bg.GoodsCode as goodscode,
bgs.SKU as sku,
bgs.RetailPrice as price,
bgs.remark as Remark,
bgs.BmpFileName as filename,
bg.categorycode as cat,
bg.salername as salername,
bg.salername2 as salername2,
case isnull(bgs.property1,'') 
WHEN '白色' THEN 'white'
WHEN '米色' THEN 'beige'
WHEN '黑色' THEN 'black'
WHEN '蓝色' THEN 'blue'
WHEN '酒红色' THEN 'Burgundy'
WHEN '褐色' THEN 'brown'
WHEN '深灰色' THEN 'dark grey'
WHEN '金色' THEN 'gold'
WHEN '灰色' THEN 'gray'
WHEN '褐' THEN 'brown'
WHEN '蓝' THEN 'blue'
WHEN '黑' THEN 'black'
WHEN '米' THEN 'beige'
WHEN '军绿' THEN 'army green'
WHEN '黄色' THEN 'yellow'
WHEN '天蓝色' THEN 'sky blue'
WHEN '银色' THEN 'silver'
WHEN '红色' THEN 'red'
WHEN '紫色' THEN 'purple'
WHEN '粉色' THEN 'pink'
WHEN '橙色' THEN 'orange'
WHEN '紫罗兰' THEN 'lavender'
WHEN '卡其色' THEN 'khaki'
WHEN '象牙白' THEN 'ivory'
WHEN '绿色' THEN 'green'
WHEN '橘红' THEN 'orange'
WHEN '玫红色' THEN 'rosy'
WHEN '玫红' THEN 'rosy'
WHEN '黄' THEN 'yellow'
WHEN '白' THEN 'white'
WHEN '天蓝' THEN 'sky Blue'
WHEN '银' THEN 'silver'
WHEN '红' THEN 'red'
WHEN '紫' THEN 'purple'
WHEN '粉' THEN 'pink'
WHEN '粉红色' THEN 'pink'
WHEN '粉色' THEN 'pink'
WHEN '橙' THEN 'orange'
WHEN '紫罗' THEN 'lavender'
WHEN '深灰' THEN 'dark Grey'
WHEN '金' THEN 'gold'
WHEN '灰' THEN 'gray'
WHEN '绿' THEN 'green'
WHEN '象牙' THEN 'ivory'
WHEN '卡其' THEN 'khaki'
ELSE isnull(bgs.property1,'') END  
as property1 ,
bgs.property2,
 isnull(bgc.CategoryName,'') as  'CategoryName',--管理类别
		CASE isnull(bgc.CategoryName,'')
		WHEN '女人世界' THEN '女人世界'
		WHEN '男人海洋' THEN '男人海洋'
    WHEN '饰品配件' THEN '饰品配件'
		WHEN '电子' THEN '电子' 
		WHEN '家居' THEN '家居' 
		WHEN '母婴' THEN '母婴' 		 
    WHEN '户外'THEN '户外'  
    WHEN '穿戴'THEN '穿戴' 
		WHEN '古装'THEN '古装'
		WHEN '耗材'THEN '耗材'
		WHEN '海外仓'THEN '海外仓'
		WHEN '已删除'THEN '已删除'   
		ELSE
		isnull(bgc.CategoryParentName,'') END as  'CategoryParentName'--父类别
INTO #tempInfoTable
from B_goods bg 
LEFT JOIN B_GoodsSKU bgs ON  bg.NID=bgs.GoodsID
LEFT JOIN  B_GoodsCats bgc on bgc.NID=bg.GoodsCategoryID 
WHERE bg.CreateDate BETWEEN  @BeginCreateDate AND @EndCreateDate 

if @SalerName1<>'' OR @SalerName2<>''
BEGIN
SELECT  --salername,salername2,GoodsCode
distinct GoodsCode
from #tempInfoTable  
where cat like @categorycode 
AND (salername LIKE @SalerName1)
AND (salername2 LIKE @SalerName2)
END
ELSE 
BEGIN
SELECT --salername,salername2,GoodsCode,cat,CategoryParentName
distinct GoodsCode,
cat
from #tempInfoTable  
where cat like @categorycode 
AND salername<>'陈鑫'
--and (salername like '%尚显贝%' or salername LIKE '%宋现中%' or salername LIKE '%陈海月%'or salername LIKE '%吴琼%'or salername LIKE '%杨淑琳%' or salername LIKE '%杨曼曼%') --@saler1 
--and(salername2 like '%尚显贝%' or salername2 LIKE '%宋现中%' or salername2 LIKE '%陈海月%'or salername2 LIKE '%吴琼%'or salername2 LIKE '%杨淑琳%'or salername2 LIKE '%杨曼曼%') --@saler2 
END

/*
SELECT 
DISTINCT GoodsCode,cat
FROM #tempInfoTable
where cat LIKE @categorycode
*/


DROP TABLE #tempInfoTable
END
