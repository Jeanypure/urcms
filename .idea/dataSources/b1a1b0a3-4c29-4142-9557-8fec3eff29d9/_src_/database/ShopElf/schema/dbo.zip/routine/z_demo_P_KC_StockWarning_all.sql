CREATE PROCEDURE [dbo].[z_demo_P_KC_StockWarning_all]

	  @MoreStoreID varchar(500),
	  @Used		int,
	  @cg		int,
	  @GoodsCatsCode varchar(200),
	  @index varchar(50),
	  @KeyStr varchar(2000),/*关键字*/
	  @WarningCats VARCHAR(1000),
	  @SupplierName varchar(2000),
      @PageNum int = 100,             --每页记录数
      @PageIndex int = 1,             --页码
      @Purchaser VARCHAR(100),   
      @GoodsUsed varchar(32),  --商品停用情况
      @GoodsState  varchar(2000), --商品sku状态
      @LocationName varchar(120) = '',  --库位
      @MoreSKU  varchar(3000)
As
BEGIN
	declare
		@PageCount int =0,          --输出页数
		@RecCount int=0,            --输出记录数	
		@TmpUsed1 int,
		@TmpUsed2 int,
		@TmpCount int
		
		if (@GoodsUsed = '0') begin   --全部
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 1
		end
		if (@GoodsUsed = '1') begin   --只查在售
		  set @TmpUsed1 = 0
		  set @TmpUsed2 = 0
		end
		if (@GoodsUsed = '2') begin  --只查停售
		  set @TmpUsed1 = 1
		  set @TmpUsed2 = 1
		end
		
		 
		IF (ISNULL(@Purchaser,'') = '')
	    SET @Purchaser = ''
	    
	    -- add by ylq 2015-04-29  库存预警类别表
	    --创建字段列表
    DECLARE @SqlStr VarChar(Max)
    
    Create Table #StoreTab
    (
      Nid int
    )
    
	CREATE TABLE #WarningCats
	(
		cName varchar(100)
	)
	--add by ylq 2015-05-15  商品sku状态
	CREATE TABLE #SkuState
	(
		cName varchar(100)
	)
	
	--add by ylq 2015-08-31
	Create table #TmpSup
	(
	  cName varchar(200)
	) 
	
	--add by ylq 2015-06-17 商品sku
	Create Table #TmpSku
	(
	  Sku varchar(100)
	 )
	 
--	Create Table #TmpKey
--	(  TmpStr varchar(100)	)
	
	 
	if @MoreStoreID <> '' 
	begin
	  SET @SqlStr = 'insert into #StoreTab(Nid) select ' + Replace(@MoreStoreID, ',', ' union select ')
	  EXEC(@SqlStr)
	end 
 
	if @GoodsState <> '' 
	begin 
	  SET @SqlStr = 'insert into #SkuState(cName) select ''' + Replace(@GoodsState, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	if @SupplierName <> ''
	begin
	  SET @SqlStr = 'insert into #TmpSup(cName) select ''' + Replace(@SupplierName, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	
	if @WarningCats <> '' 
	begin 
	  SET @SqlStr = 'insert into #WarningCats(cName) select ' + Replace(@WarningCats, ',', ' union select ') 
	  EXEC(@SqlStr) 
	end
	
	if @MoreSKU <> '' 
	begin
	  set @SqlStr = 'insert into #TmpSku(Sku) select ''' + Replace(@MoreSKU, ',', ''' union select ''')+ ''''
	  EXEC(@SqlStr)
	end
	
	/* if @KeyStr <> ''
    begin
      --set @SqlStr = ' insert into #TmpKey select ''' + REPLACE(@KeyStr,',', '''union select ''') + ''''
      --Exec(@SqlStr) 
      
      if @index = '0'
      set @KeyStr='and G.goodsCode like ''%'+@KeyStr+'%'' '
       if @index = '1'
      set @KeyStr='and G.goodsName like ''%'+@KeyStr+'%'' '
       if @index = '2'
      set @KeyStr='and G.SKU like ''%'+@KeyStr+'%'' '
       if @index = '3'
      set @KeyStr='and G.BarCode like ''%'+@KeyStr+'%'' '
       if @index = '4'
      set @KeyStr='and G.SalerName like ''%'+@KeyStr+'%'' ' 
      if @index = '5'
      set @KeyStr='and G.FitCode like ''%'+@KeyStr+'%'' '     
    end */
	
	-- 因为如果是wrNone,也包含空的值
	if EXISTS (select  cName from  #WarningCats where cName = 'wrNone') 
	begin
      insert into #WarningCats(cName) values ('') 	
	end

	    IF (ISNULL(@WarningCats,'') = '')
	    SET @WarningCats = ''
		/*生成商品表结构*/
		Create Table  #Goods
		(
			  GoodsSKUID Int/*ID*/
		)	
		/*生成仓库表结构*/
		Create Table  #Store
		(
			  StoreID Int,/*ID*/
			  StoreName Varchar(50)
		)			
		
			
		/*生成商品查询*/
		--set @TmpCount = ( select COUNT(*) from #TmpKey)
		
		--if @TmpCount < 2 begin
		if @index = '0'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsCode like '%'+@KeyStr+'%')
		end
		if @index = '1'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.goodsName like '%'+@KeyStr+'%')
		end
		if @index = '2'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or g.SKU like '%'+@KeyStr+'%' or gs.SKU like '%'+@KeyStr+'%' )
		end
		if @index = '3'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.BarCode like '%'+@KeyStr+'%')
		end
		if @index = '4'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.SalerName like '%'+@KeyStr+'%')
		end
		if @index = '5'
		begin 
			insert into #Goods 
			select  gs.NID from B_GoodsSKU gs 
				inner join B_Goods G on g.NID=gs.GoodsID  
				left join #TmpSku tmp on gs.SKU = tmp.Sku 
				left join B_Supplier sup on sup.NID = g.SupplierID 	
			where 
			  ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))			 
			  and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
			  and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 					
			  and ((@MoreSKU = '') or (tmp.Sku is Not Null))
			  and (@KeyStr='' or G.FitCode like '%'+@KeyStr+'%')
		end	  
			    
		 /*end 
		 else begin    
		   insert into #Goods 
		     select distinct  gs.NID from B_GoodsSKU gs 
			 inner join B_Goods G on g.NID=gs.GoodsID  
			 inner join #TmpKey tmp1 on (G.GoodsName like '%' + tmp1.TmpStr + '%') 
			    or (gs.SKU like '%' + tmp1.TmpStr + '%') 
			    or (G.BarCode like '%' + tmp1.TmpStr + '%') 
			    or (G.SalerName like '%' + tmp1.TmpStr + '%')
			    or (G.FitCode like '%' + tmp1.TmpStr + '%')
			 left join #TmpSku tmp on gs.SKU = tmp.Sku  
			 left join B_Supplier sup on sup.NID = g.SupplierID 	
             where ((IsNull(g.Used,0)= @TmpUsed1) or (IsNull(g.Used,0) = @TmpUsed2))
                and (@SupplierName = '' 
			       or isnull(sup.SupplierName,'') like '%' + @SupplierName + '%'
			       or isnull(sup.SupplierName,'') in (select cName from #TmpSup))
		       and (@GoodsCatsCode='' or G.CategoryCode like @GoodsCatsCode+'%') 
			   and ((@MoreSKU = '') or (tmp.Sku is Not Null))  --增加多选条件 
		 end */ 
		 
		 
		 
		 
 		
	    /*采购未入库数*/
	    --已完全入库订单商品
	     create table #InStoreD(StockOrderID int,StoreID int,GoodsSKUID int,Number numeric(18,8))
	     insert into  #InStoreD
	     select 
	       om.NID,
	       m.StoreID,
	       d.GoodsSKUID,
	       sum(d.Amount)
	     from CG_StockInD d
	     join CG_StockInM m on d.StockInNID = m.NID
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM om on m.StockOrder = om.BillNumber
	     where m.CheckFlag = 1
	     group by om.NID,d.GoodsSKUID,m.StoreID
	     --select * from #InStoreD
	     --未入库商品
	     create table #UnInStore(GoodsSKUID int,StoreID int,UnInNum numeric(18,8))
	     insert into #UnInStore(GoodsSKUID,storeid,UnInNum)
	     select 
		    d.GoodsSKUID,
		    m.StoreID,
		    SUM(case when (d.Amount - isnull(id.Number,0)) <= 0 then null else (d.Amount - isnull(id.Number,0)) end )
	     from CG_StockOrderD d
	     join #Goods g on d.GoodsSKUID = g.GoodsSKUID
	     left join CG_StockOrderM m on d.StockOrderNID = m.NID
	     left join #InStoreD id on d.StockOrderNID = id.StockOrderID and d.GoodsSKUID = id.GoodsSKUID and id.StoreID=m.StoreID
	     where 
		     (m.CheckFlag = 1)--审核通过的订单
	     and (m.Archive = 0)--不统计归档订单
	     group by d.GoodsSKUID,m.StoreID
	     --缺货或未派单的记录
	     create table #UnPaiDNum(GoodsSKUID int,UnPaiDNum numeric(10,2),StoreID int)
	     insert into #UnPaiDNum
		SELECT GoodsSKUID, SUM(SaleNum) AS SaleNum, StoreID 	
		FROM (  --未派单的销售商品 和  数量(Trade)
				SELECT ISNULL(gs.NID,0) as GoodsSKUID, 
					SUM(case when pt.RestoreStock=-1 then 0 else ptd.L_QTY end) AS SaleNum,
					ISNULL(ptd.StoreID,0)AS StoreID
				FROM P_TradeDt(nolock) ptd 
				inner join P_trade(nolock) pt on pt.NID=ptd.TradeNID
				inner join B_GoodsSKU gs on gs.SKU=ptd.SKU	   
				inner join #Goods g on gs.nid = g.GoodsSKUID	             
				WHERE pt.FilterFlag <= 5 
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptd.StoreID,0) 
		UNION all  --异常单的销售商品 和   数量(TradeUn)
			   SELECT 
						ISNULL(gs.NID,0) as GoodsSKUID, 
						SUM(case when pt.RestoreStock=-1 then 0 else ptdu.L_QTY end ) AS SaleNum ,
						ISNULL(ptdu.StoreID,0) AS StoreID
			   FROM P_TradeDtUn(nolock) ptdu 
			   inner join P_TradeUn(nolock) pt on pt.NID=ptdu.TradeNID 
			   inner join B_GoodsSKU gs on gs.SKU=ptdu.SKU
			   inner join #Goods g on gs.nid = g.GoodsSKUID		       
			   WHERE pt.FilterFlag = 1                         
			   GROUP BY ISNULL(gs.NID,0),ISNULL(ptdu.StoreID,0) 
			 ) AS C
		GROUP BY GoodsSKUID,StoreID	  	
	   
		/*生成仓库查询*/
		if @MoreStoreID = '' begin
		  insert into #store select  nid,StoreName from B_store   --where	(@StoreID=0 or nid= @StoreID)	
		end
		else begin
		  insert into #store select A.Nid, A.StoreName from B_store A
		       inner join  #StoreTab B on A.NID = B.Nid 
		end
		
		--根据selldays更新sellercount  
		declare @AutoCalcSellCount int
		set @AutoCalcSellCount=ISNULL((select top 1 paravalue from b_sysparams where paracode='AutoCalcSellCount'),0)
		if @AutoCalcSellCount=0 
		begin
		  exec P_XS_CalGoodsSKUSellCount
		end
		--查询	
		--查找销售时间范围
		Declare @SellDay1 int=5
		declare @SellDay2 int=15
		declare @SellDay3 int=30  
	        
		select  @SellDay1= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='1' and ISNUMERIC(DictionaryName)=1
		select  @SellDay2= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='2' and ISNUMERIC(DictionaryName)=1
		select  @SellDay3= cast(isnull(DictionaryName,0) as int) from B_Dictionary 
		where CategoryID in (select NID from B_DictionaryCats where CategoryName='库存预警销量天数')
				and FitCode='3' and ISNUMERIC(DictionaryName)=1			    
		if @SellDay1=0
		  set @SellDay1=5
		if @SellDay2=0
		  set @SellDay2=15
		if @SellDay3=0
		  set @SellDay3=30    
		
		--在途商品		 
		 SELECT  cd.goodsskuid,sum(cd.amount) as onroadamount,cm.storeid              into #OnRoad 
         FROM CG_StockInD cd  
         inner join CG_StockInM cm on cm.nid=cd.stockinnid
         inner join kc_stocksplitm km on cm.StockSplitNid=km.nid and km.checkflag=1 
         group by cd.goodsskuid,cm.storeid 
         
       --调拨单保存之后的预期入库
       
       select cd.GoodsSKUID,sum(cd.amount) as hopenum,cm.StoreInID                    into #StockChange
       from  KC_StockChangeD cd 
       inner join KC_StockChangeM cm on cm.nid=cd.StockChangenid and cm.checkflag=0
       group by cd.GoodsSKUID,cm.StoreInID 
       
       
          
		
		
	--	IF (@WarningCats <> 'wrNone')	
	--	BEGIN 	
			SELECT 
				@RecCount=count(1)
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	    			
			left join 
				B_Goods b on b.NID = gs.GoodsID	
			left join
				B_Supplier p on p.NID=b.SupplierID		
			left join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left join #WarningCats tmp on tmp.cName = d.WarningCats 
			-- WHERE (@WarningCats = '') OR  (d.WarningCats = @WarningCats)	
			WHERE (@WarningCats = '') OR  (tmp.cName is Not null)	

	-------------------计算记录数和页数
		   if @RecCount % @PageNum = 0
		   begin
			  set @PageCount = @RecCount/@PageNum
		   end
		   else
		   begin
			  set @PageCount = @RecCount/@PageNum+1
		   end		
		    
		   				
		 SELECT * INTO #KCtemp FROM  --TOP (@PageNum) 
			(SELECT
			     0 as SelFlag,
				 row_number() OVER(ORDER BY gs.sku ) AS rowid,
				@PageCount as fpagecount,
				@RecCount as RecCount,
				gs.SKU ,--as SKU
				gs.property1 ,
				gs.property2,
				gs.property3,
				b.BarCode,
				b.goodscode,
				b.goodsname,
				b.LinkUrl,
				b.LinkUrl2,
				b.LinkUrl3,				
				b.MinPrice,
				b.model,
				b.unit,
				b.class,
				case when d.KcMaxNum=0 then gs.maxnum else d.KcMaxNum end as maxnum,
				case when d.KcMinNum=0 then gs.minnum else d.KcMinNum end as minnum,
				d.SellCount,
				d.SellCount1 as  SellCount1,
				d.SellCount2 as SellCount2,
				d.SellCount3  as SellCount3,
				case when d.SellDays=0 then b.SellDays else d.SellDays end as sellDays,
				case 
				when d.SellCount=0 then 0 --没有销售的，直接为 0 
				else 
				cast((d.Number-d.ReservationNum)/
					(case when d.SellCount =0 then 1 else d.SellCount end)
					*
					(case when isnull(b.sellDays,0) <=0  then 1 else b.sellDays end) 
				as dec(12,2)) --保留2位小数
				end 
				as CanSellDay, --可卖天数,要考虑除数为0的情况 可用库存/一定时间内平均每天销售数＝可卖天数
				
				b.SupplierID,
				b.PackageCount,
				onroad.onroadamount,
				p.SupplierName,
				s.storeName,
				d.StoreID,
				d.GoodsID,
				d.GoodsSKUID,
				d.Number,
				d.ReservationNum,
				d.Number-d.ReservationNum as usenum,
				d.Price as costprice,
				d.money as costmoney,
				--case when (d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0) then 1 else 0  end as purchase,
				case when (d.Number-d.ReservationNum-
						(case when d.KcMinNum>0 then d.KcMinNum else gs.MinNum end)
						+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) 
					and (gs.SellCount3>0 OR d.SellCount3>0) then 1 else 0  end as purchase,				
				(SELECT TOP 1 bsl.LocationName
				   FROM B_StoreLocation bsl WHERE bsl.nid = isNull(bgs.LocationID,0) ) AS LocationName,
				d.OutCode,
				bd.DictionaryName as WarningCats,   --d.WarningCats
		       -- ISNULL(b.GoodsStatus,'') AS GoodsStatus,
		        IsNull(gs.GoodsSKUStatus,'') as GoodsStatus, -- add by ylq 2015-04-15 取的是sku表的状态信息
		        b.SalerName as SalerName,
		        b.SalerName2 as SalerName2,
                u.UnInNum as NotInStore	,
		        b.Purchaser,
		        case when d.StockDays=0 then  b.StockDays else d.StockDays end as StockDays,
		        goodsPrice=case when gs.CostPrice<>0 then gs.CostPrice else b.CostPrice end,
		        up.UnPaiDNum,
		        --库存上限-可用库存+库存下限+缺货及未派单数量 30天销量不在加入判断条件
		  --     case when gs.MaxNum-(d.Number-d.ReservationNum)+gs.minnum-isnull(u.UnInNum,0)+ISNULL(up.UnPaiDNum,0)<0 then  0 else
				--gs.MaxNum-(d.Number-d.ReservationNum)+gs.minnum-isnull(u.UnInNum,0)+ISNULL(up.UnPaiDNum,0)	end as SuggestNum,
		       case when 
					(case when d.KcMaxNum>0 then d.KcMaxNum else gs.MaxNum end)
					-(d.Number-d.ReservationNum)+
					(case when d.KcMinNum>0 then d.KcMinNum else gs.MinNum end)
					-isnull(u.UnInNum,0)+ISNULL(up.UnPaiDNum,0)<0 then  0 
					else
					(case when d.KcMaxNum>0 then d.KcMaxNum else gs.MaxNum end)
					-(d.Number-d.ReservationNum)+
					(case when d.KcMinNum>0 then d.KcMinNum else gs.MinNum end)
					-isnull(u.UnInNum,0)+ISNULL(up.UnPaiDNum,0)	end 
				as SuggestNum,				
				round((
					d.SellCount1/(@SellDay1*1.00) + 
					d.SellCount2/(@SellDay2*1.00) + 
					d.SellCount3/(@SellDay3*1.00))/3.00,2) as DayNum,
				d.Number-d.ReservationNum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) + isnull(sc.hopenum,0) as hopeUseNum,
				c.CategoryName,
				-- 增加产品创建时间 2015.1.14 ylq
				b.CreateDate, 
				--增加默认发货仓库
				sto.StoreName as DefStoreName,
				-- 库存成本金额  2015-06-30
				D.Number * case when IsNull(gs.CostPrice,0) <> 0 then gs.CostPrice else
				    IsNull(b.CostPrice,0) end  as GoodsCostMoney,
				--sku名称   add ylq 2015-07-21
				gs.SKUName,
				gs.ChangeStatusTime,
				b.StockMinAmount,
				--add 增加货号,重量 2015.12.03 ylq 
				gs.ModelNum,
				case when ISNULL(gs.Weight,0) = 0 then ISNULL(b.Weight,0) else ISNULL(gs.Weight,0) end as [Weight],
				-- add by ylq 2016-03-23  加最长采购缺货天数
				 isnull((select max(DATEDIFF(DAY,Dateadd(hour,8,bb.ORDERTIME), GETDATE())) 
					from P_TradeDtUn(nolock) aa left join P_TradeUn(nolock) bb on aa.TradeNID = bb.NID  
					where bb.FilterFlag = 1 and aa.SKU=gs.SKU),0) as MaxDelayDays      
			From 
				KC_CurrentStock(nolock)  D
			inner join 
				#Store s on s.StoreID = d.StoreID				
			inner join 
				#Goods g on g.GoodsSKUID = d.GoodsSKUID	
			
			left outer join 
				B_GoodsSKU gs on gs.NID = d.GoodsSKUID	
			LEFT outer JOIN 
				B_GoodsSKULocation bgs ON gs.NID = bgs.GoodsSKUID	AND isNull(bgs.StoreID,0) = isNull(d.StoreID,0)	
		    -- add by ylq 2015-05-19 
			left join  B_StoreLocation bsll on bsll.nid = isNull(bgs.LocationID,0)    			
			left outer join 
				B_Goods b on b.NID = gs.GoodsID
		    left outer join B_Store sto on b.StoreID = sto.NID 
			left outer join	
			    B_GoodsCats c on c.NID=b.GoodsCategoryID	
			left outer join
				B_Supplier p on p.NID=b.SupplierID		
			left outer join #UnInStore u on d.GoodsSKUID = u.GoodsSKUID and d.StoreID=u.StoreID
			left outer join #UnPaiDNum up on up.GoodsSKUID = d.GoodsSKUID and d.StoreID=up.StoreID
		    left outer join #WarningCats tmp on tmp.cName = IsNull(d.WarningCats,'')
		    left outer join #OnRoad onroad on onroad.goodsskuid = d.goodsskuid and onroad.storeid=d.storeid 
		    left outer join #StockChange sc on sc.goodsskuid = d.goodsskuid and sc.storeinid = d.storeid
		    left outer join #SkuState tmp1 on tmp1.cName = ISNULL(gs.GoodsSKUStatus,'')
		    left outer join B_DictionaryCats bdc on bdc.CategoryName='库存预警类别'
		    left outer join B_Dictionary  bd on bd.fitcode=d.WarningCats and isnull(bd.fitcode,'')<>'' and bd.CategoryID=bdc.nid		    
			
			WHERE  ((IsNull(b.Used,0)= @TmpUsed1) or (IsNull(b.Used,0) = @TmpUsed2))  
			   and   ((@WarningCats = '') OR  (tmp.cName is Not Null)) -- add by ylq 2015-04-20
			   and   ((@GoodsState = '') OR  (tmp1.cName is Not Null)) -- add by ylq 2015-05-15 
			   AND ((@Purchaser = '') OR (ISNULL(b.Purchaser,'') = @Purchaser) )
				and  (@cg='0' or  (@cg='1' and (d.Number-d.ReservationNum-gs.minnum+isnull(u.UnInNum,0)-ISNULL(up.UnPaiDNum,0) <=0) and (gs.SellCount3>0)) )
				-- add by yq 2015-05-19  增加库位条件
				and ((@LocationName = '') or (ISNULL(bsll.LocationName,'') like '%'+@LocationName+'%'))	
		     ) A
			WHERE  rowid > (@PageNum*(@PageIndex-1))
			ORDER BY A.sku
		
		
	select * from #KCtemp
	 


	drop table #KCtemp				
        drop table #SkuState
		Drop Table #Store
		Drop Table #Goods
		Drop Table #WarningCats
		Drop Table #OnRoad
		Drop Table #StockChange
END
