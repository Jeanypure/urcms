CREATE PROCEDURE [dbo].[z_demo_cate_sum]
(
	@SalerName VARCHAR(50),               --业绩归属人1
  @chanel VARCHAR(50),                 --销售渠道
 @CategoryName VARCHAR(50),            --管理类别
 @CategoryParentName VARCHAR(50)        --父类别
)
AS
BEGIN
SET NOCOUNT ON

CREATE TABLE #yi(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #er(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #san(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #si(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #wu(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #liu(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #qi(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #ba(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #jiu(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

CREATE TABLE #shi(
CategoryName VARCHAR(50),
CategoryParentname VARCHAR(50),
SaleMoneyRmb FLOAT null,
ProfitRmb FLOAT null
)

INSERT INTO #yi EXEC z_demo_cate_demodemo '2016-01-01','2016-01-31',@SalerName,@chanel --这个是1月份的
--SELECT * from #yi
INSERT INTO #er EXEC z_demo_cate_demodemo '2016-02-01','2016-02-29',@SalerName,@chanel --这个是2月份的
INSERT INTO #san EXEC z_demo_cate_demodemo '2016-03-01','2016-03-31',@SalerName,@chanel --这个是3月份的
INSERT INTO #si EXEC z_demo_cate_demodemo '2016-04-01','2016-04-30',@SalerName,@chanel --这个是4月份的
INSERT INTO #wu EXEC z_demo_cate_demodemo '2016-05-01','2016-05-31',@SalerName,@chanel --这个是5月份的
INSERT INTO #liu EXEC z_demo_cate_demodemo '2016-06-01','2016-06-30',@SalerName,@chanel --这个是6月份的
INSERT INTO #qi EXEC z_demo_cate_demodemo '2016-07-01','2016-07-31',@SalerName,@chanel --这个是7月份的
INSERT INTO #ba EXEC z_demo_cate_demodemo '2016-08-01','2016-08-31',@SalerName,@chanel --这个是8月份的
INSERT INTO #jiu EXEC z_demo_cate_demodemo '2016-09-01','2016-09-30',@SalerName,@chanel --这个是9月份的

DECLARE @Endshiy DATETIME;
set @Endshiy =	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,0,GETDATE()) AS DATE) AS DATETIME))))--近1天 的结束时间 
INSERT INTO #shi EXEC z_demo_cate_demodemo '2016-10-01',@Endshiy,@SalerName,@chanel --这个是10月份的 结束时间是近天的

CREATE TABLE #AllInfoTempbiao(
CategoryName VARCHAR(50) ,
CategoryParentname VARCHAR(50) ,
yiSaleMoneyRmb INT,
yiProfitRmb INT,
erSaleMoneyRmb INT,
erProfitRmb INT,
sanSaleMoneyRmb INT,
sanProfitRmb INT,
siSaleMoneyRmb INT,
siProfitRmb INT,
wuSaleMoneyRmb INT,
wuProfitRmb INT,
liuSaleMoneyRmb INT,
liuProfitRmb INT,
qiSaleMoneyRmb INT,
qiProfitRmb INT,
baSaleMoneyRmb INT,
baProfitRmb INT,
jiuSaleMoneyRmb INT,
jiuProfitRmb INT,
shiSaleMoneyRmb INT,
shiProfitRmb INT
)
INSERT INTO  #AllInfoTempbiao
select 
 isnull(isnull(isnull(isnull(isnull(isnull(isnull(isnull(ISNULL(y.CategoryName, e.CategoryName),sa.CategoryName),si.CategoryName),w.CategoryName),l.CategoryName),q.CategoryName),b.CategoryName),j.CategoryName),sh.CategoryName)
 as CategoryName,       --管理类别

 isnull(isnull(isnull(isnull(isnull(isnull(isnull(isnull(ISNULL(y.CategoryParentname, e.CategoryParentname),sa.CategoryParentname),si.CategoryParentname),w.CategoryParentname),l.CategoryParentname),q.CategoryParentname),b.CategoryParentname),j.CategoryParentname),sh.CategoryParentname)
 as CategoryParentname,       --管理类别      --父类别
isnull(y.SaleMoneyRmb,0) as yiSaleMoneyRmb,                                        --1
isnull(y.ProfitRmb,0) as yiProfitRmb ,

isnull(e.SaleMoneyRmb,0) as erSaleMoneyRmb,                                        --2
isnull(e.ProfitRmb,0) as eriProfitRmb, 
 
isnull(sa.SaleMoneyRmb,0) as sanSaleMoneyRmb,                                        --3
isnull(sa.ProfitRmb,0) as saniProfitRmb,  

isnull(si.SaleMoneyRmb,0) as siSaleMoneyRmb,                                         --4
isnull(si.ProfitRmb,0) as siProfitRmb,

isnull(w.SaleMoneyRmb,0) as wuSaleMoneyRmb,                                        --5
isnull(w.ProfitRmb,0) as wuProfitRmb, 
 
isnull(l.SaleMoneyRmb,0) as liuSaleMoneyRmb,                                         --6
isnull(l.ProfitRmb,0) as liuProfitRmb,  

isnull(q.SaleMoneyRmb,0) as qiSaleMoneyRmb,                                        --7
isnull(q.ProfitRmb,0) as qiProfitRmb,

isnull(b.SaleMoneyRmb,0) as baSaleMoneyRmb,                                        --8
isnull(b.ProfitRmb,0) as baProfitRmb,

isnull(j.SaleMoneyRmb,0) as jiuSaleMoneyRmb,                                         --9
isnull(j.ProfitRmb,0) as jiuProfitRmb, 

isnull(sh.SaleMoneyRmb,0) as shiSaleMoneyRmb,                                        --10
isnull(sh.ProfitRmb,0) as shiProfitRmb 
                                
from #yi y
full OUTER JOIN #er e ON e.CategoryName=y.CategoryName
full OUTER JOIN #san sa  on sa.CategoryName=e.CategoryName
full OUTER JOIN #si si  on si.CategoryName=e.CategoryName
full OUTER JOIN #wu w  on w.CategoryName=e.CategoryName
full OUTER JOIN #liu l  on l.CategoryName=e.CategoryName
full OUTER JOIN #qi q  on q.CategoryName=e.CategoryName
full OUTER JOIN #ba b  on b.CategoryName=e.CategoryName
full OUTER JOIN #jiu j  on j.CategoryName=e.CategoryName
full OUTER JOIN #shi sh  on sh.CategoryName=e.CategoryName


SELECT 
CategoryName,
CategoryParentName,
SUM(yiSaleMoneyRmb) as yiSaleMoneyRmb,
SUM(yiSaleMoneyRmb) as yiProfitRmb,

SUM(erSaleMoneyRmb) as erSaleMoneyRmb,
SUM(erProfitRmb) as erProfitRmb,

SUM(sanSaleMoneyRmb) as sanSaleMoneyRmb,
SUM(sanProfitRmb) as sanProfitRmb,

SUM(siSaleMoneyRmb) as siSaleMoneyRmb,
SUM(siProfitRmb) as siProfitRmb,

SUM(wuSaleMoneyRmb) as wuSaleMoneyRmb,
SUM(wuProfitRmb) as wuProfitRmb,

SUM(liuSaleMoneyRmb) as liuSaleMoneyRmb,
SUM(liuProfitRmb) as liuProfitRmb,

SUM(qiSaleMoneyRmb) as qiSaleMoneyRmb,
SUM(qiProfitRmb) as qiProfitRmb,

SUM(baSaleMoneyRmb) as baSaleMoneyRmb,
SUM(baProfitRmb) as baProfitRmb,

SUM(jiuSaleMoneyRmb) as jiuSaleMoneyRmb,
SUM(jiuProfitRmb) as jiuProfitRmb,

SUM(shiSaleMoneyRmb) as shiSaleMoneyRmb,
SUM(shiProfitRmb) as shiProfitRmb
 INTO #newTable
 from #AllInfoTempbiao 

GROUP BY 
CategoryName,
CategoryParentName

select *  from #newTable bb
 WHERE ISNULL(@CategoryName, '') ='' OR  bb.CategoryName = @CategoryName 
AND ISNULL(@CategoryParentName, '') ='' OR  bb.CategoryParentname = @CategoryParentName

DROP TABLE #yi
DROP TABLE #er
DROP TABLE #san
DROP TABLE #si
DROP TABLE #wu
DROP TABLE #liu
DROP TABLE #qi
DROP TABLE #ba
DROP TABLE #jiu
DROP TABLE #shi
END