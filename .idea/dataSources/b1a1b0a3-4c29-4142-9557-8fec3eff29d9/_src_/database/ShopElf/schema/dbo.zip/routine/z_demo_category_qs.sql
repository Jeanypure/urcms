CREATE PROCEDURE [dbo].[z_demo_category_qs]
AS
BEGIN
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
EXEC P_RP_SKUlirun_shyr_sku_rjf '0','2016-01-01 00:00:00','2016-01-31 23:59:59','','0','0','','','','','','0','0','0','0','131'
END