CREATE PROCEDURE [dbo].[z_demo_zongchange]

--2016-10-07 mend 2017-01-12

(
@suffix VARCHAR(100)='',
@SalerName VARCHAR(100)='',
@pingtai VARCHAR(100)=''
)

AS
BEGIN

SET NOCOUNT ON
 DECLARE @BeginDatej1 DATE;
	DECLARE @EndDatej1 DATETIME;
  set @BeginDatej1	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-1,GETDATE()) AS DATE) AS DATETIME)) --近1天开始时间
	set @EndDatej1	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,0,GETDATE()) AS DATE) AS DATETIME))))--近1天 的结束时间


DECLARE @BeginDates1 DATE;
	DECLARE @EndDates1 DATETIME;
  set @BeginDates1	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-2,GETDATE()) AS DATE) AS DATETIME)) --上天1天开始时间
	set @EndDates1	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-1,GETDATE()) AS DATE) AS DATETIME))))--上1天 的结束时间


DECLARE @BeginDatej5 DATE;
	DECLARE @EndDatej5 DATETIME;
  set @BeginDatej5	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-5,GETDATE()) AS DATE) AS DATETIME)) --近5天开始时间
	set @EndDatej5	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,0,GETDATE()) AS DATE) AS DATETIME))))--近5天 的结束时间

DECLARE @BeginDates5 DATE;
	DECLARE @EndDates5 DATETIME;
  set @BeginDates5	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-10,GETDATE()) AS DATE) AS DATETIME)) --上5天开始时间
	set @EndDates5	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-5,GETDATE()) AS DATE) AS DATETIME))))--上5天 的结束时间


DECLARE @BeginDatej10 DATE;
	DECLARE @EndDatej10 DATETIME;
  set @BeginDatej10	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-10,GETDATE()) AS DATE) AS DATETIME)) --近10天开始时间
	set @EndDatej10	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,0,GETDATE()) AS DATE) AS DATETIME))))--近10天 的结束时间

DECLARE @BeginDates10 DATE;
	DECLARE @EndDates10 DATETIME;
  set @BeginDates10	=	DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-20,GETDATE()) AS DATE) AS DATETIME)) --上10天开始时间
	set @EndDates10	=	DATEADD(second,-1,CONVERT(DATETIME,DATEADD(HOUR,00,CAST(CAST(DATEADD(DAY,-10,GETDATE()) AS DATE) AS DATETIME))))--上10天 的结束时间



CREATE TABLE #jinyitian(
suffix VARCHAR(100),
sku VARCHAR(100),
jinyitian int
)

CREATE TABLE #shangyitian(
suffix VARCHAR(100),
sku VARCHAR(100),
shangyitian int
)

CREATE TABLE #jinwutian(
suffix VARCHAR(100),
sku VARCHAR(100),
jinwutian int
)

CREATE TABLE #shangwutian(
suffix VARCHAR(100),
sku VARCHAR(100),
shangwutian int
)

CREATE TABLE #jinshitian(
suffix VARCHAR(100),
sku VARCHAR(100),
jinshitian int
)

CREATE TABLE #shangshitian(
suffix VARCHAR(100),
sku VARCHAR(100),
shangshitian int
)

INSERT INTO #jinyitian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDatej1,@EndDate=@EndDatej1

--SELECT * FROM #jinyitian

INSERT INTO #shangyitian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDates1,@EndDate=@EndDates1
--SELECT * FROM #shangyitian

INSERT INTO #jinwutian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDatej5,@EndDate=@EndDatej5
--SELECT * FROM #jinwutian


INSERT INTO #shangwutian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDates5,@EndDate=@EndDates5
--SELECT * FROM #shangwutian

insert INTO  #jinshitian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDatej10,@EndDate=@EndDatej10
insert INTO  #shangshitian
EXEC z_demo_xiaoliangbianhua
@BeginDate=@BeginDates10,@EndDate=@EndDates10

SELECT
 isnull(isnull(isnull(isnull(ISNULL(jy.suffix, sy.suffix),jw.suffix),sw.suffix),js.suffix),ss.suffix) as suffix,       --买家简称
 isnull(isnull(isnull(isnull(isnull(jy.sku,sy.sku),jw.sku),sw.sku),js.sku),ss.sku) as sku,                       --sku
SUM(isnull(jy.jinyitian,0)) as jinyitian,                                       	--近一天
SUM(isnull(sy.shangyitian,0)) as shangyitian,                                			--上一天

SUM(isnull(jw.jinwutian,0)) as jinwutian,																						--近五天
SUM(isnull(sw.shangwutian,0)) as shangwutian,																				--上五天

SUM(isnull(js.jinshitian,0)) as jinshitian,																						--近10天
SUM(isnull(ss.shangshitian,0)) as shangshitian																				--上10天

INTO #allTempInfo                                                                   --包含所有信息的临时表 用了full OUTER join
FROM #jinyitian jy
full OUTER JOIN #shangyitian sy on jy.suffix=sy.suffix AND jy.sku=sy.sku
full OUTER JOIN #jinwutian jw on jy.suffix=jw.suffix AND jy.sku=jw.sku
FULL OUTER JOIN #shangwutian sw on jy.suffix=sw.suffix AND jy.sku=sw.sku
FULL OUTER JOIN #jinshitian js on jy.suffix=js.suffix AND jy.sku=js.sku
FULL OUTER JOIN #shangshitian ss on jy.suffix=ss.suffix AND jy.sku=ss.sku
GROUP BY isnull(isnull(isnull(isnull(ISNULL(jy.suffix, sy.suffix),jw.suffix),sw.suffix),js.suffix),ss.suffix),isnull(isnull(isnull(isnull(isnull(jy.sku,sy.sku),jw.sku),sw.sku),js.sku),ss.sku)

--select * FROM #allTempInfo
CREATE TABLE #allInfoTempTable(
pingtai VARCHAR(100),
suffix VARCHAR(100),
GoodsCode VARCHAR(100),
GoodsName VARCHAR(100),
GoodsSKUStatus VARCHAR(100),
CategoryName VARCHAR(100),
SalerName VARCHAR(100),
SalerName2 VARCHAR(100),
CreateDate VARCHAR(100),
jinyitian int,
shangyitian int,
changeOneDay int,
jinwutian int,
shangwutian int,
changeFiveDay int,
jinshitian int,
shangshitian int,
changeTenDay int
)

INSERT INTO #allInfoTempTable --插入不存在的临时表

SELECT

case when  suffix IN('eBay-11-monstercaca','eBay-03-hanzaa04','eBay-08-landchuang77','eBay-09-runrunpen','01-buy','02-2008','03-aatq','04-cheong','05-5avip','06-happygirl','07-smile','08-xea','09-niceday','10-girlspring','11-newfashion','12-showgirl','13-showtime','14-degage','15-exao','16-sunshine','17-su061','18-shuai','eBay-01-global_saler','eBay-02-supermarket6')
	 THEN 'eBay'
	 WHEN suffix IN('AMZ11-US','AMZ11-CA','AMZ10-US','AMZ10-MX','AMZ10-CA','AMZ09-US','AMZ09-MX','AMZ09-CA','AMZ01-CA','AMZ01-DE','AMZ01-ES','AMZ01-FR','AMZ01-IT','AMZ01-UK','AMZ02-JP','AMZ02-US','AMZ02-CA','AMZ02-MX','AMZ03-CA','AMZ03-MX','AMZ03-US','AMZ05-CA','AMZ04-US','AMZ04-CA','AMZ05-US','AMZ06-US','AMZ06-CA','AMZ08-CA','AMZ08-US','AMZ01-JP',
'AMZ01-MX','AMZ01-US','AMZ09-US')
	THEN 'Amazon'
	WHEN suffix IN('LZD01-eeeshopping-ID','LZD01-eeeshopping-MY','LZD01-eeeshopping-SG','LZD01-eeeshopping-TH')
	THEN 'Lazada'
	WHEN suffix IN('SMT01-eshop','SMT02-great','SMT03-happygirl','SMT04-smile','SMT05-fashion','SMT06-niceday','SMT07-girlspring','SMT08-newfashion','SMT09-showgirl','SMT10-showtime','SMT11-degaga','SMT12-fashionzone','SMT13-sunshinegir','SMT14-foxlady','SMT15-charmgarden','SMT16-girlswardrobe','SMT17-magicspace66','SMT18-my5aVIP','SMT19-YRSMT19')
	THEN 'SMT'
	WHEN suffix IN('WISE42-chuangrong1989','WIS01-eshop','WIS02-zone','WIS03-world','WIS04-hapyshop','WIS05-fashionp','WIS06-hones','WIS07-Rosa','WIS08-angel','WIS09-universe','WIS10-gossipgirl','WIS11-fashiontribe','WIS12-fantasticgirl','WIS13-decorationsector','WIS14-wednesdayshop','WISE08-Highhigh','WISE14-Fantasticfairyland','WISE09-Singledog','WISE05-Ifyou521',
	'WISE07-Coldbone','WISE10-Womenflowers','WISE13-Fastcar269','WISE16-Badgirl','WISE17-Sunshinegirl','WISE19-Highhigh2016','WISE21-Hopefine','WISE03-Sixtyplus','WISE20-Goodday125','WISE22-Feifeimarket','WISE24-Lonelybar','WISE15-Hanoba','WISE26-Privatecorner','WISE27-Travelgirl','WISE31-Beathyclube','WISE28-Foreverbeauty521','WISE29-Girlswardrobe ','WISE31-Beathyclube','WISE32-Magicspace','WISE33-Showtime128','WISE35-Eeeshopping','WISE36-Showgirl','WISE38-haiyang256')
	THEN 'Wish'
	WHEN suffix IN('Top-01')
	THEN 'Tophatter'
	WHEN suffix IN('Shopee02-topop-SG','Shopee02-topop-MY','Shopee01-eshop-MY','Shopee01-eshop-SG','Shopee01-eshop-ID')
	THEN 'Shopee'
	ELSE NULL
	END as pingtai,      --根据买家简称找对应的平台
 a.suffix ,
g.GoodsCode,
g.GoodsName,
gs.GoodsSKUStatus,
abgs.CategoryName,
g.SalerName,
g.SalerName2,
g.CreateDate,
SUM(a.jinyitian) as jinyitian,
SUM(a.shangyitian) as shangyitian,
SUM(a.jinyitian)-SUM(a.shangyitian) as changeOneDay,  --1天销量变化

SUM(a.jinwutian) as jinwutian,
SUM(a.shangwutian) as shangwutian,
SUM(a.jinwutian)-SUM(a.shangwutian) as changeFiveDay ,--5天销量变化

SUM(a.jinshitian) as jinshitian,
SUM(a.shangshitian) as shangshitian,
SUM(a.jinshitian)-SUM(a.shangshitian) as changeTenDay --10天销量变化

FROM #allTempInfo a
left join B_GoodsSKU gs on gs.SKU = a.sku
	left join B_goods g on gs.GoodsID=g.NID
	left join B_GoodsCats abgs on abgs.NID=g.GoodsCategoryID
WHERE gs.GoodsSKUStatus <>'停产'                               --产品销量变化不包含 停产状态的SKU

AND (@suffix='' or isnull(a.suffix,'') LIKE '%'+@suffix+'%')
AND (@SalerName='' or (ISNULL(@SalerName,'') = '0') OR (isnull(g.SalerName,'') in (select Personname from B_Person where NID=@SalerName)))
--AND (@pingtai='' or isnull(pingtai,'') LIKE '%'+@pingtai+'%')--pingtai = @pingtai
GROUP BY
a.suffix ,
g.GoodsCode,
gs.GoodsSKUStatus,
g.GoodsName,
g.SalerName,
g.SalerName2,
g.CreateDate,
abgs.CategoryName

SELECT
att.GoodsCode,
att.GoodsName,
att.GoodsSKUStatus,
att.CategoryName,
att.SalerName,
att.SalerName2,
att.CreateDate,
SUM(att.jinyitian)as jinyitian,
SUM(att.shangyitian) as shangyitian ,
SUM(att.jinyitian)-SUM(att.shangyitian) as changeOneDay ,
SUM(att.jinwutian) as jinwutian,
SUM(att.shangwutian) as shangwutian,
SUM(att.jinwutian)-SUM(att.shangwutian) as changeFiveDay,
SUM(att.jinshitian) as jinshitian,
SUM(att.shangshitian) as shangshitian,
SUM(att.jinshitian)-SUM(att.shangshitian) as changeTenDay

INTO #TmpSalerChange
FROM #allInfoTempTable att
WHERE @pingtai='' or isnull(pingtai,'') LIKE '%'+@pingtai+'%'
GROUP BY
att.GoodsCode,
att.GoodsName,
att.GoodsSKUStatus,
att.CategoryName,
att.SalerName,
att.SalerName2,
att.CreateDate
ORDER BY jinyitian DESC


SELECT  
 tsc.*
FROM #TmpSalerChange tsc





 DROP TABLE #jinyitian
 DROP table #shangyitian
 Drop table #jinwutian
 DROP table #shangwutian
drop table #jinshitian
drop table #shangshitian
 DROP table #allInfoTempTable

END