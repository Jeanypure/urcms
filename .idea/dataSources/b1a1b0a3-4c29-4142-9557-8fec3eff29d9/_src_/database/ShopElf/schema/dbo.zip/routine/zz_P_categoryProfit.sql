CREATE PROCEDURE [dbo].[zz_P_categoryProfit]--卖家小类

    (
   @DateFlag int,                         --时间标记 0 交易时间 1 发货时间
	@BeginDate	varchar(20),               --开始时间
	@EndDate	Varchar(20),              --结束时间
	@suffix VARCHAR(max) = '',     --卖家简称
  @pingtai VARCHAR(50)='',
  @SalerName varchar(50)='',
  @CategoryParentName varchar(50)='',
	@BeginCreateDate varchar(20)='' ,
	@EndCreateDate varchar(20) ='',
  @PageNum int = 100,             --每页记录数
  @PageIndex int = 1             --页码

   
    )
AS
begin
--SET NOCOUNT ON 加上才能查出来结果--
SET NOCOUNT ON
DECLARE
@PageCount int =0,          --输出页数
@RecCount int=0           --输出记录数	
  set @BeginDate	=	SUBSTRING(@BeginDate,1,10)
		set @EndDate	=	SUBSTRING(@EndDate,1,10)
  if @DateFlag=0
	begin
		set @BeginDate	=	DATEADD(HH,-8,@BeginDate)
		set @EndDate	=	DATEADD(HH,-8,dateadd(DD,1,@EndDate))
	end


  --declare @Sql varchar(max)

  -- 创建临时表用来存储信息
  create Table #TmpTradeInfo(
		Suffix varchar(100) not null,         --这个是我后来添加上去的字段suffix
    Nid int not null,                          --订单号
    AllWeight float Null,                      --总重量
    AllQty int Null,                           --总数量
    amt float null,                            --总销售金额
    SHIPPINGAMT float null,                    --买家付运费
    SHIPDISCOUNT float null,                   --ebay交易费
    FeeAmt float null,                         --交易费(pp手续费)
    ExpressFare float null,                    --快递费
    INSURANCEAMOUNT float null,                --包装费
    SKUPACKFEE float null,                     --SKU包装费
    SKU varchar(100) null,                     --SKU
    SKUQty int null,                           --Sku数量
    SKUWeight float null,                      --SKU重量
    SKUCostPrice float null,                   --订单SKU成本价
    SKUamt float null,                         --订单SKU销售金额
    ExchangeRate float null,                   --汇率
    goodsid int null                           --商品ID
  )
  create Table #TmpSkuFreeInfo(
		suffix varchar(100) not null,                                                 --卖家简称suffix
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --Sku数量
    SaleMoneyRmb float null,                   --SKU 销售金额￥
    ShippingAmtRmb float null,                 --SKU 买家付运费￥
    CostMoneyRmb float null,                   --SKU 销售成本￥
    eBayFeeRmb float null,                     --SKU ebay成交费￥
    PaypalFeeRmb float null,                   --SKU PP手续费￥
    ExpressFareRmb float null,                 --SKU 运费成本￥
    InPackageFeeRmb float null,                --SKU 包装成本￥
    OutPackageFeeRmb float null,               --SKU 外包装成本￥
  )
  create Table #TmpSumSkuFreeInfo(
		suffix varchar(100) not null,
    SKU varchar(100)  null,                    --SKU
    SKUQty int null,                           --销售数量
    SaleMoneyRmb float null,                   --成交价￥
    ShippingAmtRmb float null,                 --买家付运费￥
    CostMoneyRmb float null,                   --销售成本￥
    ProfitRmb float null,                      --实收利润￥
    eBayFeeRmb float null,                     --ebay成交费￥
    PaypalFeeRmb float null,                   --PP手续费￥
    ExpressFareRmb float null,                 --运费成本￥
    InPackageFeeRmb float null,                  --包装成本￥
    OutPackageFeeRmb float null,               --外包装成本￥
    AverageSaleMoneyRmb float null,            --平均售价￥
    AverageProfitRmb float null                --平均利润价￥
  )


  --查找美元的汇率
  Declare  @ExchangeRate float
  set @ExchangeRate =ISNULL((select ExchangeRate from B_CurrencyCode  where CURRENCYCODE='USD'),1)
  --查找成本计价方法
  Declare @CalcCostFlag int
  set @CalcCostFlag =ISNULL((select ParaValue from B_SysParams where ParaCode ='CalCostFlag'),0)
  -- 重寄单数据 不行 重寄单会自动删除
  --select m.OrderNumber as nid into #Tmpchongji from XS_SaleAfterM m
   --  where m.SaleType='重寄'

  --正常表的数据插入数据库
  insert into #TmpTradeInfo
  select
m.Suffix,
				m.Nid,                                                                        --订单号
         isnull((select Sum(IsNull(a.Weight,0))
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量
         isnull((select Sum(IsNull(a.l_amt,0))
                 from p_tradedt(nolock) a where a.tradenid = m.nid),0) as amt,         --总销售金额
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end,  --买家付运费 特殊运费
          m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
          m.FeeAmt
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0)
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                      --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID
  FROM  p_tradedt(nolock) d
  inner join p_trade(nolock) m on m.nid=d.tradenid
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
  left join B_CurrencyCode c on c.currencycode=m.currencycode
  where  ((@DateFlag=1 and m.FilterFlag=100 and convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate)
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )                                       --SKU

  --历史表的数据插入数据库 不用判断发货状态  m.FilterFlag = 10
  insert into #TmpTradeInfo
  select
m.Suffix,
m.Nid,                                                                            --订单号
         isnull((select Sum(IsNull(a.Weight,0))
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as allweight ,  --总重量
         isnull((select Sum(IsNull(a.L_QTY,0))
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as AllQty ,     --总数量
         isnull((select Sum(IsNull(a.l_amt,0))
                 from p_tradedt_his(nolock) a where a.tradenid = m.nid),0) as amt,     --总销售金额
          case when ISNULL(m.AMT,0)=0 then 0 else m.SHIPPINGAMT end ,  --买家付运费 特殊运费
        m.SHIPDISCOUNT ,      --ebay交易费 wish特殊，有数值也为0
         m.FeeAmt
               ,                                  --交易费(pp手续费) wish特殊,（商品金额+运费总额/0.85）*0.18
         m.ExpressFare,                                                                --快递费
         m.INSURANCEAMOUNT,                                                            --包装费
         case when d.L_TAXAMT=0 then d.L_QTY*ISNULL(bg.PackFee,0)
              else d.L_TAXAMT*0 end,                                                   --SKU包装费
         d.sku,                                                                        --SKU
         d.l_qty,                                                                      --SKU数量
         d.weight,                                                                     --SKU重量
         case when @CalcCostFlag =0 then d.CostPrice
              else d.L_QTY*(case when bgs.costprice<>0 then bgs.costprice
              else isnull(bg.CostPrice,0) end ) end as SKUCostPrice,                   --订单SKU成本价
         case when ISNULL(m.AMT,0)=0 then 0 else d.l_amt end,                                                                       --订单SKU销售金额
         isnull(c.ExchangeRate,1),                                                     --汇率
         bg.nid as goodsid                                                             --商品ID
  FROM  p_tradedt_his(nolock) d
  inner join p_trade_his(nolock) m on m.nid=d.tradenid
  LEFT JOIN B_GoodsSKU bgs ON isnull(d.SKU,'')=bgs.SKU
  LEFT JOIN B_Goods bg ON bgs.GoodsID = bg.NID
  left join B_CurrencyCode c on c.currencycode=m.currencycode
  where  ((@DateFlag=1 and  convert(varchar(10),m.CLOSINGDATE,121) between @BeginDate and @endDate)
			or  (@DateFlag=0 and m.ORDERTIME between @BeginDate and @endDate) )                                                                    --SKU
  --更新总重量和总金额,总数量如果是0 那么改成1
  update #TmpTradeInfo set allweight = 1 where ISNULL(allweight,0) = 0
  update #TmpTradeInfo set amt = 1 where ISNULL(amt,0) = 0
  update #TmpTradeInfo set AllQty = 1 where ISNULL(AllQty,0) = 0

  --计算金额并插入临时表
  --SKU 销售金额￥    = SKU费用 * 币种汇率
  --SKU 买家付运费￥  = (买家付运费 * 币种汇率) * SKU重量 / 总重量
  --SKU 销售成本￥    = 订单SKU成本价
  --SKU ebay成交费￥  = (ebay交易费 * 美元汇率) * SKU费用 / 总费用
  --SKU PP手续费￥    = (pp手续费 * 币种汇率) * SKU费用 / 总费用
  --SKU 运费成本￥    = 快递费 * SKU重量 / 总重量
  --SKU 包装成本￥    = (包装费 * 1.0) * SKU数量 / 总数量 + sku包装费
  insert into #TmpSkuFreeInfo
  select suffix,                                                --suffix卖家简称
				 SKU,                                                    --SKU
         SKUQty ,                                                --Sku数量
         SKUamt * ExchangeRate,                                  --SKU 销售金额￥
         (SHIPPINGAMT * ExchangeRate) * SKUamt/amt ,             --SKU 买家付运费￥
         SKUCostPrice ,                                          --SKU 销售成本￥
         (SHIPDISCOUNT * @ExchangeRate) * SKUamt/amt,            --SKU ebay成交费￥
         (FeeAmt * ExchangeRate) * SKUamt/amt,                   --SKU PP手续费￥
         ExpressFare * SKUWeight / AllWeight,                    --SKU 运费成本￥
         SKUPACKFEE,                                             --SKU 内包装成本￥
        (INSURANCEAMOUNT * 1.0) * SKUQty / AllQty                --sku 外包装成本
  from #TmpTradeInfo

  --统计金额插入临时表
  --成交价￥       = sum(SKU 销售金额￥ + SKU 买家付运费￥)
  --买家付运费￥   = sum(SKU 买家付运费￥)
  --销售成本￥     = sum(SKU 销售成本￥)
  --实收利润￥     = sum(SKU 销售金额￥ + SKU 买家付运费￥ - SKU 销售成本￥ - SKU ebay成交费￥
  --                     - SKU PP手续费￥ - SKU 运费成本￥ - SKU 包装成本￥)
  --ebay成交费￥   = sum(SKU ebay成交费￥)
  --PP手续费￥     = sum(SKU PP手续费￥)
  --运费成本￥     = sum(SKU 运费成本￥)
  --包装成本￥     = sum(SKU 包装成本￥)
  --平均售价￥     = 成交价￥ / sum(Sku数量)
  --平均利润价￥   = 实收利润￥ / sum(Sku数量)
  insert into #TmpSumSkuFreeInfo
  select  suffix,                                                 --卖家简称suffix
				 SKU,                                                  --SKU
         SKUQty,                                               --销售数量
         SaleMoneyRmb,                                         --成交价￥
         ShippingAmtRmb,                                       --买家付运费￥
         CostMoneyRmb,                                         --销售成本￥
         ProfitRmb,                                            --实收利润￥
         eBayFeeRmb  ,                                         --ebay成交费￥
         PaypalFeeRmb ,                                        --PP手续费￥
         ExpressFareRmb ,                                      --运费成本￥
         InPackageFeeRmb ,                                     --内包装成本￥
         OutPackageFeeRmb ,                                       --外包装成本￥
         case when SKUQty = 0 then 0
              else SaleMoneyRmb/SKUQty end,                    --平均售价￥
         case when SKUQty = 0 then 0
              else ProfitRmb/SKUQty end                        --平均利润价￥
  from
  (select  suffix,                                                 --卖家简称suffix
					SKU,                                                  --SKU
         sum(SKUQty) as SKUQty,                                --数量
         SUM(SaleMoneyRmb + ShippingAmtRmb) as SaleMoneyRmb,   --成交价￥
         SUM(ShippingAmtRmb) as ShippingAmtRmb,                --买家付运费￥
         SUM(CostMoneyRmb) as CostMoneyRmb,                    --销售成本￥
         SUM(SaleMoneyRmb + ShippingAmtRmb - CostMoneyRmb
             - eBayFeeRmb - PaypalFeeRmb - ExpressFareRmb
             - InPackageFeeRmb-OutPackageFeeRmb) as ProfitRmb,   --实收利润￥
         SUM(eBayFeeRmb) as eBayFeeRmb  ,                      --ebay成交费￥
         SUM(PaypalFeeRmb) as PaypalFeeRmb ,                   --PP手续费￥
         SUM(ExpressFareRmb) as ExpressFareRmb ,               --运费成本￥
         SUM(InPackageFeeRmb) as InPackageFeeRmb,                   --内包装成本￥
         SUM(OutPackageFeeRmb) as OutPackageFeeRmb                   --外包装成本￥
  from #TmpSkuFreeInfo
  group by SKU,suffix) aa

  SELECT   * INTO #CategoryProfit  FROM (select
     
    suffix,--as '卖家简称',																												--张蓉要的suffix 字段
  case when  suffix IN('eBay-14-lonelyway','eBay-11-monstercaca','eBay-03-hanzaa04','eBay-08-landchuang77','eBay-09-runrunpen','01-buy','02-2008','03-aatq','04-cheong','05-5avip','06-happygirl','07-smile','08-xea','09-niceday','10-girlspring','11-newfashion','12-showgirl','13-showtime','14-degage','15-exao','16-sunshine','17-su061','18-shuai','eBay-01-global_saler','eBay-02-supermarket6')
	 THEN 'eBay'
	 WHEN suffix IN('AMZ10-CA','AMZ09-CA','AMZ01-CA','AMZ01-DE','AMZ01-ES','AMZ01-FR','AMZ01-IT','AMZ01-UK','AMZ02-JP','AMZ02-US','AMZ02-CA','AMZ02-MX','AMZ03-CA','AMZ03-MX','AMZ03-US','AMZ05-CA','AMZ04-US','AMZ04-CA','AMZ05-US','AMZ06-US','AMZ06-CA','AMZ08-CA','AMZ08-US','AMZ01-JP',
'AMZ01-MX','AMZ01-US','AMZ09-US')
	THEN 'Amazon'
	WHEN suffix IN('LZD01-eeeshopping-ID','LZD01-eeeshopping-MY','LZD01-eeeshopping-SG','LZD01-eeeshopping-TH')
	THEN 'Lazada'
	WHEN suffix IN('SMT01-eshop','SMT02-great','SMT03-happygirl','SMT04-smile','SMT05-fashion','SMT06-niceday','SMT07-girlspring','SMT08-newfashion','SMT09-showgirl','SMT10-showtime','SMT11-degaga','SMT12-fashionzone','SMT13-sunshinegir','SMT14-foxlady','SMT15-charmgarden','SMT16-girlswardrobe','SMT17-magicspace66','SMT18-my5aVIP','SMT19-YRSMT19')
	THEN 'SMT'
	WHEN suffix IN('WISE43-ringringlee2','WISE42-chuangrong1989','WIS01-eshop','WIS02-zone','WIS03-world','WIS04-hapyshop','WIS05-fashionp','WIS06-hones','WIS07-Rosa','WIS08-angel','WIS09-universe','WIS10-gossipgirl','WIS11-fashiontribe','WIS12-fantasticgirl','WIS13-decorationsector','WIS14-wednesdayshop','WISE08-Highhigh','WISE14-Fantasticfairyland','WISE09-Singledog','WISE05-Ifyou521',
	'WISE07-Coldbone','WISE10-Womenflowers','WISE13-Fastcar269','WISE16-Badgirl','WISE17-Sunshinegirl','WISE19-Highhigh2016','WISE21-Hopefine','WISE03-Sixtyplus','WISE20-Goodday125','WISE22-Feifeimarket','WISE24-Lonelybar','WISE15-Hanoba','WISE26-Privatecorner','WISE27-Travelgirl','WISE31-Beathyclube','WISE28-Foreverbeauty521','WISE29-Girlswardrobe ','WISE31-Beathyclube','WISE32-Magicspace','WISE33-Showtime128','WISE35-Eeeshopping','WISE36-Showgirl','WISE38-haiyang256')
	THEN 'Wish'
	WHEN suffix IN('Top-01')
	THEN 'Tophatter'
	WHEN suffix IN('Shopee01-eshop-MY','Shopee01-eshop-SG','Shopee01-eshop-ID')
	THEN 'Shopee'
	ELSE NULL
	END as pingtai,
 case when abgs.CategoryName='女人世界'
   THEN '女人世界'
   when abgs.CategoryName='男人海洋'
   THEN '男人海洋'
   when abgs.CategoryName='饰品配件'
   THEN '饰品配件'
   when abgs.CategoryName='户外'
   THEN '户外'
   when abgs.CategoryName='家居'
   THEN '家居'
   when abgs.CategoryName='电子'
   THEN '电子'
   when abgs.CategoryName='母婴'
   THEN '母婴'
   when abgs.CategoryName='节日'
   THEN '节日'
   when abgs.CategoryName='穿戴'
   THEN '穿戴'
   when abgs.CategoryName='古装'
   THEN '古装'
   when abgs.CategoryName='耗材'
   THEN '耗材'
   when abgs.CategoryName='海外仓'
   THEN '海外仓'
   when abgs.CategoryName='清仓'
   THEN '清仓'
   when abgs.CategoryName='已删除'
   THEN '已删除'
   ELSE isnull(abgs.CategoryParentName,'')
   END as CategoryParentName ,-- '父管理类别',

    isnull(abgs.CategoryName,'') as aliascnname ,-- '管理类别',
isnull(g.SalerName,'')as SalerName,
isnull(g.CreateDate,'') as CreateDate,
count(DISTINCT g.GoodsCode)as GoodsCodeQty,
    SUM(fg.SKUQty) as SKUQty,
    round(case when isnull(sum(fg.SaleMoneyRmb),0)=0 THEN 0 ELSE sum(fg.SaleMoneyRmb) end,2 ) as zsale,-- '销售额',--'SaleMoneyRmb',


    round(case when isnull(sum(fg.ProfitRmb),0)=0 THEN 0 ELSE sum(fg.ProfitRmb) end,2 ) as zlr, --'实收利润',--'',

    round(case when isnull(sum(fg.SaleMoneyRmb),0)=0 then 0 else sum(fg.ProfitRmb)*100/ sum(fg.SaleMoneyRmb) end,2) as lrl
  from #TmpSumSkuFreeInfo fg
  left join B_GoodsSKU gs on gs.SKU=fg.sku
  left join B_goods g on gs.GoodsID=g.NID
  left join B_GoodsCats abgs on abgs.NID=g.GoodsCategoryID
	 GROUP BY CreateDate,suffix,CategoryParentName,CategoryName,SalerName) as lalala

WHERE (isnull(@suffix,'') = '' or isnull(suffix,'') like '%'+@suffix+'%')
AND (ISNULL(@pingtai,'') = '' OR isnull(pingtai,'') like '%'+@pingtai+'%')
AND (ISNULL(@SalerName,'') = '' OR isnull(SalerName,'') like '%'+@SalerName+'%')
AND (ISNULL(@CategoryParentName,'') = '' OR isnull(CategoryParentName,'') like '%'+@CategoryParentName+'%')
AND (isnull(CreateDate,'') BETWEEN @BeginCreateDate AND @EndCreateDate)


SELECT  @RecCount=count(1) FROM #CategoryProfit
				

-------------------计算记录数和页数
		   if @RecCount % @PageNum = 0
		   begin
			  set @PageCount = @RecCount/@PageNum
		   end
		   else
		   begin
			  set @PageCount = @RecCount/@PageNum+1
		   end	

SELECT 
case pingtai 
WHEN '随便' THEN '随便'
ELSE '汇总' END as pingtai,
case suffix
WHEN '随便' THEN '随便'
ELSE '汇总' END as suffix,

case CategoryParentName
WHEN '随便' THEN '随便'
ELSE '汇总' END 
 as CategoryParentName,
case aliascnname
WHEN '随便' THEN '随便'
ELSE '汇总' END 
 as aliascnname,
  GoodsCodeQty, 
	SKUQty,
  round(zsale,2)as zsale,
	round(zlr,2)as zlr,
  round(lrl,2)as lrl
into #temp222 FROM #CategoryProfit


select 
  pingtai,
	suffix,
	CategoryParentName,
	aliascnname,
  GoodsCodeQty,
  SKUQty,
	round(zsale,2)as zsale,
	round(zlr,2)as zlr,
	round(lrl,2)as lrl 
INTO #Templastresult
 from #CategoryProfit UNION ALL (select
pingtai,
	suffix,
CategoryParentName,
aliascnname,
sum(GoodsCodeQty) as GoodsCodeQty,
sum(SKUQty) as SKUQty,
round(sum(zsale),2) as zsale,
round(sum(zlr),2) as zlr,
round(case when isnull(sum(zlr),0)=0 then 0 else sum(zlr)*100/ sum(zsale) end,2) as lrl
 from #temp222 GROUP BY pingtai,suffix,CategoryParentName,aliascnname) 
select 
  row_number() OVER(ORDER BY CategoryParentName) AS rowid,--OVER(ORDER BY gs.sku )
	@PageCount as fpagecount,
	@RecCount as RecCount,
tlr.* from #Templastresult tlr

	drop table #TmpTradeInfo
	drop table #TmpSkuFreeInfo
	drop table #TmpSumSkuFreeInfo
	drop table #CategoryProfit 
drop table #temp222 
end
