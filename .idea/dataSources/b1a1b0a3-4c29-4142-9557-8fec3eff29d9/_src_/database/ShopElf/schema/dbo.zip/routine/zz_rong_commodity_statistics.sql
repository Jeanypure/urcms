CREATE PROCEDURE [dbo].[zz_rong_commodity_statistics] --2016-11-30下午 商品统计表
(
@BeginDate	varchar(20),               --开始时间
@EndDate	Varchar(20)              --结束时间
)
AS
BEGIN
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'

Create table #fGoods(
sku varchar(100),
l_qty int,
l_AMT money,
costmoney money,
Interest money
)

insert into #fGoods 
	select 
	isnull(d.SKU,'') as SKU,
	sum(d.l_qty) as l_qty,
	sum(isnull(d.l_AMT*isnull(b.ExchangeRate,1),0)) as l_AMT,
	sum(d.costprice) as costmoney,
	sum(d.l_AMT*isnull(b.ExchangeRate,1)-d.costprice) as Interest from P_TradeDtUn d
	left outer join P_TradeUn m on m.nid=d.tradenid 
	left outer join B_CurrencyCode b on b.currencycode=m.currencycode
	where 1=1
	 and DateAdd(hour,8,ordertime)>=@BeginDate and DateAdd(hour,8,ordertime)<=@EndDate
	 --and SUFFIX in('01-buy')
	 and (isnull(d.sku,'')<>'')
	 group by  isnull(d.SKU,'') 
	 union all select isnull(d.SKU,'') as SKU,
	 sum(d.l_qty) as l_qty,
	 sum(isnull(d.l_AMT*isnull(b.ExchangeRate,1),0)) as l_AMT,
	 sum(d.costprice) as costmoney,
	 sum(d.l_AMT*isnull(b.ExchangeRate,1)-d.costprice) as Interest from
	  P_TradeDt d 
	  left outer join P_Trade m on m.nid=d.tradenid 
	  left outer join B_CurrencyCode b on b.currencycode=m.currencycode 
	  where 1=1 
	  and DateAdd(hour,8,ordertime)>=@BeginDate and DateAdd(hour,8,ordertime)<=@EndDate
	  --and SUFFIX in('01-buy')
	  and (isnull(d.sku,'')<>'') group by isnull(d.SKU,'') 
	  union all select isnull(d.SKU,'') as SKU ,
	  sum(d.l_qty)as l_qty,
	  sum(isnull(d.l_AMT*isnull(b.ExchangeRate,1),0)) as l_AMT,
	  sum(d.costprice) as costmoney,
	  sum(d.l_AMT*isnull(b.ExchangeRate,1)-d.costprice) as Interest From P_TradeDt_His d 
	  left outer join P_Trade_His m on m.nid=d.tradenid 
	  left outer join B_CurrencyCode b on b.currencycode=m.currencycode 
	  where 1=1
	  and DateAdd(hour,8,ordertime)>=@BeginDate and DateAdd(hour,8,ordertime)<=@EndDate
	 -- and SUFFIX in('01-buy') 
	  and(isnull(d.SKU,'')<>'')
	  group by isnull(d.SKU,'')

	  select 
	  g.GoodsCode as 商品编码,
    d.SKU as SKU,
	  sum(d.l_qty) as 销量
-- 	  sum(d.l_AMT) as l_AMT,
-- 	  sum(d.costmoney) as costmoney,
-- 	  sum(d.Interest) as Interest 
	  from #fGoods d 
	  left outer join B_GoodsSKU gs on
	  isnull(gs.SKU,'')=isnull(d.SKU,'')
	  left outer join B_Goods g on g.NID=gs.GoodsID
	  left outer join B_Goodscats gl on gl.NID=g.GoodsCategoryID 
	  group by g.GoodsCode,g.GoodsName,g.Class,g.Model,d.SKU
	  drop table #fGoods



END