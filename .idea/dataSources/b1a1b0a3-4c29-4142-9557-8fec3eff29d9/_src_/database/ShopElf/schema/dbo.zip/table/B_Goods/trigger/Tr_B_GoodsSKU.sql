
CREATE TRIGGER [dbo].[Tr_B_GoodsSKU] 
   ON  [dbo].[B_Goods] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF not EXISTS (SELECT s.SKU FROM B_GoodsSKU s 
							JOIN inserted AS i ON s.GoodsID = i.NID)
	begin
		  insert into B_GoodsSKU (GoodsID,SKU,SKUName,BmpFileName, [Weight],CostPrice,RetailPrice, 
		      LocationID,MaxNum,MinNum)
		  select i.NID,i.SKU,i.GoodsName,i.BmpFileName, [Weight],CostPrice,RetailPrice,
				isnull((select top 1 nid from B_StoreLocation),0),MaxNum,MinNum from inserted i 
		  where isnull(i.SKU,'')<> ''
		  

	end						
END
