CREATE TRIGGER [dbo].[CG_OutofStockInsert] on [dbo].[CG_OutofStock] 
AFTER INSERT 
as 
BEGIN
  DECLARE @TradeNID VARCHAR(50)	
    
  DECLARE FETCH_CG_OutofStock CURSOR  
  FOR SELECT TradeNID 
      FROM INSERTED
  OPEN FETCH_CG_OutofStock
  FETCH NEXT FROM FETCH_CG_OutofStock INTO @TradeNID
  WHILE (@@FETCH_STATUS = 0)
  BEGIN  	
  	IF (NOT EXISTS(SELECT 1 FROM CG_OutofStock_Total WHERE TradeNID = @TradeNID)	) and (ISNULL(@TradeNID,'') <> '')	--不存在时，自动增加
  	BEGIN
  		INSERT INTO CG_OutofStock_Total(TradeNID)  VALUES(@TradeNID)
  	END  	
	--更新
  	UPDATE CG_OutofStock_Total
  	SET StockMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,0)
	                                 ,StoreMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,1)
	                                 ,SaleMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,2)
	                                 ,ServiceMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,3)
	                                 ,PrintMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,4)
	                                 ,ServiceMethodTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,5)
  	WHERE TradeNID=@TradeNID and  ISNULL(@TradeNID,'') <> ''	
  	
    FETCH NEXT FROM FETCH_CG_OutofStock	INTO @TradeNID
  END 
  CLOSE FETCH_CG_OutofStock
  DEALLOCATE FETCH_CG_OutofStock  
  	 
  --IF NOT EXISTS (SELECT  1 FROM CG_OutofStock_Total JOIN INSERTED ON CG_OutofStock_Total.TradeNID = INSERTED.TradeNID)
  --BEGIN
  --	DECLARE @TradeNID VARCHAR(50)
  --	SET @TradeNID = (SELECT TOP 1 TradeNID FROM INSERTED)
  --	if ISNULL(@TradeNID,'') <> ''
  -- 	INSERT INTO CG_OutofStock_Total(TradeNID)   	VALUES(@TradeNID)
  --	UPDATE CG_OutofStock_Total
  --	SET StockMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,0)
	 --                                ,StoreMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,1)
	 --                                ,SaleMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,2)
	 --                                ,ServiceMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,3)
	 --                                ,PrintMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,4)
	 --                                ,ServiceMethodTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,5)
  --	WHERE TradeNID=@TradeNID and ISNULL(@TradeNID,'') <> ''  	
  --END 
 END 

