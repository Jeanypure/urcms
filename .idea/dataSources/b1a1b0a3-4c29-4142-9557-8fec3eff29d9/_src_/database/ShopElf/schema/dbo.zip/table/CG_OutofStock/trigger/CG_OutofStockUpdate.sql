------------------------------------------------------------------------------------------------------
--	CG_OutofStockUpdate			更新备注汇总信息
--算法：
--参数: 
--建立: 徐工 2012-07-XX
--修改: 陈卫 2012-08-04 修正只有在CG_OutofStock_Total中不存在对应记录时，才会插入和更新相应备注，
-- 			已存在记录的没有进行更新备注的逻辑问题
------------------------------------------------------------------------------------------------------

CREATE TRIGGER [dbo].[CG_OutofStockUpdate] on [dbo].[CG_OutofStock] 
AFTER UPDATE  
as 
BEGIN
  DECLARE @TradeNID VARCHAR(50)	

  DECLARE FETCH_CG_OutofStock CURSOR  
  FOR SELECT TradeNID 
	  FROM INSERTED
  OPEN FETCH_CG_OutofStock
  FETCH NEXT FROM FETCH_CG_OutofStock INTO @TradeNID
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
    	  	
  	IF (NOT EXISTS(SELECT 1 FROM CG_OutofStock_Total WHERE TradeNID = @TradeNID)	) and (ISNULL(@TradeNID,'') <> '')	--不存在时，自动增加
  	BEGIN
  		INSERT INTO CG_OutofStock_Total(TradeNID)  VALUES(@TradeNID)
  	END  	
	--更新
  	UPDATE CG_OutofStock_Total
  	SET StockMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,0)
	                                 ,StoreMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,1)
	                                 ,SaleMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,2)
	                                 ,ServiceMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,3)
	                                 ,PrintMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,4)
	                                 ,ServiceMethodTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,5)
  	WHERE TradeNID=@TradeNID and  ISNULL(@TradeNID,'') <> ''
  	  	
	FETCH NEXT FROM FETCH_CG_OutofStock	INTO @TradeNID
  END 
  CLOSE FETCH_CG_OutofStock
  DEALLOCATE FETCH_CG_OutofStock  
	
	
	--DECLARE @TradeNID VARCHAR(50)
  	--SET @TradeNID = (SELECT TOP 1 TradeNID FROM INSERTED)
  	--IF (NOT EXISTS(SELECT 1 FROM CG_OutofStock_Total WHERE TradeNID = @TradeNID)	) and (ISNULL(@TradeNID,'') <> '')	--不存在时，自动增加
  	--BEGIN
  		--INSERT INTO CG_OutofStock_Total(TradeNID)  VALUES(@TradeNID)
  	--END  	
	--更新
  	--UPDATE CG_OutofStock_Total
  	--SET StockMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,0)
	                                 --,StoreMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,1)
	                                 --,SaleMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,2)
	                                 --,ServiceMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,3)
	                                 --,PrintMemoTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,4)
	                                 --,ServiceMethodTotal = dbo.Ex_Get_OutOfStockMemoLogs(@TradeNID,5)
  	--WHERE TradeNID=@TradeNID and  ISNULL(@TradeNID,'') <> ''

end
